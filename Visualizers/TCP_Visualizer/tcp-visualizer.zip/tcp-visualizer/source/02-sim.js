(function () {
'use strict';
var APP_ID = 'tcp-visualizer';

/* =====================================================================
   TCP MODEL. Pure code: nothing here touches the page, so the tests can
   run it on its own. Sequence numbers are kept relative to each side's
   initial sequence number (the SYN is 0, the first data byte is 1), and
   turned into raw 32-bit numbers only for display.
   ===================================================================== */
var MOD = 4294967296;
function m32(x) { x = x % MOD; return x < 0 ? x + MOD : x; }

var ST = { CLOSED: 'CLOSED', LISTEN: 'LISTEN', SYN_SENT: 'SYN_SENT', SYN_RCVD: 'SYN_RCVD', ESTAB: 'ESTABLISHED', FW1: 'FIN_WAIT_1', FW2: 'FIN_WAIT_2',
  CW: 'CLOSE_WAIT', CLOSING: 'CLOSING', LAST_ACK: 'LAST_ACK', TW: 'TIME_WAIT' };
/* the same states as Linux ss and Windows netstat print them */
var SPELL = {   /* the same states as Linux ss and Windows netstat print them */
  linux: { CLOSED: 'not listed', LISTEN: 'LISTEN', SYN_SENT: 'SYN-SENT', SYN_RCVD: 'SYN-RECV', ESTABLISHED: 'ESTAB', FIN_WAIT_1: 'FIN-WAIT-1', FIN_WAIT_2: 'FIN-WAIT-2',
    CLOSE_WAIT: 'CLOSE-WAIT', CLOSING: 'CLOSING', LAST_ACK: 'LAST-ACK', TIME_WAIT: 'TIME-WAIT' },
  windows: { CLOSED: 'not listed', LISTEN: 'LISTENING', SYN_SENT: 'SYN_SENT', SYN_RCVD: 'SYN_RECEIVED', ESTABLISHED: 'ESTABLISHED', FIN_WAIT_1: 'FIN_WAIT_1', FIN_WAIT_2: 'FIN_WAIT_2',
    CLOSE_WAIT: 'CLOSE_WAIT', CLOSING: 'CLOSING', LAST_ACK: 'LAST_ACK', TIME_WAIT: 'TIME_WAIT' },
  rfc: { CLOSED: 'CLOSED', LISTEN: 'LISTEN', SYN_SENT: 'SYN-SENT', SYN_RCVD: 'SYN-RECEIVED', ESTABLISHED: 'ESTABLISHED', FIN_WAIT_1: 'FIN-WAIT-1', FIN_WAIT_2: 'FIN-WAIT-2',
    CLOSE_WAIT: 'CLOSE-WAIT', CLOSING: 'CLOSING', LAST_ACK: 'LAST-ACK', TIME_WAIT: 'TIME-WAIT' }
};

function simDefaults(c) {
  var d = {
    isnA: 1000, isnB: 5000, portA: 48212, portB: 5000,
    mssA: 1460, mssB: 1460,          // MSS each side announces in its SYN
    ts: false, sack: true, ws: -1,   // options: Timestamps, SACK, Window Scale shift (-1 = off)
    rbufA: 4000, rbufB: 4000,        // receive buffer sizes in bytes
    delay: 50, rate: 160,            // one-way delay (ms) and link rate (kbit/s, so a 140-byte frame takes 7 ms)
    dack: false, dackMs: 40,         // delayed ACKs and their timer
    nagle: false,
    rtoMin: 1000, rtoInit: 1000, synRetries: 6, twMs: 60000,
    listen: true, simOpen: false, openA: 'active', sendFromListen: false,   // openA: active | passive | none
    writes: [],                      // { side, at, bytes } or { side, onRead: n, bytes }
    readA: { kind: 'now' }, readB: { kind: 'now' },   // now | pause (until) | never
    closeA: { kind: 'afterWrites' }, closeB: { kind: 'onFin', delay: 0 },   // afterWrites | at | onFin | never
    lose: [], maxT: 400000
  };
  if (c) for (var k in c) if (c.hasOwnProperty(k)) d[k] = c[k];
  return d;
}

function simulate(cfgIn) {
  var cfg = simDefaults(cfgIn);
  var E = { A: mkEnd('A'), B: mkEnd('B') };
  var Q = [], qn = 0, now = 0, segs = [], snaps = [], log = [], rtts = [], linkFree = { A: 0, B: 0 }, errors = [];
  var lose = {}; (cfg.lose || []).forEach(function (n) { lose[n] = true; });

  function mkEnd(side) {
    return { side: side, peer: side === 'A' ? 'B' : 'A', state: ST.CLOSED, iss: m32(side === 'A' ? cfg.isnA : cfg.isnB), port: side === 'A' ? cfg.portA : cfg.portB,
      mss: side === 'A' ? cfg.mssA : cfg.mssB, rbuf: side === 'A' ? cfg.rbufA : cfg.rbufB, read: side === 'A' ? cfg.readA : cfg.readB, close: side === 'A' ? cfg.closeA : cfg.closeB,
      sndUna: 0, sndNxt: 0, sndMax: 0, written: 0, sndWnd: 0, maxSndWnd: 0, finQueued: false, finSent: false,
      rcvNxt: 0, readTotal: 0, ooo: [], finAt: -1, finRcvd: false, eof: false, lastAdvWin: -1, ackOwed: false,
      peerPay: 536, tsOK: false, sackOK: false, wsOK: false, peerShift: 0, myShift: 0, peerOpts: null,
      rto: cfg.rtoInit, srtt: null, rttvar: null, rtoAt: null, rtoTok: 0, backoff: 0, timing: null,
      dackAt: null, dackTok: 0, dackCount: 0, persistAt: null, persistTok: 0, persistIv: 0, twTok: 0,
      advEdge: null, dupAcks: 0, inRec: false, recType: '', recover: 0, sacked: [], retxDone: {}, synTries: 0, writesLeft: 0, err: '' };
  }
  function push(t, k, side, d) { Q.push({ t: t, k: k, s: side, d: d, n: qn++ }); }
  function pop() {
    var bi = 0; for (var i = 1; i < Q.length; i++) if (Q[i].t < Q[bi].t || (Q[i].t === Q[bi].t && Q[i].n < Q[bi].n)) bi = i;
    return Q.splice(bi, 1)[0];
  }
  function note(side, text) { log.push({ t: now, side: side, text: text }); }
  function setState(X, s) { if (X.state !== s) { X.state = s; X.stateLog.push({ t: now, s: s }); } }
  E.A.stateLog = [{ t: 0, s: ST.CLOSED }]; E.B.stateLog = [{ t: 0, s: ST.CLOSED }];

  function dataEnd(X) { return 1 + X.written; }                 // relative sequence number just after the last data byte
  function delivered(X) { return Math.max(0, X.rcvNxt - 1 - (X.finRcvd ? 1 : 0)); }
  function unread(X) { return delivered(X) - X.readTotal; }
  function free(X) { return Math.max(0, X.rbuf - unread(X)); }
  function winField(X, isSyn) {   // never shrink the window already offered (RFC 9293 3.8.6); round up to the scale step if needed, as Linux does
    var f = free(X), cur = X.advEdge === null ? 0 : Math.max(0, X.advEdge - X.rcvNxt);
    if (isSyn || !X.wsOK) return Math.min(65535, Math.max(f, cur));
    var g = Math.pow(2, X.myShift), field = Math.min(65535, Math.floor(f / g));
    if (field * g < cur) field = Math.min(65535, Math.ceil(cur / g));
    return field;
  }
  function synOptLen(o) { return 4 + (o.ts ? 12 : (o.sackPerm ? 4 : 0)) + (o.ws !== null ? 4 : 0); }
  function sackBlocks(X) {
    if (!X.sackOK || !X.ooo.length) return [];
    return X.ooo.slice().sort(function (a, b) { return b.upd - a.upd; }).slice(0, X.tsOK ? 3 : 4).map(function (b) { return [b.s, b.e]; });
  }

  /* put one segment on the wire */
  function emit(X, sg) {
    var isSyn = !!sg.f.S;
    sg.from = X.side; sg.to = X.peer;
    if (sg.f.A && sg.ack === undefined) sg.ack = X.rcvNxt;
    if (sg.win === undefined) {
      sg.win = sg.f.R && !sg.f.A && X.state === ST.CLOSED ? 0 : winField(X, isSyn);
      if (sg.closedRst) sg.win = 0;
    }
    sg.winBytes = isSyn || !X.wsOK ? sg.win : sg.win * Math.pow(2, X.myShift);
    sg.scaled = !isSyn && X.wsOK;
    if (!sg.sack) sg.sack = sg.f.A && !isSyn && !sg.f.R ? sackBlocks(X) : [];
    if (isSyn) sg.hdr = 20 + synOptLen(sg.opts);
    else if (sg.closedRst) sg.hdr = 20;
    else sg.hdr = 20 + (X.tsOK ? 12 : 0) + (sg.sack.length ? 4 + 8 * sg.sack.length : 0);
    sg.frame = 14 + 20 + sg.hdr + sg.len;
    var tx = sg.frame * 8 / cfg.rate;
    var start = Math.max(now, linkFree[X.side]);
    linkFree[X.side] = start + tx;
    sg.tSend = r3(start); sg.tArr = r3(start + tx + cfg.delay);
    sg.n = segs.length + 1; sg.lost = !!lose[sg.n]; sg.tEmit = now;
    sg.iss = X.iss; sg.peerIss = E[X.peer].iss;
    segs.push(sg);
    if (!sg.lost) push(sg.tArr, 'arrive', X.peer, sg);
    if (sg.f.A) { X.ackOwed = false; X.dackAt = null; X.dackTok++; X.dackCount = 0; X.lastAdvWin = sg.winBytes; }
    if ((sg.f.A || sg.f.S) && !sg.f.R) X.advEdge = (sg.f.S ? 1 : X.rcvNxt) + sg.winBytes;
    return sg;
  }
  function r3(v) { return Math.round(v * 1000) / 1000; }

  function armRto(X) {
    var v = Math.min(X.rto * Math.pow(2, X.backoff), 120000);
    X.rtoTok++; X.rtoAt = r3(now + v); push(X.rtoAt, 'rto', X.side, X.rtoTok);
  }
  function stopRto(X) { X.rtoTok++; X.rtoAt = null; }
  function armPersist(X) {
    if (!X.persistIv) X.persistIv = X.rto;
    X.persistTok++; X.persistAt = r3(now + X.persistIv); push(X.persistAt, 'persist', X.side, X.persistTok);
  }
  function stopPersist(X) { X.persistTok++; X.persistAt = null; X.persistIv = 0; }

  function sendSyn(X, retx) {
    var o = { mss: X.mss, sackPerm: cfg.sack, ts: cfg.ts, ws: cfg.ws >= 0 ? cfg.ws : null };
    var sg = emit(X, { kind: 'syn', f: { S: 1 }, seq: 0, len: 0, opts: o, retx: retx || null });
    if (!retx && !X.timing) X.timing = { seq: 1, t: sg.tSend };
    if (retx) X.timing = null;
    X.sndNxt = 1; X.sndMax = 1;
    return sg;
  }
  function sendSynAck(X, retx) {
    var p = X.peerOpts;
    var o = { mss: X.mss, sackPerm: cfg.sack && p.sackPerm, ts: cfg.ts && p.ts, ws: cfg.ws >= 0 && p.ws !== null ? cfg.ws : null };
    var sg = emit(X, { kind: 'syn', f: { S: 1, A: 1 }, seq: 0, len: 0, opts: o, retx: retx || null });
    if (!retx && !X.timing) X.timing = { seq: 1, t: sg.tSend };
    if (retx) X.timing = null;
    X.sndNxt = 1; X.sndMax = Math.max(X.sndMax, 1);
    return sg;
  }
  function negotiate(X, mine, theirs) {   // after both SYNs are known
    X.tsOK = !!(mine.ts && theirs.ts); X.sackOK = !!(mine.sackPerm && theirs.sackPerm);
    X.wsOK = mine.ws !== null && theirs.ws !== null; X.myShift = X.wsOK ? mine.ws : 0; X.peerShift = X.wsOK ? theirs.ws : 0;
    X.peerPay = theirs.mss - (X.tsOK ? 12 : 0);
  }
  function sendAck(X, kind) { return emit(X, { kind: kind || 'ack', f: { A: 1 }, seq: X.sndNxt, len: 0 }); }

  function rttSample(X, R) {
    if (X.srtt === null) { X.srtt = R; X.rttvar = R / 2; }
    else { X.rttvar = 0.75 * X.rttvar + 0.25 * Math.abs(X.srtt - R); X.srtt = 0.875 * X.srtt + 0.125 * R; }
    X.rto = Math.max(cfg.rtoMin, X.srtt + 4 * X.rttvar);
    rtts.push({ t: now, side: X.side, R: r3(R), srtt: X.srtt, rttvar: X.rttvar, rto: X.rto });
  }

  /* send whatever the window allows */
  function trySend(X) {
    if (!(X.state === ST.ESTAB || X.state === ST.CW)) return;
    for (var guard = 0; guard < 2000; guard++) {
      var end = dataEnd(X), pending = end - X.sndNxt, usable = X.sndUna + X.sndWnd - X.sndNxt;
      if (pending > 0) {
        if (usable <= 0) break;
        var size = Math.min(X.peerPay, pending, usable);
        if (size < X.peerPay && size < pending && usable < X.maxSndWnd / 2) break;         // sender silly window avoidance
        if (cfg.nagle && size < X.peerPay && X.sndMax > X.sndUna) break;                     // Nagle's algorithm
        var fin = X.finQueued && !X.finSent && X.sndNxt + size === end;
        var f = { A: 1 }; if (X.sndNxt + size === end) f.P = 1; if (fin) f.F = 1;
        var sg = emit(X, { kind: 'data', f: f, seq: X.sndNxt, len: size });
        X.sndNxt += size + (fin ? 1 : 0); X.sndMax = Math.max(X.sndMax, X.sndNxt);
        if (!X.timing) X.timing = { seq: X.sndNxt, t: sg.tSend };
        if (fin) finSentNow(X);
        if (X.rtoAt === null) armRto(X);
        continue;
      }
      if (X.finQueued && !X.finSent && X.sndNxt === end) {
        var sf = emit(X, { kind: 'fin', f: { F: 1, A: 1 }, seq: X.sndNxt, len: 0 });
        X.sndNxt += 1; X.sndMax = Math.max(X.sndMax, X.sndNxt);
        if (!X.timing) X.timing = { seq: X.sndNxt, t: sf.tSend };
        finSentNow(X);
        if (X.rtoAt === null) armRto(X);
      }
      break;
    }
    var pend = dataEnd(X) - X.sndNxt;
    if (pend > 0 && X.sndWnd === 0 && X.sndMax === X.sndUna && X.persistAt === null) armPersist(X);
  }
  function finSentNow(X) {
    X.finSent = true;
    if (X.state === ST.ESTAB) setState(X, ST.FW1); else if (X.state === ST.CW) setState(X, ST.LAST_ACK);
  }

  /* resend the segment that starts at sequence number s */
  function retransmit(X, s, why) {
    var end = dataEnd(X), sg;
    if (s >= end) sg = emit(X, { kind: 'fin', f: { F: 1, A: 1 }, seq: end, len: 0, retx: why });
    else {
      var size = Math.min(X.peerPay, Math.min(end, X.sndMax) - s), f = { A: 1 };
      if (size <= 0) size = Math.min(X.peerPay, end - s);
      if (s + size === end) { f.P = 1; if (X.finSent) f.F = 1; }
      sg = emit(X, { kind: 'data', f: f, seq: s, len: size, retx: why });
    }
    X.retxDone[s] = true; X.timing = null;   // Karn's rule: no sample from anything sent twice
    return sg;
  }
  function isSacked(X, s) { for (var i = 0; i < X.sacked.length; i++) if (s >= X.sacked[i][0] && s < X.sacked[i][1]) return true; return false; }
  function nextHole(X) {   // first byte at or above SND.UNA that is not SACKed and not yet resent in this recovery
    var hi = 0; X.sacked.forEach(function (b) { hi = Math.max(hi, b[1]); });
    for (var s = X.sndUna; s < hi; ) {
      if (isSacked(X, s)) { var nx = s; X.sacked.forEach(function (b) { if (s >= b[0] && s < b[1]) nx = b[1]; }); s = nx; continue; }
      if (!X.retxDone[s]) return s;
      s += Math.min(X.peerPay, dataEnd(X) - s) || 1;
    }
    return -1;
  }
  function addSacked(X, blocks) {
    blocks.forEach(function (b) {
      var s = b[0], e = b[1], out = [];
      X.sacked.forEach(function (c) { if (c[1] < s || c[0] > e) out.push(c); else { s = Math.min(s, c[0]); e = Math.max(e, c[1]); } });
      out.push([s, e]); out.sort(function (a, b2) { return a[0] - b2[0]; }); X.sacked = out;
    });
  }

  /* the application reads what has arrived in order */
  function appRead(X) {
    var u = unread(X); if (u <= 0) return;
    var before = X.lastAdvWin;
    X.readTotal += u;
    var nw = free(X);
    if (X.state !== ST.CLOSED && before >= 0 && (before === 0 ? nw >= Math.min(X.rbuf / 2, X.mss) : (nw >= 2 * before && nw - before >= X.mss))) {
      sendAck(X, 'wupd'); note(X.side, 'The application read ' + u + ' bytes, so ' + X.side + ' sends a window update (window ' + nw + ').');
    }
  }
  function afterDeliver(X) {
    if (X.read.kind === 'now') appRead(X);
    // writes that wait for received bytes
    cfg.writes.forEach(function (w) {
      if (w.side === X.side && w.onRead !== undefined && !w.done && X.readTotal >= w.onRead) { w.done = true; doWrite(X, w.bytes); }
    });
    if (X.finRcvd && unread(X) === 0 && !X.eof) {
      X.eof = true;
      if (X.close.kind === 'onFin') push(r3(now + (X.close.delay || 0)), 'close', X.side);
    }
  }
  function doWrite(X, bytes) {
    if (X.state === ST.LISTEN && cfg.sendFromListen) {
      setState(X, ST.SYN_SENT); sendSyn(X); armRto(X);
      note(X.side, X.side + '\'s listening program sends data first, so ' + X.side + ' turns active and sends a SYN.');
    }
    if (!(X.state === ST.ESTAB || X.state === ST.CW || X.state === ST.SYN_SENT || X.state === ST.SYN_RCVD)) return;
    if (X.finQueued) return;
    X.written += bytes; X.writesLeft--; trySend(X);
    if (X.writesLeft === 0 && X.close.kind === 'afterWrites') push(now, 'close', X.side);
  }
  function doClose(X) {
    if (X.state === ST.ESTAB || X.state === ST.CW) {
      if (unread(X) > 0) {   // closing with unread data aborts the connection
        emit(X, { kind: 'rst', f: { R: 1, A: 1 }, seq: X.sndNxt, len: 0, win: winField(X, false) });
        note(X.side, X.side + ' closes with ' + unread(X) + ' unread bytes, so it sends RST (reset) instead of FIN.');
        setState(X, ST.CLOSED); stopRto(X); stopPersist(X); X.err = 'reset sent';
        return;
      }
      X.finQueued = true; trySend(X);
    } else if (X.close.now && X.state === ST.SYN_SENT) {   // the program gives up before an answer: forget the connection, send nothing
      setState(X, ST.CLOSED); stopRto(X); X.err = 'closed before it connected';
      note(X.side, X.side + '\'s program closes before any answer, so ' + X.side + ' forgets the connection. No segment is sent.');
    } else if (X.close.now && X.state === ST.SYN_RCVD && X.written === 0) {   // close during the handshake: send FIN at once
      X.finQueued = true;
      var sf = emit(X, { kind: 'fin', f: { F: 1, A: 1 }, seq: X.sndNxt, len: 0 });
      X.sndNxt += 1; X.sndMax = Math.max(X.sndMax, X.sndNxt); X.finSent = true; setState(X, ST.FW1); if (X.rtoAt === null) armRto(X);
      note(X.side, X.side + '\'s program closes during the handshake, so ' + X.side + ' sends FIN at once (Seq=' + sf.seq + ').');
    } else if (X.state === ST.SYN_SENT || X.state === ST.SYN_RCVD) { X.finQueued = true; }   // FIN goes out after the handshake and the data
    else if (X.state === ST.LISTEN) { setState(X, ST.CLOSED); stopRto(X); }
  }
  function enterTW(X) {
    setState(X, ST.TW); stopRto(X); X.twTok++; push(r3(now + cfg.twMs), 'tw', X.side, X.twTok);
  }

  /* a segment arrives at X */
  function arrive(X, sg) {
    var n0 = X.stateLog.length;
    arrive1(X, sg);
    var L = X.stateLog;   // ACK of our FIN and the other FIN in the same segment: one arc, FIN_WAIT_1 -> TIME_WAIT
    if (L.length - n0 === 2 && n0 > 0 && L[n0 - 1].s === ST.FW1 && L[n0].s === ST.FW2 && L[n0 + 1].s === ST.TW) L.splice(n0, 1);
  }
  function arrive1(X, sg) {
    var Y = E[X.peer];
    if (X.state === ST.CLOSED) {   // nobody here: answer with RST
      if (sg.f.R) return;
      if (sg.f.A) emit(X, { kind: 'rst', f: { R: 1 }, seq: sg.ack, len: 0, closedRst: true, ack: 0 });
      else { if (X.iss === m32(cfg.isnB) && X.side === 'B') X.iss = MOD - 1; emit(X, { kind: 'rst', f: { R: 1, A: 1 }, seq: 1, len: 0, closedRst: true, ack: sg.seq + sg.len + (sg.f.S ? 1 : 0) + (sg.f.F ? 1 : 0) }); }
      note(X.side, 'No program is listening on port ' + X.port + ', so ' + X.side + ' answers with RST (reset).');
      return;
    }
    if (sg.f.R) {
      var was = X.state;
      setState(X, ST.CLOSED); stopRto(X); stopPersist(X);
      X.err = was === ST.SYN_SENT ? 'connection refused' : 'connection reset';
      note(X.side, X.side + ' gets RST: ' + X.err + '.');
      return;
    }
    if (X.state === ST.LISTEN) {
      if (!sg.f.S || sg.f.A) return;
      X.peerOpts = sg.opts; X.rcvNxt = 1; X.sndWnd = sg.win; X.maxSndWnd = sg.win;
      setState(X, ST.SYN_RCVD); negotiate(X, { mss: X.mss, sackPerm: cfg.sack, ts: cfg.ts, ws: cfg.ws >= 0 ? cfg.ws : null }, sg.opts);
      sendSynAck(X); armRto(X); return;
    }
    if (X.state === ST.SYN_SENT) {
      if (sg.f.S && sg.f.A) {
        if (sg.ack !== 1) return;
        X.peerOpts = sg.opts; negotiate(X, { mss: X.mss, sackPerm: cfg.sack, ts: cfg.ts, ws: cfg.ws >= 0 ? cfg.ws : null }, sg.opts);
        X.rcvNxt = 1; X.sndUna = 1; X.sndWnd = sg.win; X.maxSndWnd = sg.win; X.backoff = 0;
        if (X.timing) { rttSample(X, now - X.timing.t); X.timing = null; }
        stopRto(X); setState(X, ST.ESTAB); sendAck(X); trySend(X); return;
      }
      if (sg.f.S) {   // simultaneous open
        X.peerOpts = sg.opts; X.rcvNxt = 1; X.sndWnd = sg.win; X.maxSndWnd = sg.win;
        negotiate(X, { mss: X.mss, sackPerm: cfg.sack, ts: cfg.ts, ws: cfg.ws >= 0 ? cfg.ws : null }, sg.opts);
        setState(X, ST.SYN_RCVD); sendSynAck(X, null); return;
      }
      return;
    }
    if (X.state === ST.FW1 && X.sndUna < 1 && sg.f.S && sg.f.A && sg.ack >= 1) {   // closed during the handshake: this ACKs the SYN only
      X.sndUna = 1; X.sndWnd = sg.win; X.maxSndWnd = Math.max(X.maxSndWnd, sg.win); X.backoff = 0; sendAck(X); return;
    }
    if (X.state === ST.SYN_RCVD) {
      if (sg.f.S && !sg.f.A) { X.backoff++; sendSynAck(X, 'dup'); armRto(X); note(X.side, X.side + ' gets the SYN again and resends its SYN, ACK.'); return; }
      if (sg.f.A && sg.ack >= 1) {
        X.sndUna = 1; X.backoff = 0;
        if (X.timing) { rttSample(X, now - X.timing.t); X.timing = null; }
        stopRto(X); setState(X, ST.ESTAB);
        if (sg.f.S) { sendAck(X); }
        X.sndWnd = sg.f.S ? sg.win : sg.win * Math.pow(2, X.peerShift); X.maxSndWnd = Math.max(X.maxSndWnd, X.sndWnd);
        if (sg.f.S) return;
        trySend(X);
        if (!sg.len && !sg.f.F) return;
      } else return;
    }
    if (X.state === ST.TW) { if (sg.f.F) { sendAck(X); X.twTok++; push(r3(now + cfg.twMs), 'tw', X.side, X.twTok); note(X.side, X.side + ' gets the FIN again in TIME_WAIT and resends the last ACK.'); } return; }
    if (sg.f.S) { if (sg.f.A) sendAck(X); return; }   // an old SYN, ACK: just acknowledge

    /* 1. the acknowledgment field */
    if (sg.f.A) {
      var ack = sg.ack, wnd = sg.win * Math.pow(2, X.peerShift);
      if (sg.sack && sg.sack.length) addSacked(X, sg.sack);
      if (ack > X.sndUna && ack <= X.sndMax) {
        X.sndUna = ack; X.backoff = 0; X.dupAcks = 0;
        X.sacked = X.sacked.filter(function (b) { return b[1] > ack; });
        if (X.timing && ack >= X.timing.seq) { rttSample(X, now - X.timing.t); X.timing = null; }
        if (X.sndUna >= X.sndMax) stopRto(X); else armRto(X);
        if (X.inRec) {
          if (ack >= X.recover) { X.inRec = false; X.retxDone = {}; }
          else {   // partial ACK: the next hole is lost too
            var h = X.sackOK && X.sacked.length ? nextHole(X) : X.sndUna;
            if (h < 0) h = X.sndUna;
            if (!X.retxDone[h] || h === X.sndUna) { retransmit(X, h, 'partial'); note(X.side, 'A partial ACK (Ack=' + ack + ') shows the next hole: ' + X.side + ' resends Seq=' + h + '.'); }
          }
        }
        if (X.finSent && ack === dataEnd(X) + 1) {
          if (X.state === ST.FW1) setState(X, ST.FW2);
          else if (X.state === ST.CLOSING) enterTW(X);
          else if (X.state === ST.LAST_ACK) { setState(X, ST.CLOSED); stopRto(X); }
        }
        X.sndWnd = wnd; X.maxSndWnd = Math.max(X.maxSndWnd, wnd);
      } else if (ack === X.sndUna) {
        if (!sg.len && !sg.f.F && X.sndMax > X.sndUna && wnd === X.sndWnd && wnd > 0) {
          X.dupAcks++;
          if (X.dupAcks === 3 && !X.inRec) {
            X.inRec = true; X.recType = 'fast'; X.recover = X.sndMax; X.retxDone = {};
            retransmit(X, X.sndUna, 'fast'); note(X.side, 'Third duplicate ACK for byte ' + ack + ': ' + X.side + ' resends Seq=' + ack + ' at once (fast retransmit).');
          } else if (X.inRec && X.sackOK) {
            var hh = nextHole(X);
            if (hh >= 0 && hh !== X.sndUna) { retransmit(X, hh, 'fast'); note(X.side, 'The SACK blocks show another hole: ' + X.side + ' resends Seq=' + hh + '.'); }
          }
        }
        X.sndWnd = wnd; X.maxSndWnd = Math.max(X.maxSndWnd, wnd);
      }
      if (X.sndWnd > 0 && X.persistAt !== null) stopPersist(X);
      if (X.state === ST.CLOSED) return;
    }

    /* 2. data and FIN */
    var s = sg.seq, e = s + sg.len, immediate = false;
    if (!sg.len && !sg.f.F) {
      if (s < X.rcvNxt) { sendAck(X); }    // a zero-window probe below RCV.NXT: answer at once with the window
      trySend(X); return;
    }
    var right = Math.max(X.rcvNxt + free(X), X.advEdge === null ? 0 : X.advEdge);
    if (e <= X.rcvNxt && !(sg.f.F && !X.finRcvd && e === X.rcvNxt)) { sendAck(X); trySend(X); return; }   // old duplicate
    if (s > X.rcvNxt) {   // out of order: hold it, ACK at once
      var b = { s: s, e: Math.min(e, right), upd: now };
      var merged = [];
      X.ooo.forEach(function (o) { if (o.e < b.s || o.s > b.e) merged.push(o); else { b.s = Math.min(b.s, o.s); b.e = Math.max(b.e, o.e); } });
      merged.push(b); merged.sort(function (p, q) { return p.s - q.s; }); X.ooo = merged;
      if (sg.f.F) X.finAt = e;
      sendAck(X); trySend(X); return;
    }
    var hadGap = X.ooo.length > 0;
    var accept = Math.min(e, right) - X.rcvNxt;
    if (accept < 0) accept = 0;
    X.rcvNxt += accept;
    while (X.ooo.length && X.ooo[0].s <= X.rcvNxt) { X.rcvNxt = Math.max(X.rcvNxt, X.ooo[0].e); X.ooo.shift(); }
    if (sg.f.F && e === X.rcvNxt) X.finAt = e;
    if (X.finAt >= 0 && X.finAt === X.rcvNxt && !X.finRcvd) {
      X.rcvNxt += 1; X.finRcvd = true; immediate = immediate || hadGap;
      if (X.state === ST.ESTAB) setState(X, ST.CW);
      else if (X.state === ST.FW1) { if (X.sndUna === dataEnd(X) + 1) enterTW(X); else setState(X, ST.CLOSING); }
      else if (X.state === ST.FW2) enterTW(X);
      note(X.side, X.side + ' gets the FIN: no more data will come from ' + X.peer + '.');
    }
    if (hadGap) immediate = true;
    X.ackOwed = true;
    var counts = sg.len >= X.mss - (X.tsOK ? 12 : 0) ? 1 : 1;
    afterDeliver(X);
    trySend(X);
    if (X.ackOwed && X.state !== ST.CLOSED) {
      if (immediate || !cfg.dack || X.state === ST.TW || X.state === ST.CLOSING) sendAck(X);
      else {
        X.dackCount += counts;
        if (X.dackCount >= 2) sendAck(X);
        else if (X.dackAt === null) { X.dackTok++; X.dackAt = r3(now + cfg.dackMs); push(X.dackAt, 'dack', X.side, X.dackTok); }
      }
    }
  }

  /* ---------- start ---------- */
  E.A.writesLeft = cfg.writes.filter(function (w) { return w.side === 'A'; }).length;
  E.B.writesLeft = cfg.writes.filter(function (w) { return w.side === 'B'; }).length;
  cfg.writes = cfg.writes.map(function (w) { var c = {}; for (var k in w) c[k] = w[k]; return c; });
  push(0, 'open', 'B'); push(0, 'open', 'A');
  cfg.writes.forEach(function (w) { if (w.at !== undefined) push(w.at, 'write', w.side, w.bytes); });
  ['A', 'B'].forEach(function (sd) {
    var X = E[sd];
    if (X.close.kind === 'at') push(X.close.at, 'close', sd);
    if (X.close.kind === 'afterWrites' && X.writesLeft === 0) push(X.close.at || 0, 'close', sd);
    if (X.read.kind === 'pause') push(X.read.until, 'readnow', sd);
  });
  snaps.push({ t: 0, A: snap(E.A), B: snap(E.B) });

  var steps = 0;
  while (Q.length && steps++ < 20000) {
    var ev = pop(); if (ev.t > cfg.maxT) break;
    now = ev.t; var X = E[ev.s];
    switch (ev.k) {
      case 'open':
        var how = ev.s === 'A' ? cfg.openA : 'passive';
        if (how === 'none') break;
        if ((ev.s === 'A' && how !== 'passive') || cfg.simOpen) { setState(X, ST.SYN_SENT); sendSyn(X); armRto(X); }
        else if (ev.s === 'A' || cfg.listen) setState(X, ST.LISTEN);
        break;
      case 'write': doWrite(X, ev.d); break;
      case 'close': doClose(X); break;
      case 'readnow': X.read = { kind: 'now' }; appRead(X); afterDeliver(X); trySend(X); break;
      case 'arrive': arrive(X, ev.d); break;
      case 'dack': if (ev.d === X.dackTok && X.ackOwed && X.state !== ST.CLOSED) sendAck(X); break;
      case 'tw': if (ev.d === X.twTok && X.state === ST.TW) { setState(X, ST.CLOSED); note(X.side, 'TIME_WAIT ends: ' + X.side + ' forgets the connection.'); } break;
      case 'persist':
        if (ev.d !== X.persistTok || X.state === ST.CLOSED) break;
        if (X.sndWnd === 0 && dataEnd(X) > X.sndNxt) {
          emit(X, { kind: 'probe', f: { A: 1 }, seq: X.sndUna - 1, len: 0 });
          note(X.side, 'The window is still 0, so ' + X.side + ' sends a window probe.');
          X.persistIv = Math.min(X.persistIv * 2, 60000); X.persistTok++; X.persistAt = r3(now + X.persistIv); push(X.persistAt, 'persist', X.side, X.persistTok);
        } else stopPersist(X);
        break;
      case 'rto':
        if (ev.d !== X.rtoTok) break;
        X.rtoAt = null;
        if (X.state === ST.SYN_SENT) {
          X.synTries++;
          if (X.synTries > cfg.synRetries) { setState(X, ST.CLOSED); X.err = 'connection timed out'; note(X.side, X.side + ' gives up: connection timed out.'); break; }
          X.backoff++; sendSyn(X, 'rto'); note(X.side, 'No answer to the SYN: ' + X.side + ' resends it and doubles its timer.'); armRto(X);
        } else if (X.state === ST.SYN_RCVD) {
          X.backoff++; sendSynAck(X, 'rto'); armRto(X);
        } else if (X.sndMax > X.sndUna && X.state !== ST.CLOSED && X.state !== ST.TW) {
          X.backoff++; X.dupAcks = 0; X.inRec = true; X.recType = 'rto'; X.recover = X.sndMax; X.retxDone = {};
          var rs = X.sndUna; retransmit(X, rs, 'rto');
          note(X.side, 'Timeout: ' + X.side + ' resends Seq=' + rs + ' and doubles its timer.');
          armRto(X);
        }
        break;
    }
    snaps.push({ t: now, A: snap(E.A), B: snap(E.B) });
  }
  function snap(X) {
    return { state: X.state, sndUna: X.sndUna, sndNxt: X.sndNxt, sndMax: X.sndMax, written: X.written, dataEnd: dataEnd(X), sndWnd: X.sndWnd, finSent: X.finSent,
      rcvNxt: X.rcvNxt, delivered: delivered(X), readTotal: X.readTotal, unread: unread(X), free: free(X), rbuf: X.rbuf, ooo: X.ooo.map(function (o) { return [o.s, o.e]; }),
      rto: X.rto, srtt: X.srtt, rttvar: X.rttvar, backoff: X.backoff, dupAcks: X.dupAcks, rtoAt: X.rtoAt, persistAt: X.persistAt, dackAt: X.dackAt, err: X.err, finRcvd: X.finRcvd, peerPay: X.peerPay };
  }
  return { cfg: cfg, segs: segs, snaps: snaps, log: log, rtts: rtts, states: { A: E.A.stateLog, B: E.B.stateLog }, end: { A: snap(E.A), B: snap(E.B) },
    iss: { A: E.A.iss, B: E.B.iss }, ports: { A: cfg.portA, B: cfg.portB } };
}

/* snapshot of both sides at time t (after every event at that time) */
function snapAt(run, t) { var s = run.snaps[0]; for (var i = 0; i < run.snaps.length; i++) { if (run.snaps[i].t <= t + 1e-9) s = run.snaps[i]; else break; } return s; }
function stateAt(run, side, t) { var s = 'CLOSED'; run.states[side].forEach(function (x) { if (x.t <= t + 1e-9) s = x.s; }); return s; }

/* ---------- capture at Host A, labeled the way Wireshark labels it ---------- */
var FLAG_ORDER = [['F', 'FIN'], ['S', 'SYN'], ['R', 'RST'], ['P', 'PSH'], ['A', 'ACK']];
function flagText(f) { return FLAG_ORDER.filter(function (x) { return f[x[0]]; }).map(function (x) { return x[1]; }).join(', '); }
function segSeq(sg, raw) { return raw ? m32(sg.iss + sg.seq) : sg.seq; }
function segAck(sg, raw) { return raw ? m32(sg.peerIss + sg.ack) : sg.ack; }
function capture(run, opt) {
  opt = opt || {};
  var raw = !!opt.raw, list = [];
  run.segs.forEach(function (sg) {
    if (sg.from === 'A') list.push({ t: sg.tSend, sg: sg });
    else if (!sg.lost) list.push({ t: sg.tArr, sg: sg });
  });
  list.sort(function (a, b) { return a.t - b.t || a.sg.n - b.sg.n; });
  /* Wireshark's sequence analysis (packet-tcp.c), with relative numbers. Labels are listed in the order Wireshark prints them. */
  var D = {};
  ['A', 'B'].forEach(function (k) { D[k] = { next: null, nextT: 0, lastAck: 0, lastAckT: -1e9, win: null, winB: null, dupN: 0, lastNonDup: 0, lastAckLen: 0, segs: [], lastL: {} }; });
  var ORDER = ['ZeroWindowProbeAck', 'ZeroWindow', 'ZeroWindowProbe', 'Dup', 'Keep-Alive ACK', 'Keep-Alive', 'Window Full', 'Window Update', 'Previous segment not captured', 'Out-Of-Order', 'Spurious Retransmission', 'Fast Retransmission', 'Retransmission'];
  var mruSyn = null, firstRtt = null;
  list.forEach(function (fr, i) {
    var sg = fr.sg, X = D[sg.from], Y = D[sg.to], no = i + 1, L = {}, seq = sg.seq, len = sg.len, win = sg.win, ack = sg.f.A ? sg.ack : 0;
    var S = !!sg.f.S, Fn = !!sg.f.F, R = !!sg.f.R, ctl = S || Fn || R, done = false;
    if (len === 1 && X.next !== null && seq === X.next && Y.win === 0) { L.ZeroWindowProbe = 1; done = true; }
    if (!done) {
      if (win === 0 && !ctl) L.ZeroWindow = 1;
      if (X.next !== null && seq > X.next && !R) L['Previous segment not captured'] = 1;
      if ((len === 0 || len === 1) && X.next !== null && seq === X.next - 1 && !ctl) L['Keep-Alive'] = 1;
      if (len === 0 && win && win !== X.win && seq === X.next && ack === X.lastAck && !ctl) L['Window Update'] = 1;
      if (len > 0 && Y.winB !== null && seq + len === Y.lastAck + Y.winB && !ctl) L['Window Full'] = 1;
      if (len === 0 && win && win === X.win && seq === X.next && ack === X.lastAck && Y.lastL['Keep-Alive'] && !ctl) { L['Keep-Alive ACK'] = 1; done = true; }
      if (!done && len === 0 && win === 0 && win === X.win && seq === X.next && (ack === X.lastAck || ack === X.lastAck + 1) && Y.lastL.ZeroWindowProbe && !ctl) { L.ZeroWindowProbeAck = 1; done = true; }
      if (!done && len === 0 && win && win === X.win && seq === X.next && ack === X.lastAck && !ctl) { X.dupN++; L.Dup = 'Dup ACK ' + X.lastNonDup + '#' + X.dupN; }
    }
    if (ack !== X.lastAck) { X.lastNonDup = no; X.dupN = 0; }
    if (len > 0 || S || Fn) {
      var notAdv = X.next !== null && seq < X.next;
      if (!L['Keep-Alive']) {
        if (len > 1 && X.next !== null && X.next - 1 === seq) notAdv = false;
        if (len > 0 && Y.lastAck && seq + len <= Y.lastAck) L['Spurious Retransmission'] = 1;
        else if (notAdv && Y.dupN >= 2 && Y.lastAck === seq && fr.t - Y.lastAckT < 20) L['Fast Retransmission'] = 1;
        else {
          var thr = firstRtt ? firstRtt : 3, seen = false;
          X.segs.forEach(function (u) { if (seq >= u.seq && seq + len <= u.next) seen = true; });
          if (notAdv && fr.t - X.nextT < thr && !seen && (X.next !== seq + len + (S || Fn ? 1 : 0) || X.lastAckLen === 0)) L['Out-Of-Order'] = 1;
          else if (notAdv) L.Retransmission = 1;
        }
      }
    }
    var nextseq = seq + len;
    if (len || S || Fn) { if (S || Fn) nextseq += 1; X.segs.push({ seq: seq, next: nextseq }); }
    if (X.next === null || nextseq > X.next + (S || Fn ? 1 : 0)) X.lastAckLen = len;
    if ((X.next === null || nextseq > X.next) && !L.ZeroWindowProbe) { X.next = nextseq; X.nextT = fr.t; }
    X.win = win; X.winB = sg.winBytes; X.lastAck = ack; X.lastAckT = fr.t; X.lastL = L;
    Y.segs = Y.segs.filter(function (u) { return !(ack >= u.next); }).map(function (u) { return ack > u.seq ? { seq: ack, next: u.next } : u; });
    if (S && !sg.f.A) mruSyn = fr.t;
    if (sg.f.A && !S && mruSyn !== null && firstRtt === null) firstRtt = fr.t - mruSyn;
    fr.no = no; fr.labels = ORDER.filter(function (k) { return L[k]; }).map(function (k) { return 'TCP ' + (k === 'Dup' ? L.Dup : k); });
    fr.label = fr.labels.join('] [');
    fr.info = infoText(run, sg, raw);
    fr.src = sg.from; fr.dst = sg.to;
  });
  return list;
}
function infoText(run, sg, raw) {
  var p = run.ports, s = (sg.from === 'A' ? p.A + ' → ' + p.B : p.B + ' → ' + p.A) + ' [' + flagText(sg.f) + '] Seq=' + segSeq(sg, raw);
  if (sg.f.A) s += ' Ack=' + segAck(sg, raw);
  s += ' Win=' + sg.winBytes + ' Len=' + sg.len;
  if (sg.opts) { s += ' MSS=' + sg.opts.mss; if (sg.opts.sackPerm) s += ' SACK_PERM'; if (sg.opts.ts) s += ' TSval TSecr'; if (sg.opts.ws !== null) s += ' WS=' + Math.pow(2, sg.opts.ws); }
  (sg.sack || []).forEach(function (b) { s += ' SLE=' + (raw ? m32(sg.peerIss + b[0]) : b[0]) + ' SRE=' + (raw ? m32(sg.peerIss + b[1]) : b[1]); });
  return s;
}
function labelOf(cap, n) { for (var i = 0; i < cap.length; i++) if (cap[i].sg.n === n) return cap[i].label; return ''; }

/* RFC 6298 estimator on a list of samples (ms); skip[i] true = Karn's rule drops it */
function rtoSeries(samples, skip, rtoMin) {
  var srtt = null, rttvar = null, out = [], rto = 1000;
  samples.forEach(function (R, i) {
    if (skip && skip[i]) { out.push({ R: R, skipped: true, srtt: srtt, rttvar: rttvar, rto: rto }); return; }
    if (srtt === null) { srtt = R; rttvar = R / 2; } else { rttvar = 0.75 * rttvar + 0.25 * Math.abs(srtt - R); srtt = 0.875 * srtt + 0.125 * R; }
    var raw = srtt + 4 * rttvar; rto = Math.max(rtoMin, raw);
    out.push({ R: R, skipped: false, srtt: srtt, rttvar: rttvar, rtoRaw: raw, rto: rto });
  });
  return out;
}
/* header bytes (20-byte fixed part plus options) for the header decoder */
function headerBytes(h) {
  var b = [];
  function u16(v) { b.push((v >> 8) & 255, v & 255); }
  function u32(v) { v = m32(v); b.push(Math.floor(v / 16777216) & 255, (v >> 16) & 255, (v >> 8) & 255, v & 255); }
  u16(h.sport); u16(h.dport); u32(h.seq); u32(h.ack);
  var fl = (h.f.F ? 1 : 0) | (h.f.S ? 2 : 0) | (h.f.R ? 4 : 0) | (h.f.P ? 8 : 0) | (h.f.A ? 16 : 0) | (h.f.U ? 32 : 0);
  b.push(((h.hdr / 4) << 4) & 255, fl); u16(h.win); u16(h.csum || 0); u16(0);
  (h.optBytes || []).forEach(function (x) { b.push(x); });
  return b;
}
function decodeHeader(bytes) {
  if (bytes.length < 20) return { err: 'A TCP header is at least 20 bytes. You gave ' + bytes.length + '.' };
  function u16(i) { return bytes[i] * 256 + bytes[i + 1]; }
  function u32(i) { return ((bytes[i] * 256 + bytes[i + 1]) * 256 + bytes[i + 2]) * 256 + bytes[i + 3]; }
  var off = bytes[12] >> 4, fl = bytes[13], hdr = off * 4;
  var r = { sport: u16(0), dport: u16(2), seq: u32(4), ack: u32(8), off: off, hdr: hdr, flagsByte: fl,
    f: { C: (fl & 128) ? 1 : 0, E: (fl & 64) ? 1 : 0, U: (fl & 32) ? 1 : 0, A: (fl & 16) ? 1 : 0, P: (fl & 8) ? 1 : 0, R: (fl & 4) ? 1 : 0, S: (fl & 2) ? 1 : 0, F: (fl & 1) ? 1 : 0 },
    win: u16(14), csum: u16(16), urg: u16(18), opts: [], err: '' };
  if (off < 5) r.err = 'The header length field is ' + off + ', below the minimum of 5 (20 bytes).';
  else if (bytes.length < hdr) r.err = 'The header length field says ' + hdr + ' bytes, but you gave only ' + bytes.length + '.';
  else {
    for (var i = 20; i < hdr; ) {
      var k = bytes[i];
      if (k === 0) { r.opts.push('End of options'); break; }
      if (k === 1) { r.opts.push('NOP (padding)'); i++; continue; }
      var L = bytes[i + 1]; if (!L || i + L > hdr) { r.opts.push('Option ' + k + ' (bad length)'); break; }
      if (k === 2) r.opts.push('MSS = ' + u16(i + 2));
      else if (k === 3) r.opts.push('Window Scale: shift ' + bytes[i + 2] + ' (multiply by ' + Math.pow(2, bytes[i + 2]) + ')');
      else if (k === 4) r.opts.push('SACK permitted');
      else if (k === 5) { var bl = []; for (var j = i + 2; j + 8 <= i + L; j += 8) bl.push(u32(j) + '–' + u32(j + 4)); r.opts.push('SACK blocks: ' + bl.join(', ')); }
      else if (k === 8) r.opts.push('Timestamps: TSval ' + u32(i + 2) + ', TSecr ' + u32(i + 6));
      else r.opts.push('Option kind ' + k + ', ' + L + ' bytes');
      i += L;
    }
  }
  return r;
}
