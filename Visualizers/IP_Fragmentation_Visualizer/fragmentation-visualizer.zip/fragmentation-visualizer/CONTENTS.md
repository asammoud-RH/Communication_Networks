# Fragmentation Visualizer: files in this zip (version 1.2, November 10, 2026)

- `fragmentation-visualizer.html`: the app. One standalone file; open it in any browser.
- `README.md`: lessons, model, commands, link parameters, test results, and the requirements checklist.
- `source/`: the five parts that build the app. Rebuild with
  `cat source/01-head.html source/02-core.js source/03-learn.js source/04-calc.js source/05-challenge.js > fragmentation-visualizer.html`
  (on Windows: `copy /b source\01-head.html + source\02-core.js + source\03-learn.js + source\04-calc.js + source\05-challenge.js fragmentation-visualizer.html`).

## testing/

These scripts need Python 3 with Playwright, and the logic test also needs Scapy. They launch Chrome from `/usr/bin/google-chrome`; change `executable_path` in each script if Chrome is somewhere else on your computer. Pass the app's path as the first argument (the last three scripts default to `../fragmentation-visualizer.html`).

- `logic_test (fragmentation-visualizer).py`: re-checks every fragmentation result, ping output, and generated Challenge answer key against an independent Python model and Scapy. Add `--kernel` and run it as root on Linux to repeat the real-kernel checks (network namespaces, tcpdump, and real ping).
- `smoke_test.py`: opens every lesson, plays a round at each level, and checks for console errors and sideways scrolling on a phone.
- `interaction_check.py`: answers every Try it task, runs the animations, the Calculator, and the completion-code check, and tests with browser storage blocked.
- `phone_questions_check.py`: shows 240 Challenge questions at 360 pixels wide and checks that none scrolls sideways.
- `speed_check.py`: times the Lesson 6 pings at different animation speeds, including a speed change mid-run.
- `figure_check.py`: saves screenshots of the Lesson 6 and Calculator path figures, to check that no label is clipped or overlapping.
- `kernel-captures/`: tcpdump output (`cap*.txt`) and a packet capture (`frag.pcap`, opens in Wireshark) from the real Linux kernel runs that the app's model was checked against.
- `screenshots/`: the figure checks for version 1.2.

The shared course guides (App Requirements.md, App Template Guide.md, Deployment Guide.md, and app-template.html) are in the project's `claude/Interactive tools/` folder and aren't repeated here.
