"""Smoke test for any course app built from app-template.html.

What it does, in headless Chrome:
  1. Opens the start screen, then every mode from the top bar.
  2. Walks through every lesson with the Next button.
  3. Plays one full Challenge round at each level (answers are guesses; the
     point is that nothing breaks, not the score).
  4. Opens each mode at phone width (390 pixels) and checks that the page
     never scrolls sideways.
  5. Saves screenshots and prints every console error. "ERRORS []" at the end
     means a clean run.

Usage:
  pip install playwright --break-system-packages
  python3 smoke_test.py path/to/app.html [screenshot-folder]

Chrome path: set CHROME=/path/to/chrome if it isn't /usr/bin/google-chrome.
Firefox and Safari: run with BROWSER=firefox or BROWSER=webkit on a machine
where `playwright install firefox webkit` works.
"""
import asyncio, os, sys, pathlib
from playwright.async_api import async_playwright

APP = pathlib.Path(sys.argv[1]).resolve()
OUT = pathlib.Path(sys.argv[2] if len(sys.argv) > 2 else 'shots'); OUT.mkdir(exist_ok=True)
URL = APP.as_uri()


async def launch(p):
    kind = os.environ.get('BROWSER', 'chromium')
    if kind == 'chromium':
        return await p.chromium.launch(executable_path=os.environ.get('CHROME', '/usr/bin/google-chrome'), args=['--no-sandbox'])
    return await getattr(p, kind).launch()


async def main():
    errs = []
    async with async_playwright() as p:
        b = await launch(p)
        pg = await b.new_page(viewport={'width': 1280, 'height': 900})
        pg.on('pageerror', lambda e: errs.append('pageerror: ' + str(e)))
        pg.on('console', lambda m: errs.append('console: ' + m.text) if m.type == 'error' else None)

        await pg.goto(URL); await pg.wait_for_timeout(300)
        await pg.screenshot(path=str(OUT / 'home.png'), full_page=True)

        # Learn: every lesson through the Next button
        await pg.click('[data-go=learn]'); await pg.wait_for_timeout(300)
        n = len(await pg.query_selector_all('#stepper button'))
        print('lessons:', n)
        for i in range(n):
            await pg.screenshot(path=str(OUT / f'lesson{i + 1}.png'), full_page=True)
            if i < n - 1:
                await pg.click('#lnext'); await pg.wait_for_timeout(300)

        # Calculator
        await pg.click('.modes [data-mode=calc]'); await pg.wait_for_timeout(300)
        await pg.screenshot(path=str(OUT / 'calc.png'), full_page=True)

        # Challenge: one round per level
        await pg.click('.modes [data-mode=challenge]'); await pg.wait_for_timeout(200)
        for lvl in ['E', 'M', 'H']:
            await pg.click(f'[data-level={lvl}]'); await pg.click('#ch-start'); await pg.wait_for_timeout(150)
            rounds = 0
            while await pg.is_visible('#ch-play') and rounds < 60:
                if await pg.query_selector('#q_in'):
                    await pg.fill('#q_in', '1'); await pg.click('#q_ok')
                else:
                    await pg.click('#q_body .choice >> nth=0')
                await pg.wait_for_timeout(60)
                if rounds == 0:
                    await pg.screenshot(path=str(OUT / f'question-{lvl}.png'), full_page=True)
                await pg.click('#q_next'); await pg.wait_for_timeout(60); rounds += 1
            text = await pg.inner_text('#ch-end')
            print(f'level {lvl}: {rounds} questions;', text.split('\n')[0], '|', [l for l in text.split('\n') if 'of' in l and '-' in l][:1])
            await pg.screenshot(path=str(OUT / f'end-{lvl}.png'), full_page=True)
            await pg.click('.modes [data-mode=challenge]'); await pg.wait_for_timeout(150)

        # Phone width: no sideways scrolling on any screen
        for mode in ['home', 'learn', 'calc', 'challenge']:
            ph = await b.new_page(viewport={'width': 390, 'height': 844})
            ph.on('pageerror', lambda e: errs.append('phone pageerror: ' + str(e)))
            await ph.goto(URL + '?mode=' + mode); await ph.wait_for_timeout(300)
            sw, iw = await ph.evaluate('[document.documentElement.scrollWidth, innerWidth]')
            print(f'phone {mode}: scrollWidth {sw}, width {iw}', 'OK' if sw <= iw else 'SCROLLS SIDEWAYS')
            await ph.screenshot(path=str(OUT / f'phone-{mode}.png'), full_page=True)
            await ph.close()

        await b.close()
    print('ERRORS', errs)


asyncio.run(main())
