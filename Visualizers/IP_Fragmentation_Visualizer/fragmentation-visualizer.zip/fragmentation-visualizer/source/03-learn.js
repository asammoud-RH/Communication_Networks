
/* ===================================================== LEARN */
var LINKS = [   // [long description, MTU, short name]
  ['Ethernet', 1500, 'Ethernet'], ['PPPoE (Point-to-Point Protocol over Ethernet), used by many DSL (Digital Subscriber Line) providers', 1492, 'PPPoE'], ['A typical VPN (Virtual Private Network) tunnel', 1400, 'VPN tunnel'],
  ['A small point-to-point link', 532, 'Point-to-point link'], ['Ethernet with jumbo frames', 9000, 'Jumbo Ethernet'], ['The smallest MTU that IPv4 allows', 68, 'IPv4 minimum']
];
var lessonState = { i: store.get('lesson', 0), task: null, token: 0,
  l1: { link: 0, total: 1420 }, l2: { data: 1400, mtu: 532, stage: 4 }, l3: { data: 1400, mtu: 532, ident: newIdent(), hi: -1 },
  l4: { data: 1400, mtus: [1500, 532, 1500] }, l5: null, l6: { mtu2: 1400, payload: 1472, mode: 'want', speed: 0.5 } };
var LESSONS = [
  { t: 'What an MTU is', setup: l1 },
  { t: 'Cutting a datagram', setup: l2 },
  { t: 'The header fields', setup: l3 },
  { t: 'Across an internetwork', setup: l4 },
  { t: 'Reassembly and loss', setup: l5 },
  { t: 'Avoid it: DF and path MTU', setup: l6 }
];
function alive(tok) { return tok === lessonState.token; }
function renderStepper() {
  var st = $('#stepper');
  st.innerHTML = LESSONS.map(function (L, i) { return '<button data-l="' + i + '" class="' + (progress.lessons[i] ? 'done' : '') + '"' + (i === lessonState.i ? ' aria-current="step"' : '') + '><span class="num">' + (progress.lessons[i] ? '✓' : i + 1) + '</span>' + L.t + '</button>'; }).join('');
  $$('[data-l]', st).forEach(function (b) { b.onclick = function () { openLesson(+b.getAttribute('data-l')); }; });
  $('#lprog').style.width = (Object.keys(progress.lessons).length / LESSONS.length * 100) + '%';
}
function openLesson(i) {
  lessonState.token++;   // stops any animation from the previous lesson
  if (lessonState.i !== i) lessonState.task = null;
  lessonState.i = Math.max(0, Math.min(LESSONS.length - 1, i)); store.set('lesson', lessonState.i);
  renderStepper(); $('#lfig').innerHTML = ''; LESSONS[lessonState.i].setup();
  $('#ltext').insertAdjacentHTML('beforeend', '<div class="navrow"><button class="btn alt" id="lprev"' + (lessonState.i === 0 ? ' disabled' : '') + '>← Back</button>' +
    (lessonState.i < LESSONS.length - 1 ? '<button class="btn" id="lnext">Next lesson →</button>' : '<button class="btn amber" id="lnext">Take the challenge →</button>') + '</div>');
  $('#lprev').onclick = function () { openLesson(lessonState.i - 1); };
  $('#lnext').onclick = function () { if (lessonState.i < LESSONS.length - 1) openLesson(lessonState.i + 1); else go('challenge'); };
  writeLink();
}
function lessonDone(fb, msg) {
  fb.className = 'feedback ok'; fb.innerHTML = '✓ ' + msg + (progress.lessons[lessonState.i] ? '' : ' <b>+20 points</b>');
  if (!progress.lessons[lessonState.i]) { progress.lessons[lessonState.i] = true; addXP(20); renderStepper(); if (Object.keys(progress.lessons).length === LESSONS.length) earn('learned'); }
}
function wrong(fb, msg) { fb.className = 'feedback bad'; fb.innerHTML = msg; }
function lessonHead(n, title, body) { $('#ltext').innerHTML = '<p class="mono" style="color:var(--muted);margin:0">Lesson ' + n + ' of 6</p><h2>' + title + '</h2>' + body; }
function numIn(id, v, min, max, label) { return '<input type="number" id="' + id + '" min="' + min + '" max="' + max + '" value="' + v + '"' + (label ? ' aria-label="' + esc(label) + '"' : '') + '>'; }
function readNum(id, min, max) { var v = +$(id).value; if ($(id).value === '' || !Number.isInteger(v) || v < min || v > max) { $(id).setAttribute('aria-invalid', 'true'); return null; } $(id).removeAttribute('aria-invalid'); return v; }
function tryBox(html) { return '<div class="tryit"><h3>Try it</h3>' + html + '</div>'; }

/* Lesson 1: what an MTU is */
function l1() {
  var s = lessonState.l1, t = lessonState.task || (lessonState.task = { k: pick([1, 2, 3]) }), tl = LINKS[t.k];
  lessonHead(1, 'What an MTU is',
    '<p>An IP datagram travels inside a link-layer frame. The <b>MTU (Maximum Transmission Unit)</b> is the largest IP datagram that fits in one frame of that link. Every link technology has its own MTU.</p>' +
    '<p>A datagram is a <b>20-byte header</b> plus its <b>data</b>. Its Total Length field counts both, up to 65,535 bytes.</p>' +
    '<p>If the datagram fits, the link carries it as it is. If not, IP must <b>fragment</b> it: cut it into smaller datagrams that each fit. A host normally sends datagrams that fit its own link, so fragmentation usually happens at a <b>router</b> whose next link has a smaller MTU.</p>' +
    '<div class="row"><label>Link <select id="l1link">' + LINKS.map(function (L, i) { return '<option value="' + i + '"' + (i === s.link ? ' selected' : '') + '>' + esc(L[2]) + ' (' + L[1] + ')</option>'; }).join('') + '</select></label></div>' +
    '<div class="row"><label>Datagram size <input type="range" id="l1r" min="68" max="10000" value="' + s.total + '"></label>' + numIn('l1n', s.total, 68, 65535, 'Datagram size in bytes') + '<span>bytes</span></div>' +
    tryBox('<p>Choose <b>' + esc(tl[2]) + '</b> and set the datagram to the <b>largest size that fits</b> without fragmentation.</p><div class="feedback" id="l1fb" aria-live="polite"></div>'));
  $('#lfig').innerHTML = '<div class="card"><p class="figtitle">The datagram and the link\'s frame</p><div class="fig"><svg id="l1svg" role="img" aria-label="A datagram compared with the room in one frame of the link"></svg></div>' +
    '<ul class="legend"><li><i style="background:#0B3D5C"></i>IP header (20 bytes)</li><li><i style="background:#CFE6F0;border:1px solid #00A2D7"></i>data</li><li><i style="background:#FDE8E9;border:1px solid #E5484D"></i>too big for the link</li></ul><div class="soft" id="l1facts"></div></div>' +
    '<div class="card"><p class="figtitle">Common MTUs</p><ul class="list">' + LINKS.map(function (L) { return '<li><b class="mono">' + fmt(L[1]) + '</b>: ' + esc(L[0]) + '</li>'; }).join('') + '</ul><p class="cmdnote">Wi-Fi also carries 1500-byte datagrams, so a home network is a 1500-byte path. Tunnels and VPNs add their own headers, so they leave less room.</p></div>';
  function upd(fromRange) {
    if (fromRange) $('#l1n').value = $('#l1r').value; else { var v = readNum('#l1n', 68, 65535); if (v === null) return; $('#l1r').value = Math.min(10000, v); }
    s.total = +$('#l1n').value; s.link = +$('#l1link').value;
    var L = LINKS[s.link]; drawFrame($('#l1svg'), s.total, L[1], L[2]);
    var n = countFrags(s.total - HDR, L[1]);
    $('#l1facts').innerHTML = s.total <= L[1] ? '<span class="yes">Fits.</span> The link carries the datagram as it is.' : '<span class="no">Too big.</span> IP must cut it into <b>' + n + '</b> fragments (lesson 2), or drop it if Don\'t Fragment is set (lesson 6).';
    var fb = $('#l1fb');
    if (s.link === t.k && s.total === tl[1]) lessonDone(fb, 'Right: on this link the largest datagram is ' + fmt(tl[1]) + ' bytes, the MTU itself: 20 bytes of header and ' + fmt(tl[1] - HDR) + ' bytes of data.');
    else if (s.link === t.k && s.total < tl[1]) { fb.className = 'feedback'; fb.innerHTML = 'It fits. Can it be bigger?'; }
    else if (s.link === t.k) { fb.className = 'feedback'; fb.innerHTML = 'Too big for this link. Look at the red part.'; }
    else { fb.className = 'feedback'; fb.innerHTML = ''; }
  }
  $('#l1r').oninput = function () { upd(true); }; $('#l1n').oninput = function () { upd(false); }; $('#l1link').onchange = function () { upd(false); };
  upd(false);
}

/* Lesson 2: cutting a datagram */
function l2() {
  var s = lessonState.l2, t = lessonState.task || (lessonState.task = { mtu: pick([1000, 576, 620, 1006, 700, 900, 1250, 1300, 810]) });
  lessonHead(2, 'Cutting a datagram',
    '<p>Each fragment is a complete IP datagram with its <b>own 20-byte header</b>. So a fragment can carry at most <b>MTU − 20</b> data bytes.</p>' +
    '<p>One more rule: every fragment except the last must carry a <b>multiple of 8</b> data bytes, because the header counts positions in 8-byte units (lesson 3). Round MTU − 20 down to a multiple of 8:</p>' +
    '<p class="soft mono" style="text-align:center">data per fragment = ⌊(MTU − 20) ÷ 8⌋ × 8</p>' +
    '<p>Fill fragments with that many bytes until what is left fits in one fragment. The last fragment carries all the rest: up to MTU − 20 bytes, and it need not be a multiple of 8. (Linux cuts this way. Usually that is the same as dividing and rounding up; it can save one fragment when MTU − 20 is not a multiple of 8.)</p>' +
    '<div class="row"><label>Data ' + numIn('l2d', s.data, 1, MAX_DATA, 'Data bytes') + ' bytes</label><label>MTU ' + numIn('l2m', s.mtu, MIN_MTU, 65535, 'MTU in bytes') + '</label><button class="btn alt small" id="l2go">▶ Show the steps</button></div>' +
    '<ol class="log" id="l2steps"></ol>' +
    tryBox('<p>The next link has an MTU of <b>' + t.mtu + '</b> bytes and the datagram has 4,000 data bytes. How many data bytes does <b>fragment 1</b> carry?</p><div class="row">' + numIn('l2a', '', 0, 9000, 'Your answer') + '<button class="btn small" id="l2c">Check</button><button class="btn alt small" id="l2h">Hint</button></div><div class="feedback" id="l2fb" aria-live="polite"></div>'));
  $('#lfig').innerHTML = '<div class="card"><p class="figtitle">Where the cuts fall</p><div class="fig"><svg id="l2svg" role="img" aria-label="The data bar with the cut positions and the fragments"></svg></div>' +
    '<ul class="legend"><li><i style="background:#0B3D5C"></i>new 20-byte header</li><li><i style="background:#CFE6F0;border:1px solid #00A2D7"></i>a piece of the data</li><li><i style="background:#E5484D"></i>a cut</li></ul></div>';
  var timer = null;
  function steps() {
    var m = maxData(s.mtu), n = countFrags(s.data, s.mtu), last = s.data - (n - 1) * m;
    var items = fits(s.data, s.mtu) ? ['20 + ' + fmt(s.data) + ' = ' + fmt(s.data + HDR) + ' ≤ ' + fmt(s.mtu) + ': it fits, so there is nothing to cut.'] :
      ['Room for data: ' + fmt(s.mtu) + ' − 20 = ' + fmt(s.mtu - HDR) + ' bytes.', 'Round down to a multiple of 8: ' + fmt(m) + ' bytes per fragment.', 'Cut ' + fmt(m) + '-byte pieces until the rest fits in one fragment (at most ' + fmt(s.mtu - HDR) + ' bytes): ' + n + ' fragments.', 'The last fragment carries the rest: ' + fmt(s.data) + ' − ' + (n - 1) + ' × ' + fmt(m) + ' = ' + fmt(last) + ' bytes.'];
    $('#l2steps').innerHTML = items.slice(0, fits(s.data, s.mtu) ? 1 : Math.max(0, s.stage)).map(function (x) { return '<li>' + x + '</li>'; }).join('');
  }
  function upd() {
    var d = readNum('#l2d', 1, MAX_DATA), m = readNum('#l2m', MIN_MTU, 65535); if (d === null || m === null) return;
    s.data = d; s.mtu = m; drawCut($('#l2svg'), d, m, fits(d, m) ? 4 : s.stage); steps();
  }
  $('#l2d').oninput = function () { s.stage = 4; upd(); }; $('#l2m').oninput = function () { s.stage = 4; upd(); };
  $('#l2go').onclick = function () {
    clearInterval(timer); s.stage = 0; upd(); var tok = lessonState.token;
    timer = setInterval(function () { if (!alive(tok)) { clearInterval(timer); return; } s.stage++; upd(); if (s.stage >= 4) clearInterval(timer); }, reduceMotion ? 80 : 1100);
  };
  var ans = maxData(t.mtu);
  $('#l2c').onclick = function () {
    var v = +$('#l2a').value, fb = $('#l2fb');
    if (v === ans) lessonDone(fb, 'Correct: ' + t.mtu + ' − 20 = ' + (t.mtu - HDR) + ', and the largest multiple of 8 that fits is ' + ans + '.');
    else if (v === t.mtu - HDR) wrong(fb, 'Close. ' + v + ' is the room for data, but it must also be a multiple of 8.');
    else wrong(fb, 'Not yet. Start from the MTU, take away the header, then round down to a multiple of 8. Try MTU ' + t.mtu + ' in the boxes above.');
  };
  $('#l2h').onclick = function () { wrong($('#l2fb'), 'Hint: ' + t.mtu + ' − 20 = ' + (t.mtu - HDR) + '. Is that a multiple of 8? If not, go down to the next one.'); };
  upd();
}

/* Lesson 3: the header fields */
function l3() {
  var s = lessonState.l3, t = lessonState.task;
  if (!t) {
    var mtu = pick([532, 576, 620, 1006, 1000, 820]), m = maxData(mtu), data = rnd(2, 4) * m + rnd(1, m - 1), n = countFrags(data, mtu);
    t = lessonState.task = { mtu: mtu, data: data, n: n, q: pick(['offset', 'total']), k: rnd(2, n) };
  }
  var frs = splitFrag({ off: 0, len: t.data, mf: false }, t.mtu), ans = t.q === 'offset' ? offField(frs[t.k - 1]) : totalLen(frs[frs.length - 1]);
  lessonHead(3, 'The header fields',
    '<p>Four header fields let the destination put the pieces back together:</p><ul class="list">' +
    '<li><b>Ident</b> (Identification): a number the source picks for each datagram. Every fragment of one datagram has the <b>same Ident</b>.</li>' +
    '<li><b>M</b> (More fragments) flag: <b>1</b> on every fragment except the last, <b>0</b> on the last.</li>' +
    '<li><b>Offset</b>: where this fragment\'s data starts in the original data, counted in <b>8-byte units</b>. 512 bytes in is Offset 64.</li>' +
    '<li><b>Total Length</b>: this fragment\'s own header plus data.</li></ul>' +
    '<p>The Offset field has 13 bits, so it counts up to 8,191 units. Times 8 bytes, that covers the largest datagram (65,535 bytes). That is why fragments are cut on 8-byte boundaries.</p>' +
    '<div class="row"><label>Data ' + numIn('l3d', s.data, 1, MAX_DATA, 'Data bytes') + ' bytes</label><label>MTU ' + numIn('l3m', s.mtu, MIN_MTU, 65535, 'MTU') + '</label></div>' +
    tryBox('<p>A datagram with <b>' + fmt(t.data) + '</b> data bytes crosses a link with an MTU of <b>' + t.mtu + '</b>. ' + (t.q === 'offset' ? 'What is the <b>Offset field</b> of fragment ' + t.k + '?' : 'What is the <b>Total Length</b> of the last fragment?') + '</p><div class="row">' + numIn('l3a', '', 0, 65535, 'Your answer') + '<button class="btn small" id="l3c">Check</button><button class="btn alt small" id="l3h">Hint</button></div><div class="feedback" id="l3fb" aria-live="polite"></div>'));
  $('#lfig').innerHTML = '<div class="card"><p class="figtitle">Header fields of the original and of each fragment</p><div class="fig"><svg id="l3svg" role="img" aria-label="Ident, M, Offset and Total Length of the original datagram and of each fragment"></svg></div>' +
    '<ul class="legend"><li><i style="background:#FCE9C6;border:1px solid #0B3D5C"></i>M = 1: more fragments follow</li><li><i style="background:#fff;border:1px dashed #9DB3C1"></i>the original data, end to end</li></ul><div class="soft" id="l3facts"></div></div>';
  function upd() {
    var d = readNum('#l3d', 1, MAX_DATA), m = readNum('#l3m', MIN_MTU, 65535); if (d === null || m === null) return;
    s.data = d; s.mtu = m;
    var r = drawHeaders($('#l3svg'), d, m, s.ident, -1), fr = r.frags;
    $('#l3facts').innerHTML = fits(d, m) ? 'It fits: one datagram with M = 0 and Offset 0.' : fr.length + ' fragments. Each Offset is its first data byte ÷ 8: ' + fr.map(function (x) { return fmt(x.off) + ' ÷ 8 = ' + offField(x); }).join(', ') + '.';
  }
  $('#l3d').oninput = upd; $('#l3m').oninput = upd;
  $('#l3c').onclick = function () {
    var v = +$('#l3a').value, fb = $('#l3fb'), m = maxData(t.mtu);
    if (v === ans) lessonDone(fb, t.q === 'offset' ? 'Correct. Fragment ' + t.k + ' starts at data byte ' + fmt((t.k - 1) * m) + ' = ' + (t.k - 1) + ' × ' + m + ', and ' + fmt((t.k - 1) * m) + ' ÷ 8 = ' + ans + '.' : 'Correct. The last fragment carries ' + fmt(t.data) + ' − ' + (frs.length - 1) + ' × ' + m + ' = ' + (ans - HDR) + ' data bytes, plus the 20-byte header: ' + ans + '.');
    else if (t.q === 'offset' && v === (t.k - 1) * m) wrong(fb, 'That is the position in bytes. The Offset field counts 8-byte units.');
    else if (t.q === 'total' && v === ans - HDR) wrong(fb, 'That is the data. Total Length also counts the header.');
    else wrong(fb, 'Not yet. Type ' + fmt(t.data) + ' and ' + t.mtu + ' in the boxes above and look at the figure.');
  };
  $('#l3h').onclick = function () { wrong($('#l3fb'), 'Hint: each full fragment carries ' + maxData(t.mtu) + ' data bytes (' + t.mtu + ' − 20, rounded down to a multiple of 8).'); };
  upd();
}

/* Lesson 4: across an internetwork (the core lesson) */
var PRESETS = { classic: { data: 1400, mtus: [1500, 532, 1500] }, refrag: { data: 2980, mtus: [1500, 1000, 576] }, none: { data: 1400, mtus: [1500, 1500, 1500] }, puzzle: { data: 1400, mtus: [1500, 1000, 1500] } };
function l4() {
  var s = lessonState.l4;
  lessonHead(4, 'Across an internetwork',
    '<p>Each fragment is a complete datagram. Routers forward every fragment <b>on its own</b>, and every link wraps it in a new frame.</p>' +
    '<p>When a fragment meets an even <b>smaller link</b>, the router fragments it <b>again</b>, with the same rules. Two details matter:</p><ul class="list">' +
    '<li>The Offset still counts from the start of the <b>original</b> data.</li><li>The last piece keeps the M flag of the fragment it came from, so only the very last piece of the datagram has M = 0.</li></ul>' +
    '<p>Routers <b>never reassemble</b>. Fragmenting twice can make more, oddly sized fragments than cutting once for the smallest link.</p>' +
    '<div class="row"><label>Data ' + numIn('l4d', s.data, 1, MAX_DATA, 'Data bytes') + ' bytes</label><label>Example <select id="l4p"><option value="">choose…</option><option value="classic">1400 bytes over 1500, 532, 1500</option><option value="refrag">Fragment twice: 2980 bytes over 1500, 1000, 576</option><option value="none">No fragmentation</option></select></label></div>' +
    '<div class="row">' + s.mtus.map(function (m, i) { return '<label>Link ' + (i + 1) + ' MTU ' + numIn('l4m' + i, m, MIN_MTU, 65535, 'Link ' + (i + 1) + ' MTU') + '</label>'; }).join('') + '</div>' +
    '<div class="row"><button class="btn small" id="l4go">▶ Send</button><label>Speed <select id="l4sp"><option value="0.6">Slow</option><option value="1" selected>Normal</option><option value="1.8">Fast</option></select></label></div>' +
    '<p id="l4cap" class="soft" aria-live="polite"></p>' +
    tryBox('<p>Load the puzzle: 1400 data bytes, Link 2 at 1000. <b>Change only Link 3\'s MTU</b> so that <b>exactly four fragments</b> reach Host B.</p><div class="row"><button class="btn alt small" id="l4puz">Load the puzzle</button></div><div class="feedback" id="l4fb" aria-live="polite"></div>'));
  $('#lfig').innerHTML = '<div class="card"><p class="figtitle">How the hosts and routers are connected, and the fragments on each link</p><div class="fig"><svg id="l4svg" role="img" aria-label="Host A, routers R1 and R2, Host B, and the fragments on each link"></svg></div>' +
    '<ul class="legend"><li><i style="background:#0B3D5C"></i>20-byte header</li><li><i style="background:#CFE6F0;border:1px solid #00A2D7"></i>data, to scale</li><li><i style="background:#F5A524"></i>a router fragments</li></ul></div>' +
    '<div class="card"><p class="figtitle">Fragments that reach Host B</p><div class="fcards" id="l4cards"></div></div>';
  var ident = newIdent(), stage = null;
  function upd() {
    var d = readNum('#l4d', 1, MAX_DATA); if (d === null) return;
    var ms = []; for (var i = 0; i < 3; i++) { var v = readNum('#l4m' + i, MIN_MTU, 65535); if (v === null) return; ms.push(v); }
    s.data = d; s.mtus = ms; lessonState.token++;
    var res = sendPath(d, ms, false); stage = drawPath($('#l4svg'), ms, res);
    var last = res.frags;
    $('#l4cards').innerHTML = fragCards(last, ident);
    var splits = res.hops.map(function (h, i) { return h.split ? nodeName(i, 3) : null; }).filter(Boolean);
    $('#l4cap').innerHTML = (splits.length ? '<b>' + splits.join(' and ') + '</b> fragment' + (splits.length === 1 ? 's' : '') + '. ' : 'Nobody fragments: the datagram fits every link. ') + '<b>' + last.length + '</b> packet' + (last.length === 1 ? '' : 's') + ' reach Host B, with ' + fmt(last.length * HDR) + ' bytes of headers in all.';
    var fb = $('#l4fb');
    if (d === 1400 && ms[0] >= 1420 && ms[1] === 1000 && last.length === 4) { var a = countFrags(976, ms[2]), b2 = countFrags(424, ms[2]); lessonDone(fb, 'Yes! With Link 3 at ' + ms[2] + ', R2 cuts the 976-byte fragment into ' + a + ' and the 424-byte one into ' + b2 + ': ' + a + ' + ' + b2 + ' = 4. Each is handled on its own.'); }
    else if (d === 1400 && ms[1] === 1000) { fb.className = 'feedback'; fb.innerHTML = last.length < 4 ? 'Now ' + last.length + ' arrive. Make Link 3 smaller.' : 'Now ' + last.length + ' arrive. Make Link 3 a little bigger.'; }
    else { fb.className = 'feedback'; fb.innerHTML = ''; }
  }
  function load(p) { var P = PRESETS[p]; $('#l4d').value = P.data; P.mtus.forEach(function (m, i) { $('#l4m' + i).value = m; }); upd(); }
  $('#l4d').oninput = upd; for (var i = 0; i < 3; i++) $('#l4m' + i).oninput = upd;
  $('#l4p').onchange = function () { if (this.value) load(this.value); };
  $('#l4puz').onclick = function () { load('puzzle'); };
  $('#l4go').onclick = function () {
    upd(); var tok = lessonState.token, res = sendPath(s.data, s.mtus, false), b = $('#l4go'); b.disabled = true;
    animatePath(stage, res, +$('#l4sp').value, tok, alive, function (i, hop) {
      if (hop) $('#l4cap').innerHTML = 'Link ' + (i + 1) + ' (MTU ' + hop.mtu + '): ' + (hop.split ? '<b>' + nodeName(i, 3) + ' fragments.</b> ' : '') + hop.frags.length + (hop.frags.length === 1 ? ' packet crosses.' : ' fragments cross.');
    }).then(function () { if (alive(tok)) { b.disabled = false; $('#l4cap').innerHTML += ' Host B has them all.'; } else b.disabled = false; });
  };
  upd();
}

/* Lesson 5: reassembly and loss */
var L5_SCEN = { classic: { data: 1400, mtus: [1500, 532, 1500], name: '1400 bytes over a 532 link: 3 fragments' }, ping: { data: 3008, mtus: [1500], name: 'ping -s 3000 on Ethernet: 3 fragments' }, twice: { data: 2980, mtus: [1500, 1000, 576], name: 'Fragmented twice: 7 fragments' } };
function l5() {
  var t = lessonState.task;
  if (!t) {
    var mtu = pick([532, 576, 620, 1006, 1500]), m = maxData(mtu), n = rnd(4, 6), data = (n - 1) * m + rnd(8, m - 8), frs = splitFrag({ off: 0, len: data, mf: false }, mtu), miss = rnd(0, frs.length - 2);
    t = lessonState.task = { mtu: mtu, data: data, frs: frs, miss: miss, order: shuffle(frs.map(function (x, i) { return i; }).filter(function (i) { return i !== miss; })) };
  }
  var st = lessonState.l5 || (lessonState.l5 = { scen: 'classic' });
  lessonHead(5, 'Reassembly and loss',
    '<p>Only the <b>destination host</b> reassembles. It collects the fragments that share one Ident (and the same source, destination, and protocol), in any order. Each Offset says where a piece goes.</p>' +
    '<p>The fragment with <b>M = 0</b> reveals the full size: its Offset × 8 plus its data length. When every byte has arrived, IP hands the whole datagram to the protocol above it.</p>' +
    '<p>IP <b>never recovers</b> a lost fragment. The destination waits (Linux waits 30 seconds), then throws away every fragment it holds. One lost fragment loses the <b>whole datagram</b>, and the sender must send all of it again. Fragments that never complete also tie up memory, which attackers have used.</p>' +
    '<div class="row"><label>Example <select id="l5s">' + Object.keys(L5_SCEN).map(function (k) { return '<option value="' + k + '"' + (k === st.scen ? ' selected' : '') + '>' + L5_SCEN[k].name + '</option>'; }).join('') + '</select></label><label><input type="checkbox" id="l5lose"> Lose one fragment on the way</label></div>' +
    '<div class="row"><button class="btn small" id="l5next">Deliver the next fragment</button><button class="btn alt small" id="l5all">Deliver them all</button><button class="btn alt small" id="l5new">New arrival order</button></div>' +
    tryBox('<p>Host B holds these fragments of one datagram (MTU ' + t.mtu + '). One is missing. What is the <b>Offset field</b> of the missing fragment?</p><ul class="list mono">' + t.order.map(function (i) { var f = t.frs[i]; return '<li>Offset ' + offField(f) + ', M ' + (f.mf ? 1 : 0) + ', Total Length ' + totalLen(f) + '</li>'; }).join('') + '</ul><div class="row">' + numIn('l5a', '', 0, 8191, 'Offset of the missing fragment') + '<button class="btn small" id="l5c">Check</button><button class="btn alt small" id="l5h">Hint</button></div><div class="feedback" id="l5fb" aria-live="polite"></div>'));
  $('#lfig').innerHTML = '<div class="card"><p class="figtitle">Host B\'s reassembly buffer</p><div class="fig"><svg id="l5svg" role="img" aria-label="The reassembly buffer with the fragments received so far"></svg></div><ol class="log" id="l5log" aria-live="polite"></ol></div>';
  var S = {};
  function reset() {
    lessonState.token++;
    var sc = L5_SCEN[st.scen]; S.frags = sendPath(sc.data, sc.mtus, false).frags; S.data = sc.data;
    S.order = shuffle(S.frags.map(function (x, i) { return i; })); S.got = []; S.lost = $('#l5lose').checked ? S.order[rnd(0, S.order.length - 1)] : -1; S.done = false;
    $('#l5log').innerHTML = ''; $('#l5next').disabled = false; $('#l5all').disabled = false; draw();
  }
  function known() { return S.got.some(function (i) { return !S.frags[i].mf; }); }
  function draw() { drawBuffer($('#l5svg'), S.frags, S.got, S.data, known(), S.got.length + (S.lost >= 0 ? 1 : 0) === S.frags.length ? S.lost : -1); }
  function log(t, cls) { var li = document.createElement('li'); li.innerHTML = t; if (cls) li.className = cls; $('#l5log').appendChild(li); }
  function step() {
    if (S.done) return false;
    var pending = S.order.filter(function (i) { return S.got.indexOf(i) < 0 && i !== S.lost; });
    if (!pending.length) return false;
    var i = pending[0], fr = S.frags[i]; S.got.push(i);
    log('Fragment ' + (i + 1) + ' arrives: Offset ' + offField(fr) + ' (byte ' + fmt(fr.off) + '), ' + fmt(fr.len) + ' data bytes, M ' + (fr.mf ? 1 : 0) + (fr.mf ? '' : '. Now Host B knows the full size: ' + offField(fr) + ' × 8 + ' + fr.len + ' = ' + fmt(fr.off + fr.len) + ' bytes.'));
    draw();
    if (S.got.length === S.frags.length) { S.done = true; log('Every byte is here. IP passes the ' + fmt(S.data) + '-byte datagram up to the next protocol.', 'result'); finish(); }
    else if (S.got.length + 1 === S.frags.length && S.lost >= 0) {
      S.done = true; finish(); var tok = lessonState.token, secs = 30;
      log('Fragment ' + (S.lost + 1) + ' was lost on the way. Host B starts its 30-second timer…');
      var tick = setInterval(function () {
        if (!alive(tok)) { clearInterval(tick); return; }
        secs -= 5; if (secs > 0) return;
        clearInterval(tick); draw();
        log('Time is up. Host B throws away all ' + S.got.length + ' fragments. The whole datagram is lost; IP does not ask for the missing piece.' + (S.got.some(function (j) { return S.frags[j].off === 0; }) ? ' Because fragment 1 arrived, Host B may send an ICMP Time Exceeded message (fragment reassembly time exceeded).' : ''), 'result');
      }, reduceMotion ? 30 : 400);
    }
    return true;
  }
  function finish() { $('#l5next').disabled = true; $('#l5all').disabled = true; }
  $('#l5next').onclick = step;
  $('#l5all').onclick = function () { var tok = lessonState.token; (function go() { if (!alive(tok)) return; if (step()) setTimeout(go, reduceMotion ? 0 : 450); })(); };
  $('#l5new').onclick = reset; $('#l5lose').onchange = reset;
  $('#l5s').onchange = function () { st.scen = this.value; reset(); };
  var ans = offField(t.frs[t.miss]), m = maxData(t.mtu);
  $('#l5c').onclick = function () {
    var v = +$('#l5a').value, fb = $('#l5fb');
    if (v === ans) lessonDone(fb, 'Correct. Every full fragment carries ' + m + ' bytes, so the Offsets go up in steps of ' + (m / 8) + ': ' + t.frs.map(offField).join(', ') + '. Offset ' + ans + ' is the gap.');
    else if (v === ans * 8) wrong(fb, 'That is the position in bytes. The Offset field counts 8-byte units.');
    else wrong(fb, 'Not yet. Sort the Offsets from smallest to largest and look for the gap.');
  };
  $('#l5h').onclick = function () { wrong($('#l5fb'), 'Hint: a full fragment here carries ' + t.mtu + ' − 20 → ' + m + ' bytes, so the Offsets go up by ' + m + ' ÷ 8 = ' + (m / 8) + '.'); };
  reset();
}

/* Lesson 6: avoid fragmentation: DF, ICMP, and path MTU discovery */
var L6_MODES = [['want', 'Linux: ping -s (DF set, learns the path MTU)'], ['do', 'Linux: ping -M do -s (DF set, never fragment)'], ['dont', 'Linux: ping -M dont -s (DF clear)'], ['win', 'Windows: ping -l (DF clear)'], ['winf', 'Windows: ping -f -l (DF set)']];
function l6() {
  var s = lessonState.l6, t = lessonState.task || (lessonState.task = { mtu2: pick([1492, 1450, 1400, 1280, 1000, 576].filter(function (m) { return m !== s.mtu2; })) });
  lessonHead(6, 'Avoid it: DF and path MTU discovery',
    '<p>Fragmentation costs extra headers, extra work, and the risk of losing the whole datagram. So hosts try to avoid it.</p>' +
    '<p>The <b>DF (Don\'t Fragment)</b> flag tells routers: never fragment this datagram. A router that would have to fragment it <b>drops</b> it and sends back an ICMP (Internet Control Message Protocol) message, "Destination Unreachable: fragmentation needed" (type 3, code 4), that includes the MTU of the next link.</p>' +
    '<p><b>Path MTU discovery</b> uses this: send with DF set, and when that message comes back, remember the smaller MTU for that destination. Linux ping works this way by default: the first big ping is lost, and the next ones are fragmented by Host A itself to fit.</p>' +
    '<p>TCP (Transmission Control Protocol) avoids fragmentation by sending segments of at most MSS (Maximum Segment Size) = MTU − 40 bytes: 1460 on Ethernet. Large UDP datagrams and big pings still fragment. In <b>IPv6</b>, routers never fragment at all: only the source can, and a router answers "Packet Too Big". Every IPv6 link carries at least 1280 bytes.</p>' +
    '<div class="row"><label>Link 2 MTU <select id="l6m">' + [1500, 1492, 1450, 1400, 1280, 1000, 576].map(function (m) { return '<option' + (m === s.mtu2 ? ' selected' : '') + '>' + m + '</option>'; }).join('') + '</select></label><label>Payload <input type="range" id="l6r" min="100" max="1472" value="' + s.payload + '"></label>' + numIn('l6n', s.payload, 0, 65500, 'Ping payload in bytes') + '</div>' +
    '<div class="row"><label>Command <select id="l6mode">' + L6_MODES.map(function (m) { return '<option value="' + m[0] + '"' + (m[0] === s.mode ? ' selected' : '') + '>' + esc(m[1]) + '</option>'; }).join('') + '</select></label><button class="btn small" id="l6go">▶ Run 3 pings</button></div>' +
    '<div class="row"><label>Animation speed <span aria-hidden="true">🐢</span><input type="range" id="l6sp" min="0.25" max="3" step="0.25" value="' + s.speed + '" aria-describedby="l6spo"><span aria-hidden="true">🐇</span></label><output id="l6spo" class="mono" for="l6sp">' + s.speed + '×</output></div>' +
    tryBox('<p>Set Link 2 to <b>' + t.mtu2 + '</b>. With DF set, what is the <b>largest ping payload</b> (the number after -s or -l) that reaches Host B? Test your answer with the ping.</p><div class="row">' + numIn('l6a', '', 0, 65500, 'Largest payload') + '<button class="btn small" id="l6c">Check</button><button class="btn alt small" id="l6h">Hint</button></div><div class="feedback" id="l6fb" aria-live="polite"></div>'));
  $('#lfig').innerHTML = '<div class="card"><p class="figtitle">Host A pings Host B through R1</p><div class="fig"><svg id="l6svg" role="img" aria-label="Host A, router R1 and Host B; a ping and any ICMP message"></svg></div>' +
    '<ul class="legend"><li><i style="background:#fff;border:2px solid #00A2D7"></i>a packet, with its data size</li><li><i style="background:#FDE8E9;border:2px solid #E5484D"></i>ICMP: fragmentation needed</li></ul>' +
    '<p class="figtitle">What the terminal shows</p><div class="term" id="l6term" aria-live="polite"></div><p class="cmdnote" id="l6note"></p></div>' +
    '<div class="card"><p class="figtitle">Try it on your own computer</p><div id="l6cmds"></div></div>';
  function mtus() { return [1500, s.mtu2]; }
  function upd(fromRange) {
    if (fromRange) $('#l6n').value = $('#l6r').value; else { var v = readNum('#l6n', 0, 65500); if (v === null) return; $('#l6r').value = Math.min(1472, Math.max(100, v)); }
    s.payload = +$('#l6n').value; s.mtu2 = +$('#l6m').value; s.mode = $('#l6mode').value; lessonState.token++;
    var run = pingRun(s.mode, s.payload, mtus(), 3, '192.168.2.20');
    drawPath($('#l6svg'), mtus(), run.attempts[0].res, { icmp: true });
    $('#l6term').innerHTML = '<span class="d">$ ' + esc(cmdFor(s.mode, s.payload)) + '</span>';
    $('#l6note').textContent = 'The datagram is ' + fmt(s.payload + 28) + ' bytes: the payload, the 8-byte ICMP header, and the 20-byte IP header. The path MTU is ' + Math.min(1500, s.mtu2) + '.';
    renderCommands($('#l6cmds'), { payload: s.payload, mtu: s.mtu2, dest: '192.168.2.20' });
    checkTry();
  }
  function cmdFor(mode, n) { return { want: 'ping -c 3 -s ' + n, do: 'ping -c 3 -M do -s ' + n, dont: 'ping -c 3 -M dont -s ' + n, win: 'ping -n 3 -l ' + n, winf: 'ping -n 3 -f -l ' + n }[mode] + ' 192.168.2.20'; }
  $('#l6r').oninput = function () { upd(true); }; $('#l6n').oninput = function () { upd(false); };
  $('#l6m').onchange = function () { upd(false); }; $('#l6mode').onchange = function () { upd(false); };
  function sp() { return s.speed; }   // read at every step, so a change applies to the next packet even mid-run
  $('#l6sp').oninput = function () { s.speed = +this.value; $('#l6spo').textContent = s.speed + '×'; };
  $('#l6go').onclick = function () {
    upd(false); var tok = lessonState.token, run = pingRun(s.mode, s.payload, mtus(), 3, '192.168.2.20'), term = $('#l6term'), b = $('#l6go'), lines = run.lines;
    b.disabled = true;
    term.innerHTML = '<span class="d">$ ' + esc(cmdFor(s.mode, s.payload)) + '</span>\n' + termHTML([lines[0]]);
    var chain = Promise.resolve();
    run.attempts.forEach(function (a, i) {
      chain = chain.then(function () {
        if (!alive(tok)) return;
        var stage = drawPath($('#l6svg'), mtus(), a.res, { icmp: !a.res.ok && a.res.dropAt > 0 });
        return (a.local ? sleep(reduceMotion ? 100 : 700 / sp()) : animatePath(stage, a.res, 1.3 * sp(), tok, alive)).then(function () {
          if (!alive(tok)) return;
          if (a.res.ok) return moveChip(stage, stage.xs[2], stage.xs[0] + NODE_W, stage.cy + 0.1, 'reply', { fill: C.amber, stroke: '#B86E00', dur: 900 / sp() }, tok, alive);
        }).then(function () { if (alive(tok)) term.innerHTML += '\n' + termHTML([lines[i + 1]]); return sleep(reduceMotion ? 0 : 500 / sp()); });
      });
    });
    chain.then(function () { b.disabled = false; });
  };
  function checkTry() { /* the answer is checked with the button */ }
  var ans = Math.min(1500, t.mtu2) - 28;
  $('#l6c').onclick = function () {
    var v = +$('#l6a').value, fb = $('#l6fb');
    if (v === ans) lessonDone(fb, 'Correct: the path MTU is ' + t.mtu2 + ', so the largest datagram is ' + t.mtu2 + ' bytes. Take away 20 (IP header) and 8 (ICMP header): ' + ans + '. One more byte and R1 answers "Frag needed".');
    else if (v === t.mtu2 - 20) wrong(fb, 'Close. The ping payload sits after the 8-byte ICMP header too.');
    else if (v === 1472) wrong(fb, '1472 fits Host A\'s own link, but the path is only as big as its smallest link.');
    else wrong(fb, 'Not yet. Set Link 2 to ' + t.mtu2 + ', choose ping -M do, and try your number, then one more byte.');
  };
  $('#l6h').onclick = function () { wrong($('#l6fb'), 'Hint: payload + 8 (ICMP header) + 20 (IP header) must be at most the smallest MTU on the path.'); };
  upd(false);
}
