"""Figure check for course apps: finds overlapping or clipped text in every SVG figure.

Drives the app through many states (each lesson with its examples and extreme values,
each calculator preset, paths of 1 to 4 links, phone width) and, for every visible SVG:
  - text that overlaps other text (by more than a few pixels),
  - text that runs outside the figure,
  - figures that are empty or have zero size.
It also saves a picture of every figure in every state, so a person can look at them.

Usage: python3 figure_check.py path/to/app.html [out-folder]
"""
import asyncio, os, sys, pathlib, json
from playwright.async_api import async_playwright

APP = pathlib.Path(sys.argv[1]).resolve(); URL = APP.as_uri()
OUT = pathlib.Path(sys.argv[2] if len(sys.argv) > 2 else 'figs'); OUT.mkdir(exist_ok=True)
problems = []

CHECK = r"""(tag) => {
  const out = [];
  document.querySelectorAll('svg').forEach((svg, si) => {
    const r = svg.getBoundingClientRect();
    if (svg.closest('[hidden]') || r.width === 0) return;
    const id = svg.id || ('svg' + si);
    const texts = Array.from(svg.querySelectorAll('text')).map(t => ({ s: t.textContent, b: t.getBoundingClientRect() })).filter(t => t.s.trim() && t.b.width > 0);
    if (!svg.querySelector('rect,line,polygon,polyline,path,circle,text')) out.push(id + ': empty figure');
    // svg drawing area: the scroll box (.fig) clips; the svg itself is the drawing
    texts.forEach(t => {
      if (t.b.left < r.left - 1 || t.b.right > r.right + 1 || t.b.top < r.top - 1 || t.b.bottom > r.bottom + 1)
        out.push(id + ': clipped "' + t.s.slice(0, 40) + '"');
    });
    for (let i = 0; i < texts.length; i++) for (let j = i + 1; j < texts.length; j++) {
      const a = texts[i].b, b = texts[j].b;
      const w = Math.min(a.right, b.right) - Math.max(a.left, b.left), h = Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top);
      if (w > 2 && h > 2.5) out.push(id + ': overlap "' + texts[i].s.slice(0, 32) + '" / "' + texts[j].s.slice(0, 32) + '"');
    }
  });
  return out;
}"""


OPEN_ALL = "() => { document.querySelectorAll('details').forEach(d => { d.open = true; }); ['l1ptime', 'l1pwire', 'c_one', 'c_path'].forEach(id => { const e = document.getElementById(id); if (e) e.hidden = false; }); }"


async def snap(pg, state):
    await pg.evaluate(OPEN_ALL)   # check every figure, folded or not
    res = await pg.evaluate(CHECK, state)
    for r in res: problems.append(state + ' | ' + r)
    i = 0
    for svg in await pg.query_selector_all('svg'):
        if await svg.is_visible():
            box = await svg.bounding_box()
            if box and box['width'] > 60 and await svg.get_attribute('id') not in (None,):
                i += 1
                try: await svg.screenshot(path=str(OUT / f'{state}-{await svg.get_attribute("id")}.png'))
                except Exception: pass


async def setv(pg, sel, v, ev='input'):
    await pg.fill(sel, str(v)); await pg.dispatch_event(sel, ev)


async def run(b, width):
    tag = 'w' + str(width)
    pg = await b.new_page(viewport={'width': width, 'height': 900})
    await pg.emulate_media(reduced_motion='reduce')
    await pg.goto(URL); await pg.wait_for_timeout(200); await snap(pg, tag + '-home')
    # lesson 1
    await pg.goto(URL + '?mode=learn&lesson=1'); await pg.wait_for_timeout(200)
    for r in ['1000', '56000', '1000000', '1000000000', '100000000000']:
        for m in ['2', '10']:
            await pg.select_option('#l1rate', r); await pg.select_option('#l1mult', m); await pg.wait_for_timeout(50)
            await snap(pg, f'{tag}-l1-{r}-x{m}')
    for med in ['fiber', 'radio']:
        await pg.select_option('#l1med', med); await snap(pg, f'{tag}-l1-{med}')
    await pg.click('#l1go'); await pg.wait_for_timeout(100); await snap(pg, f'{tag}-l1-moved')
    # lesson 2: presets, mid-animation moments, extremes
    await pg.goto(URL + '?mode=learn&lesson=2'); await pg.wait_for_timeout(200)
    for p in ['lan', 'wan', 'sat', 'big']:
        await pg.select_option('#l2p', p); await pg.wait_for_timeout(100)
        for fr in ['1000', '700', '500', '300', '100', '20', '5', '1', '0']:
            await setv(pg, '#l2scrub', fr); await snap(pg, f'{tag}-l2-{p}-t{fr}')
        for i in range(4):   # every "Show" button
            await pg.click(f'#l2ev [data-ev="{i}"]'); await snap(pg, f'{tag}-l2-{p}-ev{i + 1}')
    await setv(pg, '#l2q', '50'); await setv(pg, '#l2s', '64'); await pg.select_option('#l2bw', '100000000000'); await setv(pg, '#l2d', '0'); await snap(pg, f'{tag}-l2-extreme1')
    await setv(pg, '#l2q', '0'); await setv(pg, '#l2s', '1000000000'); await pg.select_option('#l2bw', '1000'); await setv(pg, '#l2d', '20000'); await snap(pg, f'{tag}-l2-extreme2')
    # lesson 3
    await pg.goto(URL + '?mode=learn&lesson=3'); await pg.wait_for_timeout(200)
    for v in ['2', '5.5', '9']:
        await setv(pg, '#l3sz', v); await snap(pg, f'{tag}-l3-{v}')
    await pg.select_option('#l3ba', '100000000000'); await setv(pg, '#l3da', '0.001'); await snap(pg, f'{tag}-l3-extreme')
    # lesson 4
    await pg.goto(URL + '?mode=learn&lesson=4'); await pg.wait_for_timeout(200)
    for bw in ['1000', '1000000', '45000000', '100000000000']:
        for d in ['0.001', '50', '1000']:
            await pg.select_option('#l4bw', bw); await setv(pg, '#l4d', d); await snap(pg, f'{tag}-l4-{bw}-{d}')
    await pg.select_option('#l4bw', '45000000'); await setv(pg, '#l4d', '50')
    for mode, win, msg in [('one', '', '1'), ('rtt', '', '1'), ('rtt', '64', '1'), ('rtt', '200', '1'), ('one', '', ''), ('rtt', '', ''), ('rtt', '64', ''), ('one', '', '0.001')]:
        await pg.select_option('#l4mode', mode); await setv(pg, '#l4w', win); await setv(pg, '#l4m', msg)
        for fr in ['0', '100', '200', '400', '500', '700', '900', '990', '1000']:
            await setv(pg, '#l4scrub', fr); await snap(pg, f'{tag}-l4-{mode}{win}-m{msg}-t{fr}')
    # lesson 5
    await pg.goto(URL + '?mode=learn&lesson=5'); await pg.wait_for_timeout(200)
    for size, bw, rtt in [('1', '1000000000', '100'), ('100', '10000000', '20'), ('1', '1000', '0'), ('0.001', '100000000000', '500')]:
        await setv(pg, '#l5s', size); await pg.select_option('#l5bw', bw); await setv(pg, '#l5r', rtt)
        for fr in ['1000', '0', '250', '500', '800']:
            await setv(pg, '#l5scrub', fr); await snap(pg, f'{tag}-l5-{size}-{bw}-{rtt}-t{fr}')
        for i in range(5):
            await pg.click(f'#l5ev [data-ev="{i}"]'); await snap(pg, f'{tag}-l5-{size}-{bw}-{rtt}-ev{i + 1}')
    # lesson 6
    await pg.goto(URL + '?mode=learn&lesson=6'); await pg.wait_for_timeout(200)
    for fr in ['1000', '600', '300', '100', '30']:
        await setv(pg, '#l6scrub', fr); await snap(pg, f'{tag}-l6-t{fr}')
    for i, bw in enumerate(['1000', '100000000000', '1000']):
        await pg.select_option(f'#l6b{i}', bw)
    await setv(pg, '#l6qs', '0'); await setv(pg, '#l6qr', '0'); await snap(pg, f'{tag}-l6-extreme')
    # calculator
    await pg.goto(URL + '?mode=calc'); await pg.wait_for_timeout(300)
    for p in ['lan', 'wifi', 'home', 'cross', 'ocean', 'sat', 'classic']:
        await pg.select_option('#c_preset', p); await pg.wait_for_timeout(80)
        for fr in ['1000', '400']:
            await setv(pg, '#c_scrub', fr); await snap(pg, f'{tag}-calc-{p}-t{fr}')
    await setv(pg, '#c_dist', '0'); await snap(pg, f'{tag}-calc-dist0')
    await setv(pg, '#c_dist', '1000'); await setv(pg, '#c_q', '20'); await snap(pg, f'{tag}-calc-queue')
    while not await pg.is_disabled('#p_del'): await pg.click('#p_del')
    for n in range(4):
        await setv(pg, '#p_scrub', '500'); await snap(pg, f'{tag}-path-{len(await pg.query_selector_all(".linkbox"))}links')
        if n < 3: await pg.click('#p_add')
    await setv(pg, '#p_n', '100'); await snap(pg, f'{tag}-path-100pk')
    await pg.close()


async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path=os.environ.get('CHROME', '/usr/bin/google-chrome'), args=['--no-sandbox'])
        for w in [1280, 390]:
            await run(b, w)
        await b.close()
    seen = {}
    for pr in problems:
        k = pr.split(' | ', 1)[1]
        seen.setdefault(k, []).append(pr.split(' | ')[0])
    for k, v in sorted(seen.items()):
        print(f'{len(v):3d}x  {k}   e.g. {v[0]}')
    print('PROBLEMS', len(problems), 'distinct', len(seen))


asyncio.run(main())
