"""Figure check: in every lesson, every lesson case, and every Calculator preset, find SVG text
that overlaps other text or runs outside its figure. Prints each problem."""
import asyncio, sys, pathlib
from playwright.async_api import async_playwright
URL = pathlib.Path(sys.argv[1]).resolve().as_uri()
JS = r"""() => { const out = [];
  // each text's real outline (rotated labels included) as 4 corners on screen
  function quad(t) { const b = t.getBBox(), m = t.getScreenCTM(); if (!m || !b.width) return null;
    return [[b.x, b.y], [b.x + b.width, b.y], [b.x + b.width, b.y + b.height], [b.x, b.y + b.height]].map(([x, y]) => [m.a * x + m.c * y + m.e, m.b * x + m.d * y + m.f]); }
  function sep(P, Q) {   // separating-axis test with a small tolerance (1.5 px)
    for (const S of [P, Q]) for (let i = 0; i < 4; i++) { const a = S[i], b = S[(i + 1) % 4], nx = a[1] - b[1], ny = b[0] - a[0], L = Math.hypot(nx, ny) || 1;
      const pr = R => R.map(p => (p[0] * nx + p[1] * ny) / L), p = pr(P), q = pr(Q);
      if (Math.min(Math.max(...p), Math.max(...q)) - Math.max(Math.min(...p), Math.min(...q)) < 1.5) return true; }
    return false; }
  document.querySelectorAll('svg').forEach(svg => {
    if (!svg.getBoundingClientRect().width) return;
    const sb = svg.getBoundingClientRect(), ts = Array.from(svg.querySelectorAll('text')).map(t => ({ t, r: t.getBoundingClientRect(), q: quad(t), s: t.textContent }));
    ts.forEach(a => { if (a.r.width && (a.r.left < sb.left - 1 || a.r.right > sb.right + 1 || a.r.top < sb.top - 1 || a.r.bottom > sb.bottom + 1)) out.push((svg.id || '?') + ': outside: ' + a.s); });
    for (let i = 0; i < ts.length; i++) for (let j = i + 1; j < ts.length; j++) {
      const a = ts[i], b = ts[j]; if (!a.q || !b.q) continue;
      // shrink each outline to the glyph body (bboxes include line spacing)
      const shrink = Q => { const cx = (Q[0][0] + Q[2][0]) / 2, cy = (Q[0][1] + Q[2][1]) / 2; return Q.map(p => [cx + (p[0] - cx) * 0.98, cy + (p[1] - cy) * 0.7]); };
      if (!sep(shrink(a.q), shrink(b.q))) out.push((svg.id || '?') + ': overlap: "' + a.s + '" / "' + b.s + '"');
    } });
  return out; }"""
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
        pg = await b.new_page(viewport={'width': 1280, 'height': 900}); total = 0
        async def scan(tag):
            nonlocal total
            r = await pg.evaluate(JS); total += len(r)
            for x in r: print(tag, '|', x)
            await pg.evaluate("document.querySelectorAll('details').forEach(function (d) { d.open = true; })"); await pg.wait_for_timeout(60)
            r = await pg.evaluate(JS); total += len(r)
            for x in r: print(tag, '(all open) |', x)
        await pg.goto(URL); await pg.wait_for_timeout(200); await scan('home')
        for i in range(1, 9):
            await pg.goto(URL + f'?mode=learn&lesson={i}'); await pg.wait_for_timeout(250); await scan(f'lesson {i}')
            if i == 1:
                for n in range(1, 9): await pg.click(f'#l1segs [data-s="{n}"]'); await pg.wait_for_timeout(60); await scan(f'lesson 1 seg {n}')
                await pg.click('#l1raw'); await scan('lesson 1 raw')
            if i == 2:
                for k in ['closed', 'synlost', 'salost', 'silent', 'simopen']: await pg.click(f'#l2case [data-k={k}]'); await pg.wait_for_timeout(100); await scan('lesson 2 ' + k)
            if i == 3:
                for _ in range(5): await pg.click('#l3n'); await pg.wait_for_timeout(80); await scan('lesson 3 new')
                await pg.click('#l3d'); await pg.wait_for_timeout(80); await scan('lesson 3 dack')
            if i == 4:
                for v in ['300', '600', '1000']: await pg.select_option('#l4b', v); await pg.wait_for_timeout(80); await scan('lesson 4 buf ' + v)
                await pg.select_option('#l4r', 'pause5'); await pg.wait_for_timeout(80); await scan('lesson 4 pause5')
            if i == 5:
                for k in ['1', '5', '8']: await pg.click(f'#l5l [data-k="{k}"]'); await pg.wait_for_timeout(80); await scan('lesson 5 lose ' + k)
                await pg.click('#l5s'); await pg.wait_for_timeout(80); await scan('lesson 5 nosack')
                await pg.click('#l5ack [data-a]'); await pg.wait_for_timeout(80); await scan('lesson 5 ack')
            if i == 6:
                await pg.click('#l6k [data-i="2"]'); await scan('lesson 6 karn')
                await pg.select_option('#l6m', '1000'); await scan('lesson 6 min')
            if i == 8:
                for op, cl, last in [('normal', 'aFirst', 0), ('normal', 'bFirst', 1), ('normal', 'three', 0), ('normal', 'both', 0), ('simopen', 'aFirst', 0), ('simopen', 'early', 0), ('sendFirst', 'bFirst', 0), ('listenQuit', '', 0), ('giveUp', '', 0)]:
                    await pg.click(f'#l8open [data-k={op}]'); await pg.wait_for_timeout(80)
                    if cl: await pg.click(f'#l8close [data-k={cl}]'); await pg.wait_for_timeout(80)
                    if last: await pg.check('#l8last'); await pg.wait_for_timeout(80)
                    k = op + '/' + cl; await pg.click('[data-p=first]')
                    for _ in range(14):
                        await pg.click('[data-p=next]'); await pg.wait_for_timeout(1000); await scan('lesson 8 ' + k)
            if i == 7:
                for k in ['bFirst', 'three', 'both', 'lastAck', 'reset']: await pg.click(f'#l7case [data-k={k}]'); await pg.wait_for_timeout(100); await scan('lesson 7 ' + k)
        await pg.goto(URL + '?mode=calc'); await pg.wait_for_timeout(300)
        for pr in await pg.evaluate('Object.keys(TCPVisualizer.PRESETS)'):
            await pg.select_option('#c_preset', pr); await pg.wait_for_timeout(150); await scan('calc ' + pr)
            await pg.check('#c_fields [data-f=raw]'); await pg.dispatch_event('#c_fields [data-f=raw]', 'change'); await pg.wait_for_timeout(100); await scan('calc raw ' + pr)
        print('TOTAL', total)
        await b.close()
asyncio.run(main())
