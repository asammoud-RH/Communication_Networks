
/* =====================================================================
   CHALLENGE: question generators. Each question carries p: its inputs,
   so the logic test can re-check the answer on its own.
   ===================================================================== */
function numQ(type, tag, text, answer, hint, explain, p) { return { type: type, tag: tag, text: text, input: 'number', answer: answer, hint: hint, explain: explain, p: p }; }
function choiceQ(type, tag, text, right, wrongs, hint, explain, p) {
  var ch = [right]; wrongs.forEach(function (w) { if (ch.indexOf(w) < 0) ch.push(w); });
  ch = shuffle(ch.slice(0, 4)); return { type: type, tag: tag, text: text, input: 'choice', choices: ch, answer: ch.indexOf(right), hint: hint, explain: explain, p: p };
}
var FLAG_DEF = { SYN: 'opens a connection and states the initial sequence number', FIN: 'says "no more data from this side"', RST: 'aborts the connection at once', ACK: 'says the Acknowledgment field is valid', PSH: 'asks the receiver to hand the data to the program now' };
/* ---------- Easy */
function flagQ() {
  var k = pick(Object.keys(FLAG_DEF));
  return choiceQ('flag', 'hs', 'Which flag ' + FLAG_DEF[k] + '?', k, shuffle(Object.keys(FLAG_DEF).filter(function (x) { return x !== k; })),
    'SYN synchronizes, FIN finishes, RST resets.', k + ' ' + FLAG_DEF[k] + '.', { kind: 'flag', k: k });
}
function nextAckQ() {
  var v = pick(['data', 'data', 'syn', 'fin', 'datafin']), s = v === 'syn' ? 0 : rnd(1, 9000), L = v === 'syn' || v === 'fin' ? 0 : rnd(1, 1448);
  var syn = v === 'syn' ? 1 : 0, fin = v === 'fin' || v === 'datafin' ? 1 : 0, ans = s + L + syn + fin;
  var d = v === 'syn' ? 'a <b>SYN</b> with Seq=0' : v === 'fin' ? 'a <b>FIN</b> with Seq=' + s + ' and Len=0' : v === 'datafin' ? 'a segment with flags <b>FIN, PSH, ACK</b>, Seq=' + s + ', and Len=' + L : 'a data segment with Seq=' + s + ' and Len=' + L;
  return numQ('nextAck', 'num', 'Host B has every earlier byte and receives ' + d + '. What <b>Acknowledgment number</b> does B send back? (Relative numbers.)', ans,
    'An ACK names the next number expected. SYN and FIN each use one number.', s + ' + ' + L + (syn ? ' + 1 (SYN)' : '') + (fin ? ' + 1 (FIN)' : '') + ' = ' + ans + '.', { kind: 'nextAck', s: s, L: L, syn: syn, fin: fin });
}
function hdrLenQ() {
  var N = rnd(5, 15);
  if (Math.random() < 0.5) return numQ('hdrLen', 'num', 'A TCP header\'s 4-bit header length field is <b>' + N + '</b> (hexadecimal ' + N.toString(16).toUpperCase() + '). How many <b>bytes</b> long is the header?', N * 4, 'The field counts 32-bit words.', N + ' × 4 = ' + N * 4 + ' bytes.', { kind: 'hdrLen', N: N });
  return numQ('hdrLenR', 'num', 'A TCP header is <b>' + N * 4 + ' bytes</b> long. What number is in its 4-bit header length field?', N, 'The field counts 4-byte words.', N * 4 + ' ÷ 4 = ' + N + '.', { kind: 'hdrLenR', B: N * 4 });
}
function mssQ() {
  var M = pick([1500, 1492, 1400, 9000, 1280, 576]), ts = Math.random() < 0.5;
  if (ts) return numQ('mssTs', 'num', 'An IPv4 link has an <b>MTU of ' + M + '</b>, and both sides use the <b>Timestamps</b> option. How many <b>data bytes</b> does a full segment carry?', M - 52,
    'MTU − 20 (IP) − 20 (TCP) is the MSS. Timestamps take 12 more bytes of every segment.', M + ' − 20 − 20 = ' + (M - 40) + ' (the MSS), and ' + (M - 40) + ' − 12 = ' + (M - 52) + '.', { kind: 'mssTs', M: M });
  return numQ('mss', 'num', 'An IPv4 link has an <b>MTU of ' + M + '</b>. What <b>MSS</b> does TCP announce in its SYN?', M - 40, 'Take away the 20-byte IP header and the 20-byte TCP header.', M + ' − 20 − 20 = ' + (M - 40) + '.', { kind: 'mss', M: M });
}
var STATE_EVENTS = [
  ['ESTABLISHED', 'its program calls close, so it sends FIN', 'FIN_WAIT_1'], ['ESTABLISHED', 'it gets a FIN and ACKs it', 'CLOSE_WAIT'], ['LISTEN', 'it gets a SYN and answers SYN, ACK', 'SYN_RCVD'],
  ['SYN_SENT', 'it gets SYN, ACK and answers ACK', 'ESTABLISHED'], ['FIN_WAIT_2', 'it gets the other side\'s FIN and ACKs it', 'TIME_WAIT'], ['CLOSE_WAIT', 'its program calls close, so it sends FIN', 'LAST_ACK'],
  ['FIN_WAIT_1', 'it gets an ACK of its FIN (and no FIN yet)', 'FIN_WAIT_2'], ['LAST_ACK', 'it gets the ACK of its FIN', 'CLOSED'], ['FIN_WAIT_1', 'it gets a FIN before its own FIN is ACKed', 'CLOSING'], ['SYN_RCVD', 'it gets the ACK of its SYN', 'ESTABLISHED']
];
function stateQ() {
  var e = pick(STATE_EVENTS), all = ['FIN_WAIT_1', 'FIN_WAIT_2', 'CLOSE_WAIT', 'LAST_ACK', 'TIME_WAIT', 'CLOSING', 'ESTABLISHED', 'SYN_RCVD', 'CLOSED'];
  return choiceQ('state', 'close', 'A host is in <b>' + e[0] + '</b>, and ' + e[1] + '. What state is it in now?', e[2], shuffle(all.filter(function (x) { return x !== e[2] && x !== e[0]; })),
    'Follow the arrow out of ' + e[0] + ' for this event in the state diagram.', e[0] + ' → ' + e[2] + '.', { kind: 'state', from: e[0], ev: e[1] });
}
function spellQ() {
  var st = pick(['SYN_RCVD', 'ESTABLISHED', 'TIME_WAIT', 'CLOSE_WAIT', 'FIN_WAIT_2', 'LISTEN', 'LAST_ACK']), os = pick(['linux', 'windows']), right = SPELL[os][st];
  var pool = [SPELL.linux[st], SPELL.windows[st], st, SPELL.rfc[st], st.replace(/_/g, ' '), st.toLowerCase()].filter(function (x, i, a) { return x !== right && a.indexOf(x) === i; });
  var tool = os === 'linux' ? '<code>ss -tan</code> on Linux' : '<code>netstat -an</code> on Windows';
  return choiceQ('spell', 'close', 'A connection is in the state the TCP state diagram calls <b>' + st + '</b>. How does ' + tool + ' print it?', right, pool,
    os === 'linux' ? 'ss uses hyphens and shortens a few names (ESTAB, SYN-RECV).' : 'netstat uses underscores, spells out SYN_RECEIVED, and says LISTENING.', tool.replace(/<[^>]+>/g, '') + ' prints ' + right + '.', { kind: 'spell', st: st, os: os });
}
var LABELS = [
  ['TCP Retransmission', 'A data segment with the same Seq and Len as one Host A already sent, sent again after A\'s timer ran out.'],
  ['TCP Dup ACK', 'An ACK with no data, the same Ack and the same Win as the ACK just before it, while data is outstanding.'],
  ['TCP ZeroWindow', 'An ACK from the receiver that advertises Win=0.'],
  ['TCP Window Update', 'An ACK with no data and the same Ack as the last one, but a bigger Win.'],
  ['TCP Keep-Alive', 'Linux\'s window probe: an ACK with no data and Seq one below the next byte the receiver expects.']
];
function labelQ() {
  var l = pick(LABELS);
  return choiceQ('label', 'win', 'Which label does Wireshark put on this segment?<br><i>' + l[1] + '</i>', '[' + l[0] + ']', LABELS.filter(function (x) { return x !== l; }).map(function (x) { return '[' + x[0] + ']'; }),
    'Wireshark compares each segment with the ones before it in the same direction.', 'Wireshark labels it [' + l[0] + '].', { kind: 'label', l: l[0] });
}
/* ---------- Medium */
function hsQ() {
  var x = pick([rnd(0, MOD - 1), MOD - 1, rnd(0, MOD - 1)]), y = pick([rnd(0, MOD - 1), MOD - 1, rnd(0, 999999)]), w = pick(['saAck', 'ackSeq', 'ackAck', 'bData']);
  var ans = { saAck: m32(x + 1), ackSeq: m32(x + 1), ackAck: m32(y + 1), bData: m32(y + 1) }[w];
  var ask = { saAck: 'the <b>Ack</b> in B\'s SYN, ACK', ackSeq: 'the <b>Seq</b> in A\'s final ACK', ackAck: 'the <b>Ack</b> in A\'s final ACK', bData: 'the <b>Seq</b> of B\'s first data segment' }[w];
  return numQ('hs', 'hs', 'Host A\'s SYN has raw Seq=<span class="addr">' + x + '</span>. Host B answers SYN, ACK with raw Seq=<span class="addr">' + y + '</span>. What is ' + ask + ' (raw)?', ans,
    'Each SYN uses one number. Past 4294967295 the count starts again at 0.', 'The answer is ' + (w === 'saAck' || w === 'ackSeq' ? x : y) + ' + 1' + ((w === 'saAck' || w === 'ackSeq' ? x : y) === MOD - 1 ? ', which wraps to 0' : '') + ' = ' + ans + '.', { kind: 'hs', x: x, y: y, w: w });
}
function ladderQ() {
  var n = rnd(2, 4), lens = []; for (var i = 0; i < n; i++) lens.push(pick([100, 200, 300, 500, 536, 1000, 1448, rnd(20, 900)]));
  var starts = [1]; for (var j = 1; j < n; j++) starts.push(starts[j - 1] + lens[j - 1]);
  var tot = starts[n - 1] + lens[n - 1], bl = rnd(10, 400), w = pick(['seqLast', 'ackAll', 'aAck']);
  var txt = 'After the handshake, Host A sends ' + n + ' data segments with <b>Len=' + lens.join(', ') + '</b>, and the first has Seq=1. ';
  if (w === 'seqLast') return numQ('ladder', 'num', txt + 'What is the <b>Seq of segment ' + n + '</b>?', starts[n - 1], 'Each Seq is the previous Seq + the previous Len.', starts.map(function (s, k) { return 'Seq=' + s; }).join(', ') + '.', { kind: 'ladderSeq', lens: lens });
  if (w === 'ackAll') return numQ('ladder', 'num', txt + 'B receives them all and replies with ' + bl + ' bytes of its own. What <b>Ack</b> does B\'s reply carry?', tot, 'The Ack is the next byte B expects from A.', '1 + ' + lens.join(' + ') + ' = ' + tot + '.', { kind: 'ladderAck', lens: lens });
  return numQ('ladder', 'num', txt + 'B replies with <b>' + bl + '</b> bytes (its first data, Seq=1). What <b>Ack</b> does A send for B\'s reply?', 1 + bl, 'Each direction counts its own bytes. B\'s bytes start at 1.', 'B sent bytes 1 to ' + bl + ', so A expects ' + (1 + bl) + ' next.', { kind: 'ladderAAck', bl: bl });
}
function advWinQ() {
  var B = pick([4096, 8192, 16384, 32768, 65535, 400, 1000, 2000]), U = Math.min(B, pick([0, 100, 1000, 1448, 2896, rnd(1, B)]));
  return numQ('advWin', 'win', 'Host B\'s receive buffer holds <b>' + fmt(B) + '</b> bytes, and its program has not read <b>' + fmt(U) + '</b> of them yet. What window does B\'s next ACK advertise?', B - U, 'The window is the free space in the buffer.', fmt(B) + ' − ' + fmt(U) + ' = ' + fmt(B - U) + '.', { kind: 'advWin', B: B, U: U });
}
function usableQ() {
  var una = rnd(1, 50) * 100 + 1, w = pick([400, 1000, 2000, 4380, 8760]), infl = Math.min(w, 100 * rnd(0, w / 100)), nxt = una + infl;
  return numQ('usable', 'win', 'At Host A, SND.UNA = <b>' + una + '</b> and SND.NXT = <b>' + nxt + '</b>. The last window B advertised is <b>' + w + '</b>. How many more bytes may A send now?', una + w - nxt,
    'Usable window = SND.UNA + window − SND.NXT.', una + ' + ' + w + ' − ' + nxt + ' = ' + (una + w - nxt) + '.', { kind: 'usable', una: una, nxt: nxt, w: w });
}
function wsQ() {
  var F = rnd(1, 65535), s = pick([1, 2, 3, 5, 7, 8, 9, 10, 14]);
  return numQ('ws', 'win', 'Both SYNs carried the Window Scale option, and Host B announced a <b>shift of ' + s + '</b>. A later segment from B has <b>Window field ' + fmt(F) + '</b>. How many bytes does it advertise?', F * Math.pow(2, s),
    'Multiply the field by 2 to the power of the shift.', fmt(F) + ' × 2^' + s + ' = ' + fmt(F) + ' × ' + Math.pow(2, s) + ' = ' + fmt(F * Math.pow(2, s)) + '.', { kind: 'ws', F: F, s: s });
}
function twQ() {
  var k = pick(['a', 'b', 'both', 'rst']), right = { a: 'Only Host A', b: 'Only Host B', both: 'Both hosts', rst: 'Neither host' }[k];
  var txt = { a: 'Host A closes first, then Host B closes, and every segment arrives.', b: 'Host B closes first, then Host A closes, and every segment arrives.', both: 'Both programs close at the same moment, so the two FINs cross on the wire.', rst: 'Host B\'s program closes with unread data in its buffer, so B sends RST.' }[k];
  return choiceQ('tw', 'close', txt + ' Which side ends in TIME_WAIT?', right, ['Only Host A', 'Only Host B', 'Both hosts', 'Neither host'].filter(function (x) { return x !== right; }),
    'TIME_WAIT belongs to the side that closed first. A reset skips it.', { a: 'A closed first, so A waits in TIME_WAIT.', b: 'B closed first, so B waits in TIME_WAIT.', both: 'Both closed first: each goes FIN_WAIT_1 → CLOSING → TIME_WAIT.', rst: 'A reset closes both sides at once, with no TIME_WAIT.' }[k], { kind: 'tw', k: k });
}
function refusedQ() {
  var k = pick(['refused', 'timeout', 'ok', 'reset']), p = 'A → B  ';
  var lines = {
    refused: ['A → B  48212 → 5000 [SYN] Seq=0 Win=64240 Len=0 MSS=1460', 'B → A  5000 → 48212 [RST, ACK] Seq=1 Ack=1 Win=0 Len=0'],
    timeout: ['A → B  48212 → 5000 [SYN] Seq=0 Win=64240 Len=0 MSS=1460', 'A → B  [TCP Retransmission] 48212 → 5000 [SYN] Seq=0 Win=64240 Len=0', 'A → B  [TCP Retransmission] 48212 → 5000 [SYN] Seq=0 Win=64240 Len=0'],
    ok: ['A → B  48212 → 5000 [SYN] Seq=0 Win=64240 Len=0 MSS=1460', 'B → A  5000 → 48212 [SYN, ACK] Seq=0 Ack=1 Win=65160 Len=0 MSS=1460', 'A → B  48212 → 5000 [ACK] Seq=1 Ack=1 Win=64256 Len=0'],
    reset: ['A → B  48212 → 5000 [PSH, ACK] Seq=1 Ack=1 Win=502 Len=18', 'B → A  5000 → 48212 [ACK] Seq=1 Ack=19 Win=509 Len=0', 'B → A  5000 → 48212 [RST, ACK] Seq=1 Ack=19 Win=509 Len=0']
  }[k];
  var right = { refused: 'Connection refused', timeout: 'Connection timed out (no answer)', ok: 'Connected', reset: 'Connection reset by the other side' }[k];
  return choiceQ('refused', 'hs', 'Host A\'s capture shows:<ul class="qlines">' + lines.map(function (l) { return '<li>' + esc(l) + '</li>'; }).join('') + '</ul>What does A\'s program report?', right,
    ['Connection refused', 'Connection timed out (no answer)', 'Connected', 'Connection reset by the other side'].filter(function (x) { return x !== right; }),
    'RST in answer to a SYN means nothing listens there. Resent SYNs mean nothing answers at all.', { refused: 'B answered the SYN with RST: no program listens on port 5000.', timeout: 'Nothing answers, so A keeps resending the SYN and finally gives up.', ok: 'All three handshake segments are there.', reset: 'An established connection got RST: the other program aborted it.' }[k], { kind: 'refused', k: k });
}
function payloadQ() {
  var N = pick([5, 8, 8, 10, 11]), L = rnd(0, 1448), T = 20 + 4 * N + L;
  return numQ('payload', 'num', 'An IPv4 packet has <b>Total Length ' + T + '</b> and a 20-byte IP header. The TCP header length field is <b>' + N + '</b>. How many <b>data bytes</b> does the segment carry?', L,
    'Data = total − IP header − TCP header. The TCP field counts 4-byte words.', T + ' − 20 − ' + N + ' × 4 = ' + L + '.', { kind: 'payload', T: T, N: N });
}
/* ---------- Hard */
function lossAckQ() {
  var S = pick([100, 500, 1000, 1448]), N = rnd(5, 9), k = rnd(1, N - 2), j = rnd(k + 1, N), after = Math.random() < 0.35;
  if (after) return numQ('lossAck', 'loss', 'Host A sends ' + N + ' segments of ' + S + ' bytes (the first has Seq=1). Only segment ' + k + ' is lost. B ACKs every arrival at once. A resends segment ' + k + ', and it arrives. What <b>Ack</b> does B send then?', 1 + S * N,
    'B already holds every other segment, out of order.', 'The resend fills the only gap, so B acknowledges everything: 1 + ' + N + ' × ' + S + ' = ' + (1 + S * N) + '.', { kind: 'lossAfter', S: S, N: N, k: k });
  return numQ('lossAck', 'loss', 'Host A sends ' + N + ' segments of ' + S + ' bytes (the first has Seq=1). Only segment ' + k + ' is lost. B ACKs every arrival at once. What <b>Ack</b> does B send when segment ' + j + ' arrives?', 1 + S * (k - 1),
    'B cannot acknowledge past a gap.', 'Segment ' + k + ' starts at 1 + ' + (k - 1) + ' × ' + S + ' = ' + (1 + S * (k - 1)) + '. Until it arrives, every ACK says ' + (1 + S * (k - 1)) + '.', { kind: 'lossDup', S: S, N: N, k: k, j: j });
}
function lossHowQ() {
  var N = rnd(4, 10), k = rnd(1, N), d = N - k, right = d >= 3 ? 'Fast retransmit after the third duplicate ACK' : 'A timeout';
  return choiceQ('lossHow', 'loss', 'Host A sends ' + N + ' segments in a row, and only segment ' + k + ' is lost. B ACKs every arrival at once. How does A find out and resend it?', right,
    ['Fast retransmit after the third duplicate ACK', 'A timeout', 'B asks for it with a NAK (negative acknowledgment)', 'A resends every segment after it'].filter(function (x) { return x !== right; }),
    'Count the segments after the lost one: each brings one duplicate ACK.', d + ' segment' + (d === 1 ? '' : 's') + ' follow' + (d === 1 ? 's' : '') + ' the lost one, so A gets ' + d + ' duplicate ACK' + (d === 1 ? '' : 's') + '. ' + (d >= 3 ? 'Three is enough for fast retransmit.' : 'That is fewer than three, so A waits for its timer.'), { kind: 'lossHow', N: N, k: k });
}
function rtoQ() {
  var a = rnd(5, 40), b = rnd(5, 120), R1 = 16 * a, R2 = 8 * b, karn = Math.random() < 0.35, mid = 8 * rnd(5, 200);
  var var2 = 0.375 * R1 + 0.25 * Math.abs(R1 - R2), s2 = 0.875 * R1 + 0.125 * R2, rto = s2 + 4 * var2;
  var list = karn ? R1 + ', ' + mid + ' (from a segment that was sent twice), ' + R2 : R1 + ', ' + R2;
  return numQ('rto', 'timer', 'A connection gets its first round-trip samples: <b>' + list + '</b> ms. Using RFC 6298 (no minimum), what is the <b>RTO</b> after the last sample, in ms?', rto,
    'First sample: SRTT = R, RTTVAR = R/2. Then RTTVAR = ¾RTTVAR + ¼|SRTT − R| (old SRTT), SRTT = ⅞SRTT + ⅛R, RTO = SRTT + 4·RTTVAR.' + (karn ? ' Karn\'s rule skips the doubtful sample.' : ''),
    (karn ? 'Karn\'s rule skips ' + mid + '. ' : '') + 'After ' + R1 + ': SRTT = ' + R1 + ', RTTVAR = ' + R1 / 2 + '. After ' + R2 + ': RTTVAR = ' + var2 + ', SRTT = ' + s2 + ', RTO = ' + s2 + ' + 4 × ' + var2 + ' = ' + rto + ' ms.', { kind: 'rto', R1: R1, R2: R2, karn: karn, mid: mid });
}
function synRetryQ() {
  var v = pick(['linuxK', 'linuxAll', 'winAll', 'custom']);
  if (v === 'linuxK') { var k = rnd(2, 6); return numQ('syn', 'timer', 'Nothing answers Host A\'s SYN. A\'s first timeout is 1 s, and each timeout doubles the next one. How many <b>seconds</b> after the first SYN is the <b>' + ['', '1st', '2nd', '3rd', '4th', '5th', '6th'][k] + ' resend</b>?', Math.pow(2, k) - 1, 'Add the waits: 1, 2, 4, …', 'The waits are ' + [1, 2, 4, 8, 16, 32].slice(0, k).join(' + ') + ' = ' + (Math.pow(2, k) - 1) + ' s.', { kind: 'synK', k: k }); }
  if (v === 'linuxAll') return numQ('syn', 'timer', 'Linux resends an unanswered SYN <b>6 times</b> (net.ipv4.tcp_syn_retries = 6), starting with a 1 s timeout and doubling it each time. After how many <b>seconds</b> does connect give up with "Connection timed out"?', 127, 'It waits 1 s, then 2 s, … , and after the 6th resend it waits once more.', '1 + 2 + 4 + 8 + 16 + 32 + 64 = 127 s.', { kind: 'synAll', r0: 1, n: 6 });
  if (v === 'winAll') return numQ('syn', 'timer', 'A Windows host starts with a <b>3 s</b> timeout (InitialRto 3000 ms), doubles it each time, and resends an unanswered SYN <b>twice</b> (MaxSynRetransmissions 2). After how many <b>seconds</b> does it give up?', 21, 'Add the waits after the first SYN and each of the two resends.', '3 + 6 + 12 = 21 s.', { kind: 'synAll', r0: 3, n: 2 });
  var r0 = pick([1, 2, 3]), n = rnd(2, 5), tot = r0 * (Math.pow(2, n + 1) - 1);
  return numQ('syn', 'timer', 'A host starts with a <b>' + r0 + ' s</b> timeout, doubles it each time, and resends an unanswered SYN <b>' + n + ' times</b>. After how many <b>seconds</b> does it give up?', tot, 'Add one wait after the first SYN and one after each resend.', 'The waits are ' + Array.apply(null, Array(n + 1)).map(function (x, i) { return r0 * Math.pow(2, i); }).join(' + ') + ' = ' + tot + ' s.', { kind: 'synAll', r0: r0, n: n });
}
function wrapQ() {
  var s = MOD - rnd(1, 1448), L = rnd(1, 1448);
  return numQ('wrap', 'num', 'A segment has raw <b>Seq=<span class="addr">' + s + '</span></b> and <b>Len=' + L + '</b>. What raw Seq does the sender\'s next segment have?', m32(s + L),
    'Sequence numbers are 32 bits: after 4294967295 comes 0.', s + ' + ' + L + ' = ' + (s + L) + ', and ' + (s + L) + ' − 4294967296 = ' + m32(s + L) + '.', { kind: 'wrap', s: s, L: L });
}
function thrQ() {
  var R = pick([10, 20, 25, 40, 50, 80, 100]), M = pick([1, 2, 4, 5, 8, 10, 16, 20, 40]), W = M * R * 125;
  return numQ('thr', 'win', 'The receiver\'s window stays at <b>' + fmt(W) + ' bytes</b>, and the round-trip time is <b>' + R + ' ms</b>. At most how many <b>Mbit/s</b> can the sender reach?', M,
    'At most one window per round trip: window × 8 ÷ RTT.', fmt(W) + ' × 8 bits ÷ ' + R + ' ms = ' + fmt(W * 8) + ' ÷ 0.' + String(R / 1000).split('.')[1] + ' s = ' + M + ' Mbit/s.', { kind: 'thr', W: W, R: R });
}
function zeroQ() {
  var right = 'Nothing until a timer runs out; then a small window probe';
  return choiceQ('zero', 'win', 'Host B\'s ACK says <b>Win=0</b>, and Host A still has data to send. What does A send next?', right, ['Its next full segment at once', 'A RST to end the connection', 'The same data again, every RTT'],
    'A must not send data into a closed window, but it must not wait forever either.', 'A starts the persist timer. When it runs out, it sends a window probe (on Linux: no data and Seq one below SND.UNA; Wireshark says Keep-Alive), and B answers with its current window.', { kind: 'zero' });
}
function impossibleQ() {
  var a = rnd(2, 5) * 50, b = rnd(1, 6) * 10;
  var run = simulate({ mssA: 1000, mssB: 1000, rbufA: 4000, rbufB: 4000, writes: [{ side: 'A', at: 0, bytes: a }, { side: 'B', onRead: a, bytes: b }], closeA: { kind: 'at', at: 400 }, closeB: { kind: 'onFin', delay: 0 }, dack: true, sack: false });
  var cap = capture(run, {}), lines = cap.map(function (f) { return { t: f.src + ' → ' + f.dst + '  ' + f.info, sg: f.sg }; });
  var k = pick(['ack', 'fin', 'synack', 'seq']), idx, bad;
  if (k === 'ack') { idx = indexWhere(lines, function (l) { return l.sg.from === 'B' && l.sg.kind === 'data'; }); bad = lines[idx].t.replace('Ack=' + lines[idx].sg.ack, 'Ack=' + (lines[idx].sg.ack + pick([50, 100, 200]))); }
  else if (k === 'fin') { idx = lastWhere(lines, function (l) { return l.sg.from === 'A' && l.sg.kind === 'ack'; }); bad = lines[idx].t.replace('Ack=' + lines[idx].sg.ack, 'Ack=' + (lines[idx].sg.ack - 1)); }
  else if (k === 'synack') { idx = 1; bad = lines[1].t.replace('Ack=1', 'Ack=0'); }
  else { idx = indexWhere(lines, function (l) { return l.sg.from === 'A' && l.sg.kind === 'fin'; }); if (idx < 0) idx = indexWhere(lines, function (l) { return l.sg.from === 'A' && l.sg.f.F; }); bad = lines[idx].t.replace('Seq=' + lines[idx].sg.seq, 'Seq=' + (lines[idx].sg.seq + pick([1, 10, 100]))); }
  var shown = lines.map(function (l, i) { return i === idx ? bad : l.t; });
  var why = { ack: 'B acknowledges bytes that A never sent: A sent only ' + a + ' bytes, so B\'s Ack can be at most ' + (a + 1) + '.', fin: 'The last ACK must acknowledge B\'s FIN, which uses one number: Ack = FIN\'s Seq + 1.', synack: 'B\'s SYN, ACK must acknowledge A\'s SYN, which used number 0, so its Ack must be 1.', seq: 'A\'s FIN must start right after A\'s last data byte, at Seq=' + (a + 1) + '.' }[k];
  return choiceQ('impossible', 'num', 'One line of this capture at Host A (relative numbers, no losses) cannot be right. Which one?<ol class="qlines">' + shown.map(function (l, i) { return '<li>' + (i + 1) + '. ' + esc(l) + '</li>'; }).join('') + '</ol>', 'Line ' + (idx + 1),
    shuffle(shown.map(function (l, i) { return 'Line ' + (i + 1); }).filter(function (x) { return x !== 'Line ' + (idx + 1); })), 'Check every Ack against what the other side has really sent, and remember SYN and FIN use one number each.', why, { kind: 'impossible', k: k, a: a, b: b, line: idx + 1, shown: shown });
}
function indexWhere(a, f) { for (var i = 0; i < a.length; i++) if (f(a[i])) return i; return -1; }
function lastWhere(a, f) { for (var i = a.length - 1; i >= 0; i--) if (f(a[i])) return i; return -1; }
var GEN = {
  E: [flagQ, nextAckQ, hdrLenQ, mssQ, stateQ, spellQ, labelQ],
  M: [hsQ, ladderQ, advWinQ, usableQ, wsQ, twQ, refusedQ, payloadQ],
  H: [lossAckQ, lossHowQ, rtoQ, synRetryQ, wrapQ, thrQ, zeroQ, impossibleQ]
};
function makeRound(level, n) {
  var out = [], bag = [];
  while (out.length < n) { if (!bag.length) bag = shuffle(GEN[level].slice()); out.push(bag.pop()()); }
  return out;
}

/* ===================================================== CHALLENGE: play */
var BADGES = [
  { id: 'first', b: '🎯', t: 'First round', d: 'Finish a challenge round' },
  { id: 'perfect', b: '💯', t: 'Perfect 10', d: 'Answer all ten questions right' },
  { id: 'streak', b: '🔥', t: 'On fire', d: 'Five right answers in a row' },
  { id: 'sprint', b: '⚡', t: 'Speed runner', d: 'Eight right answers in a sprint' },
  { id: 'scholar', b: '📘', t: 'Scholar', d: 'Finish all eight lessons' },
  { id: 'hs', b: '🤝', t: 'Handshake', d: 'Three handshake questions right in one round' },
  { id: 'num', b: '🔢', t: 'Byte counter', d: 'Three numbering questions right in one round' },
  { id: 'win', b: '🪟', t: 'Window watcher', d: 'Three window questions right in one round' },
  { id: 'loss', b: '🔎', t: 'Loss detective', d: 'Two loss questions right in a Hard round' },
  { id: 'timer', b: '⏱', t: 'Timer tuner', d: 'Two timer questions right in one round' },
  { id: 'close', b: '🚪', t: 'Clean close', d: 'Two closing questions right in one round' }
];
function earn(id) { if (progress.badges[id]) return false; progress.badges[id] = Date.now(); store.set('progress', progress); return true; }
function renderShelf() {
  $('#badgeShelf').innerHTML = BADGES.map(function (b) { return '<span class="badge' + (progress.badges[b.id] ? '' : ' locked') + '" title="' + esc(b.d) + '"><span class="b" aria-hidden="true">' + b.b + '</span>' + b.t + '<span class="sr" style="position:absolute;left:-9999px">' + (progress.badges[b.id] ? ' (earned)' : ' (not yet: ' + esc(b.d) + ')') + '</span></span>'; }).join('');
  var best = progress.best; $('#bestLine').textContent = 'Best scores: Easy ' + (best.E || 0) + ', Medium ' + (best.M || 0) + ', Hard ' + (best.H || 0) + (best.S ? ', Sprint ' + best.S : '');
}
var game = null;
function startRound() {
  var level = ($('.level[aria-pressed=true]') || $('.level')).getAttribute('data-level'), sprint = $('#sprint').checked;
  game = { level: level, sprint: sprint, qs: makeRound(level, sprint ? 40 : 10), i: 0, score: 0, streak: 0, bestStreak: 0, right: 0, answered: 0, log: [], tags: {}, ends: sprint ? Date.now() + 120000 : 0, timer: null };
  $('#ch-setup').hidden = true; $('#ch-end').hidden = true; $('#ch-play').hidden = false;
  $('#q_timerbar').hidden = !sprint;
  if (sprint) game.timer = setInterval(tick, 250);
  showQ();
}
function tick() { if (!game) return; var left = game.ends - Date.now(); $('#q_timer').style.width = Math.max(0, left / 1200) + '%'; if (left <= 0) { clearInterval(game.timer); endRound(); } }
function chips() {
  $('#q_n').textContent = game.sprint ? 'Answered ' + game.answered : 'Question ' + Math.min(game.i + 1, game.qs.length) + ' of ' + game.qs.length;
  $('#q_score').textContent = '★ ' + game.score; $('#q_streak').textContent = '🔥 streak ' + game.streak;
}
function showQ() {
  if (!game) return; chips();
  var q = game.qs[game.i], body = $('#q_body'); q.hinted = false;
  var answerUI = q.input === 'choice'
    ? '<div class="choices">' + q.choices.map(function (c, i) { return '<button class="choice" data-i="' + i + '">' + (/^\[TCP/.test(c) ? '<code>' + esc(c) + '</code>' : esc(c)) + '</button>'; }).join('') + '</div>'
    : '<div class="row"><input type="number" id="q_in" aria-label="Your answer" class="wide"><button class="btn" id="q_ok">Check</button></div>';
  body.innerHTML = '<div class="qtext">' + q.text + '</div>' + answerUI +
    '<div class="row"><button class="btn alt small" id="q_hint">Hint (−3)</button></div><div class="feedback" id="q_fb" aria-live="polite"></div><div class="row" id="q_nextrow" hidden><button class="btn amber" id="q_next">Next →</button></div>';
  $('#q_hint').onclick = function () { if (q.hinted || q.done) return; q.hinted = true; var fb = $('#q_fb'); fb.className = 'feedback'; fb.style.background = 'var(--amber-soft)'; fb.innerHTML = '💡 ' + q.hint; };
  if (q.input === 'choice') $$('.choice', body).forEach(function (b) { b.onclick = function () { answer(+b.getAttribute('data-i'), b); }; });
  else { $('#q_ok').onclick = function () { answer(Number($('#q_in').value)); }; $('#q_in').onkeydown = function (e) { if (e.key === 'Enter') answer(Number($('#q_in').value)); }; $('#q_in').focus(); }
  $('#q_next').onclick = nextQ;
}
function answer(v, btn) {
  var q = game.qs[game.i]; if (q.done) return;
  if (q.input === 'number' && ($('#q_in').value.trim() === '' || isNaN(v))) { var f0 = $('#q_fb'); f0.className = 'feedback bad'; f0.innerHTML = 'Type a number first.'; return; }
  q.done = true;
  var ok = q.input === 'number' ? Math.abs(v - q.answer) < 1e-9 : v === q.answer, fb = $('#q_fb'); fb.style.background = '';
  game.answered++;
  if (ok) {
    game.right++; game.streak++; game.bestStreak = Math.max(game.bestStreak, game.streak);
    var pts = 10 + Math.min(game.streak - 1, 5) * 2 - (q.hinted ? 3 : 0); game.score += pts;
    game.tags[q.tag] = (game.tags[q.tag] || 0) + 1;
    fb.className = 'feedback ok pop'; fb.innerHTML = '<b>Correct! +' + pts + '</b>' + (game.streak >= 3 ? ' 🔥 ' + game.streak + ' in a row' : '') + '<br>' + q.explain;
  } else {
    game.streak = 0;
    var right = q.input === 'choice' ? q.choices[q.answer] : q.answer;
    fb.className = 'feedback bad'; fb.innerHTML = '<b>Not quite.</b> The answer is <b>' + esc(right) + '</b>.<br>' + q.explain;
  }
  game.log.push({ q: q.text, ok: ok, right: q.input === 'choice' ? q.choices[q.answer] : String(q.answer) });
  if (q.input === 'choice') $$('#q_body .choice').forEach(function (b, i) { b.disabled = true; if (i === q.answer) b.classList.add('right'); else if (b === btn) b.classList.add('wrong'); });
  else { $('#q_in').disabled = true; $('#q_ok').disabled = true; }
  $('#q_hint').disabled = true; $('#q_nextrow').hidden = false; $('#q_next').focus(); chips();
}
function nextQ() { game.i++; if (game.i >= game.qs.length || (game.sprint && Date.now() > game.ends)) endRound(); else showQ(); }
function code(level, score, right, total) {   // completion code with a checksum (deters casual editing; not secure)
  var s = 'TV|' + level + '|' + score + '|' + right + '|' + total, h = 2166136261;
  for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
  return level + score + '-' + right + 'of' + total + '-' + (h % 1679616).toString(36).toUpperCase().padStart(4, '0');
}
function checkCode(c) {
  var m = /^([EMHS])(\d+)-(\d+)of(\d+)-([0-9A-Z]{4})$/.exec(String(c).trim().toUpperCase().replace('OF', 'of'));
  if (!m) return null; return code(m[1], +m[2], +m[3], +m[4]) === m[0] ? { level: m[1], score: +m[2], right: +m[3], total: +m[4] } : false;
}
function endRound() {
  if (!game) return; clearInterval(game.timer);
  var g = game, total = g.sprint ? g.answered : g.qs.length, pct = total ? g.right / total : 0, stars = pct >= 0.9 ? 3 : pct >= 0.7 ? 2 : pct >= 0.5 ? 1 : 0;
  var lvl = g.sprint ? 'S' : g.level, fresh = [], t = g.tags;
  function tryEarn(cond, id) { if (cond && earn(id)) fresh.push(id); }
  tryEarn(g.answered > 0, 'first'); tryEarn(!g.sprint && g.right === 10, 'perfect'); tryEarn(g.bestStreak >= 5, 'streak'); tryEarn(g.sprint && g.right >= 8, 'sprint');
  tryEarn((t.hs || 0) >= 3, 'hs'); tryEarn((t.num || 0) >= 3, 'num'); tryEarn((t.win || 0) >= 3, 'win'); tryEarn(g.level === 'H' && (t.loss || 0) >= 2, 'loss'); tryEarn((t.timer || 0) >= 2, 'timer'); tryEarn((t.close || 0) >= 2, 'close');
  var newBest = g.score > (progress.best[lvl] || 0); if (newBest) progress.best[lvl] = g.score;
  store.set('progress', progress); addXP(g.score);
  var cd = code(lvl, g.score, g.right, total), lname = { E: 'Easy', M: 'Medium', H: 'Hard', S: 'Sprint' }[lvl];
  $('#ch-play').hidden = true; var end = $('#ch-end'); end.hidden = false;
  end.innerHTML = '<h2>' + (stars === 3 ? 'Outstanding!' : stars === 2 ? 'Great work!' : stars === 1 ? 'Good start!' : 'Keep practicing!') + '</h2>' +
    '<div class="stars" aria-label="' + stars + ' of 3 stars">' + '★★★'.slice(0, stars) + '<span style="color:#D3E3EC">' + '★★★'.slice(0, 3 - stars) + '</span></div>' +
    '<p style="font-size:19px"><b>' + g.score + ' points</b> · ' + g.right + ' of ' + total + ' right · best streak ' + g.bestStreak + (newBest ? ' · <span class="oneway">new best for ' + lname + '!</span>' : '') + '</p>' +
    (fresh.length ? '<h3>New badges</h3><div class="badges">' + fresh.map(function (id) { var b = BADGES.filter(function (x) { return x.id === id; })[0]; return '<span class="badge pop"><span class="b">' + b.b + '</span>' + b.t + '</span>'; }).join('') + '</div>' : '') +
    '<h3>Completion code</h3><p>If you are asked for it, copy this code.</p><span class="code" id="ccode">' + cd + '</span> <button class="btn alt small" id="ccopy">Copy</button>' +
    '<div class="row" style="margin-top:16px"><button class="btn amber" id="again">Play again</button>' + (g.level !== 'H' ? '<button class="btn" id="harder">Try ' + (g.level === 'E' ? 'Medium' : 'Hard') + '</button>' : '') + '<button class="btn alt" id="toLearn">Review the lessons</button></div>' +
    '<details><summary>Review your answers</summary><ol class="list">' + g.log.map(function (l) { return '<li>' + (l.ok ? '<span class="yes">✓</span> ' : '<span class="no">✗</span> ') + l.q + ' <i>Answer: ' + esc(l.right) + '</i></li>'; }).join('') + '</ol></details>';
  $('#ccopy').onclick = function () { copyText(cd, $('#ccopy')); };
  $('#again').onclick = function () { startRound(); };
  if ($('#harder')) $('#harder').onclick = function () { setLevel(g.level === 'E' ? 'M' : 'H'); startRound(); };
  $('#toLearn').onclick = function () { go('learn'); };
  if (stars === 3) burst();
  game = null; renderShelf(); writeLink();
}
function burst() {
  if (reduceMotion) return;
  var b = document.createElement('div'); b.className = 'burst'; b.setAttribute('aria-hidden', 'true');
  for (var i = 0; i < 40; i++) { var s = document.createElement('span'); s.textContent = pick(['★', '✦', '●', '▲']); s.style.left = rnd(0, 100) + '%'; s.style.color = pick(['#00A2D7', '#F5A524', '#13A88A', '#7B61FF']); s.style.animationDelay = (Math.random() * 0.6) + 's'; b.appendChild(s); }
  document.body.appendChild(b); setTimeout(function () { if (b.parentNode) b.parentNode.removeChild(b); }, 2800);
}
function setLevel(l) { $$('.level').forEach(function (b) { b.setAttribute('aria-pressed', String(b.getAttribute('data-level') === l)); }); }

/* ===================================================== hero figure on the start screen */
function drawHero() {
  var f = new Fig($('#heroFig'), 0, 7.2, 0, 4, 1.6), xa = 1.4, xb = 5.8;
  f.slab(xa - 0.75, 3.35, 1.5, 0.5, { text: 'Host A', fill: '#fff', fs: 9.5, bold: true });
  f.slab(xb - 0.75, 3.35, 1.5, 0.5, { text: 'Host B', fill: '#fff', fs: 9.5, bold: true });
  f.line(xa, 3.3, xa, 0.15, { color: '#fff', lw: 2.2 }); f.line(xb, 3.3, xb, 0.15, { color: '#fff', lw: 2.2 });
  [[xa, 3.0, xb, 2.55, 'SYN  Seq=0', '#E7E1FF', 'w'], [xb, 2.55, xa, 2.1, 'SYN, ACK  Ack=1', '#E7E1FF', 'w'], [xa, 2.1, xb, 1.65, 'ACK  Ack=1', '#CFE6F0', 'w'], [xa, 1.55, xb, 1.1, 'Seq=1 Len=100', '#F5A524', 'w'], [xb, 1.1, xa, 0.65, 'ACK  Ack=101', '#CFE6F0', 'w']].forEach(function (a) {
    f.arrow(a[0], a[1], a[2], a[3], { color: a[5], lw: 2, mk: a[6] });
    f.text((a[0] + a[2]) / 2, (a[1] + a[3]) / 2 + 0.17, a[4], { fs: 8, color: '#fff', bold: true });
  });
}

/* ===================================================== navigation and links */
var VIEWS = ['home', 'learn', 'calc', 'challenge'], current = 'home', calcReady = false;
function go(mode) {
  current = VIEWS.indexOf(mode) >= 0 ? mode : 'home';
  if (lessonState.player) lessonState.player.stop();
  if (calcPlayer) calcPlayer.stop();
  VIEWS.forEach(function (v) { $('#view-' + v).hidden = v !== current; });
  if (current !== 'learn') document.body.classList.remove('widepage');
  $$('.modes button[data-mode]').forEach(function (b) { b.setAttribute('aria-pressed', String(b.getAttribute('data-mode') === current)); });
  if (current === 'learn') { if (lessonState.map === undefined) lessonState.map = !Object.keys(progress.lessons).length; if (lessonState.map) openMap(); else openLesson(lessonState.i); }
  if (current === 'challenge') { if (game) { clearInterval(game.timer); game = null; } $('#ch-setup').hidden = false; $('#ch-play').hidden = true; $('#ch-end').hidden = true; renderShelf(); }
  if (current === 'calc') { if (!calcReady) { calcInit(); calcReady = true; } calc(); }
  window.scrollTo(0, 0); writeLink();
}
function writeLink() {
  try {
    var q = new URLSearchParams(); q.set('mode', current);
    if (current === 'learn') q.set('lesson', lessonState.map ? 'map' : lessonState.i + 1);
    if (current === 'calc' && calcState) {
      var s = calcState; q.set('preset', s.preset); q.set('mss', s.mss); q.set('rbuf', s.rbufB); q.set('sack', s.sack); q.set('dack', s.dack); q.set('ws', s.ws); q.set('close', s.close);
      if (s.lose.length) q.set('lose', s.lose.join('-')); if (s.raw) q.set('raw', 1);
    }
    if (current === 'challenge') q.set('level', ($('.level[aria-pressed=true]') || $('.level')).getAttribute('data-level'));
    if (OS === 'windows') q.set('os', 'windows');
    if (window.history && history.replaceState) history.replaceState(null, '', location.pathname + '?' + q.toString());
  } catch (e) { /* some embeds block history changes */ }
}
function readLink() {
  var q; try { q = new URLSearchParams(location.search); } catch (e) { return null; }
  if (q.get('lesson')) { lessonState.map = q.get('lesson') === 'map'; lessonState.i = Math.max(0, Math.min(LESSONS.length - 1, (+q.get('lesson') || 1) - 1)); }
  if (/^[EMH]$/.test(q.get('level') || '')) setLevel(q.get('level'));
  if (q.get('os') === 'windows' || q.get('os') === 'linux') OS = q.get('os');
  var p = q.get('preset'), touched = false;
  calcState = calcReset(PRESETS[p] ? p : 'clean');
  function num(k, lo, hi, key) { var v = q.get(k); if (v !== null && /^-?\d+$/.test(v) && +v >= lo && +v <= hi) { calcState[key || k] = +v; touched = true; } }
  num('mss', 1, 9000); num('rbuf', 1, 1000000, 'rbufB'); num('sack', 0, 1); num('dack', 0, 1); num('ws', -1, 14); num('raw', 0, 1);
  if (['a', 'b', 'both', 'none'].indexOf(q.get('close')) >= 0) calcState.close = q.get('close');
  if (q.get('lose')) calcState.lose = q.get('lose').split(/[-,]/).map(Number).filter(function (n) { return n >= 1 && n <= 999; });
  return q.get('mode');
}

/* ===================================================== start */
function init() {
  var mode = readLink();   // read the link before anything rewrites it
  drawHero(); showXP(false); renderShelf(); setOS(OS);
  $$('.modes button[data-mode]').forEach(function (b) { b.onclick = function () { go(b.getAttribute('data-mode')); }; });
  $$('[data-go]').forEach(function (b) { b.onclick = function () { go(b.getAttribute('data-go')); }; });
  $$('.topbar [data-os]').forEach(function (b) { b.onclick = function () { setOS(b.getAttribute('data-os')); writeLink(); }; });
  osListeners.push(function () { if (current === 'learn' && lessonState.player) lessonState.player.show(); if (current === 'calc' && calcPlayer) calcPlayer.show(); });
  $('#home').onclick = function () { go('home'); };
  $$('.level').forEach(function (b) { b.onclick = function () { setLevel(b.getAttribute('data-level')); writeLink(); }; });
  $('#ch-start').onclick = startRound;
  $('#q_quit').onclick = function () { endRound(); };
  $('#resetProgress').onclick = function () { progress = { xp: 0, lessons: {}, badges: {}, best: {} }; store.set('progress', progress); showXP(false); renderShelf(); if (current === 'learn') renderStepper(); };
  $('#verifyBtn').onclick = function () { var r = checkCode($('#verifyIn').value); $('#verifyOut').innerHTML = r ? '<span class="yes">Valid:</span> ' + { E: 'Easy', M: 'Medium', H: 'Hard', S: 'Sprint' }[r.level] + ', ' + r.score + ' points, ' + r.right + ' of ' + r.total + ' right.' : '<span class="no">Not a valid code.</span>'; };
  go(mode || 'home');
}
init();
window.TCPVisualizer = { lossState: lossState, lossCaption: lossCaption, simulate: simulate, capture: capture, rtoSeries: rtoSeries, decodeHeader: decodeHeader, headerBytes: headerBytes, m32: m32, snapAt: snapAt, stateAt: stateAt, SPELL: SPELL,
  GEN: GEN, makeRound: makeRound, solveLesson: function () { if (lessonState.solve) lessonState.solve(); }, code: code, checkCode: checkCode, LESSONS: LESSONS, PRESETS: PRESETS, calcCfg: calcCfg, calcReset: calcReset };
})();
</script>
</body>
</html>
