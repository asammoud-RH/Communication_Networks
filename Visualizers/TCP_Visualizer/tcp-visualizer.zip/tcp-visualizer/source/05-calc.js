
/* =====================================================================
   CALCULATOR: the Connection Sandbox and quick calculators
   ===================================================================== */
var PRESETS = {
  clean: { t: 'Clean transfer', c: { aBytes: 600, bBytes: 0, mss: 100, ts: 0, sack: 1, ws: -1, rbufB: 1000, rbufA: 1000, read: 'now', delay: 50, rate: 160, dack: 0, nagle: 0, rtoMin: 1000, close: 'a', bDelay: 100, listen: 1, isnA: 1000, isnB: 5000, lose: [] } },
  echo: { t: 'Ethernet-sized echo (Timestamps, Window Scale, delayed ACKs)', c: { aBytes: 6, bBytes: 11, mss: 1460, ts: 1, sack: 1, ws: 7, rbufB: 65536, rbufA: 65536, read: 'now', delay: 20, rate: 10000, dack: 1, close: 'a', bDelay: 100 } },
  slow: { t: 'Slow reader (zero window)', c: { aBytes: 900, rbufB: 300, read: 'pause', readUntil: 3000, close: 'none' } },
  fast: { t: 'One loss, fast retransmit', c: { aBytes: 800, rbufB: 1000, lose: [5], close: 'none' } },
  rto: { t: 'One loss, timeout (last segment lost)', c: { aBytes: 400, rbufB: 1000, lose: [7], close: 'none' } },
  lostack: { t: 'Lost ACK', c: { aBytes: 300, rbufB: 1000, lose: [7], close: 'none' } },
  lostsyn: { t: 'Lost SYN', c: { aBytes: 100, lose: [1], close: 'none' } },
  closed: { t: 'Port closed (RST)', c: { listen: 0, close: 'none' } },
  half: { t: 'Half-close: A closes, B keeps sending', c: { aBytes: 100, bBytes: 250, bOnFin: 1, close: 'a', bDelay: 400 } },
  simclose: { t: 'Simultaneous close', c: { aBytes: 0, close: 'both', closeAt: 500 } },
  wrap: { t: 'Sequence numbers wrap past 2^32', c: { aBytes: 300, isnA: 4294967200, isnB: 4294967290, raw: 1, close: 'a' } },
  unread: { t: 'Close with unread data (RST)', c: { aBytes: 120, read: 'never', close: 'b', closeAt: 800 } }
};
var CALC_DEF = PRESETS.clean.c;
var calcState = null;
function calcReset(p) { var s = {}, k; for (k in CALC_DEF) s[k] = CALC_DEF[k]; s.lose = []; s.raw = 0; s.readUntil = 2000; s.closeAt = 600; s.bOnFin = 0; s.preset = p || 'clean';
  var pc = (PRESETS[p] || PRESETS.clean).c; for (k in pc) s[k] = pc[k]; s.lose = (pc.lose || []).slice(); return s; }
function calcCfg(s) {
  var w = [];
  if (s.aBytes > 0) w.push({ side: 'A', at: 0, bytes: s.aBytes });
  if (s.bBytes > 0) w.push(s.bOnFin ? { side: 'B', at: s.bDelay > 0 ? 350 : 0, bytes: s.bBytes } : { side: 'B', onRead: Math.max(1, s.aBytes), bytes: s.bBytes });
  var c = { isnA: s.isnA, isnB: s.isnB, mssA: s.mss, mssB: s.mss, ts: !!s.ts, sack: !!s.sack, ws: s.ws, rbufA: s.rbufA, rbufB: s.rbufB, delay: s.delay, rate: s.rate,
    dack: !!s.dack, nagle: !!s.nagle, rtoMin: s.rtoMin, listen: !!s.listen, writes: w, lose: s.lose.slice(),
    readB: s.read === 'now' ? { kind: 'now' } : s.read === 'pause' ? { kind: 'pause', until: s.readUntil } : { kind: 'never' } };
  if (s.close === 'a') { c.closeA = s.aBytes > 0 ? { kind: 'afterWrites' } : { kind: 'at', at: s.closeAt }; c.closeB = { kind: 'onFin', delay: s.bDelay }; }
  else if (s.close === 'b') { c.closeB = { kind: 'at', at: s.closeAt }; c.closeA = { kind: 'onFin', delay: s.bDelay }; }
  else if (s.close === 'both') { c.closeA = { kind: 'at', at: s.closeAt }; c.closeB = { kind: 'at', at: s.closeAt }; }
  else { c.closeA = { kind: 'never' }; c.closeB = { kind: 'never' }; }
  if (s.bOnFin && s.close === 'a') { c.closeA = { kind: 'afterWrites' }; c.closeB = { kind: 'onFin', delay: s.bDelay }; }
  return c;
}
var CALC_FIELDS = [
  ['aBytes', 'A writes (bytes)', 'num', 0, 20000], ['bBytes', 'B writes back (bytes)', 'num', 0, 20000],
  ['mss', 'MSS, Maximum Segment Size (both sides)', 'sel', [[100, '100 (toy size)'], [536, '536'], [1460, '1460 (Ethernet)']]],
  ['rbufB', 'B\'s receive buffer (bytes)', 'num', 1, 1000000], ['rbufA', 'A\'s receive buffer (bytes)', 'num', 1, 1000000],
  ['read', 'B\'s application', 'sel', [['now', 'reads at once'], ['pause', 'pauses, then reads'], ['never', 'never reads']]], ['readUntil', 'It starts reading at (ms)', 'num', 0, 100000],
  ['delay', 'One-way delay (ms)', 'num', 0, 5000], ['rate', 'Link rate (kbit/s)', 'num', 8, 10000000],
  ['ts', 'Timestamps option', 'chk'], ['sack', 'SACK (Selective Acknowledgment)', 'chk'], ['ws', 'Window Scale', 'sel', [[-1, 'off'], [0, 'shift 0 (× 1)'], [2, 'shift 2 (× 4)'], [7, 'shift 7 (× 128)'], [10, 'shift 10 (× 1024)'], [14, 'shift 14 (× 16384)']]],
  ['dack', 'Delayed ACKs (40 ms)', 'chk'], ['nagle', 'Nagle\'s algorithm', 'chk'], ['rtoMin', 'Minimum RTO (retransmission timeout)', 'sel', [[1000, '1 s (standard)'], [200, '200 ms (Linux)']]],
  ['close', 'Who closes', 'sel', [['a', 'A, after writing'], ['b', 'B first'], ['both', 'both at once'], ['none', 'nobody']]], ['closeAt', 'Closes at (ms)', 'num', 0, 100000], ['bDelay', 'The other side closes after (ms)', 'num', 0, 100000],
  ['bOnFin', 'B keeps writing after A\'s FIN (half-close)', 'chk'], ['listen', 'B listens on the port', 'chk'],
  ['isnA', 'A\'s ISN (initial sequence number), raw', 'num', 0, 4294967295], ['isnB', 'B\'s ISN, raw', 'num', 0, 4294967295], ['raw', 'Show raw numbers', 'chk']
];
function calcInit() {
  if (!calcState) calcState = calcReset('clean');
  $('#calcRoot').innerHTML =
    '<div class="card"><h2>Connection sandbox</h2><p>Build a TCP (Transmission Control Protocol) connection: pick a preset, or click a segment in the timeline to lose it. Segments are named by their flags: SYN (synchronize), ACK (acknowledgment), FIN (finish), RST (reset).</p>' +
    '<div class="row"><label>Preset <select id="c_preset">' + Object.keys(PRESETS).map(function (k) { return '<option value="' + k + '">' + PRESETS[k].t + '</option>'; }).join('') + '</select></label></div>' +
    '<div class="row"><label>Lost segments <input type="text" id="c_lose" size="14" spellcheck="false" placeholder="for example 5, 9"></label><button class="btn alt small" id="c_noloss">No losses</button></div>' +
    '<details class="more"><summary>All settings</summary><div class="inputs" id="c_fields"></div></details>' +
    '<p id="c_err" class="no" aria-live="polite"></p><div class="calcgrid" id="c_stats"></div><details class="more"><summary>More numbers</summary><div class="calcgrid" id="c_stats2"></div></details><div id="c_badges"></div><div id="c_sum"></div></div>' +
    '<div class="card"><p class="figtitle">Timeline</p><div id="c_pl"></div><div class="fig tall capped"><svg id="c_ldr" role="img"></svg></div>' + LADDER_LEGEND + '</div>' +
    fold('What happened, in words', '<div id="c_ev"></div>') +
    fold('Buffers and the window (data from A to B)', '<div class="pl2"></div><div class="fig capped"><svg id="c_rib" role="img"></svg></div>' + RIBBON_LEGEND + '<div id="c_wst"></div>') +
    fold('State-transition diagram', '<p class="cmdnote">Each box is a state. The markers A and B show where each host is; each arrow is labeled event/action.</p><div class="pl2"></div><div class="fig capped fit"><svg id="c_sm" role="img"></svg></div><div class="soft" id="c_smstep" aria-live="polite"></div>' + SM_LEGEND) +
    fold('Wireshark-style capture at Host A', '<div id="c_pk"></div>') +
    '<div class="card"><h2>Quick calculators</h2><p class="cmdnote">Open one to use it.</p>' +
      '<details class="qc"><summary>Decode a TCP header</summary><p class="cmdnote">Paste the TCP header bytes in hexadecimal (for example from Wireshark: right-click the TCP layer, Copy, …as Hex Stream).</p><textarea id="q_hex" rows="3" style="width:100%;font-family:var(--mono)" spellcheck="false">bb 54 13 88 6d 70 1e 8f 00 00 00 00 a0 02 fa f0 9f 2e 00 00 02 04 05 b4 04 02 08 0a 0d cb 04 6b 00 00 00 00 01 03 03 07</textarea><div id="q_hexout"></div><div class="fig capped"><svg id="q_hexfig" role="img"></svg></div>' +
      '</details><details class="qc"><summary>Sequence and acknowledgment numbers</summary><div class="row"><label>Seq, the sequence number (raw) <input type="number" id="q_seq" class="wide" value="4294967200"></label><label>Len, the data length <input type="number" id="q_len" value="300"></label><label><input type="checkbox" id="q_syn"> SYN</label><label><input type="checkbox" id="q_fin"> FIN</label><label>Sender\'s ISN (initial sequence number) <input type="number" id="q_isn" class="wide" value="4294967100"></label></div><div class="calcgrid" id="q_seqout"></div>' +
      '</details><details class="qc"><summary>Windows and throughput</summary><div class="row"><label>Buffer <input type="number" id="q_buf" value="65536"></label><label>Unread <input type="number" id="q_unr" value="16384"></label><label>In flight <input type="number" id="q_inf" value="20000"></label><label>RTT, round-trip time (ms) <input type="number" id="q_rtt" value="40"></label></div><div class="row"><label>Or a window field <input type="number" id="q_wf" value="502"></label><label>scale shift <input type="number" id="q_ws" value="7" min="0" max="14"></label></div><div class="calcgrid" id="q_winout"></div>' +
      '</details><details class="qc"><summary>Retransmission timer (standard RFC 6298, Request for Comments)</summary><div class="row"><label>Round-trip time (RTT) samples (ms) <input type="text" id="q_rtts" size="28" value="100, 120, 300, 110"></label><label>Minimum <select id="q_min"><option value="1000">1 s</option><option value="200">200 ms</option><option value="0">none</option></select></label></div><div id="q_rtoout"></div>' +
      '</details><details class="qc"><summary>MSS (Maximum Segment Size) from the MTU (Maximum Transmission Unit)</summary><div class="row"><label>MTU (Maximum Transmission Unit) <input type="number" id="q_mtu" value="1500"></label><label>IP (Internet Protocol) <select id="q_ipv"><option value="20">IPv4 (20-byte header)</option><option value="40">IPv6 (40-byte header)</option></select></label><label><input type="checkbox" id="q_mts" checked> Timestamps</label></div><div class="calcgrid" id="q_mssout"></div>' +
    '</details></div>' +
    fold('Commands for Linux and Windows', '<div id="c_cmds"></div>') +
    fold('Terms used here', termsList(GLOSS.map(function (g) { return g[0]; }).join(' ')));
  var h = '';
  CALC_FIELDS.forEach(function (f) {
    if (f[2] === 'num') h += '<label>' + f[1] + '<input type="number" data-f="' + f[0] + '" min="' + f[3] + '" max="' + f[4] + '"></label>';
    else if (f[2] === 'sel') h += '<label>' + f[1] + '<select data-f="' + f[0] + '">' + f[3].map(function (o) { return '<option value="' + o[0] + '">' + o[1] + '</option>'; }).join('') + '</select></label>';
    else h += '<label style="flex-direction:row;align-items:center;gap:6px"><input type="checkbox" data-f="' + f[0] + '"> ' + f[1] + '</label>';
  });
  $('#c_fields').innerHTML = h;
  $$('#c_fields [data-f]').forEach(function (e) { e.onchange = function () { readCalc(); calc(); }; });
  $('#c_preset').onchange = function () { calcState = calcReset(this.value); fillCalc(); calc(); };
  $('#c_lose').onchange = function () { readCalc(); calc(); };
  $('#c_noloss').onclick = function () { calcState.lose = []; fillCalc(); calc(); };
  ['q_hex'].forEach(function (id) { $('#' + id).oninput = quickHex; });
  ['q_seq', 'q_len', 'q_syn', 'q_fin', 'q_isn'].forEach(function (id) { $('#' + id).oninput = quickSeq; $('#' + id).onchange = quickSeq; });
  ['q_buf', 'q_unr', 'q_inf', 'q_rtt', 'q_wf', 'q_ws'].forEach(function (id) { $('#' + id).oninput = quickWin; });
  $('#q_rtts').oninput = quickRto; $('#q_min').onchange = quickRto;
  ['q_mtu', 'q_ipv', 'q_mts'].forEach(function (id) { $('#' + id).oninput = quickMss; $('#' + id).onchange = quickMss; });
  cmdPanel($('#c_cmds'), ['states', 'connect', 'inside', 'settings', 'zero', 'loss', 'wireshark']);
  fillCalc(); quickHex(); quickSeq(); quickWin(); quickRto(); quickMss();
}
function fillCalc() {
  var s = calcState; $('#c_preset').value = PRESETS[s.preset] ? s.preset : 'clean';
  $$('#c_fields [data-f]').forEach(function (e) { var k = e.getAttribute('data-f'); if (e.type === 'checkbox') e.checked = !!s[k]; else e.value = s[k]; });
  $('#c_lose').value = s.lose.join(', ');
}
function readCalc() {
  var s = calcState, bad = [];
  CALC_FIELDS.forEach(function (f) {
    var e = $('#c_fields [data-f="' + f[0] + '"]'); if (!e) return;
    if (f[2] === 'chk') s[f[0]] = e.checked ? 1 : 0;
    else if (f[2] === 'sel') { var v = e.value; s[f[0]] = /^-?\d+$/.test(v) ? +v : v; }
    else { var n = Math.floor(+e.value); if (e.value === '' || isNaN(n) || n < f[3] || n > f[4]) bad.push(f[1] + ' must be ' + f[3] + ' to ' + fmt(f[4])); else s[f[0]] = n; }
  });
  s.lose = ($('#c_lose').value.match(/\d+/g) || []).map(Number).filter(function (n) { return n >= 1 && n <= 999; });
  $('#c_err').textContent = bad.join('. ');
}
var calcPlayer = null;
function calc() {
  if (!$('#c_ldr')) return;
  var s = calcState, run = simulate(calcCfg(s)), raw = !!s.raw;
  if (calcPlayer) calcPlayer.stop();
  var A = run.end.A, B = run.end.B, retx = run.segs.filter(function (x) { return x.retx; }).length, lastT = run.segs.length ? run.segs[run.segs.length - 1].tArr : 0;
  var deliv = B.delivered, tFirst = null, tLast = null;
  run.segs.forEach(function (x) { if (x.from === 'A' && x.len > 0) { if (tFirst === null) tFirst = x.tSend; } });
  var full = run.segs.filter(function (x) { return x.from === 'B' && x.f.A && x.ack >= 1 + s.aBytes && s.aBytes > 0; })[0];
  if (full) tLast = full.tArr;
  $('#c_stats').innerHTML = stat('Segments sent', run.segs.length) + stat('Resent', retx, retx > 0) + stat('Lost', run.segs.filter(function (x) { return x.lost; }).length) +
    stat('All of A\'s data ACKed at', tLast !== null ? ms(tLast) : (s.aBytes ? 'not yet' : '–'));
  $('#c_stats2').innerHTML = stat('Bytes that reached B in order', fmt(deliv) + ' of ' + fmt(s.aBytes)) + stat('Data per full segment', run.end.A.peerPay + ' bytes') + (tLast !== null && tFirst !== null && tLast > tFirst ? stat('Average throughput', fmt(Math.round(s.aBytes * 8 / (tLast - tFirst))) + ' kbit/s') : '') +
    stat('Final retransmission timeout (RTO) at A', A.srtt !== null ? ms(A.rto) : '1 s (no sample)');
  var sum = [];
  if (A.err) sum.push('Host A: ' + A.err + '.'); if (B.err) sum.push('Host B: ' + B.err + '.');
  $('#c_sum').innerHTML = sum.length ? '<p class="oneway">' + sum.join(' ') + '</p>' : '';
  var lastT = null;
  function render(T) {
    drawLadder($('#c_ldr'), run, { T: T, raw: raw, click: true });
    $$('#c_ldr [data-n]').forEach(function (g) { function tog() { var n = +g.getAttribute('data-n'), i = s.lose.indexOf(n); if (i >= 0) s.lose.splice(i, 1); else s.lose.push(n); s.lose.sort(function (a, b) { return a - b; }); fillCalc(); calc(); } g.onclick = tog; g.onkeydown = function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); tog(); } }; });
    drawRibbons($('#c_rib'), run, T); $('#c_wst').innerHTML = windowStats(run, T);
    drawStateMachine($('#c_sm'), run, T, { prevT: lastT }); $('#c_smstep').innerHTML = smStepText(run, lastT, T); lastT = T;
    $('#c_badges').innerHTML = stateBadges(run, T);
    $('#c_pk').innerHTML = packetList(run, T, raw);
    $('#c_ev').innerHTML = eventList(run, T) || '<p class="cmdnote">Nothing unusual: no losses, resets, or timeouts.</p>';
  }
  calcPlayer = makePlayer($('#c_pl'), run, render);
  $$('#calcRoot .pl2').forEach(function (b) { calcPlayer.attach(b); });
  writeLink();
}
function quickHex() {
  var t = $('#q_hex').value.replace(/0x/gi, '').replace(/[^0-9a-fA-F]/g, '');
  var b = []; for (var i = 0; i + 1 < t.length; i += 2) b.push(parseInt(t.substr(i, 2), 16));
  var r = decodeHeader(b), out = $('#q_hexout');
  if (r.err && b.length < 20) { out.innerHTML = '<p class="no">' + r.err + '</p>'; $('#q_hexfig').innerHTML = ''; return; }
  out.innerHTML = (r.err ? '<p class="no">' + r.err + '</p>' : '') + '<div class="calcgrid">' + stat('Ports', r.sport + ' → ' + r.dport) + stat('Sequence number (raw)', r.seq) + stat('Acknowledgment number', r.f.A ? r.ack : r.ack + ' (unused)') +
    stat('Header length', r.off + ' words = ' + r.hdr + ' bytes') + stat('Flags', flagText(r.f) || 'none') + stat('Window field', r.win) + stat('Checksum', '0x' + r.csum.toString(16).toUpperCase().padStart(4, '0')) + '</div>' +
    (r.opts.length ? '<p><b>Options:</b> ' + r.opts.map(function (x) { return esc(x).replace('SACK permitted', 'SACK (Selective Acknowledgment) permitted'); }).join('; ') + '</p>' : '<p>No options.</p>') + '<p class="cmdnote">' + (b.length > r.hdr && !r.err ? (b.length - r.hdr) + ' bytes after the header are data.' : 'The data length comes from the IP (Internet Protocol) total length: total − IP header − ' + r.hdr + '.') + '</p>';
  if (!r.err) drawHeader($('#q_hexfig'), { sport: r.sport, dport: r.dport, seq: r.seq, ack: r.ack, seqNote: 'raw', hdr: r.hdr, f: r.f, win: r.win, csum: r.csum, optText: r.opts.join(', '), len: Math.max(0, b.length - r.hdr) });
}
function quickSeq() {
  var s = Math.floor(+$('#q_seq').value), L = Math.max(0, Math.floor(+$('#q_len').value || 0)), sy = $('#q_syn').checked ? 1 : 0, fi = $('#q_fin').checked ? 1 : 0, isn = Math.floor(+$('#q_isn').value);
  if (!(s >= 0 && s < MOD) || !(isn >= 0 && isn < MOD)) { $('#q_seqout').innerHTML = '<p class="no">Sequence numbers run from 0 to 4,294,967,295.</p>'; return; }
  var used = L + sy + fi, nx = m32(s + used);
  $('#q_seqout').innerHTML = stat('Numbers this segment uses', used + (sy || fi ? ' (' + L + ' data' + (sy ? ' + SYN' : '') + (fi ? ' + FIN' : '') + ')' : '')) + stat('Bytes it carries', L ? m32(s + sy) + ' to ' + m32(s + sy + L - 1) : 'none') +
    stat('Ack that acknowledges it', nx, true) + stat('Next Seq from the same side', nx) + stat('Relative Seq (Wireshark)', m32(s - isn)) + stat('Relative Ack', m32(nx - isn)) + (s + used >= MOD ? stat('Note', 'wrapped past 2^32') : '');
}
function quickWin() {
  var buf = +$('#q_buf').value || 0, un = +$('#q_unr').value || 0, inf = +$('#q_inf').value || 0, rtt = +$('#q_rtt').value || 0, wf = Math.max(0, Math.min(65535, +$('#q_wf').value || 0)), sh = Math.max(0, Math.min(14, +$('#q_ws').value || 0));
  var adv = Math.max(0, buf - un), use = Math.max(0, adv - inf), sc = wf * Math.pow(2, sh);
  $('#q_winout').innerHTML = stat('Advertised window (buffer − unread)', fmt(adv)) + stat('Usable window (advertised − in flight)', fmt(use), use === 0) + stat('Scaled window (field × 2^shift)', fmt(sc)) +
    (rtt > 0 ? stat('Throughput limit with ' + fmt(adv) + ' bytes per RTT', (Math.round(adv * 8 / rtt / 10) / 100) + ' Mbit/s') : '') + stat('Field needed for ' + fmt(adv) + ' bytes at this shift', Math.floor(adv / Math.pow(2, sh)) > 65535 ? 'too big: use a larger shift' : Math.floor(adv / Math.pow(2, sh)));
}
function quickRto() {
  var S = ($('#q_rtts').value.match(/\d+(\.\d+)?/g) || []).map(Number).filter(function (v) { return v > 0; }).slice(0, 20), mn = +$('#q_min').value;
  if (!S.length) { $('#q_rtoout').innerHTML = '<p>Before any sample, the RTO is 1 s.</p>'; return; }
  var ser = rtoSeries(S, null, mn), l = ser[ser.length - 1], r1 = function (v) { return Math.round(v * 10) / 10; };
  $('#q_rtoout').innerHTML = '<div class="calcgrid">' + stat('SRTT (smoothed RTT)', r1(l.srtt) + ' ms') + stat('RTTVAR (RTT variation)', r1(l.rttvar) + ' ms') + stat('SRTT + 4 × RTTVAR', r1(l.rtoRaw) + ' ms') + stat('RTO', r1(l.rto) + ' ms', true) + stat('After 3 timeouts in a row', r1(l.rto * 8) + ' ms') + '</div>';
}
function quickMss() {
  var mtu = +$('#q_mtu').value || 0, ip = +$('#q_ipv').value, ts = $('#q_mts').checked, mss = mtu - ip - 20;
  $('#q_mssout').innerHTML = mss > 0 ? stat('MSS announced in the SYN', mss) + stat('Data per full segment', (mss - (ts ? 12 : 0)) + (ts ? ' (12 bytes go to the Timestamps option)' : ''), true) + stat('Frame on Ethernet', (mtu + 14) + ' bytes') : '<p class="no">The MTU is too small.</p>';
}
