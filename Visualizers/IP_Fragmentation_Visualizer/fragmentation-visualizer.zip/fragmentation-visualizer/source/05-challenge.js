
/* ===================================================== CHALLENGE: question generators
   Each question carries p: the inputs, so the logic test can re-check the answer independently. */
var Q_MTUS = [532, 576, 620, 700, 810, 900, 1000, 1006, 1250, 1300, 1400, 1492, 1500];
function numQ(type, tag, text, answer, hint, explain, p) { return { type: type, tag: tag, text: text, input: 'number', answer: answer, hint: hint, explain: explain, p: p }; }
function choiceQ(type, tag, text, right, wrongs, hint, explain, p) {
  var ch = [right]; wrongs.forEach(function (w) { if (ch.indexOf(w) < 0) ch.push(w); });
  ch = shuffle(ch); return { type: type, tag: tag, text: text, input: 'choice', choices: ch, answer: ch.indexOf(right), hint: hint, explain: explain, p: p };
}
function needFrag(minFrags, maxFrags, mtuList) {   // data size and MTU with a given number of fragments
  var M, m, D;
  do { M = pick(mtuList || Q_MTUS); m = maxData(M); D = (rnd(minFrags, maxFrags) - 1) * m + rnd(1, m); } while (countFrags(D, M) < minFrags);
  return { D: D, M: M, m: m, n: countFrags(D, M) };
}
/* Easy */
function fitsQ() {
  var M = pick([1500, 1492, 1400, 576, 532, 1280]), T = M + pick([-28, -20, -8, -1, 0, 1, 8, 20, 28]);
  return choiceQ('fits', 'size', 'A datagram with a <b>Total Length of ' + fmt(T) + '</b> bytes reaches a link with an <b>MTU of ' + fmt(M) + '</b>. Must it be fragmented?', T > M ? 'Yes' : 'No', [T > M ? 'No' : 'Yes'],
    'Compare the Total Length (header included) with the MTU.', T > M ? fmt(T) + ' > ' + fmt(M) + ': it is ' + (T - M) + ' bytes too big, so IP must fragment it (or drop it if DF is set).' : fmt(T) + ' ≤ ' + fmt(M) + ': it fits as it is. The MTU is the largest datagram, header included.', { kind: 'fits', T: T, M: M });
}
function perQ() {
  var M = pick(Q_MTUS), m = maxData(M);
  return numQ('per', 'size', 'A link has an <b>MTU of ' + M + '</b>. How many <b>data bytes</b> does each fragment carry, except the last one?', m,
    'Take away the 20-byte header, then round down to a multiple of 8.', M + ' − 20 = ' + (M - HDR) + (M - HDR === m ? ', which is already a multiple of 8.' : ', rounded down to a multiple of 8: ' + m + '.'), { kind: 'per', M: M });
}
function countQ(level) {
  var c = needFrag(2, level === 'E' ? 4 : 7);
  return numQ('count', 'size', 'A datagram with <b>' + fmt(c.D) + ' data bytes</b> must cross a link with an <b>MTU of ' + c.M + '</b>. How many fragments does IP make?', c.n,
    'Find the data per fragment first: ' + c.M + ' − 20, rounded down to a multiple of 8.', explainSplit(c.D, c.M), { kind: 'count', D: c.D, M: c.M });
}
function offQ() {
  var k = rnd(1, 900), B = 8 * k;
  return numQ('off', 'off', 'A fragment\'s data starts at <b>byte ' + fmt(B) + '</b> of the original data. What is its <b>Offset field</b>?', k,
    'The Offset field counts 8-byte units.', fmt(B) + ' ÷ 8 = ' + k + '.', { kind: 'off', B: B });
}
function pingTotQ() {
  var N = pick([56, 64, 100, 500, 1000, 1200, 1372, 1400, 1472, 1500, 2000, 3000, 4000, 8972]);
  return numQ('ptot', 'size', 'On Linux, <code>ping -s ' + N + '</code> sends a ' + N + '-byte payload. What is the <b>Total Length</b> of the IP datagram, before any fragmentation?', N + 28,
    'Add the 8-byte ICMP header and the 20-byte IP header.', N + ' + 8 (ICMP) + 20 (IP) = ' + (N + 28) + '. Linux prints it too: ' + N + '(' + (N + 28) + ') bytes of data.', { kind: 'ptot', N: N });
}
/* Medium */
function lastTotQ() {
  var c = needFrag(2, 6), last = c.D - (c.n - 1) * c.m;
  return numQ('lastTot', 'size', 'A datagram with <b>' + fmt(c.D) + ' data bytes</b> crosses a link with an <b>MTU of ' + c.M + '</b>. What is the <b>Total Length</b> of the last fragment?', last + HDR,
    'Full fragments carry ' + c.m + ' bytes each. What is left for the last one? Then add the header.', explainSplit(c.D, c.M) + ' The last carries ' + last + ' data bytes, plus 20 bytes of header: ' + (last + HDR) + '.', { kind: 'lastTot', D: c.D, M: c.M });
}
function kOffQ() {
  var c = needFrag(3, 7), k = rnd(2, c.n);
  return numQ('kOff', 'off', 'A datagram with <b>' + fmt(c.D) + ' data bytes</b> crosses a link with an <b>MTU of ' + c.M + '</b>. What is the <b>Offset field of fragment ' + k + '</b>?', (k - 1) * c.m / 8,
    'Fragment ' + k + ' starts after ' + (k - 1) + ' full fragments of ' + c.m + ' bytes. Divide by 8.', 'Fragment ' + k + ' starts at byte ' + (k - 1) + ' × ' + c.m + ' = ' + fmt((k - 1) * c.m) + ', and ' + fmt((k - 1) * c.m) + ' ÷ 8 = ' + ((k - 1) * c.m / 8) + '.', { kind: 'kOff', D: c.D, M: c.M, k: k });
}
function rangeQ() {
  var M = pick(Q_MTUS), m = maxData(M), j = rnd(1, 6), off = j * m / 8, len = pick([m, rnd(8, m - 1)]), T = len + HDR, a = off * 8, b = a + len - 1;
  return choiceQ('range', 'off', 'A fragment has <b>Offset ' + off + '</b> and <b>Total Length ' + T + '</b>. Which bytes of the original data does it carry?', fmt(a) + ' to ' + fmt(b),
    [fmt(off) + ' to ' + fmt(off + len - 1), fmt(a) + ' to ' + fmt(a + T - 1), fmt(a + 1) + ' to ' + fmt(b + 1), fmt(a) + ' to ' + fmt(a + len)],
    'Offset × 8 is the first byte. Total Length includes the 20-byte header.', 'It starts at ' + off + ' × 8 = ' + fmt(a) + ' and carries ' + T + ' − 20 = ' + len + ' bytes, so it ends at byte ' + fmt(b) + '.', { kind: 'range', off: off, T: T });
}
function wsQ() {
  var B = pick([1480, 2960, 4440, 5920, 512, 1024, 1376, 976, 552, 1104, 8 * rnd(10, 999)]);
  return numQ('ws', 'off', 'In Wireshark\'s packet details, a fragment shows <b>Fragment Offset: ' + fmt(B) + '</b>. What number is in the header\'s 13-bit Offset field, the one the filter <code>ip.frag_offset</code> compares?', B / 8,
    'Wireshark\'s details show bytes. The header counts 8-byte units.', fmt(B) + ' ÷ 8 = ' + (B / 8) + '. So the filter ip.frag_offset == ' + (B / 8) + ' finds it.', { kind: 'ws', B: B });
}
function pLastQ() {
  var M = pick([1500, 1500, 1492, 1400, 9000]), m = maxData(M), N, data, n;
  do { N = M === 9000 ? rnd(9000, 30000) : rnd(1500, 6000); data = N + 8; n = countFrags(data, M); } while (n < 2);
  var last = data - (n - 1) * m;
  return numQ('plast', 'size', 'Host A runs <code>ping -M dont -s ' + N + '</code> on a link with an <b>MTU of ' + M + '</b>. How many <b>data bytes</b> are in the last fragment?', last,
    'The IP data is the payload plus the 8-byte ICMP header. Each full fragment carries ' + M + ' − 20 → ' + m + ' bytes.', 'IP data = ' + N + ' + 8 = ' + fmt(data) + '. ' + explainSplit(data, M) + ' The last carries ' + fmt(data) + ' − ' + fmt((n - 1) * m) + ' = ' + last + '.', { kind: 'plast', N: N, M: M });
}
function udpCountQ() {
  var M = pick([1500, 1492, 1400, 576]), U = rnd(1500, 12000), data = U + 8, n = countFrags(data, M);
  return numQ('udpcount', 'size', 'A program sends a <b>UDP payload of ' + fmt(U) + ' bytes</b> on a link with an <b>MTU of ' + M + '</b>. How many fragments does IP make?', n,
    'The IP data is the UDP payload plus the 8-byte UDP header.', 'IP data = ' + fmt(U) + ' + 8 = ' + fmt(data) + '. ' + explainSplit(data, M), { kind: 'udpcount', U: U, M: M });
}
/* Hard */
function pathList(mtus) { return mtus.join(', '); }
function refragSetup() {
  var mtus, D, res, once;
  do {
    var m2 = pick([1400, 1006, 1000, 900, 820, 700]), m3 = pick([576, 620, 532, 1000, 700, 300].filter(function (x) { return x < 1500; }));
    mtus = [1500, m2, m3]; D = pick([rnd(1200, 1480), rnd(1500, 4400)]);
    res = sendPath(D, mtus, false); once = splitFrag({ off: 0, len: D, mf: false }, Math.min.apply(null, mtus));
  } while (res.frags.length < 3 || res.frags.length > 9 || res.frags.map(offField).join() === once.map(offField).join());
  return { mtus: mtus, D: D, res: res, once: once };
}
function refragQ() {
  var s = refragSetup(), n = s.res.frags.length;
  return numQ('refrag', 'path', 'Host A sends a datagram with <b>' + fmt(s.D) + ' data bytes</b> over three links with MTUs <b>' + pathList(s.mtus) + '</b> (DF clear). How many fragments <b>reach Host B</b>?', n,
    'Fragment for each link in turn. A router splits each fragment that is too big on its own.', s.res.hops.map(function (h, i) { return 'Link ' + (i + 1) + ': ' + h.frags.map(function (f) { return f.len; }).join(' + '); }).join('. ') + '. So ' + n + ' fragments arrive.', { kind: 'refrag', D: s.D, mtus: s.mtus });
}
function refragOffQ() {
  var s = refragSetup(), right = s.res.frags.map(offField).join(', ');
  var wrongs = [s.once.map(offField).join(', '), s.res.frags.map(function (f) { return f.off; }).join(', '), s.res.frags.map(function (f, i) { return i * maxData(s.mtus[2]) / 8; }).join(', ')];
  return choiceQ('refragOffs', 'path', 'A datagram with <b>' + fmt(s.D) + ' data bytes</b> crosses links with MTUs <b>' + pathList(s.mtus) + '</b>. Which <b>Offset fields</b> arrive at Host B?', right, wrongs,
    'Routers split fragments one by one, and every Offset counts from the start of the original data.', s.res.hops.map(function (h, i) { return 'Link ' + (i + 1) + ': ' + h.frags.map(function (f) { return f.len; }).join(' + '); }).join('. ') + '. Starting bytes ÷ 8: ' + right + '.', { kind: 'refragOffs', D: s.D, mtus: s.mtus });
}
function missingQ() {
  var c = needFrag(4, 7, [532, 576, 620, 1006, 1500, 1000]), frs = splitFrag({ off: 0, len: c.D, mf: false }, c.M), miss = rnd(0, frs.length - 2), have = shuffle(frs.filter(function (x, i) { return i !== miss; }));
  return numQ('missing', 'off', 'Host B holds these fragments of one datagram: ' + have.map(function (f) { return '<span class="addr">[Offset ' + offField(f) + ', M ' + (f.mf ? 1 : 0) + ', Total Length ' + totalLen(f) + ']</span>'; }).join(' ') + '. One is missing. What is its <b>Offset field</b>?', offField(frs[miss]),
    'Each full fragment here carries ' + c.m + ' bytes, so the Offsets go up by ' + (c.m / 8) + '.', 'In order the Offsets are ' + frs.map(offField).join(', ') + ', so ' + offField(frs[miss]) + ' is missing. Without it, Host B throws the whole datagram away when its timer runs out.', { kind: 'missing', got: have.map(function (f) { return [offField(f), f.mf ? 1 : 0, totalLen(f)]; }) });
}
function dfQ() {
  var mtus = [1500, pick([1500, 1492, 1400, 1280, 1000]), pick([1500, 1400, 1280, 1006, 576])], N = pick([1472, 1473, 1400, 1372, 1252, 1200, 980, 2000, 1464]);
  var run = pingRun('do', N, mtus, 1), right = run.lines[1].t.replace(/ time=[\d.]+ ms/, ' …');
  var w = ['ping: local error: message too long, mtu=1500', 'From 192.168.1.1 icmp_seq=1 Frag needed and DF set (mtu = ' + mtus[1] + ')', 'From 192.168.2.2 icmp_seq=1 Frag needed and DF set (mtu = ' + mtus[2] + ')', (N + 8) + ' bytes from 192.168.3.20: icmp_seq=1 ttl=62 …'];
  return choiceQ('df', 'path', 'Links: Host A → <b>' + mtus[0] + '</b> → R1 → <b>' + mtus[1] + '</b> → R2 → <b>' + mtus[2] + '</b> → Host B (192.168.3.20). R1 is 192.168.1.1 and R2 is 192.168.2.2. What is the first line Linux prints after the header for <code>ping -c 1 -M do -s ' + N + ' 192.168.3.20</code>?', right, w.filter(function (x) { return x !== right; }),
    'The datagram is ' + N + ' + 28 = ' + (N + 28) + ' bytes. Find the first link that is too small.', 'The datagram is ' + (N + 28) + ' bytes. ' + (run.attempts[0].res.ok ? 'It fits every link, so the reply comes back.' : run.attempts[0].local ? 'It is bigger than Host A\'s own link, so ping refuses to send it.' : 'Link ' + (run.attempts[0].res.dropAt + 1) + ' is too small, so ' + nodeName(run.attempts[0].res.dropAt, 3) + ' drops it and reports that link\'s MTU.'), { kind: 'df', N: N, mtus: mtus });
}
function largestQ() {
  var mtus = [1500, pick([1500, 1492, 1450, 1400, 1280, 1000]), pick([1500, 1492, 1400, 1280, 576])], pm = Math.min.apply(null, mtus);
  return numQ('largest', 'path', 'A path has links with MTUs <b>' + pathList(mtus) + '</b>. What is the <b>largest payload</b> for <code>ping -M do -s</code> that reaches the far end?', pm - 28,
    'Find the path MTU, then take away the IP and ICMP headers.', 'The path MTU is ' + pm + '. ' + pm + ' − 20 (IP) − 8 (ICMP) = ' + (pm - 28) + '. One byte more and a router (or Host A) says the message is too long.', { kind: 'largest', mtus: mtus });
}
function wireQ() {
  var s = refragSetup(), n = s.res.frags.length, wire = s.D + n * HDR;
  return numQ('wire', 'path', 'A datagram with <b>' + fmt(s.D) + ' data bytes</b> crosses links with MTUs <b>' + pathList(s.mtus) + '</b>. How many bytes of IP datagrams (headers included) cross the <b>last link</b>?', wire,
    'Count the fragments on the last link: each has its own 20-byte header.', n + ' fragments on the last link: ' + fmt(s.D) + ' data bytes + ' + n + ' × 20 = ' + fmt(wire) + '.', { kind: 'wire', D: s.D, mtus: s.mtus });
}
function learnQ() {
  var m2 = pick([1492, 1400, 1280, 1000, 576]), mtus = [1500, m2], N = pick([m2 - 28, m2 - 27, 1472, 1200, 1400, 1000, 600].filter(function (x) { return x > 0 && x <= 1472; }));
  var run = pingRun('want', N, mtus, 3), got = run.received;
  var A = 'All 3 get replies', B = 'Ping 1: Frag needed (mtu = ' + m2 + '); pings 2 and 3 get replies', Cc = 'All 3: Frag needed (mtu = ' + m2 + ')', D = 'All 3: local error: message too long';
  var right = got === 3 ? A : got === 2 ? B : Cc;
  return choiceQ('learn', 'path', 'Host A → <b>1500</b> → R1 → <b>' + m2 + '</b> → Host B. Host A runs <code>ping -c 3 -s ' + N + '</code> on Linux (DF set by default). What happens?', right, [A, B, Cc, D].filter(function (x) { return x !== right; }),
    'The datagram is ' + (N + 28) + ' bytes. Linux ping learns from a "Frag needed" message.', (N + 28 <= m2 ? (N + 28) + ' ≤ ' + m2 + ', so every ping fits the whole path.' : (N + 28) + ' > ' + m2 + ': R1 drops ping 1 and reports MTU ' + m2 + '. Linux remembers it and fragments pings 2 and 3 itself, so they arrive.'), { kind: 'learn', N: N, mtus: mtus });
}
var GEN = {
  E: [fitsQ, perQ, function () { return countQ('E'); }, offQ, pingTotQ],
  M: [lastTotQ, kOffQ, rangeQ, wsQ, pLastQ, udpCountQ, function () { return countQ('M'); }],
  H: [refragQ, refragOffQ, missingQ, dfQ, largestQ, wireQ, learnQ]
};
function makeRound(level, n) {
  var out = [], bag = [];
  while (out.length < n) { if (!bag.length) bag = shuffle(GEN[level].slice()); out.push(bag.pop()()); }
  return out;
}

/* ===================================================== CHALLENGE: play */
var BADGES = [
  { id: 'first', b: '🎯', t: 'First round', d: 'Finish a challenge round' },
  { id: 'perfect', b: '💯', t: 'Perfect 10', d: 'Answer all ten questions right' },
  { id: 'streak', b: '🔥', t: 'On fire', d: 'Five right answers in a row' },
  { id: 'offset', b: '📏', t: 'Offset oracle', d: 'Every Offset question right in a round (at least three)' },
  { id: 'path', b: '🧭', t: 'Path finder', d: 'Three path or DF questions right in a Hard round' },
  { id: 'sprint', b: '⚡', t: 'Speed runner', d: 'Eight right answers in a sprint' },
  { id: 'learned', b: '📘', t: 'Scholar', d: 'Finish all six lessons' }
];
function earn(id) { if (progress.badges[id]) return false; progress.badges[id] = Date.now(); store.set('progress', progress); return true; }
function renderShelf() {
  $('#badgeShelf').innerHTML = BADGES.map(function (b) { return '<span class="badge' + (progress.badges[b.id] ? '' : ' locked') + '" title="' + esc(b.d) + '"><span class="b" aria-hidden="true">' + b.b + '</span>' + b.t + '</span>'; }).join('');
  var best = progress.best; $('#bestLine').textContent = 'Best scores: Easy ' + (best.E || 0) + ', Medium ' + (best.M || 0) + ', Hard ' + (best.H || 0) + (best.S ? ', Sprint ' + best.S : '');
}
var game = null;
function startRound() {
  var level = ($('.level[aria-pressed=true]') || $('.level')).getAttribute('data-level'), sprint = $('#sprint').checked;
  game = { level: level, sprint: sprint, qs: makeRound(level, sprint ? 40 : 10), i: 0, score: 0, streak: 0, bestStreak: 0, right: 0, answered: 0, log: [], tags: {}, ends: sprint ? Date.now() + 120000 : 0, timer: null };
  $('#ch-setup').hidden = true; $('#ch-end').hidden = true; $('#ch-play').hidden = false;
  $('#q_timerbar').hidden = !sprint;
  if (sprint) game.timer = setInterval(tick, 250);
  showQ();
}
function tick() {
  if (!game) return; var left = game.ends - Date.now();
  $('#q_timer').style.width = Math.max(0, left / 1200) + '%';
  if (left <= 0) { clearInterval(game.timer); endRound(); }
}
function chips() {
  $('#q_n').textContent = game.sprint ? 'Answered ' + game.answered : 'Question ' + Math.min(game.i + 1, game.qs.length) + ' of ' + game.qs.length;
  $('#q_score').textContent = '★ ' + game.score;
  $('#q_streak').textContent = '🔥 streak ' + game.streak;
}
function showQ() {
  if (!game) return; chips();
  var q = game.qs[game.i], body = $('#q_body'); q.hinted = false;
  var answerUI = q.input === 'choice'
    ? '<div class="choices">' + q.choices.map(function (c, i) { return '<button class="choice" data-i="' + i + '">' + (/^(ping|From|\d+ bytes)/.test(c) ? '<code>' + esc(c) + '</code>' : esc(c)) + '</button>'; }).join('') + '</div>'
    : '<div class="row"><input type="number" id="q_in" min="0" aria-label="Your answer"><button class="btn" id="q_ok">Check</button></div>';
  body.innerHTML = '<p class="qtext">' + q.text + '</p>' + answerUI +
    '<div class="row"><button class="btn alt small" id="q_hint">Hint (−3)</button></div><div class="feedback" id="q_fb" aria-live="polite"></div><div class="row" id="q_nextrow" hidden><button class="btn amber" id="q_next">Next →</button></div>';
  $('#q_hint').onclick = function () { if (q.hinted || q.done) return; q.hinted = true; var fb = $('#q_fb'); fb.className = 'feedback'; fb.style.background = 'var(--amber-soft)'; fb.innerHTML = '💡 ' + q.hint; };
  if (q.input === 'choice') $$('.choice', body).forEach(function (b) { b.onclick = function () { answer(+b.getAttribute('data-i'), b); }; });
  else { $('#q_ok').onclick = function () { answer(+$('#q_in').value); }; $('#q_in').onkeydown = function (e) { if (e.key === 'Enter') answer(+$('#q_in').value); }; $('#q_in').focus(); }
  $('#q_next').onclick = nextQ;
}
function answer(v, btn) {
  var q = game.qs[game.i]; if (q.done) return; q.done = true;
  var ok = v === q.answer, fb = $('#q_fb'); fb.style.background = '';
  game.answered++;
  if (ok) {
    game.right++; game.streak++; game.bestStreak = Math.max(game.bestStreak, game.streak);
    var pts = 10 + Math.min(game.streak - 1, 5) * 2 - (q.hinted ? 3 : 0); game.score += pts;
    game.tags[q.tag] = (game.tags[q.tag] || 0) + 1;
    fb.className = 'feedback ok pop'; fb.innerHTML = '<b>Correct! +' + pts + '</b>' + (game.streak >= 3 ? ' 🔥 ' + game.streak + ' in a row' : '') + '<br>' + q.explain;
  } else {
    game.streak = 0; game.tags[q.tag + '_miss'] = 1;
    var right = q.input === 'choice' ? q.choices[q.answer] : q.answer;
    fb.className = 'feedback bad'; fb.innerHTML = '<b>Not quite.</b> The answer is <b>' + esc(right) + '</b>.<br>' + q.explain;
  }
  game.log.push({ q: q.text, ok: ok, right: q.input === 'choice' ? q.choices[q.answer] : String(q.answer) });
  if (q.input === 'choice') $$('#q_body .choice').forEach(function (b, i) { b.disabled = true; if (i === q.answer) b.classList.add('right'); else if (b === btn) b.classList.add('wrong'); });
  else { $('#q_in').disabled = true; $('#q_ok').disabled = true; }
  $('#q_hint').disabled = true; $('#q_nextrow').hidden = false; $('#q_next').focus(); chips();
}
function nextQ() { game.i++; if (game.i >= game.qs.length || (game.sprint && Date.now() > game.ends)) endRound(); else showQ(); }
function code(level, score, right, total) {   // completion code with a checksum (deters casual editing; not secure)
  var s = 'FV|' + level + '|' + score + '|' + right + '|' + total, h = 2166136261;
  for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
  return level + score + '-' + right + 'of' + total + '-' + (h % 1679616).toString(36).toUpperCase().padStart(4, '0');
}
function checkCode(c) {
  var m = /^([EMHS])(\d+)-(\d+)of(\d+)-([0-9A-Z]{4})$/.exec(String(c).trim().toUpperCase().replace('OF', 'of'));
  if (!m) return null; return code(m[1], +m[2], +m[3], +m[4]) === m[0] ? { level: m[1], score: +m[2], right: +m[3], total: +m[4] } : false;
}
function endRound() {
  if (!game) return; clearInterval(game.timer);
  var g = game, total = g.sprint ? g.answered : g.qs.length, pct = total ? g.right / total : 0, stars = pct >= 0.9 ? 3 : pct >= 0.7 ? 2 : pct >= 0.5 ? 1 : 0;
  var lvl = g.sprint ? 'S' : g.level, fresh = [];
  if (g.answered && earn('first')) fresh.push('first');
  if (!g.sprint && g.right === 10 && earn('perfect')) fresh.push('perfect');
  if (g.bestStreak >= 5 && earn('streak')) fresh.push('streak');
  if ((g.tags.off || 0) >= 3 && !g.tags.off_miss && earn('offset')) fresh.push('offset');
  if (g.level === 'H' && (g.tags.path || 0) >= 3 && earn('path')) fresh.push('path');
  if (g.sprint && g.right >= 8 && earn('sprint')) fresh.push('sprint');
  var newBest = g.score > (progress.best[lvl] || 0); if (newBest) progress.best[lvl] = g.score;
  store.set('progress', progress); addXP(g.score);
  var cd = code(lvl, g.score, g.right, total), lname = { E: 'Easy', M: 'Medium', H: 'Hard', S: 'Sprint' }[lvl];
  $('#ch-play').hidden = true; var end = $('#ch-end'); end.hidden = false;
  end.innerHTML = '<h2>' + (stars === 3 ? 'Outstanding!' : stars === 2 ? 'Great work!' : stars === 1 ? 'Good start!' : 'Keep practicing!') + '</h2>' +
    '<div class="stars" aria-label="' + stars + ' of 3 stars">' + '★★★'.slice(0, stars) + '<span style="color:#D3E3EC">' + '★★★'.slice(0, 3 - stars) + '</span></div>' +
    '<p style="font-size:19px"><b>' + g.score + ' points</b> · ' + g.right + ' of ' + total + ' right · best streak ' + g.bestStreak + (newBest ? ' · <span class="oneway">new best for ' + lname + '!</span>' : '') + '</p>' +
    (fresh.length ? '<h3>New badges</h3><div class="badges">' + fresh.map(function (id) { var b = BADGES.filter(function (x) { return x.id === id; })[0]; return '<span class="badge pop"><span class="b">' + b.b + '</span>' + b.t + '</span>'; }).join('') + '</div>' : '') +
    '<h3>Completion code</h3><p>If you are asked for it, copy this code.</p><span class="code" id="ccode">' + cd + '</span> <button class="btn alt small" id="ccopy">Copy</button>' +
    '<div class="row" style="margin-top:16px"><button class="btn amber" id="again">Play again</button>' + (g.level !== 'H' ? '<button class="btn" id="harder">Try ' + (g.level === 'E' ? 'Medium' : 'Hard') + '</button>' : '') + '<button class="btn alt" id="toLearn">Review the lessons</button></div>' +
    '<details><summary>Review your answers</summary><ol class="list">' + g.log.map(function (l) { return '<li>' + (l.ok ? '<span class="yes">✓</span> ' : '<span class="no">✗</span> ') + l.q + ' <i>Answer: ' + esc(l.right) + '</i></li>'; }).join('') + '</ol></details>';
  $('#ccopy').onclick = function () { copyText(cd, $('#ccopy')); };
  $('#again').onclick = function () { startRound(); };
  if ($('#harder')) $('#harder').onclick = function () { setLevel(g.level === 'E' ? 'M' : 'H'); startRound(); };
  $('#toLearn').onclick = function () { go('learn'); };
  if (stars === 3) burst();
  game = null; renderShelf(); writeLink();
}
function burst() {
  if (reduceMotion) return;
  var b = document.createElement('div'); b.className = 'burst'; b.setAttribute('aria-hidden', 'true');
  for (var i = 0; i < 40; i++) { var s = document.createElement('span'); s.textContent = pick(['★', '✦', '●', '▲']); s.style.left = rnd(0, 100) + '%'; s.style.color = pick(['#00A2D7', '#F5A524', '#13A88A', '#7B61FF']); s.style.animationDelay = (Math.random() * 0.6) + 's'; b.appendChild(s); }
  document.body.appendChild(b); setTimeout(function () { if (b.parentNode) b.parentNode.removeChild(b); }, 2800);
}
function setLevel(l) { $$('.level').forEach(function (b) { b.setAttribute('aria-pressed', String(b.getAttribute('data-level') === l)); }); }

/* ===================================================== hero figure on the start screen */
function drawHero() {
  var f = new Fig($('#heroFig'), 0, 7.2, 0, 4, 1.65);
  f.slab(0.2, 2.9, 1.3, 0.7, { text: 'Host A', fill: '#fff', fs: 9.5, bold: true });
  f.slab(2.95, 2.9, 1.3, 0.7, { text: 'Router', fill: '#fff', fs: 9.5, bold: true });
  f.slab(5.7, 2.9, 1.3, 0.7, { text: 'Host B', fill: '#fff', fs: 9.5, bold: true });
  f.line(1.5, 3.25, 2.95, 3.25, { color: '#fff', lw: 2 }); f.line(4.25, 3.25, 5.7, 3.25, { color: '#fff', lw: 2 });
  f.text(2.22, 3.48, 'MTU 1500', { fs: 8, color: '#CFE6F0', bold: true }); f.text(4.97, 3.48, 'MTU 532', { fs: 8, color: '#FCE9C6', bold: true });
  f.rect(0.35, 1.6, 0.18, 0.5, { fill: C.navy, stroke: '#fff', lw: 1 }); f.rect(0.53, 1.6, 2.05, 0.5, { fill: C.panel, stroke: '#fff', lw: 1 });
  f.text(1.46, 1.85, '1400 data bytes', { fs: 8.5, bold: true });
  f.arrow(2.7, 1.85, 3.5, 1.85, { color: '#fff', lw: 1.6 }); f.text(3.1, 2.15, '✂', { fs: 14, color: '#F5A524' });
  [[512, '#CFE6F0'], [512, '#E7E1FF'], [376, '#FCE9C6']].forEach(function (p, i) {
    var y = 2.25 - i * 0.62, w = p[0] / 512 * 1.9;
    f.rect(3.7, y - 0.25, 0.18, 0.42, { fill: C.navy, stroke: '#fff', lw: 1 }); f.rect(3.88, y - 0.25, w, 0.42, { fill: p[1], stroke: '#fff', lw: 1 });
    f.text(3.88 + w / 2, y - 0.04, String(p[0]), { fs: 8, bold: true });
    f.text(6.05, y - 0.04, 'Offset ' + (i * 64), { fs: 8, color: '#fff', ha: 'left' });
  });
}

/* ===================================================== navigation and links */
var VIEWS = ['home', 'learn', 'calc', 'challenge'], current = 'home';
function go(mode) {
  current = VIEWS.indexOf(mode) >= 0 ? mode : 'home';
  lessonState.token++;
  VIEWS.forEach(function (v) { $('#view-' + v).hidden = v !== current; });
  $$('.modes button').forEach(function (b) { b.setAttribute('aria-pressed', String(b.getAttribute('data-mode') === current)); });
  if (current === 'learn') openLesson(lessonState.i);
  if (current === 'challenge') { if (game) { clearInterval(game.timer); game = null; } $('#ch-setup').hidden = false; $('#ch-play').hidden = true; $('#ch-end').hidden = true; renderShelf(); }
  if (current === 'calc') calc();
  window.scrollTo(0, 0); writeLink();
}
function writeLink() {
  try {
    var q = new URLSearchParams(); q.set('mode', current);
    if (current === 'learn') q.set('lesson', lessonState.i + 1);
    if (current === 'calc') { q.set('size', calcState.size); q.set('kind', calcState.kind); q.set('mtus', calcState.mtus.join('-')); if (calcState.df) q.set('df', '1'); }
    if (current === 'challenge') q.set('level', ($('.level[aria-pressed=true]') || $('.level')).getAttribute('data-level'));
    if (window.history && history.replaceState) history.replaceState(null, '', location.pathname + '?' + q.toString());
  } catch (e) { /* some embeds block history changes */ }
}
function readLink() {
  var q; try { q = new URLSearchParams(location.search); } catch (e) { return null; }
  if (q.get('lesson')) lessonState.i = Math.max(0, Math.min(LESSONS.length - 1, (+q.get('lesson') || 1) - 1));
  if (/^[EMH]$/.test(q.get('level') || '')) setLevel(q.get('level'));
  var sz = +q.get('size'); if (q.get('size') && Number.isInteger(sz) && sz >= 0 && sz <= MAX_DATA) calcState.size = sz;
  if (KINDS[q.get('kind')]) calcState.kind = q.get('kind');
  if (q.get('df') === '1') calcState.df = 1;
  if (q.get('mtus')) { var ms = q.get('mtus').split(/[-,]/).map(Number).filter(function (m) { return Number.isInteger(m) && m >= MIN_MTU && m <= 65535; }).slice(0, 4); if (ms.length) calcState.mtus = ms; }
  return q.get('mode');
}

/* ===================================================== start */
function init() {
  var mode = readLink();   // read the link before anything rewrites it
  drawHero(); showXP(false); calcInit(); renderShelf();
  $$('.modes button').forEach(function (b) { b.onclick = function () { go(b.getAttribute('data-mode')); }; });
  $$('[data-go]').forEach(function (b) { b.onclick = function () { go(b.getAttribute('data-go')); }; });
  $('#home').onclick = function () { go('home'); };
  $$('.level').forEach(function (b) { b.onclick = function () { setLevel(b.getAttribute('data-level')); writeLink(); }; });
  $('#ch-start').onclick = startRound;
  $('#q_quit').onclick = function () { endRound(); };
  $('#resetProgress').onclick = function () { progress = { xp: 0, lessons: {}, badges: {}, best: {} }; store.set('progress', progress); showXP(false); renderShelf(); if (current === 'learn') renderStepper(); };
  $('#verifyBtn').onclick = function () { var r = checkCode($('#verifyIn').value); $('#verifyOut').innerHTML = r ? '<span class="yes">Valid:</span> ' + { E: 'Easy', M: 'Medium', H: 'Hard', S: 'Sprint' }[r.level] + ', ' + r.score + ' points, ' + r.right + ' of ' + r.total + ' right.' : '<span class="no">Not a valid code.</span>'; };
  go(mode || 'home');
}
init();
window.FragViz = { maxData: maxData, splitFrag: splitFrag, sendPath: sendPath, countFrags: countFrags, pingRun: pingRun, GEN: GEN, makeRound: makeRound, code: code, checkCode: checkCode };
})();
</script>
</body>
</html>
