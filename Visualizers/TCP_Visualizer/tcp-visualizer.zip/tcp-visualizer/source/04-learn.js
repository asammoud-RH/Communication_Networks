
/* =====================================================================
   LEARN: eight lessons
   ===================================================================== */
var lessonState = { i: 0, token: 0, player: null };
function lessonHead(i, title) { return '<p class="mono" style="color:var(--muted);margin:0">Lesson ' + (i + 1) + ' of ' + LESSONS.length + '</p><h2>' + title + '</h2>'; }
function tryBox(id, html) { return '<div class="tryit"><h3>Try it</h3>' + html + '<div class="feedback" id="' + id + 'fb" aria-live="polite"></div></div>'; }
function seeBox(intro) { return '<details class="seeit"><summary>See it on your computer</summary><div id="seeCmds"></div></details>'; }
function more(label, html) { return '<details class="more"><summary>' + label + '</summary>' + html + '</details>'; }
function fold(title, inner, id) { return '<details class="card fold"' + (id ? ' id="' + id + '"' : '') + '><summary class="figtitle">' + title + '</summary>' + inner + '</details>'; }
function figCard(title, inner, legend) { return '<div class="card"><p class="figtitle">' + title + '</p>' + inner + (legend || '') + '</div>'; }

/* mount a run in the figure column: player, ladder, and any extra views */
function mountRun(run, o) {
  o = o || {};
  if (lessonState.player) lessonState.player.stop();
  var h = '';
  if (o.side) h += '<div class="card"><div id="pl"></div><div id="rb"></div><div class="sbs">' +
    '<div><p class="figtitle">The TCP state-transition diagram</p><div class="fig fit"><svg id="smf" role="img"></svg></div><div class="soft" id="smstep" aria-live="polite"></div>' + SM_LEGEND + '</div>' +
    '<div><p class="figtitle">' + (o.title || 'Timeline') + '</p><div class="fig tall sbsl"><div class="hosthdr" aria-hidden="true"><span style="left:33.2%">Host A</span><span style="left:66.8%">Host B</span></div><svg id="ldr" role="img"></svg></div>' + LADDER_LEGEND + seqNote(run) + '</div></div></div>';
  else if (o.smFirst) h += '<div class="card"><p class="figtitle">The TCP state-transition diagram</p><div id="pl"></div><div id="rb"></div><div class="fig fit"><svg id="smf" role="img"></svg></div><div class="soft" id="smstep" aria-live="polite"></div>' + SM_LEGEND + '</div>';
  if (!o.side) h += '<div class="card"><p class="figtitle">' + (o.title || 'Timeline: Host A and Host B') + '</p>' + (o.smFirst ? '<div class="pl2"></div>' : '<div id="pl"></div>' + (o.badges !== false ? '<div id="rb"></div>' : '')) +
    '<div class="fig' + (o.tall || run.segs.length > 14 ? ' tall' : '') + '"><svg id="ldr" role="img"></svg></div>' + LADDER_LEGEND + seqNote(run) + (o.click ? '<p class="cmdnote">Click a segment to lose it, or click a lost one to deliver it.</p>' : '') + '</div>';
  if (o.loss) h += '<div class="card"><p class="figtitle">The gap, step by step</p><div class="pl2"></div><div class="fig"><svg id="lossf" role="img"></svg></div><p class="lossnow" id="lossc" aria-live="polite"></p>' + LOSS_LEGEND + '<div id="losst"></div></div>';
  if (o.ribbons) h += '<div class="card"><p class="figtitle">Buffers and the window</p><div class="pl2"></div><div class="fig"><svg id="rib" role="img"></svg></div>' + RIBBON_LEGEND + '<div id="wst"></div></div>';
  if (o.events) h += fold('What happened, in words', '<div id="ev"></div>', 'evc');
  if (o.sm && !o.smFirst) h += fold('The TCP state-transition diagram', '<p class="cmdnote">Each end of a connection is always in one <b>state</b>, shown as a box. The markers A and B show where each host is; each arrow is labeled event/action: what moves a host along it, then what that host sends. Lesson 8 walks through the whole diagram.</p><div class="pl2"></div><div class="fig fit"><svg id="smf" role="img"></svg></div><div class="soft" id="smstep" aria-live="polite"></div>' + SM_LEGEND);
  if (o.pkts !== false) h += fold('Wireshark-style capture at Host A', '<div id="pk"></div>');
  $('#lfig').innerHTML = h;
  var lastT = null;
  /* a timeline that scrolls inside its box keeps the current moment in view */
  function keepNowInView() {
    var bx0 = $('#ldr') && $('#ldr').parentNode, hh0 = bx0 && $('.hosthdr', bx0);
    if (hh0 && !bx0.onscroll) bx0.onscroll = function () { hh0.classList.toggle('on', bx0.scrollTop > 40); };
    var box = $('#ldr') && $('#ldr').parentNode, line = box && $('#ldr .nowline');
    if (!box || box.scrollHeight <= box.clientHeight + 4) return;
    var y = line ? line.getBoundingClientRect().top - box.getBoundingClientRect().top + box.scrollTop : 0;
    var want = Math.max(0, y - box.clientHeight * 0.45);
    if (Math.abs(box.scrollTop - want) > 24) box.scrollTop = want;
    var hh = $('.hosthdr', box); if (hh) hh.classList.toggle('on', box.scrollTop > 40);
  }
  function render(T) {
    drawLadder($('#ldr'), run, { T: T, raw: o.raw && o.raw(), hide: o.hide, click: o.click, hl: o.hl });
    keepNowInView();
    if ($('#rb')) $('#rb').innerHTML = stateBadges(run, T);
    if (o.ribbons) { drawRibbons($('#rib'), run, T); $('#wst').innerHTML = windowStats(run, T); }
    if (o.loss) { drawLossView($('#lossf'), run, T); $('#lossc').innerHTML = lossCaption(run, T); $('#losst').innerHTML = lossStats(run, T); }
    if (o.sm || o.smFirst || o.side) { drawStateMachine($('#smf'), run, T, { prevT: lastT, clickable: !!o.arcClick }); $('#smstep').innerHTML = smStepText(run, lastT, T); }
    lastT = T;
    if (o.pkts !== false) $('#pk').innerHTML = packetList(run, T, o.raw && o.raw());
    if (o.events) { $('#ev').innerHTML = eventList(run, T); $('#evc').hidden = !run.log.length; }
    if (o.arcClick) $$('#smf [data-arc]').forEach(function (g) { g.onclick = function () { o.arcClick(g.getAttribute('data-arc')); }; g.onkeydown = function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); o.arcClick(g.getAttribute('data-arc')); } }; });
    if (o.click) $$('#ldr [data-n]').forEach(function (g) { g.onclick = function () { o.click(+g.getAttribute('data-n')); }; g.onkeydown = function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); o.click(+g.getAttribute('data-n')); } }; });
  }
  lessonState.player = makePlayer($('#pl'), run, render, { statesOnly: !!o.statesOnly, start: o.start });
  $$('#lfig .pl2').forEach(function (b) { lessonState.player.attach(b); });
  return lessonState.player;
}
/* why one side's Seq never moves: say so under the timeline */
function seqNote(run) {
  var out = [];
  [['A', 'B'], ['B', 'A']].forEach(function (p) {
    var mine = run.segs.filter(function (g) { return g.from === p[0]; });
    if (!mine.length || !run.segs.some(function (g) { return g.from === p[1] && g.len > 0; })) return;
    if (mine.some(function (g) { return g.len > 0; })) return;
    var fin = mine.some(function (g) { return g.f.F; });
    out.push('Host ' + p[0] + ' sends no data here, so its sequence number (Seq) stays at 1 and Host ' + p[1] + '\'s acknowledgment number (Ack) stays at 1. Only Host ' + p[1] + '\'s Seq and Host ' + p[0] + '\'s Ack move.' +
      (fin ? ' Host ' + p[0] + '\'s FIN (finish) uses one number, so the ACK (acknowledgment) of that FIN has Ack=2.' : ''));
  });
  return out.length ? '<p class="cmdnote">' + out.join(' ') + '</p>' : '';
}
function numIn(id, label, w) { return '<label>' + label + ' <input type="number" id="' + id + '"' + (w ? ' class="wide"' : '') + '></label>'; }
function val(id) { var v = $('#' + id).value.trim(); return v === '' ? NaN : Number(v); }
function hexBytes(b) { return b.map(function (x) { return x.toString(16).toUpperCase().padStart(2, '0'); }).join(' '); }

var BASE = { mssA: 100, mssB: 100, rbufA: 400, rbufB: 400, delay: 50, rate: 160, closeA: { kind: 'never' }, closeB: { kind: 'never' } };
function cfgWith(o) { var c = {}, k; for (k in BASE) c[k] = BASE[k]; for (k in o) c[k] = o[k]; return c; }

var LESSONS = [
/* ---------------------------------------------------------------- 1 */
{ t: 'A segment and its header', setup: function () {
  var sel = 4, raw = false;
  var run = simulate({ mssA: 1460, mssB: 1460, ts: true, sack: true, ws: 7, rbufA: 64240, rbufB: 65160, delay: 20, rate: 10000, isnA: 1844674407, isnB: 3006284720,
    writes: [{ side: 'A', at: 60, bytes: 100 }], closeA: { kind: 'at', at: 400 }, closeB: { kind: 'onFin', delay: 0 }, dack: true });
  $('#ltext').innerHTML = lessonHead(0, 'A segment and its header') +
    '<p>TCP cuts the stream of bytes into <b>segments</b>. Each segment has a header of at least 20 bytes, then the data. Pick a segment of a short connection in the figure to see its header. Each segment is named by its flags: SYN (synchronize) opens, ACK (acknowledgment) confirms, PSH (push) delivers data now, FIN (finish) closes.</p>' +
    more('What each field means', '<ul class="list"><li><b>Ports</b> name the two programs.</li><li><b>Sequence number</b>: the number of the first data byte in this segment. The SYN (synchronize) takes a number too.</li><li><b>Acknowledgment number</b>: the next byte this side expects. It counts only when the ACK flag is 1.</li><li><b>Header length</b>: 4 bits that count 32-bit words, so 5 means 20 bytes and 10 means 40.</li><li><b>Flags</b>: SYN opens, FIN (finish) closes, RST (reset) aborts, ACK marks the Acknowledgment field valid, PSH (push) asks the receiver to hand the data to the program now.</li><li><b>Window</b>: how many more bytes this side can take.</li><li><b>Options</b>: MSS (Maximum Segment Size), SACK (Selective Acknowledgment), Timestamps, and Window Scale, mostly in the SYNs.</li></ul>' +
    '<p>TCP never states the data length. The receiver works it out: IP (Internet Protocol) total length − IP header − TCP header.</p>') +
    tryBox('l1', '<p>Here is a TCP header in hexadecimal, from a packet whose IP (Internet Protocol) total length is <b id="l1tot"></b> bytes (with a 20-byte IP header).</p><div class="term" id="l1hex"></div>' +
      '<div class="fields">' + numIn('l1h', 'TCP header length (bytes)') + '<label>Flags set <select id="l1f"><option value="">choose…</option><option>SYN</option><option>SYN, ACK</option><option>ACK</option><option>PSH, ACK</option><option>FIN, ACK</option><option>RST, ACK</option></select></label>' + numIn('l1p', 'Data length (bytes)') + '</div>' +
      '<div class="row"><button class="btn small" id="l1c">Check</button><button class="btn alt small" id="l1n">New header</button></div>') + seeBox();
  $('#lfig').innerHTML = '<div class="card"><p class="figtitle">Pick a segment</p><div class="chips2" id="l1segs"></div><div class="row"><label><input type="checkbox" id="l1raw"> Raw 32-bit numbers (not relative)</label></div><div class="fig"><svg id="l1hdr" role="img"></svg></div><div id="l1sz"></div></div>' +
    fold('Wireshark-style capture at Host A', '<div id="l1pk"></div>');
  function draw() {
    var sg = run.segs[sel - 1];
    $('#l1segs').innerHTML = run.segs.map(function (s) { return '<button class="chip2" data-s="' + s.n + '" aria-pressed="' + (s.n === sel) + '" style="' + (s.n === sel ? 'background:var(--panel);border-color:var(--brand);color:var(--navy)' : '') + '">#' + s.n + ' ' + s.from + '→' + s.to + ' [' + flagText(s.f) + ']' + (s.len ? ' ' + s.len + ' B' : '') + '</button>'; }).join('');
    $$('#l1segs [data-s]').forEach(function (b) { b.onclick = function () { sel = +b.getAttribute('data-s'); draw(); }; });
    drawHeader($('#l1hdr'), segHeader(run, sg, raw));
    $('#l1sz').innerHTML = '<div class="calcgrid">' + stat('Ethernet header', '14') + stat('IP header', '20') + stat('TCP header', String(sg.hdr)) + stat('Data', String(sg.len)) + stat('Frame length in Wireshark', String(sg.frame), true) + stat('IP total length', String(20 + sg.hdr + sg.len)) + '</div>' +
      '<p class="cmdnote">This connection uses Timestamps, so every segment after the SYNs carries 12 option bytes and the header is 32 bytes. That is why a full segment on Ethernet carries 1448 data bytes, not 1460.</p>';
    $('#l1pk').innerHTML = packetList(run, null, raw);
  }
  $('#l1raw').onchange = function () { raw = this.checked; draw(); };
  draw();
  var q;
  function gen() {
    var kind = pick(['syn', 'synack', 'data', 'ack', 'fin', 'rst']), f = {}, opt = [], hdr = 20, len = 0;
    function ts() { return [1, 1, 8, 10].concat([rnd(0, 255), rnd(0, 255), rnd(0, 255), rnd(0, 255), rnd(0, 255), rnd(0, 255), rnd(0, 255), rnd(0, 255)]); }
    if (kind === 'syn' || kind === 'synack') { f = kind === 'syn' ? { S: 1 } : { S: 1, A: 1 }; opt = [2, 4, 5, 180, 4, 2, 8, 10, rnd(0, 255), rnd(0, 255), rnd(0, 255), rnd(0, 255), 0, 0, 0, 0, 1, 3, 3, 7]; if (kind === 'synack') { opt[12] = rnd(1, 255); opt[13] = rnd(0, 255); } }
    else if (kind === 'data') { f = { A: 1, P: 1 }; opt = pick([[], ts()]); len = rnd(1, 1448); }
    else if (kind === 'ack') { f = { A: 1 }; opt = pick([[], ts()]); }
    else if (kind === 'fin') { f = { F: 1, A: 1 }; opt = pick([[], ts()]); }
    else { f = { R: 1, A: 1 }; }
    hdr = 20 + opt.length;
    var b = headerBytes({ sport: pick([48212, 51744, 39020]), dport: pick([5000, 80, 443, 22]), seq: rnd(0, MOD - 1), ack: f.A ? rnd(0, MOD - 1) : 0, f: f, hdr: hdr, win: rnd(500, 65535), csum: rnd(0, 65535), optBytes: opt });
    q = { hdr: hdr, len: len, flags: flagText(f), tot: 20 + hdr + len };
    $('#l1hex').textContent = hexBytes(b); $('#l1tot').textContent = q.tot;
    lessonState.solve = function () { $('#l1h').value = q.hdr; $('#l1f').value = q.flags; $('#l1p').value = q.len; };
    ['l1h', 'l1p'].forEach(function (id) { $('#' + id).value = ''; }); $('#l1f').value = ''; $('#l1fb').innerHTML = ''; $('#l1fb').className = 'feedback';
  }
  gen(); $('#l1n').onclick = gen;
  $('#l1c').onclick = function () {
    var okH = val('l1h') === q.hdr, okF = $('#l1f').value === q.flags, okP = val('l1p') === q.len;
    if (okH && okF && okP) lessonDone($('#l1fb'), 'Header length ' + q.hdr + ' bytes, flags ' + q.flags + ', and ' + q.tot + ' − 20 − ' + q.hdr + ' = ' + q.len + ' data bytes.');
    else wrong($('#l1fb'), (!okH ? 'Header length: find byte 13 (the 13th byte, counting from 1). Its first hex digit counts 32-bit words; multiply by 4. ' : '') + (!okF ? 'Flags: byte 14 holds them. FIN = 01, SYN = 02, RST = 04, PSH = 08, ACK = 10 (hex). Add them up. ' : '') + (!okP ? 'Data length: IP total length − 20 − the TCP header length.' : ''));
  };
  cmdPanel($('#seeCmds'), ['connect', 'wireshark'], 'Start a server and a client, type a line, and find the segment in Wireshark. Expand "Transmission Control Protocol" to see these fields.');
} },
/* ---------------------------------------------------------------- 2 */
{ t: 'Opening a connection', setup: function () {
  var c = { kase: 'normal', raw: true, isnA: 3141592653, isnB: 2718281828 };
  $('#ltext').innerHTML = lessonHead(1, 'Opening a connection') +
    '<p>Before any data, the two sides agree on starting numbers with a <b>three-way handshake</b>:</p><ol class="list"><li>A sends <b>SYN</b> (synchronize) with sequence number Seq = <i>x</i>, its initial sequence number (ISN).</li><li>B answers <b>SYN, ACK</b> (acknowledgment) with Seq = <i>y</i> and Ack = <i>x</i> + 1.</li><li>A sends <b>ACK</b> with Seq = <i>x</i> + 1 and Ack = <i>y</i> + 1.</li></ol>' +
    '<p>Each host is always in a named <b>state</b>, such as LISTEN (waiting for a connection) or ESTABLISHED (connected). The two badges above the timeline show both states as you step.</p>' +
    more('Random starting numbers, options, and failures', '<p>Each SYN uses one sequence number, so the first data byte is ISN + 1. Each side picks its ISN at random, so an old segment from an earlier connection is unlikely to fit. Wireshark hides this by showing <b>relative</b> numbers: it subtracts the ISN, so every SYN shows Seq=0. The raw numbers are 32 bits and wrap around after 4,294,967,295.</p>' +
    '<p>The SYNs also carry options: each side\'s MSS (Maximum Segment Size, the most data in one segment), whether it can use SACK (Selective Acknowledgment), and its Window Scale. When nothing listens on the port, B answers with <b>RST</b> (reset): "connection refused" at once. When nothing answers at all, A resends the SYN after 1 s, then 2 s, 4 s, and so on, and finally gives up: "connection timed out".</p>') +
    '<p class="lead">Pick a case, then step through it.</p>' +
    '<div class="chips2" id="l2case">' + [['normal', 'Normal'], ['closed', 'Port closed'], ['synlost', 'SYN lost'], ['salost', 'SYN, ACK lost'], ['silent', 'No answer at all'], ['simopen', 'Both open at once']].map(function (x) { return '<button class="chip2" data-k="' + x[0] + '">' + x[1] + '</button>'; }).join('') + '</div>' +
    more('Starting numbers', '<div class="row"><label>A\'s ISN <input type="number" id="l2a" class="wide" min="0" max="4294967295" value="' + c.isnA + '"></label><label>B\'s ISN <input type="number" id="l2b" class="wide" min="0" max="4294967295" value="' + c.isnB + '"></label><label><input type="checkbox" id="l2raw" checked> Raw numbers</label></div>') +
    tryBox('l2', '<p>A picks ISN <b class="addr" id="l2x"></b> and B picks <b class="addr" id="l2y"></b>. Fill in the raw numbers.</p><div class="fields">' + numIn('l2s1', 'SYN: Seq', 1) + numIn('l2s2', 'SYN, ACK: Seq', 1) + numIn('l2a2', 'SYN, ACK: Ack', 1) + numIn('l2s3', 'ACK: Seq', 1) + numIn('l2a3', 'ACK: Ack', 1) + '</div><div class="row"><button class="btn small" id="l2c">Check</button><button class="btn alt small" id="l2n">New numbers</button></div>') + seeBox();
  function run() {
    var o = cfgWith({ isnA: c.isnA, isnB: c.isnB, sack: true, ws: 7, rbufA: 64240, rbufB: 65160, mssA: 1460, mssB: 1460 });
    if (c.kase === 'closed') o.listen = false;
    if (c.kase === 'synlost') o.lose = [1];
    if (c.kase === 'salost') o.lose = [2];
    if (c.kase === 'silent') { o.lose = [1, 2, 3, 4, 5, 6, 7]; }
    if (c.kase === 'simopen') { o.simOpen = true; o.listen = false; }
    var r = simulate(o);
    $$('#l2case [data-k]').forEach(function (b) { b.setAttribute('aria-pressed', String(b.getAttribute('data-k') === c.kase)); b.style.cssText = b.getAttribute('data-k') === c.kase ? 'background:var(--panel);border-color:var(--brand);color:var(--navy)' : ''; });
    mountRun(r, { raw: function () { return c.raw; }, sm: true, events: true, tall: c.kase === 'silent' });
  }
  $('#l2a').onchange = function () { var v = Math.floor(+this.value); if (v >= 0 && v < MOD) { c.isnA = v; run(); } };
  $('#l2b').onchange = function () { var v = Math.floor(+this.value); if (v >= 0 && v < MOD) { c.isnB = v; run(); } };
  $('#l2raw').onchange = function () { c.raw = this.checked; run(); };
  $$('#l2case [data-k]').forEach(function (b) { b.onclick = function () { c.kase = b.getAttribute('data-k'); run(); }; });
  run();
  var x, y;
  function gen() { x = pick([rnd(0, MOD - 1), MOD - rnd(1, 3), rnd(0, MOD - 1)]); y = pick([rnd(0, MOD - 1), MOD - 1, rnd(0, 99999)]); $('#l2x').textContent = x; $('#l2y').textContent = y; lessonState.solve = function () { [x, y, m32(x + 1), m32(x + 1), m32(y + 1)].forEach(function (v, i) { $('#' + ['l2s1', 'l2s2', 'l2a2', 'l2s3', 'l2a3'][i]).value = v; }); }; ['l2s1', 'l2s2', 'l2a2', 'l2s3', 'l2a3'].forEach(function (i) { $('#' + i).value = ''; }); $('#l2fb').innerHTML = ''; $('#l2fb').className = 'feedback'; }
  gen(); $('#l2n').onclick = gen;
  $('#l2c').onclick = function () {
    var want = [x, y, m32(x + 1), m32(x + 1), m32(y + 1)], got = ['l2s1', 'l2s2', 'l2a2', 'l2s3', 'l2a3'].map(val), bad = [];
    want.forEach(function (w, i) { if (got[i] !== w) bad.push(['the SYN\'s Seq', 'the SYN, ACK\'s Seq', 'the SYN, ACK\'s Ack', 'the ACK\'s Seq', 'the ACK\'s Ack'][i]); });
    if (!bad.length) lessonDone($('#l2fb'), 'SYN Seq=' + x + '; SYN, ACK Seq=' + y + ' Ack=' + m32(x + 1) + '; ACK Seq=' + m32(x + 1) + ' Ack=' + m32(y + 1) + '. Each SYN used one number' + (x === MOD - 1 || y === MOD - 1 ? ', and 4294967295 + 1 wraps to 0.' : '.'));
    else wrong($('#l2fb'), 'Check ' + bad.join(', ') + '. An Ack names the next number expected, and each SYN uses one number. Past 4294967295 the count starts again at 0.');
  };
  cmdPanel($('#seeCmds'), ['connect', 'states', 'settings'], 'Start a server, connect to it, and look at both sides\' states. Then try a port where nothing listens.');
} },
/* ---------------------------------------------------------------- 3 */
{ t: 'Numbering every byte', setup: function () {
  var c = { a: 250, b: 60, dack: false };
  $('#ltext').innerHTML = lessonHead(2, 'Numbering every byte') +
    '<p>TCP numbers <b>bytes</b>, not segments. A segment with sequence number Seq = 101 and length Len = 100 carries bytes 101 to 200, so the next one starts at 201.</p>' +
    '<p>An <b>ACK</b> (acknowledgment) names the next byte the receiver expects, and it covers everything before it (it is <b>cumulative</b>). Ack = 301 means "I have bytes 1 to 300".</p>' +
    more('Piggybacking and delayed ACKs', '<p>Data flows both ways, and each direction has its own numbers. When B has data to send back, its data segment also carries the ACK. This is called <b>piggybacking</b>.</p>' +
    '<p>Receivers may wait a little before ACKing, hoping to piggyback the ACK or to cover two segments with one ACK. This is a <b>delayed ACK</b>: at least every second full segment, or after a short timer (40 ms here, about what Linux uses; Windows uses 200 ms).</p>' +
    '<p>Each segment carries at most one MSS (Maximum Segment Size) of data: 100 bytes in these lessons, so the numbers stay easy. On Ethernet it is 1460, or 1448 with Timestamps.</p>') +
    '<div class="row"><label>A writes <input type="number" id="l3a" min="1" max="900" value="' + c.a + '"> bytes</label><label>then B replies <input type="number" id="l3b" min="0" max="400" value="' + c.b + '"> bytes</label><label><input type="checkbox" id="l3d"> Delayed ACKs</label></div>' +
    tryBox('l3', '<p>In the timeline, three numbers are hidden (shown as ?). A wrote <b id="l3wa"></b> bytes, and B answered with <b id="l3wb"></b>. Fill them in.</p><div class="fields" id="l3q"></div><div class="row"><button class="btn small" id="l3c">Check</button><button class="btn alt small" id="l3n">New connection</button></div>') + seeBox();
  var task = null, hide = {};
  function run() {
    var r = simulate(cfgWith({ rbufB: 1000, rbufA: 1000, dack: c.dack, writes: [{ side: 'A', at: 0, bytes: c.a }].concat(c.b > 0 ? [{ side: 'B', onRead: c.a, bytes: c.b }] : []) }));
    mountRun(r, { title: 'Timeline: sequence and acknowledgment numbers', hide: hide });
    return r;
  }
  $('#l3a').onchange = function () { var v = Math.floor(+this.value); if (v >= 1 && v <= 900) { c.a = v; gen(true); } };
  $('#l3b').onchange = function () { var v = Math.floor(+this.value); if (v >= 0 && v <= 400) { c.b = v; gen(true); } };
  $('#l3d').onchange = function () { c.dack = this.checked; gen(true); };
  function gen(keep) {
    if (!keep) { c.a = rnd(150, 380); c.b = rnd(20, 90); c.dack = false; $('#l3a').value = c.a; $('#l3b').value = c.b; $('#l3d').checked = false; }
    hide = {};
    var r = simulate(cfgWith({ rbufB: 1000, rbufA: 1000, dack: c.dack, writes: [{ side: 'A', at: 0, bytes: c.a }].concat(c.b > 0 ? [{ side: 'B', onRead: c.a, bytes: c.b }] : []) }));
    var dataA = r.segs.filter(function (s) { return s.from === 'A' && s.kind === 'data'; }), dataB = r.segs.filter(function (s) { return s.from === 'B' && s.kind === 'data'; });
    var lastA = r.segs.filter(function (s) { return s.from === 'A'; }).slice(-1)[0];
    var cands = [];
    if (dataA.length > 1) cands.push([dataA[dataA.length - 1], 'seq']);
    if (dataA.length > 1) cands.push([dataA[1], 'seq']);
    if (dataB.length) { cands.push([dataB[0], 'ack']); cands.push([dataB[0], 'seq']); }
    if (lastA && lastA.kind === 'ack') { cands.push([lastA, 'ack']); cands.push([lastA, 'seq']); }
    var ackB = r.segs.filter(function (s) { return s.from === 'B' && s.kind === 'ack'; }); if (ackB.length) cands.push([ackB[0], 'ack']);
    var seen = {}; cands = shuffle(cands).filter(function (x) { var k = x[0].n + x[1]; if (seen[k]) return false; seen[k] = 1; return true; }).slice(0, 3);
    cands.sort(function (p, q) { return p[0].n - q[0].n; });
    cands.forEach(function (x) { hide[x[0].n] = hide[x[0].n] || {}; hide[x[0].n][x[1]] = true; });
    task = cands.map(function (x) { return { n: x[0].n, f: x[1], v: x[1] === 'seq' ? x[0].seq : x[0].ack }; });
    $('#l3wa').textContent = c.a; $('#l3wb').textContent = c.b;
    $('#l3q').innerHTML = task.map(function (t, i) { return numIn('l3t' + i, 'Segment #' + t.n + ': ' + (t.f === 'seq' ? 'Seq' : 'Ack')); }).join('');
    $('#l3fb').innerHTML = ''; $('#l3fb').className = 'feedback';
    lessonState.solve = function () { task.forEach(function (t, i) { $('#l3t' + i).value = t.v; }); };
    run();
  }
  $('#l3n').onclick = function () { gen(false); };
  $('#l3c').onclick = function () {
    var bad = task.filter(function (t, i) { return val('l3t' + i) !== t.v; });
    if (!bad.length) lessonDone($('#l3fb'), task.map(function (t) { return '#' + t.n + ' ' + (t.f === 'seq' ? 'Seq' : 'Ack') + '=' + t.v; }).join(', ') + '. Seq is the first byte the segment carries; Ack is the next byte expected.');
    else wrong($('#l3fb'), 'Look again at ' + bad.map(function (t) { return '#' + t.n; }).join(' and ') + '. Seq = previous Seq + previous Len in the same direction. Ack = the other side\'s next byte: its last Seq + Len.');
  };
  gen(true);
  cmdPanel($('#seeCmds'), ['connect', 'wireshark'], 'Connect with nc, type a short line on each side, and read Seq, Ack, and Len in Wireshark. Statistics → Flow Graph draws a timeline like this one.');
} },
/* ---------------------------------------------------------------- 4 */
{ t: 'Flow control: the sliding window', setup: function () {
  var c = { buf: 400, read: 'pause2' };
  $('#ltext').innerHTML = lessonHead(3, 'Flow control: the sliding window') +
    '<p>B keeps arriving bytes in a <b>receive buffer</b> until its application reads them. Every segment B sends advertises how much room is left: the <b>window</b>.</p>' +
    '<p>A may have at most one window of bytes in flight (sent but not yet acknowledged). With SND.UNA, the oldest unacknowledged byte, and SND.NXT, the next byte to send:</p>' +
    '<ul class="list"><li>bytes in flight = SND.NXT − SND.UNA</li><li>usable window = SND.UNA + advertised window − SND.NXT</li></ul>' +
    more('Zero window, probes, and Window Scale', '<p>If B\'s application stops reading, the window shrinks to <b>0</b> and A must stop. A then sends a small <b>window probe</b> now and then (Linux sends one with Seq one below SND.UNA and no data; Wireshark labels it Keep-Alive) so it learns when the window opens. When the application reads, B sends a <b>window update</b>.</p>' +
    '<p>The window field has 16 bits, so it stops at 65,535 bytes. The <b>Window Scale</b> option, agreed in the SYNs, multiplies it by 2<sup>shift</sup>. Wireshark shows the result.</p>') +
    '<div class="row"><label>B\'s buffer <select id="l4b"><option>300</option><option selected>400</option><option>600</option><option>1000</option></select> bytes</label><label>B\'s application <select id="l4r"><option value="now">reads at once</option><option value="pause2" selected>pauses for 2 s</option><option value="pause5">pauses for 5 s</option></select></label></div>' +
    more('Window Scale calculator', '<div class="soft"><b>Window Scale</b>: field <input type="number" id="l4f" value="502" min="0" max="65535"> × 2<sup><input type="number" id="l4s" value="7" min="0" max="14" style="width:4em"></sup> = <b id="l4w" class="mono"></b> bytes</div>') +
    tryBox('l4', '<p id="l4qt"></p><div class="fields">' + numIn('l4q1', 'Advertised window (bytes)') + numIn('l4q2', 'Usable window (bytes)') + '<label>May A send a 100-byte segment? <select id="l4q3"><option value="">choose…</option><option>yes</option><option>no</option></select></label></div><div class="row"><button class="btn small" id="l4c">Check</button><button class="btn alt small" id="l4n">New numbers</button></div>') + seeBox();
  function ws() { var f = Math.max(0, Math.min(65535, Math.floor(+$('#l4f').value || 0))), s = Math.max(0, Math.min(14, Math.floor(+$('#l4s').value || 0))); $('#l4w').textContent = fmt(f * Math.pow(2, s)); }
  $('#l4f').oninput = ws; $('#l4s').oninput = ws; ws();
  function run() {
    var rd = c.read === 'now' ? { kind: 'now' } : { kind: 'pause', until: c.read === 'pause2' ? 2000 : 5000 };
    var r = simulate(cfgWith({ rbufB: c.buf, writes: [{ side: 'A', at: 0, bytes: 1000 }], readB: rd }));
    mountRun(r, { title: 'Timeline: A sends 1000 bytes', ribbons: true, events: true });
  }
  $('#l4b').onchange = function () { c.buf = +this.value; run(); };
  $('#l4r').onchange = function () { c.read = this.value; run(); };
  run();
  var q;
  function gen() {
    var B = pick([400, 500, 600, 800, 1000, 2000]), U = 100 * rnd(0, B / 100), adv = B - U, F = Math.min(adv, 100 * rnd(0, Math.max(0, adv / 100)));
    if (Math.random() < 0.3) F = adv;
    q = { B: B, U: U, F: F, adv: adv, use: adv - F };
    $('#l4qt').innerHTML = 'B\'s receive buffer holds <b>' + B + '</b> bytes. Its application has not yet read <b>' + U + '</b> of them. B sends an ACK now. Since that ACK, A has sent <b>' + F + '</b> more bytes, all still in flight.';
    lessonState.solve = function () { $('#l4q1').value = q.adv; $('#l4q2').value = q.use; $('#l4q3').value = q.use >= 100 ? 'yes' : 'no'; };
    ['l4q1', 'l4q2'].forEach(function (i) { $('#' + i).value = ''; }); $('#l4q3').value = ''; $('#l4fb').innerHTML = ''; $('#l4fb').className = 'feedback';
  }
  gen(); $('#l4n').onclick = gen;
  $('#l4c').onclick = function () {
    var a = val('l4q1') === q.adv, u = val('l4q2') === q.use, y = $('#l4q3').value === (q.use >= 100 ? 'yes' : 'no');
    if (a && u && y) lessonDone($('#l4fb'), 'Window = ' + q.B + ' − ' + q.U + ' = ' + q.adv + '. Usable = ' + q.adv + ' − ' + q.F + ' = ' + q.use + (q.use >= 100 ? ', so a 100-byte segment fits.' : ', so A must wait.'));
    else wrong($('#l4fb'), (!a ? 'The window is the free space in B\'s buffer. ' : '') + (!u ? 'Usable window = advertised window − bytes already in flight. ' : '') + (!y ? 'A may send only if the segment fits in the usable window.' : ''));
  };
  cmdPanel($('#seeCmds'), ['zero', 'wireshark', 'inside'], 'Make a receiver that does not read, fill its window, and watch for [TCP ZeroWindow], [TCP Keep-Alive], and [TCP Window Update] in Wireshark.');
} },
/* ---------------------------------------------------------------- 5 */
{ t: 'Loss and retransmission', setup: function () {
  var c = { lose: [3], sack: true, n: 8 };
  $('#ltext').innerHTML = lessonHead(4, 'Loss and retransmission') +
    '<p>When a segment is lost, the receiver keeps the later segments in its buffer (out of order) but cannot move its ACK (acknowledgment) past the gap. Every later arrival gets the <b>same ACK</b> again: a <b>duplicate ACK</b>.</p>' +
    '<p>The sender finds the loss in one of two ways:</p><ul class="list"><li><b>Three duplicate ACKs</b>: it resends the missing segment at once. This is <b>fast retransmit</b>.</li><li><b>Timeout</b>: no ACK comes before the retransmission timer (RTO) expires, so it resends the oldest unacknowledged segment and doubles the timer. This happens when too few segments follow the loss, for example when the last one is lost.</li></ul>' +
    more('Selective acknowledgment, lost ACKs, and what is left out', '<p>With <b>SACK</b> (Selective Acknowledgment), duplicate ACKs also list the blocks that did arrive, so the sender can resend just the holes. A lost <b>ACK</b> usually costs nothing: the next ACK is cumulative and covers it.</p>' +
    '<p>When the sender resends, it also slows down. That part is congestion control, which this tool leaves out.</p>') +
    '<div class="row"><label>A sends <select id="l5n"><option>4</option><option>6</option><option selected>8</option></select> segments of 100 bytes</label><label><input type="checkbox" id="l5s" checked> SACK</label></div>' +
    '<p style="margin-bottom:2px"><b>Lose these data segments</b> (Seq is each one\'s sequence number):</p><div class="chips2" id="l5l"></div><div class="chips2" id="l5ack"></div>' +
    tryBox('l5', '<p id="l5qt"></p><div class="fields">' + numIn('l5q1', 'Ack number in those duplicate ACKs') + numIn('l5q2', 'How many duplicate ACKs?') + '<label>How is the lost segment resent? <select id="l5q3"><option value="">choose…</option><option value="fast">fast retransmit</option><option value="rto">timeout</option></select></label></div><div class="row"><button class="btn small" id="l5c">Check</button><button class="btn alt small" id="l5x">New loss</button></div>') + seeBox();
  function chips() {
    var h = ''; for (var k = 1; k <= c.n; k++) h += '<button class="chip2" data-k="' + k + '" aria-pressed="' + (c.lose.indexOf(k) >= 0) + '">segment ' + k + ' (Seq=' + (1 + 100 * (k - 1)) + ')</button>';
    $('#l5l').innerHTML = h;
    $('#l5ack').innerHTML = '<button class="chip2" data-a="1" aria-pressed="' + (c.lose.indexOf('a') >= 0) + '">B\'s first ACK</button>';
    $$('#l5l [data-k]').forEach(function (b) { b.onclick = function () { var k = +b.getAttribute('data-k'), i = c.lose.indexOf(k); if (i >= 0) c.lose.splice(i, 1); else c.lose.push(k); run(); }; });
    $('#l5ack [data-a]').onclick = function () { var i = c.lose.indexOf('a'); if (i >= 0) c.lose.splice(i, 1); else c.lose.push('a'); run(); };
  }
  function run() {
    chips();
    var lose = c.lose.map(function (k) { return k === 'a' ? 4 + c.n : 3 + k; });
    var r = simulate(cfgWith({ rbufB: 1000, sack: c.sack, n: c.n, writes: [{ side: 'A', at: 0, bytes: 100 * c.n }], lose: lose }));
    mountRun(r, { title: 'Timeline: A sends ' + c.n + ' segments', loss: true, events: true, click: function (n) {
      var k = n - 3; if (k >= 1 && k <= c.n) { var i = c.lose.indexOf(k); if (i >= 0) c.lose.splice(i, 1); else c.lose.push(k); run(); }
      else if (n === 4 + c.n) { var j = c.lose.indexOf('a'); if (j >= 0) c.lose.splice(j, 1); else c.lose.push('a'); run(); } } });
  }
  $('#l5n').onchange = function () { c.n = +this.value; c.lose = c.lose.filter(function (k) { return k === 'a' || k <= c.n; }); run(); };
  $('#l5s').onchange = function () { c.sack = this.checked; run(); };
  run();
  var q;
  function gen() {
    var N = rnd(5, 9), k = rnd(1, N - 1); q = { N: N, k: k, ack: 1 + 100 * (k - 1), dups: N - k, how: N - k >= 3 ? 'fast' : 'rto' };
    $('#l5qt').innerHTML = 'A sends <b>' + N + '</b> segments of 100 bytes (Seq=1, 101, 201, …), and only segment <b>' + k + '</b> is lost. B ACKs every segment at once.';
    lessonState.solve = function () { $('#l5q1').value = q.ack; $('#l5q2').value = q.dups; $('#l5q3').value = q.how; };
    ['l5q1', 'l5q2'].forEach(function (i) { $('#' + i).value = ''; }); $('#l5q3').value = ''; $('#l5fb').innerHTML = ''; $('#l5fb').className = 'feedback';
  }
  gen(); $('#l5x').onclick = gen;
  $('#l5c').onclick = function () {
    var a = val('l5q1') === q.ack, d = val('l5q2') === q.dups, h = $('#l5q3').value === q.how;
    if (a && d && h) lessonDone($('#l5fb'), 'B still expects byte ' + q.ack + ', so the ' + q.dups + ' later segments each bring Ack=' + q.ack + '. ' + (q.how === 'fast' ? 'Three or more duplicates: fast retransmit.' : 'Fewer than three duplicates, so A waits for its timer.'));
    else wrong($('#l5fb'), (!a ? 'The duplicate ACKs name the first missing byte: where segment ' + q.k + ' starts. ' : '') + (!d ? 'Each segment after the lost one brings one duplicate ACK. ' : '') + (!h ? 'Fast retransmit needs three duplicate ACKs.' : ''));
  };
  cmdPanel($('#seeCmds'), ['loss', 'wireshark', 'inside'], 'Add loss on a Linux computer, send a file through nc, and filter Wireshark for retransmissions and duplicate ACKs. Remove the loss when you are done.');
} },
/* ---------------------------------------------------------------- 6 */
{ t: 'Setting the timer', setup: function () {
  var c = { samples: '100, 120, 300, 110, 90, 95', skip: {}, min: 0 };
  $('#ltext').innerHTML = lessonHead(5, 'Setting the timer') +
    '<p>How long should a sender wait before it resends? Too short and it resends segments that were only slow; too long and a loss stalls the connection. Round-trip times (RTT) differ from path to path and change over time, so TCP measures them.</p>' +
    '<p>For each new round-trip sample R, the standard RFC 6298 (Request for Comments 6298) updates a smoothed RTT (SRTT) and the RTT variation (RTTVAR):</p>' +
    '<ul class="list"><li>First sample: SRTT = R, RTTVAR = R / 2.</li><li>Later: RTTVAR = ¾ RTTVAR + ¼ |SRTT − R| (using the old SRTT), then SRTT = ⅞ SRTT + ⅛ R.</li><li>RTO (retransmission timeout) = SRTT + 4 × RTTVAR, but at least the minimum (1 s in the standard; 200 ms on Linux).</li></ul>' +
    more('Karn\'s rule and backoff', '<p><b>Karn\'s rule</b>: when a segment was sent twice, its ACK (acknowledgment) could belong to either copy, so that sample is skipped. <b>Backoff</b>: each timeout doubles the RTO (1 s, 2 s, 4 s, …) until an ACK for new data arrives. Before any sample, the RTO is 1 s.</p>') +
    '<div class="row"><label>Round-trip time samples in ms <input type="text" id="l6s" size="28" value="' + c.samples + '"></label><label>Minimum RTO <select id="l6m"><option value="0">none (see the formula)</option><option value="200">200 ms (Linux)</option><option value="1000">1 s (standard)</option></select></label></div>' +
    '<p style="margin-bottom:2px"><b>Sent twice?</b> (Karn\'s rule skips these)</p><div class="chips2" id="l6k"></div>' +
    tryBox('l6', '<p id="l6qt"></p><div class="fields">' + numIn('l6q1', 'New RTTVAR (ms)') + numIn('l6q2', 'New SRTT (ms)') + numIn('l6q3', 'New RTO (ms)') + '</div><div class="row"><button class="btn small" id="l6c">Check</button><button class="btn alt small" id="l6n">New numbers</button></div>') + seeBox();
  $('#lfig').innerHTML = figCard('SRTT and RTO after each sample', '<div class="fig"><svg id="l6p" role="img"></svg></div>', RTO_LEGEND) + fold('The working, sample by sample', '<ol class="events" id="l6w"></ol>') +
    fold('Backoff: timeouts in a row', '<ol class="events" id="l6b"></ol>');
  function parse() { return ($('#l6s').value.match(/\d+(\.\d+)?/g) || []).map(Number).filter(function (v) { return v > 0 && v < 100000; }).slice(0, 12); }
  function r1(v) { return Math.round(v * 10) / 10; }
  function draw() {
    var S = parse(), skip = S.map(function (x, i) { return !!c.skip[i]; }), ser = rtoSeries(S, skip, c.min);
    $('#l6k').innerHTML = S.map(function (s, i) { return '<button class="chip2" data-i="' + i + '" aria-pressed="' + !!c.skip[i] + '">sample ' + (i + 1) + ' (' + s + ' ms)</button>'; }).join('');
    $$('#l6k [data-i]').forEach(function (b) { b.onclick = function () { var i = +b.getAttribute('data-i'); c.skip[i] = !c.skip[i]; draw(); }; });
    if (S.length) drawRtoPlot($('#l6p'), ser, c.min);
    $('#l6w').innerHTML = ser.map(function (s, i) {
      if (s.skipped) return '<li><b>Sample ' + (i + 1) + ' (' + s.R + ' ms)</b>: skipped by Karn\'s rule; nothing changes.</li>';
      return '<li><b>Sample ' + (i + 1) + ' (' + s.R + ' ms)</b>: RTTVAR = ' + r1(s.rttvar) + ', SRTT = ' + r1(s.srtt) + ', SRTT + 4 × RTTVAR = ' + r1(s.rtoRaw) + (s.rto !== s.rtoRaw ? ', raised to the minimum: RTO = ' + r1(s.rto) : ', so RTO = ' + r1(s.rto)) + ' ms.</li>';
    }).join('');
    var last = ser.length ? ser[ser.length - 1].rto : 1000, b = [];
    for (var k = 0; k < 5; k++) b.push('<li>Timeout ' + (k + 1) + ': wait ' + r1(last * Math.pow(2, k)) + ' ms, resend, double the RTO.</li>');
    $('#l6b').innerHTML = b.join('');
  }
  $('#l6s').oninput = function () { c.skip = {}; draw(); }; $('#l6m').onchange = function () { c.min = +this.value; draw(); };
  draw();
  var q;
  function gen() {
    var srtt = 8 * rnd(60, 180), rttvar = 4 * rnd(20, 90), R = 8 * rnd(40, 260);
    var nv = 0.75 * rttvar + 0.25 * Math.abs(srtt - R), ns = 0.875 * srtt + 0.125 * R;
    q = { srtt: srtt, rttvar: rttvar, R: R, nv: nv, ns: ns, rto: ns + 4 * nv };
    $('#l6qt').innerHTML = 'SRTT = <b>' + srtt + '</b> ms and RTTVAR = <b>' + rttvar + '</b> ms. A new sample arrives: R = <b>' + R + '</b> ms. Use the standard formulas (no minimum is needed here).';
    lessonState.solve = function () { $('#l6q1').value = q.nv; $('#l6q2').value = q.ns; $('#l6q3').value = q.rto; };
    ['l6q1', 'l6q2', 'l6q3'].forEach(function (i) { $('#' + i).value = ''; }); $('#l6fb').innerHTML = ''; $('#l6fb').className = 'feedback';
  }
  gen(); $('#l6n').onclick = gen;
  $('#l6c').onclick = function () {
    function ok(id, v) { return Math.abs(val(id) - v) <= 0.5; }
    var a = ok('l6q1', q.nv), b = ok('l6q2', q.ns), d = ok('l6q3', q.rto);
    if (a && b && d) lessonDone($('#l6fb'), 'RTTVAR = ¾ × ' + q.rttvar + ' + ¼ × |' + q.srtt + ' − ' + q.R + '| = ' + q.nv + '. SRTT = ⅞ × ' + q.srtt + ' + ⅛ × ' + q.R + ' = ' + q.ns + '. RTO = ' + q.ns + ' + 4 × ' + q.nv + ' = ' + q.rto + ' ms.');
    else wrong($('#l6fb'), (!a ? 'RTTVAR uses the old SRTT: ¾ RTTVAR + ¼ |SRTT − R|. ' : '') + (!b ? 'SRTT = ⅞ SRTT + ⅛ R. ' : '') + (!d ? 'RTO uses the new values: SRTT + 4 × RTTVAR.' : ''));
  };
  cmdPanel($('#seeCmds'), ['inside', 'settings'], 'Open a connection and look at its timer: on Linux, ss -ti prints rtt as SRTT/RTTVAR in ms and rto in ms.');
} },
/* ---------------------------------------------------------------- 7 */
{ t: 'Closing and TIME_WAIT', setup: function () {
  var c = { kase: 'aFirst' };
  var CASES = [['aFirst', 'A closes first'], ['bFirst', 'B closes first'], ['three', 'B closes at once (3 segments)'], ['both', 'Both close at once'], ['lastAck', 'Last ACK lost'], ['reset', 'Close with unread data']];
  $('#ltext').innerHTML = lessonHead(6, 'Closing and TIME_WAIT') +
    '<p>Each direction closes on its own. A <b>FIN</b> (finish) means "no more data from me", and it uses one sequence number, so its ACK (acknowledgment) is FIN\'s sequence number + 1. The other side can still send until it closes too. That is a <b>half-close</b>.</p>' +
    '<ul class="list"><li>The side that closes first goes FIN_WAIT_1 → FIN_WAIT_2 → <b>TIME_WAIT</b>.</li><li>The other side goes CLOSE_WAIT (its program has been told the other side finished) → LAST_ACK → CLOSED.</li></ul>' +
    more('Three-segment close, TIME_WAIT, and resets', '<p>If B closes as soon as it reads the FIN, its FIN rides on the ACK, so a capture shows three segments, not four.</p>' +
    '<p><b>Why TIME_WAIT?</b> The side that sent the last ACK waits 2 × MSL (Maximum Segment Lifetime), 60 seconds on Linux and 120 on Windows, for two reasons:</p><ul class="list"><li>If that ACK is lost, the other side resends its FIN, and the ACK must be sent again.</li><li>Old segments must die out before the same two addresses and ports are used again.</li></ul>' +
    '<p>Closing with data still unread sends <b>RST</b> (reset) instead: the other program gets "connection reset".</p>') +
    '<div class="chips2" id="l7case">' + CASES.map(function (x) { return '<button class="chip2" data-k="' + x[0] + '">' + x[1] + '</button>'; }).join('') + '</div>' +
    tryBox('l7', '<p id="l7qt"></p><div class="fields"><label>A\'s state <select id="l7a"></select></label><label>B\'s state <select id="l7b"></select></label></div><div class="row"><button class="btn small" id="l7c">Check</button><button class="btn alt small" id="l7n">New case</button></div>') + seeBox();
  var STATES = ['ESTABLISHED', 'FIN_WAIT_1', 'FIN_WAIT_2', 'CLOSE_WAIT', 'CLOSING', 'LAST_ACK', 'TIME_WAIT', 'CLOSED'];
  ['l7a', 'l7b'].forEach(function (id) { $('#' + id).innerHTML = '<option value="">choose…</option>' + STATES.map(function (s) { return '<option>' + s + '</option>'; }).join(''); });
  function cfgFor(k) {
    var o = cfgWith({ dack: true, writes: [{ side: 'A', at: 0, bytes: 150 }] });
    if (k === 'aFirst') { o.closeA = { kind: 'at', at: 600 }; o.closeB = { kind: 'onFin', delay: 300 }; }
    if (k === 'bFirst') { o.closeB = { kind: 'at', at: 600 }; o.closeA = { kind: 'onFin', delay: 300 }; }
    if (k === 'three') { o.closeA = { kind: 'at', at: 600 }; o.closeB = { kind: 'onFin', delay: 0 }; }
    if (k === 'both') { o.closeA = { kind: 'at', at: 600 }; o.closeB = { kind: 'at', at: 600 }; }
    if (k === 'lastAck') { o.closeA = { kind: 'at', at: 600 }; o.closeB = { kind: 'onFin', delay: 0 }; }
    if (k === 'reset') { o.readB = { kind: 'never' }; o.closeB = { kind: 'at', at: 600 }; }
    if (k === 'lastAck') { var r0 = simulate(o); var fins = r0.segs.filter(function (s) { return s.from === 'B' && s.f.F; }); o.lose = [fins[0].n + 1]; }
    return o;
  }
  function run() {
    $$('#l7case [data-k]').forEach(function (b) { var on = b.getAttribute('data-k') === c.kase; b.setAttribute('aria-pressed', String(on)); b.style.cssText = on ? 'background:var(--panel);border-color:var(--brand);color:var(--navy)' : ''; });
    mountRun(simulate(cfgFor(c.kase)), { sm: true, events: true });
  }
  $$('#l7case [data-k]').forEach(function (b) { b.onclick = function () { c.kase = b.getAttribute('data-k'); run(); }; });
  run();
  var q;
  function gen() {
    var k = pick(['aFirst', 'bFirst', 'three', 'both', 'reset', 'mid']), o, txt, T;
    if (k === 'mid') { o = cfgFor('aFirst'); var r = simulate(o); var fa = r.segs.filter(function (s) { return s.from === 'A' && s.f.F; })[0];
      var ab = r.segs.filter(function (s) { return s.from === 'B' && s.f.A && !s.f.F && s.ack === fa.seq + 1; })[0]; T = ab.tArr + 1; q = { a: stateAt(r, 'A', T), b: stateAt(r, 'B', T) };
      txt = 'A has sent its FIN, and B has acknowledged it but has not closed yet (its program is still working). What state is each side in?'; }
    else {
      var r2 = simulate(cfgFor(k)), last = r2.segs[r2.segs.length - 1]; T = last.tArr + 1;
      q = { a: stateAt(r2, 'A', T), b: stateAt(r2, 'B', T) };
      txt = { aFirst: 'A closes first, and B closes a little later. All the closing segments arrive. What state is each side in a second later?', bFirst: 'B closes first, and A closes a little later. All the closing segments arrive. What state is each side in a second later?',
        three: 'A closes, and B closes as soon as it reads the FIN, so its FIN rides on its ACK. Everything arrives. What state is each side in a second later?', both: 'Both programs close at the same moment, so the FINs cross. Everything arrives. What state is each side in a second later?',
        reset: 'B\'s program closes while A\'s data is still unread in B\'s buffer. What state is each side in a second later?' }[k];
    }
    lessonState.solve = function () { $('#l7a').value = q.a; $('#l7b').value = q.b; };
    $('#l7qt').innerHTML = txt; $('#l7a').value = ''; $('#l7b').value = ''; $('#l7fb').innerHTML = ''; $('#l7fb').className = 'feedback';
  }
  gen(); $('#l7n').onclick = gen;
  $('#l7c').onclick = function () {
    var a = $('#l7a').value === q.a, b = $('#l7b').value === q.b;
    if (a && b) lessonDone($('#l7fb'), 'A is in ' + q.a + ' and B is in ' + q.b + '. ' + (q.a === 'TIME_WAIT' || q.b === 'TIME_WAIT' ? 'TIME_WAIT belongs to whoever sent the last ACK of a FIN without needing an answer.' : ''));
    else wrong($('#l7fb'), 'Follow the state diagram for each side. The side whose FIN went first ends in TIME_WAIT; the other side ends CLOSED after its FIN is acknowledged. A reset closes at once.');
  };
  cmdPanel($('#seeCmds'), ['states', 'connect'], 'Open and close a few connections with nc, then list the sockets in TIME_WAIT. They disappear after about 60 seconds on Linux.');
} },
/* ---------------------------------------------------------------- 8 */
{ t: 'The state diagram, step by step', wide: true, setup: function () {
  var c = { open: 'normal', close: 'aFirst', last: false };
  var OPENS = [['normal', 'B listens, A connects'], ['simopen', 'Both connect at once'], ['sendFirst', 'Both listen, B sends first'], ['listenQuit', 'B listens, then quits'], ['giveUp', 'A gives up before an answer']];
  var CLOSES = [['aFirst', 'A closes first'], ['bFirst', 'B closes first'], ['three', 'B closes as soon as A\'s FIN arrives'], ['both', 'Both close at once'], ['early', 'A closes during the handshake']];
  /* which choices take each arrow of the diagram */
  var ARC_PATH = { 'CLOSED>LISTEN': ['normal', 'aFirst'], 'LISTEN>CLOSED': ['listenQuit'], 'CLOSED>SYN_SENT': ['normal', 'aFirst'], 'SYN_SENT>CLOSED': ['giveUp'],
    'LISTEN>SYN_RCVD': ['normal', 'aFirst'], 'LISTEN>SYN_SENT': ['sendFirst', 'aFirst'], 'SYN_SENT>SYN_RCVD': ['simopen', 'aFirst'], 'SYN_RCVD>ESTABLISHED': ['normal', 'aFirst'],
    'SYN_SENT>ESTABLISHED': ['normal', 'aFirst'], 'SYN_RCVD>FIN_WAIT_1': ['simopen', 'early'], 'ESTABLISHED>FIN_WAIT_1': ['normal', 'aFirst'], 'ESTABLISHED>CLOSE_WAIT': ['normal', 'aFirst'],
    'FIN_WAIT_1>FIN_WAIT_2': ['normal', 'aFirst'], 'FIN_WAIT_1>CLOSING': ['normal', 'both'], 'FIN_WAIT_1>TIME_WAIT': ['normal', 'three'], 'FIN_WAIT_2>TIME_WAIT': ['normal', 'aFirst'],
    'CLOSING>TIME_WAIT': ['normal', 'both'], 'CLOSE_WAIT>LAST_ACK': ['normal', 'aFirst'], 'LAST_ACK>END': ['normal', 'aFirst'], 'TIME_WAIT>END': ['normal', 'aFirst'] };
  var seen = lessonState.arcsSeen || (lessonState.arcsSeen = {});
  $('#ltext').innerHTML = lessonHead(7, 'The state diagram, step by step') +
    '<p>Each end of a connection keeps its own <b>state</b>, drawn as a box. Each arc is labeled <b>event/action</b>: what moves that end along the arc (a segment arriving, or its program calling open or close), then what it sends: SYN (synchronize), ACK (acknowledgment), or FIN (finish).</p>' +
    '<p class="lead">Choose how the connection opens and closes, or click any arrow in the diagram. Then press ▶ to take one step at a time.</p>' +
    '<p class="pp">How it opens</p><div class="chips2" id="l8open">' + OPENS.map(function (x) { return '<button class="chip2" data-k="' + x[0] + '">' + x[1] + '</button>'; }).join('') + '</div>' +
    '<p class="pp">How it closes</p><div class="chips2" id="l8close">' + CLOSES.map(function (x) { return '<button class="chip2" data-k="' + x[0] + '">' + x[1] + '</button>'; }).join('') + '</div>' +
    '<p class="cmdnote" id="l8why"></p>' +
    '<div class="row"><label><input type="checkbox" id="l8last"> Lose the last ACK (the side in LAST_ACK resends its FIN)</label></div>' +
    '<p class="cmdnote" id="l8cov" aria-live="polite"></p>' +
    more('The usual paths, and the rare ones', '<ul class="list"><li><b>Opening, server:</b> CLOSED → LISTEN → SYN_RCVD → ESTABLISHED.</li><li><b>Opening, client:</b> CLOSED → SYN_SENT → ESTABLISHED.</li><li><b>The side that closes first:</b> ESTABLISHED → FIN_WAIT_1 → FIN_WAIT_2 → TIME_WAIT → CLOSED.</li><li><b>The other side:</b> ESTABLISHED → CLOSE_WAIT → LAST_ACK → CLOSED.</li><li><b>Both close at once:</b> FIN_WAIT_1 → CLOSING → TIME_WAIT.</li><li><b>FIN and ACK in one segment:</b> FIN_WAIT_1 → TIME_WAIT, when the other side\'s FIN also acknowledges this side\'s FIN.</li><li><b>Rare:</b> both connect at once (SYN_SENT → SYN_RCVD); a program closes during the handshake (SYN_RCVD → FIN_WAIT_1); a listening program quits (LISTEN → CLOSED); a client gives up before any answer (SYN_SENT → CLOSED, no segment sent); a listening program sends first (LISTEN → SYN_SENT: allowed by the standard, but the sockets interface of Linux and Windows has no way to ask for it).</li></ul>' +
    '<p>Data moves only in ESTABLISHED, and in one direction in FIN_WAIT_2 and CLOSE_WAIT (a half-closed connection). Timers and resends are not arcs: a lost segment is simply sent again, and when nothing answers, TCP gives up and returns to CLOSED.</p>' +
    '<p class="cmdnote">Names: the diagram uses the classic short names. The standard RFC 9293 (Request for Comments 9293) writes them with hyphens (SYN-RECEIVED, TIME-WAIT). Linux <code>ss</code> prints SYN-RECV and ESTAB; Windows <code>netstat</code> prints SYN_RECEIVED and LISTENING.</p>') +
    tryBox('l8', '<p id="l8qt"></p><div class="fields" id="l8q"></div><div class="row"><button class="btn small" id="l8c">Check</button><button class="btn alt small" id="l8n">New case</button></div>') + seeBox();
  function noClose(op) { return op === 'listenQuit' || op === 'giveUp'; }
  function closeOk(op, cl) { return !noClose(op) && (cl !== 'early' || op === 'simopen'); }
  function cfgFor(op, cl, last) {
    var o = cfgWith({ dack: cl === 'three', writes: [{ side: 'A', at: 0, bytes: 100 }] }), t = 500;
    if (op === 'simopen') { o.simOpen = true; o.listen = false; o.writes = []; }
    if (op === 'sendFirst') { o.openA = 'passive'; o.sendFromListen = true; o.writes = [{ side: 'B', at: 200, bytes: 100 }]; t = 700; }
    if (op === 'listenQuit') { o.openA = 'none'; o.writes = []; o.closeB = { kind: 'at', at: 300 }; return o; }
    if (op === 'giveUp') { o.writes = []; o.lose = [1]; o.closeA = { kind: 'at', at: 600, now: true }; return o; }
    if (cl === 'aFirst') { o.closeA = { kind: 'at', at: t }; o.closeB = { kind: 'onFin', delay: 300 }; }
    if (cl === 'bFirst') { o.closeB = { kind: 'at', at: t }; o.closeA = { kind: 'onFin', delay: 300 }; }
    if (cl === 'three') { o.closeA = { kind: 'at', at: t }; o.closeB = { kind: 'onFin', delay: 0 }; }
    if (cl === 'both') { o.closeA = { kind: 'at', at: t }; o.closeB = { kind: 'at', at: t }; }
    if (cl === 'early') { o.closeA = { kind: 'at', at: 70, now: true }; o.closeB = { kind: 'onFin', delay: 300 }; }
    if (last) {   // lose the ACK of the FIN sent from LAST_ACK
      var r0 = simulate(o), la = ['A', 'B'].filter(function (sd) { return r0.states[sd].some(function (x) { return x.s === 'LAST_ACK'; }); })[0];
      if (la) {
        var fin = r0.segs.filter(function (g) { return g.from === la && g.f.F; })[0];
        var ack = fin && r0.segs.filter(function (g) { return g.from !== la && !g.f.F && g.len === 0 && g.ack === fin.seq + 1 && g.tSend >= fin.tArr - 1e-9; })[0];
        if (ack) o.lose = (o.lose || []).concat([ack.n]);
      }
    }
    return o;
  }
  function canLoseLast(op, cl) { var r0 = simulate(cfgFor(op, cl, false)); return ['A', 'B'].some(function (sd) { return r0.states[sd].some(function (x) { return x.s === 'LAST_ACK'; }); }); }
  function arcKey(x) { return x.arc ? x.arc[0] + '>' + x.arc[1] : ''; }
  function run(focus) {
    if (!closeOk(c.open, c.close) && !noClose(c.open)) c.close = 'aFirst';
    function mark(id, val, ok) { $$('#' + id + ' [data-k]').forEach(function (b) { var k = b.getAttribute('data-k'), on = k === val, en = ok(k); b.disabled = !en; b.setAttribute('aria-pressed', String(on && en)); b.style.cssText = on && en ? 'background:var(--panel);border-color:var(--brand);color:var(--navy)' : ''; }); }
    mark('l8open', c.open, function () { return true; });
    mark('l8close', c.close, function (k) { return closeOk(c.open, k); });
    var canLast = !noClose(c.open) && canLoseLast(c.open, c.close); if (!canLast) c.last = false;
    $('#l8last').disabled = !canLast; $('#l8last').checked = c.last;
    $('#l8why').textContent = noClose(c.open) ? 'No connection opens in this path, so there is nothing to close.' : c.open !== 'simopen' ? '"A closes during the handshake" needs "Both connect at once": only then does A wait in SYN_RCVD.' : '';
    var r = simulate(cfgFor(c.open, c.close, c.last)), steps = smSteps(r, -1, Infinity);
    steps.forEach(function (x) { if (x.arc) seen[arcKey(x)] = true; });
    var n = Object.keys(seen).length, miss = SM_ARCS.filter(function (e) { return !seen[e[0] + '>' + e[1]]; });
    $('#l8cov').innerHTML = 'Arrows you have taken: <b>' + n + ' of ' + SM_ARCS.length + '</b>.' + (miss.length ? ' Gray arrows are still to take: click one.' : ' You have taken every arrow in the diagram.');
    var p = mountRun(r, { side: true, pkts: false, statesOnly: true, start: 'first', title: 'Timeline: the segments behind each step', arcClick: pickArc });
    if (focus) { var hit = steps.filter(function (x) { return arcKey(x) === focus; })[0]; if (hit) p.seekTime(hit.t, true); }
  }
  function pickArc(key) {
    var path = ARC_PATH[key]; if (!path) return;
    var r = simulate(cfgFor(c.open, c.close, c.last));
    if (!smSteps(r, -1, Infinity).some(function (x) { return arcKey(x) === key; })) { c.open = path[0]; if (path[1]) c.close = path[1]; c.last = false; }
    run(key);
  }
  $$('#l8open [data-k]').forEach(function (b) { b.onclick = function () { c.open = b.getAttribute('data-k'); run(); }; });
  $$('#l8close [data-k]').forEach(function (b) { b.onclick = function () { if (!b.disabled) { c.close = b.getAttribute('data-k'); run(); } }; });
  $('#l8last').onchange = function () { c.last = this.checked; run(); };
  run();
  var STATES = ['LISTEN', 'SYN_SENT', 'SYN_RCVD', 'ESTABLISHED', 'FIN_WAIT_1', 'FIN_WAIT_2', 'CLOSING', 'TIME_WAIT', 'CLOSE_WAIT', 'LAST_ACK', 'CLOSED'];
  var q;
  var OPEN_TXT = { normal: 'B listens and A connects; A sends data.', simopen: 'Both programs connect at the same moment, so the two SYNs cross.', sendFirst: 'Both programs listen; then B\'s program sends data first.' };
  var CLOSE_TXT = { aFirst: 'A closes first; B closes a little later.', bFirst: 'B closes first; A closes a little later.', three: 'A closes; B closes as soon as A\'s FIN arrives, so its FIN rides on its ACK.', both: 'Both programs close at the same moment.', early: 'A\'s program closes during the handshake; B closes later.' };
  function gen() {
    var op = pick(['normal', 'normal', 'simopen', 'sendFirst']), cl = pick(op === 'simopen' ? ['aFirst', 'bFirst', 'three', 'both', 'early'] : ['aFirst', 'bFirst', 'three', 'both']);
    var side = pick(['A', 'B']), r = simulate(cfgFor(op, cl, false));
    var seq = r.states[side].slice(1).map(function (x) { return x.s; });
    var txt = OPEN_TXT[op] + ' ' + CLOSE_TXT[cl];
    q = { seq: seq, side: side };
    $('#l8qt').innerHTML = txt + ' Choose <b>Host ' + side + '\'s</b> states in order, from its first state after CLOSED until it is CLOSED again (' + seq.length + ' states).';
    $('#l8q').innerHTML = seq.map(function (x, i) { return '<label>' + (i + 1) + '. <select id="l8s' + i + '"><option value="">choose…</option>' + STATES.map(function (s) { return '<option>' + s + '</option>'; }).join('') + '</select></label>'; }).join('');
    $('#l8fb').innerHTML = ''; $('#l8fb').className = 'feedback';
    lessonState.solve = function () { seq.forEach(function (s, i) { $('#l8s' + i).value = s; }); };
  }
  gen(); $('#l8n').onclick = gen;
  $('#l8c').onclick = function () {
    var firstBad = -1; q.seq.forEach(function (s, i) { if (firstBad < 0 && $('#l8s' + i).value !== s) firstBad = i; });
    if (firstBad < 0) lessonDone($('#l8fb'), 'Host ' + q.side + ': ' + q.seq.join(' → ') + '. Choose that path above and step through it to watch the marker take those arcs.');
    else wrong($('#l8fb'), 'Your first ' + firstBad + ' state' + (firstBad === 1 ? ' is' : 's are') + ' right. For state ' + (firstBad + 1) + ', follow the arc out of ' + (firstBad ? q.seq[firstBad - 1] : 'CLOSED') + ' for the next event at Host ' + q.side + '.');
  };
  cmdPanel($('#seeCmds'), ['states', 'connect'], 'Open a connection with nc on two terminals and list the states on both sides at each stage: after connecting, after the client presses Ctrl+C (its program ends, so it closes first), and after the server stops.');
} }
];
var MAP_PARTS = [['Opening a connection', 0, 2], ['Moving data', 2, 4], ['When segments are lost', 4, 6], ['Closing, and the whole picture', 6, 8]];
var MAP_DESC = ['Read every field of a TCP (Transmission Control Protocol) header and work out how much data a segment carries.',
  'Follow the three-way handshake and its numbers, and see what happens when a port is closed or the opening SYN (synchronize) segment is lost.',
  'Predict the sequence (Seq) and acknowledgment (Ack) numbers as data flows both ways.',
  'See how the receiver\'s window limits the sender, and what happens when the window reaches zero.',
  'Find a lost segment from duplicate acknowledgments (ACKs) or a timeout, and see what the sender resends.',
  'Work out how long the sender waits before it resends, from measured round-trip times.',
  'Close a connection from either side, and see why one side waits in TIME_WAIT.',
  'Walk both hosts through every state of the state diagram, from setup to close.'];
function openMap() {
  lessonState.map = true; lessonState.token++;
  if (lessonState.player) { lessonState.player.stop(); lessonState.player = null; }
  renderStepper();
  var next = 0; while (next < LESSONS.length - 1 && progress.lessons[next]) next++;
  var any = Object.keys(progress.lessons).length;
  $('#lmap').innerHTML = '<h2>Lesson map</h2><p>Eight short lessons in four parts. Each lesson builds on the one before, so take them in order the first time. Each one ends with a Try it task worth 20 points.</p>' +
    MAP_PARTS.map(function (p, k) {
      return '<h3>Part ' + (k + 1) + ': ' + p[0] + '</h3><ol class="lmap" start="' + (p[1] + 1) + '">' + LESSONS.slice(p[1], p[2]).map(function (L, j) {
        var i = p[1] + j;
        return '<li><button data-l="' + i + '" class="' + (progress.lessons[i] ? 'done' : '') + '"><span class="num">' + (progress.lessons[i] ? '✓' : i + 1) + '</span><span><b>' + L.t + '</b><span class="d">' + MAP_DESC[i] + '</span></span></button></li>';
      }).join('') + '</ol>';
    }).join('') +
    '<div class="row"><button class="btn" id="lnext">' + (any ? 'Continue with lesson ' + (next + 1) + ' →' : 'Start lesson 1 →') + '</button></div>';
  $$('#lmap [data-l]').forEach(function (b) { b.onclick = function () { openLesson(+b.getAttribute('data-l')); window.scrollTo(0, 0); }; });
  $('#lnext').onclick = function () { openLesson(next); window.scrollTo(0, 0); };
  $('#lmap').hidden = false; $('#view-learn .lesson').hidden = true;
  writeLink();
}
function renderStepper() {
  $('#mapslot').innerHTML = '<button data-map class="mapbtn"' + (lessonState.map ? ' aria-current="step"' : '') + ' aria-label="Lesson map: all eight lessons" title="Lesson map"><span class="num">☰</span><span class="lt">Lesson map</span></button>';
  $('#stepper').innerHTML = LESSONS.map(function (L, i) { return '<button data-l="' + i + '" class="' + (progress.lessons[i] ? 'done' : '') + '"' + (i === lessonState.i && !lessonState.map ? ' aria-current="step"' : '') + ' title="Lesson ' + (i + 1) + ': ' + L.t + '" aria-label="Lesson ' + (i + 1) + ': ' + L.t + (progress.lessons[i] ? ', done' : '') + '"><span class="num">' + (progress.lessons[i] ? '✓' : i + 1) + '</span><span class="lt">' + L.t + '</span></button>'; }).join('');
  $$('#stepper [data-l]').forEach(function (b) { b.onclick = function () { openLesson(+b.getAttribute('data-l')); }; });
  $('#mapslot [data-map]').onclick = openMap;
  $('#lprog').style.width = (Object.keys(progress.lessons).length / LESSONS.length * 100) + '%';
}
function openLesson(i) {
  lessonState.i = Math.max(0, Math.min(LESSONS.length - 1, i)); lessonState.token++; lessonState.map = false;
  $('#lmap').hidden = true; $('#lmap').innerHTML = ''; $('#view-learn .lesson').hidden = false;
  lessonState.wide = !!LESSONS[lessonState.i].wide; $('#view-learn .lesson').className = 'lesson' + (lessonState.wide ? ' wide' : '');
  document.body.classList.toggle('widepage', lessonState.wide);
  if (lessonState.player) { lessonState.player.stop(); lessonState.player = null; }
  renderStepper(); $('#lfig').innerHTML = ''; LESSONS[lessonState.i].setup();
  var tl = termsList($('#ltext').textContent + ' ' + $('#lfig').textContent);
  if (tl) $('#ltext').insertAdjacentHTML('beforeend', more('Terms in this lesson', tl));
  var last = lessonState.i === LESSONS.length - 1;
  $('#ltext').insertAdjacentHTML('beforeend', '<div class="navrow"><button class="btn alt" id="lprev"' + (lessonState.i ? '' : ' disabled') + '>← Back</button><button class="btn' + (last ? ' amber' : '') + '" id="lnext">' + (last ? 'Take the challenge →' : 'Next lesson →') + '</button></div>');
  $('#lprev').onclick = function () { openLesson(lessonState.i - 1); window.scrollTo(0, 0); };
  $('#lnext').onclick = function () { if (!last) { openLesson(lessonState.i + 1); window.scrollTo(0, 0); } else go('challenge'); };
  $('#ltask').innerHTML = '';
  placeTask();
  writeLink();
}
/* On narrow screens the figures come right after the lesson's short text and controls,
   and the Try it task, the commands, and Back/Next move below them. */
var narrowMQ = null;
try { narrowMQ = window.matchMedia('(max-width: 980px)'); } catch (e) { narrowMQ = null; }
function placeTask() {
  var narrow = !!(narrowMQ && narrowMQ.matches) || !!lessonState.wide, from = narrow ? $('#ltext') : $('#ltask'), to = narrow ? $('#ltask') : $('#ltext');
  if (!from || !to) return;
  Array.prototype.slice.call(from.children).forEach(function (n) { if (/(^| )(tryit|seeit|navrow)( |$)/.test(n.className)) to.appendChild(n); });
  $('#ltask').hidden = !$('#ltask').children.length;
}
if (narrowMQ) { if (narrowMQ.addEventListener) narrowMQ.addEventListener('change', placeTask); else if (narrowMQ.addListener) narrowMQ.addListener(placeTask); }
function lessonDone(fb, msg) {
  var first = !progress.lessons[lessonState.i];
  fb.className = 'feedback ok pop'; fb.innerHTML = '✓ ' + msg + (first ? ' <b>+20 points</b>' : '');
  if (first) { progress.lessons[lessonState.i] = true; store.set('progress', progress); addXP(20); renderStepper(); if (Object.keys(progress.lessons).length === LESSONS.length) earn('scholar'); }
}
function wrong(fb, msg) { fb.className = 'feedback bad'; fb.innerHTML = msg; }
