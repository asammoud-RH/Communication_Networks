import asyncio, pathlib
from playwright.async_api import async_playwright
import sys
URL = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else pathlib.Path(__file__).parent.parent / 'fragmentation-visualizer.html').resolve().as_uri()
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
        ph = await b.new_page(viewport={'width': 360, 'height': 800}); worst = 0; errs=[]
        ph.on('pageerror', lambda e: errs.append(str(e)))
        for lvl in 'EMH':
            for r in range(8):
                await ph.goto(URL + f'?mode=challenge&level={lvl}'); await ph.click('#ch-start')
                for i in range(10):
                    w = await ph.evaluate('document.documentElement.scrollWidth')
                    if w > 360: print('WIDE', lvl, w, (await ph.inner_text('.qtext'))[:120])
                    worst = max(worst, w)
                    if await ph.query_selector('#q_in'): await ph.fill('#q_in', '1'); await ph.click('#q_ok')
                    else: await ph.click('#q_body .choice >> nth=0')
                    w = await ph.evaluate('document.documentElement.scrollWidth'); worst = max(worst, w)
                    if w > 360: print('WIDE after answer', lvl, w)
                    await ph.click('#q_next')
                w = await ph.evaluate('document.documentElement.scrollWidth'); worst = max(worst, w)
        print('240 questions at 360 px, widest page:', worst, 'errors', errs)
        await b.close()
asyncio.run(main())
