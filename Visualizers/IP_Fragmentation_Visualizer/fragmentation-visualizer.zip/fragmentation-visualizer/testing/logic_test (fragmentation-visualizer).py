"""Logic test for Fragmentation Visualizer.

The app exposes its model and question generators on window.FragViz. This
script calls them in headless Chrome and re-checks every result independently:

  1. Fragmentation: compare the app with an independent Python model and with
     Scapy's fragment() on thousands of random sizes and MTUs (one link), and
     with the Python model on random three-link paths (re-fragmentation).
  2. Real kernel (optional, needs root and `ip netns`): build Host A, R1, R2,
     Host B as network namespaces, send real pings, capture the fragments that
     reach Host B with tcpdump, and compare them with the app. Also compares
     the app's ping output (Linux -M do / -M dont / default) with real ping.
  3. Questions: generate 120 rounds per level and re-check every answer key;
     choices must be unique and the answer index valid.
  4. Completion code: a code checks as valid, and an edited code does not.

Usage: python3 "logic_test (fragmentation-visualizer).py" path/to/fragmentation-visualizer.html [--kernel]
"""
import sys, pathlib, asyncio, json, random, re, math, subprocess, time, shutil
from playwright.async_api import async_playwright

URL = pathlib.Path(sys.argv[1]).resolve().as_uri()
KERNEL = '--kernel' in sys.argv
HDR = 20


# ---------------------------------------------------------- independent model
def room(mtu): return mtu - HDR
def mdata(mtu): return (mtu - HDR) // 8 * 8
def split(off, ln, mf, mtu):
    """Linux ip_do_fragment: len = min(left, mtu - hlen); if len < left: len &= ~7."""
    out, o, left = [], 0, ln
    while left > 0:
        n = min(left, mtu - HDR)
        if n < left: n &= ~7
        left -= n
        out.append((off + o, n, True if left > 0 else mf)); o += n
    return out
def path(D, mtus):
    fr = [(0, D, False)]
    for m in mtus:
        nxt = []
        for f in fr: nxt += split(*f, m) if f[1] + HDR > m else [f]
        fr = nxt
    return fr
def comma(n): return f'{n:,}'


def scapy_split(D, mtu):
    from scapy.all import IP, Raw, fragment
    if D + HDR <= mtu: return [(0, D, False)]
    pk = IP(dst='10.0.0.1', proto=1) / Raw(b'x' * D)
    return [(p.frag * 8, len(p[Raw].load), bool(p.flags & 1)) for p in fragment(pk, fragsize=mtu - HDR)]


# ---------------------------------------------------------- real kernel helpers (optional)
def sh(c): return subprocess.run(c, shell=True, capture_output=True, text=True).stdout
def kernel_setup():
    sh('for n in KA K1 K2 KB; do ip netns del $n 2>/dev/null; done')
    cmds = '''for n in KA K1 K2 KB; do ip netns add $n; ip -n $n link set lo up; done
ip link add ka0 type veth peer name k10; ip link add k11 type veth peer name k20; ip link add k21 type veth peer name kb0
ip link set ka0 netns KA; ip link set k10 netns K1; ip link set k11 netns K1; ip link set k20 netns K2; ip link set k21 netns K2; ip link set kb0 netns KB
ip -n KA addr add 192.168.1.10/24 dev ka0; ip -n K1 addr add 192.168.1.1/24 dev k10; ip -n K1 addr add 192.168.2.1/24 dev k11
ip -n K2 addr add 192.168.2.2/24 dev k20; ip -n K2 addr add 192.168.3.1/24 dev k21; ip -n KB addr add 192.168.3.20/24 dev kb0
for p in "KA ka0" "K1 k10" "K1 k11" "K2 k20" "K2 k21" "KB kb0"; do set -- $p; ip -n $1 link set $2 up; done
ip -n KA route add default via 192.168.1.1; ip -n K1 route add 192.168.3.0/24 via 192.168.2.2; ip -n K2 route add 192.168.1.0/24 via 192.168.2.1; ip -n KB route add default via 192.168.3.1
ip netns exec K1 sysctl -qw net.ipv4.ip_forward=1; ip netns exec K2 sysctl -qw net.ipv4.ip_forward=1'''
    sh(cmds)
    return 'ttl' in sh('ip netns exec KA ping -c1 -W1 192.168.3.20')
def kernel_mtus(m):
    sh(f'ip -n KA link set ka0 mtu {m[0]}; ip -n K1 link set k10 mtu {m[0]}; ip -n K1 link set k11 mtu {m[1]}; ip -n K2 link set k20 mtu {m[1]}; ip -n K2 link set k21 mtu {m[2]}; ip -n KB link set kb0 mtu {m[2]}')
    sh('ip netns exec KA ip route flush cache')
def kernel_frags(D):
    cap = subprocess.Popen('ip netns exec KB tcpdump -l -n -v -i kb0 "icmp and src 192.168.1.10"', shell=True, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True)
    time.sleep(0.6); sh(f'ip netns exec KA ping -c1 -W1 -M dont -s {D - 8} 192.168.3.20'); time.sleep(0.4)
    sh('pkill -f "tcpdump -l -n -v -i kb0"'); out = cap.communicate()[0]
    fr = []
    for m in re.finditer(r'offset (\d+), flags \[([^\]]*)\].*?length (\d+)\)', out):
        fr.append((int(m.group(1)), int(m.group(3)) - HDR, '+' in m.group(2)))
    return sorted(fr)
def kernel_ping(mode, N, count=3):
    flag = {'want': '', 'do': '-M do', 'dont': '-M dont'}[mode]
    out = sh(f'ip netns exec KA ping -c {count} -i 0.3 -W1 {flag} -s {N} 192.168.3.20 2>&1')
    return [re.sub(r' time=[\d.]+ ms', '', l) for l in out.splitlines() if l.strip() and not l.startswith('---') and 'packets transmitted' not in l and not l.startswith('rtt')]


async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
        pg = await b.new_page(); errs = []
        pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: errs.append(m.text) if m.type == 'error' else None)
        await pg.goto(URL); await pg.wait_for_timeout(300)
        app = lambda D, ms: pg.evaluate('([D,ms])=>FragViz.sendPath(D,ms,false).frags.map(f=>[f.off,f.len,f.mf])', [D, ms])

        # 1a. one link: app vs Python vs Scapy
        cases = [(random.randint(1, 65515), random.choice([68, 100, 296, 530, 532, 576, 620, 700, 810, 1000, 1006, 1280, 1400, 1492, 1500, random.randint(68, 9000)])) for _ in range(3000)]
        got = await pg.evaluate('(cs)=>cs.map(([D,m])=>FragViz.splitFrag({off:0,len:D,mf:false},m).map(f=>[f.off,f.len,f.mf]))', cases)
        bad = sc = 0
        for (D, m), g in zip(cases, got):
            g = [tuple(x) for x in g]; exp = split(0, D, False, m) if D + HDR > m else [(0, D, False)]
            if g != exp: bad += 1; print('ONE-LINK MISMATCH', D, m, g[:3], exp[:3])
            if D <= 20000 and scapy_split(D, m) != g: sc += 1; print('SCAPY MISMATCH', D, m)
        print('one link: cases', len(cases), 'mismatches vs Python', bad, 'vs Scapy', sc)
        # 1b. paths of three links (re-fragmentation)
        pc = [(random.randint(1, 9000), [random.choice([1500, 9000, 1492]), random.randint(300, 1500), random.randint(68, 1500)]) for _ in range(1500)]
        got = await pg.evaluate('(cs)=>cs.map(([D,ms])=>FragViz.sendPath(D,ms,false).frags.map(f=>[f.off,f.len,f.mf]))', pc)
        bad = 0
        for (D, ms), g in zip(pc, got):
            if [tuple(x) for x in g] != path(D, ms): bad += 1; print('PATH MISMATCH', D, ms)
            fr = path(D, ms)
            assert sum(f[1] for f in fr) == D and all(f[0] % 8 == 0 for f in fr) and [f[2] for f in fr].count(False) == 1
        print('paths: cases', len(pc), 'mismatches', bad)
        # lesson 4 puzzle: which Link 3 MTUs give exactly four fragments?
        ok = [m for m in range(68, 1501) if len(path(1400, [1500, 1000, m])) == 4]
        print('lesson 4 puzzle answers: MTU', ok[0], 'to', ok[-1], 'count', len(ok), 'contiguous', ok == list(range(ok[0], ok[-1] + 1)))

        # 2. real kernel
        if KERNEL and shutil.which('ip') and kernel_setup():
            kb = kc = 0
            kcases = [(1400, [1500, 532, 1500]), (2980, [1500, 1000, 576]), (1014, [1500, 530, 1500]), (3008, [1500, 1500, 1500])] + \
                     [(random.randint(600, 6000), [1500, random.choice([1400, 1006, 1000, 900, 700, 620, 576, 532, 530]), random.choice([1500, 1000, 576, 532, 300, 296, 200])]) for _ in range(24)]
            for D, ms in kcases:
                kernel_mtus(ms); real = kernel_frags(D); mine = sorted(tuple(x) for x in await app(D, ms))
                kc += 1
                if real != mine: kb += 1; print('KERNEL MISMATCH', D, ms, real[:4], mine[:4])
            print('kernel fragment cases', kc, 'mismatches', kb)
            pb = pcnt = 0
            for mode in ['want', 'do', 'dont']:
                for N, ms in [(1472, [1500, 1400, 1500]), (1372, [1500, 1400, 1500]), (1392, [1500, 532, 1500]), (520, [1500, 532, 1500]), (3000, [1500, 1500, 1500]), (1452, [1500, 1492, 1280]), (1300, [1500, 1492, 1280]), (2000, [1500, 1000, 576])]:
                    kernel_mtus(ms); real = kernel_ping(mode, N)
                    mine = await pg.evaluate('([m,N,ms])=>FragViz.pingRun(m,N,ms,3).lines.map(l=>l.t.replace(/ time=[\\d.]+ ms/,""))', [mode, N, ms])
                    pcnt += 1
                    if real != mine: pb += 1; print('PING MISMATCH', mode, N, ms, '\n  real', real, '\n  app ', mine)
            print('kernel ping cases', pcnt, 'mismatches', pb)
            sh('for n in KA K1 K2 KB; do ip netns del $n 2>/dev/null; done')
        else:
            print('kernel checks skipped (run as root with --kernel)')

        # 3. question generators
        qs = await pg.evaluate('''()=>{const out=[];['E','M','H'].forEach(L=>{for(let i=0;i<120;i++){FragViz.makeRound(L,10).forEach(q=>out.push({L,type:q.type,text:q.text.replace(/<[^>]+>/g,''),input:q.input,answer:q.answer,choices:q.choices||null,p:q.p}))}});return out}''')
        probs = 0; counts = {}
        for q in qs:
            t, P = q['type'], q['p']; counts[t] = counts.get(t, 0) + 1
            if q['input'] == 'choice':
                if not (0 <= q['answer'] < len(q['choices'])): probs += 1; print('BAD idx', q); continue
                if len(set(q['choices'])) != len(q['choices']) or len(q['choices']) < 2: probs += 1; print('DUP choices', q)
                right = q['choices'][q['answer']]
            else: right = q['answer']
            def exp_val():
                k = P['kind']
                if k == 'fits': return 'Yes' if P['T'] > P['M'] else 'No'
                if k == 'per': return mdata(P['M'])
                if k == 'count': return len(path(P['D'], [P['M']]))
                if k == 'off': return P['B'] // 8
                if k == 'ptot': return P['N'] + 28
                if k == 'lastTot': return path(P['D'], [P['M']])[-1][1] + HDR
                if k == 'kOff': return path(P['D'], [P['M']])[P['k'] - 1][0] // 8
                if k == 'range':
                    a = P['off'] * 8; return f"{comma(a)} to {comma(a + P['T'] - HDR - 1)}"
                if k == 'ws': return P['B'] // 8
                if k == 'plast': return path(P['N'] + 8, [P['M']])[-1][1]
                if k == 'udpcount': return len(path(P['U'] + 8, [P['M']]))
                if k == 'refrag': return len(path(P['D'], P['mtus']))
                if k == 'refragOffs': return ', '.join(str(f[0] // 8) for f in path(P['D'], P['mtus']))
                if k == 'wire': return P['D'] + HDR * len(path(P['D'], P['mtus']))
                if k == 'largest': return min(P['mtus']) - 28
                if k == 'missing':
                    got = P['got']; full = max(g[2] - HDR for g in got if g[1] == 1); last = [g for g in got if g[1] == 0][0]
                    end = last[0] * 8 + last[2] - HDR; offs = set(range(0, end - (last[2] - HDR), full)) | {last[0] * 8}
                    miss = sorted(o // 8 for o in offs - {g[0] * 8 for g in got})
                    return miss[0] if len(miss) == 1 else ('AMBIGUOUS', miss)
                if k == 'df':
                    N, ms = P['N'], P['mtus']; T = N + 28; addr = ['', '192.168.1.1', '192.168.2.2']
                    if T > ms[0]: return f'ping: local error: message too long, mtu={ms[0]}'
                    for j in (1, 2):
                        if T > ms[j]: return f'From {addr[j]} icmp_seq=1 Frag needed and DF set (mtu = {ms[j]})'
                    return f'{N + 8} bytes from 192.168.3.20: icmp_seq=1 ttl=62 …'
                if k == 'learn':
                    N, ms = P['N'], P['mtus']; T = N + 28
                    if T <= min(ms): return 'All 3 get replies'
                    return f'Ping 1: Frag needed (mtu = {ms[1]}); pings 2 and 3 get replies'
                return ('UNKNOWN', k)
            e = exp_val()
            if e != right: probs += 1; print('ANSWER', t, q['text'][:120], '| app:', right, '| expected:', e)
            # the numbers in the text must match the inputs
            if t in ('count', 'lastTot', 'kOff') and (comma(P['D']) not in q['text'] or str(P['M']) not in q['text']): probs += 1; print('TEXT', q['text'])
        print('questions', len(qs), 'problems', probs, json.dumps(counts))

        # 4. completion code
        print(await pg.evaluate('''()=>{const c=FragViz.code('H',96,9,10);return [c,FragViz.checkCode(c),FragViz.checkCode(c.replace('96','99')),FragViz.checkCode(c.toLowerCase())]}'''))
        print('ERRORS', errs)
        await b.close()

asyncio.run(main())
