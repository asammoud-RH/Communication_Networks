
/* ===================================================== CALCULATOR */
var calcState = { size: 1392, kind: 'ping', df: 0, mtus: [1500, 532, 1500], ident: newIdent() };
var CALC_PRESETS = { classic: [1500, 532, 1500], refrag: [1500, 1000, 576], tunnel: [1500, 1400, 1500], local: [1500] };
function calcLinks() {
  $('#c_links').innerHTML = calcState.mtus.map(function (m, i) {
    return '<div class="linkbox"><b>Link ' + (i + 1) + (i === 0 ? ' (Host A\'s own link)' : '') + '</b><label>MTU <input type="number" min="' + MIN_MTU + '" max="65535" value="' + m + '" data-li="' + i + '" aria-label="Link ' + (i + 1) + ' MTU"></label></div>';
  }).join('');
  $$('#c_links [data-li]').forEach(function (inp) { inp.oninput = function () { var v = +inp.value; if (inp.value === '' || !Number.isInteger(v) || v < MIN_MTU || v > 65535) { inp.setAttribute('aria-invalid', 'true'); $('#c_err').textContent = 'Each MTU must be a whole number from 68 to 65,535.'; return; } inp.removeAttribute('aria-invalid'); calcState.mtus[+inp.getAttribute('data-li')] = v; calc(); }; });
  $('#c_add').disabled = calcState.mtus.length >= 4; $('#c_del').disabled = calcState.mtus.length <= 1;
}
function calcInit() {
  $('#c_size').value = calcState.size; $('#c_kind').value = calcState.kind; $('#c_df').value = String(calcState.df);
  $('#c_size').oninput = function () { calc(); }; $('#c_kind').onchange = calc; $('#c_df').onchange = calc;
  $('#c_preset').onchange = function () { if (!this.value) return; calcState.mtus = CALC_PRESETS[this.value].slice(); if (this.value === 'classic') { $('#c_kind').value = 'ping'; $('#c_size').value = 1392; } if (this.value === 'refrag') { $('#c_kind').value = 'ping'; $('#c_size').value = 2972; } calcLinks(); calc(); this.value = ''; };
  $('#c_add').onclick = function () { if (calcState.mtus.length < 4) { calcState.mtus.push(1500); calcLinks(); calc(); } };
  $('#c_del').onclick = function () { if (calcState.mtus.length > 1) { calcState.mtus.pop(); calcLinks(); calc(); } };
  calcLinks();
}
function calc() {
  var err = $('#c_err'), size = +$('#c_size').value, kind = $('#c_kind').value, df = $('#c_df').value === '1', K = KINDS[kind];
  var maxSize = MAX_DATA - K.add;
  if ($('#c_size').value === '' || !Number.isInteger(size) || size < (kind === 'data' ? 1 : 0) || size > maxSize) { err.textContent = 'Type a whole number from ' + (kind === 'data' ? 1 : 0) + ' to ' + fmt(maxSize) + ': an IPv4 datagram is at most 65,535 bytes.'; return; }
  if (calcState.mtus.some(function (m) { return !(m >= MIN_MTU && m <= 65535); })) return;
  err.textContent = ''; calcState.size = size; calcState.kind = kind; calcState.df = df ? 1 : 0;
  var mtus = calcState.mtus, data = size + K.add, total = data + HDR, res = sendPath(data, mtus, df), pmtu = Math.min.apply(null, mtus);
  var stats = [['IP datagram (Total Length)', fmt(total) + ' bytes'], ['Path MTU (smallest link)', fmt(pmtu)]];
  if (res.ok) {
    var last = res.frags, wire = last.reduce(function (s, f) { return s + totalLen(f); }, 0);
    stats = stats.concat([['Packets on Link 1', String(res.hops[0].frags.length)], ['Packets that reach Host B', String(last.length)], ['Bytes on the last link', fmt(wire)], ['Extra header bytes', fmt((last.length - 1) * HDR)], ['Efficiency on the last link', (data / wire * 100).toFixed(1) + '% data']]);
  } else stats.push(['Result', res.dropAt === 0 ? 'Host A refuses to send it' : 'R' + res.dropAt + ' drops it']);
  stats.push(['Largest ' + K.name + ' with DF set', fmt(Math.max(0, pmtu - HDR - K.add)) + ' bytes']);
  $('#c_stats').innerHTML = stats.map(function (s) { return '<div class="stat"><div class="k">' + s[0] + '</div><div class="v">' + s[1] + '</div></div>'; }).join('');
  // DF result and the terminal
  var out = '';
  if (df && !res.ok) out += '<p class="feedback bad">' + (res.dropAt === 0 ? 'The datagram is bigger than Host A\'s own link (' + mtus[0] + '), and DF forbids fragmenting, so Host A does not send it. The program gets an error at once.' : 'R' + res.dropAt + ' would have to fragment for Link ' + (res.dropAt + 1) + ' (MTU ' + res.mtu + '). DF is set, so it drops the datagram and sends Host A an ICMP "fragmentation needed" message that carries the MTU ' + res.mtu + '.') + '</p>';
  else if (df) out += '<p class="feedback ok">The datagram fits every link, so DF changes nothing: it arrives whole.</p>';
  if (kind === 'ping' && size <= 65500) {
    var mL = df ? 'do' : 'dont', mW = df ? 'winf' : 'win', rl = pingRun(mL, size, mtus, 3), rw = pingRun(mW, size, mtus, 3);
    out += '<div class="calcgrid" style="grid-template-columns:repeat(auto-fit,minmax(280px,1fr))"><div><p class="cmdnote">Linux: <code>ping -c 3 ' + (df ? '-M do' : '-M dont') + ' -s ' + size + ' ' + destAddr(mtus.length) + '</code></p><div class="term">' + termHTML(rl.lines) + '</div></div>' +
      '<div><p class="cmdnote">Windows: <code>ping -n 3 ' + (df ? '-f ' : '') + '-l ' + size + ' ' + destAddr(mtus.length) + '</code></p><div class="term">' + termHTML(rw.lines) + '</div></div></div>' +
      '<p class="cmdnote">Addresses in this model: Host A is 192.168.1.10, Link k is 192.168.k.0/24, and Host B is ' + destAddr(mtus.length) + '.' + (df && !res.ok && res.dropAt > 0 && res.mtu < LINUX_MIN_PMTU ? ' Linux never remembers a path MTU below 552 bytes, so it keeps getting the router\'s message.' : '') + '</p>';
  }
  $('#c_df_out').innerHTML = out;
  drawPath($('#c_path'), mtus, res, { icmp: true });
  $('#c_cards').innerHTML = res.ok ? fragCards(res.frags, calcState.ident) : '<p class="no">Nothing reaches Host B.</p>';
  $('#c_all').innerHTML = res.hops.map(function (h, i) { return '<h3>Link ' + (i + 1) + ' (MTU ' + h.mtu + '): ' + h.frags.length + (h.frags.length === 1 ? ' packet' : ' packets') + '</h3><div class="fcards">' + fragCards(h.frags, calcState.ident) + '</div>'; }).join('');
  renderCommands($('#c_cmds'), { payload: kind === 'ping' ? size : Math.max(0, pmtu - 28), mtu: pmtu < 1500 ? pmtu : 1400, dest: destAddr(mtus.length) });
  writeLink();
}
