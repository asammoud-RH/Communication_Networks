import asyncio, pathlib, time
from playwright.async_api import async_playwright
import sys
URL = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else pathlib.Path(__file__).parent.parent / 'fragmentation-visualizer.html').resolve().as_uri()
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
        pg = await b.new_page(viewport={'width':1280,'height':900}); errs=[]
        pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto(URL+'?mode=learn&lesson=6'); await pg.wait_for_timeout(300)
        for v in ['0.5','1','3']:
            await pg.fill('#l6sp', v) if False else await pg.evaluate(f"(()=>{{const r=document.querySelector('#l6sp');r.value='{v}';r.dispatchEvent(new Event('input'))}})()")
            t=time.time(); await pg.click('#l6go')
            await pg.wait_for_function("!document.querySelector('#l6go').disabled", timeout=60000)
            print(f'speed {v}x: label', await pg.inner_text('#l6spo'), '| 3 pings took %.1f s' % (time.time()-t))
        # change speed mid-run
        await pg.evaluate("(()=>{const r=document.querySelector('#l6sp');r.value='0.5';r.dispatchEvent(new Event('input'))})()")
        t=time.time(); await pg.click('#l6go'); await pg.wait_for_timeout(1500)
        await pg.evaluate("(()=>{const r=document.querySelector('#l6sp');r.value='3';r.dispatchEvent(new Event('input'))})()")
        await pg.wait_for_function("!document.querySelector('#l6go').disabled", timeout=60000)
        print('slow then fast mid-run: %.1f s' % (time.time()-t), '| terminal lines:', len((await pg.inner_text('#l6term')).splitlines()))
        await pg.evaluate("(()=>{const r=document.querySelector('#l6sp');r.value='1';r.dispatchEvent(new Event('input'))})()")
        await pg.click('#l6go'); await pg.wait_for_timeout(1200); await pg.screenshot(path='l6-speed.png', full_page=True)
        ph = await b.new_page(viewport={'width':360,'height':800}); await ph.goto(URL+'?mode=learn&lesson=6'); await ph.wait_for_timeout(300)
        print('phone width', await ph.evaluate('document.documentElement.scrollWidth'))
        await ph.screenshot(path='l6-phone.png', full_page=False)
        print('ERRORS', errs); await b.close()
asyncio.run(main())
