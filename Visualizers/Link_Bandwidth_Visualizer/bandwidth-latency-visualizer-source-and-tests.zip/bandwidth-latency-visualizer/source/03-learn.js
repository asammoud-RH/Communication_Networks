/* ===================================================== animation speed: one setting for every Send button, 0.5× by default */
var SPEEDS = [0.25, 0.5, 1, 2];
var animSpeed = (function () { var v = +store.get('speed', 0.5); return SPEEDS.indexOf(v) >= 0 ? v : 0.5; })();
function speedHTML() {
  return '<label class="speed">Speed <select data-speed aria-label="Animation speed">' + SPEEDS.map(function (v) { return '<option value="' + v + '"' + (v === animSpeed ? ' selected' : '') + '>' + v + '×</option>'; }).join('') + '</select></label>';
}
function wireSpeeds() {
  $$('[data-speed]').forEach(function (s) {
    s.value = String(animSpeed);
    s.onchange = function () { animSpeed = +s.value; store.set('speed', animSpeed); $$('[data-speed]').forEach(function (o) { o.value = String(animSpeed); }); };
  });
}
/* Like animate(), but the run time is ms at 1× and the speed can change mid-run. */
function animateS(ms, step, alive) {
  return new Promise(function (resolve) {
    if (reduceMotion || ms <= 0) { step(1); resolve(); return; }
    var f = 0, last = null;
    function frame(ts) {
      if (!alive()) { resolve(); return; }
      if (last !== null) f = Math.min(1, f + (ts - last) * animSpeed / ms);
      last = ts; step(f);
      if (f < 1) window.requestAnimationFrame(frame); else resolve();
    }
    window.requestAnimationFrame(frame);
  });
}

/* ===================================================== player: Send + time slider + speed, repeated next to every figure it moves, all in sync */
function stripHTML(p, label) {
  return '<div class="scrub"><button class="btn small" id="' + p + 'play">▶ ' + (label || 'Send') + '</button><label for="' + p + 'scrub">Time</label>' +
    '<input type="range" id="' + p + 'scrub" min="0" max="1000" value="0"><span class="tnow" id="' + p + 'tnow"></span>' + speedHTML() + '</div>';
}
function Player(o) {   // o.strips: id prefixes of the control strips; o.draw(frac) draws and returns the time label; o.ms: run time at 1×
  var self = this; this.o = o; this.frac = o.frac === undefined ? 0 : o.frac; this.tok = 0;
  o.strips.forEach(function (p) {
    $('#' + p + 'scrub').oninput = function () { self.tok++; self.frac = this.value / 1000; self.show(); };
    $('#' + p + 'play').onclick = function () { self.play(); };
  });
  wireSpeeds();
}
Player.prototype.show = function () {
  var lab = this.o.draw(this.frac), f = this.frac;
  this.o.strips.forEach(function (p) {
    var sc = $('#' + p + 'scrub'), tn = $('#' + p + 'tnow');
    if (sc) sc.value = Math.round(f * 1000);
    if (tn && lab !== undefined) tn.textContent = lab;
  });
};
Player.prototype.jump = function (f) { this.tok++; this.frac = clamp(f, 0, 1); this.show(); };
Player.prototype.play = function () {
  var self = this, tok = ++this.tok, outer = this.o.alive || function () { return true; };
  var btns = this.o.strips.map(function (p) { return $('#' + p + 'play'); }).filter(Boolean);
  btns.forEach(function (b) { b.disabled = true; });
  return animateS(this.o.ms || 4500, function (f) { self.frac = f; self.show(); }, function () { return tok === self.tok && outer(); })
    .then(function () { btns.forEach(function (b) { b.disabled = false; }); });
};

/* ===================================================== timeline: wire figure + space-time figure on one player */
function Timeline(o) {
  var self = this; this.o = o;
  this.pl = new Player({ strips: o.strips, ms: o.ms || 4500, alive: o.alive, frac: o.frac, draw: function (f) { return self.draw(f); } });
}
Timeline.prototype.set = function (names, links, bits) { this.names = names; this.links = links; this.r = pathTimes(bits, links); this.pl.show(); };
Timeline.prototype.draw = function (frac) {
  if (!this.r) return '';
  var tot = this.r.total, tc = tot * frac;
  if (this.o.wire) drawWire(this.o.wire, { names: this.names, hops: this.r.hops, links: this.links, tc: tc });
  if (this.o.extra) this.o.extra(tc, this.r);
  if (this.o.st) drawSpaceTime(this.o.st, { names: this.names, hops: this.r.hops, tc: tc, tMax: tot, detail: this.o.detail });
  return 't = ' + fmtT(tc, 4);
};
Timeline.prototype.jump = function (frac) { this.pl.jump(frac); };
Timeline.prototype.play = function () { return this.pl.play(); };
var ST_LEGEND = '<ul class="legend"><li><i style="background:#CFE6F0;border:1px solid #00A2D7"></i>the packet\'s bits</li><li><i style="background:#FDF0D5;border:1px solid #F5A524"></i>waiting in a queue</li><li><i style="background:#F5A524;height:3px"></i>the chosen moment</li></ul>';
function figFold(title, body, open) { return '<details class="figfold"' + (open ? ' open' : '') + '><summary>' + title + '</summary>' + body + '</details>'; }

/* ===================================================== LEARN */
var lessonState = { i: (function () { var v = store.get('lesson', -1); return clamp(isFinite(+v) ? +v : -1, -1, 5); })(), task: null, token: 0,
  l1: { rate: 1e6, mult: 2, medium: 'copper', cv: 1, cu: 'MB', view: 'time' },
  l2: { size: 1500, bw: 10e6, distKm: 1000, medium: 'fiber', q: 1 },
  l3: { bwA: 100e6, dA: 250, bwB: 10e6, dB: 10, lsize: 5 },
  l4: { dMs: 50, bw: 45e6, mode: 'one', winKB: '', msg: 1, msgu: 'MB' },
  l5: { size: 1, unit: 'MB', bw: 1e9, rtt: 100 },
  l6: { size: 1500, links: [{ bw: 100e6, dist: 100, medium: 'copper' }, { bw: 1e9, dist: 20000, medium: 'fiber' }, { bw: 10e6, dist: 500000, medium: 'fiber' }], qs: 0, qr: 2 } };
var LESSONS = [
  { t: 'A bit is a slice of time', setup: l1, what: 'See how long one bit lasts, and how long it is on the wire.' },
  { t: 'Three parts of latency', setup: l2, what: 'Watch a packet travel and add up its queue, transmit, and propagation times.' },
  { t: 'Which part dominates?', setup: l3, what: 'Compare a far, fast link with a near, slow one for small and large messages.' },
  { t: 'The pipe: delay × bandwidth', setup: l4, what: 'Watch the link fill with bits and find the window that keeps it full.' },
  { t: 'Bandwidth is not throughput', setup: l5, what: 'Watch a download from request to completion and find the rate it really gets.' },
  { t: 'Across a switch and a router', setup: l6, what: 'Add up the delays link by link, find the bottleneck, and predict ping times.' }
];
var PARTS = [
  { t: 'Part 1: One packet on one link', l: [0, 1, 2] },
  { t: 'Part 2: Keeping the link busy', l: [3, 4] },
  { t: 'Part 3: A real path', l: [5] }
];
function partOf(i) { for (var k = 0; k < PARTS.length; k++) if (PARTS[k].l.indexOf(i) >= 0) return PARTS[k].t; return ''; }
function alive(tok) { return tok === lessonState.token; }
function lessonAlive() { var tok = lessonState.token; return function () { return tok === lessonState.token && current === 'learn'; }; }
function renderStepper() {
  var st = $('#stepper'), cur = lessonState.i;
  st.innerHTML = '<button data-l="-1" class="mapbtn" aria-label="Lesson map"' + (cur < 0 ? ' aria-current="step"' : '') + '><span class="num" aria-hidden="true">☰</span><span class="t">Lesson map</span></button>' +
    LESSONS.map(function (L, i) {
      return '<button data-l="' + i + '" class="' + (progress.lessons[i] ? 'done' : '') + '"' + (i === cur ? ' aria-current="step"' : '') + ' aria-label="Lesson ' + (i + 1) + ': ' + esc(L.t) + (progress.lessons[i] ? ' (done)' : '') + '" title="' + esc(L.t) + '">' +
        '<span class="num">' + (progress.lessons[i] ? '✓' : i + 1) + '</span><span class="t">' + L.t + '</span></button>';
    }).join('');
  $$('[data-l]', st).forEach(function (b) { b.onclick = function () { openLesson(+b.getAttribute('data-l')); }; });
  $('#lprog').style.width = (Object.keys(progress.lessons).length / LESSONS.length * 100) + '%';
}
function renderMap() {
  $('#ltext').innerHTML = '<h2>Lesson map</h2><div class="mapintro"><p>Six short lessons in three parts. Each lesson has a short intro, a few controls, one main figure that you can play and step through, and a Try it task worth 20 points.</p>' +
    '<p>Start with Part 1 if bandwidth and delay are new to you. Extra explanations and figures are folded under <b>Show more</b> and the other closed sections; open them when you want more.</p></div>' +
    '<div class="mapparts">' + PARTS.map(function (P) {
      return '<div class="mappart"><h3>' + P.t + '</h3>' + P.l.map(function (i) {
        return '<button class="mapitem' + (progress.lessons[i] ? ' done' : '') + '" data-ml="' + i + '"><b>' + (i + 1) + '. ' + LESSONS[i].t + '</b><span>' + LESSONS[i].what + '</span></button>';
      }).join('') + '</div>';
    }).join('') + '</div>';
  $$('[data-ml]').forEach(function (b) { b.onclick = function () { openLesson(+b.getAttribute('data-ml')); }; });
}
function openLesson(i) {
  lessonState.token++;   // stops any animation from the previous lesson
  i = clamp(i, -1, LESSONS.length - 1);
  if (lessonState.i !== i) lessonState.task = null;
  lessonState.i = i; store.set('lesson', i);
  renderStepper(); $('#lfig').innerHTML = ''; $('#ltry').innerHTML = '';
  $('#lgrid').className = 'lesson' + (i < 0 ? ' map' : '');
  if (i < 0) renderMap(); else LESSONS[i].setup();
  var nav = '<div class="navrow">' + (i < 0 ? '<span></span>' : '<button class="btn alt" id="lprev">← ' + (i === 0 ? 'Lesson map' : 'Back') + '</button>') +
    (i < LESSONS.length - 1 ? '<button class="btn" id="lnext">' + (i < 0 ? 'Start Lesson 1 →' : 'Next lesson →') + '</button>' : '<button class="btn amber" id="lnext">Take the challenge →</button>') + '</div>';
  $('#ltry').insertAdjacentHTML('beforeend', nav);
  if ($('#lprev')) $('#lprev').onclick = function () { openLesson(lessonState.i - 1); };
  $('#lnext').onclick = function () { if (lessonState.i < LESSONS.length - 1) openLesson(lessonState.i + 1); else go('challenge'); };
  wireSpeeds();
  writeLink();
}
/* One lesson's text column: kicker, title, a short intro, Show more and Terms (both closed), then the controls right above the figure. */
function lessonText(n, title, o) {
  $('#ltext').innerHTML = '<p class="kicker">Lesson ' + n + ' of 6 · ' + partOf(n - 1) + '</p><h2>' + title + '</h2><div class="intro">' + o.intro + '</div>' +
    '<details class="fold"><summary>Show more</summary>' + o.more + '</details>' +
    '<details class="fold"><summary>Terms in this lesson</summary><ul class="terms">' + o.terms.map(function (t) { return '<li><b>' + t[0] + '</b>: ' + t[1] + '</li>'; }).join('') + '</ul></details>' +
    '<div class="ctls">' + o.ctl + '</div>';
}
function setTry(html) { $('#ltry').innerHTML = tryBox(html); }
function lessonDone(fb, msg) {
  fb.className = 'feedback ok'; fb.innerHTML = '✓ ' + msg + (progress.lessons[lessonState.i] ? '' : ' <b>+20 points</b>');
  if (!progress.lessons[lessonState.i]) { progress.lessons[lessonState.i] = true; addXP(20); renderStepper(); if (Object.keys(progress.lessons).length === LESSONS.length) earn('learned'); }
}
function wrong(fb, msg) { fb.className = 'feedback bad'; fb.innerHTML = msg; }
function note(fb, msg) { fb.className = 'feedback note'; fb.innerHTML = msg; }
function numIn(id, v, min, max, label, step) { return '<input type="number" id="' + id + '" min="' + min + '" max="' + max + '" step="' + (step || 'any') + '" value="' + v + '"' + (label ? ' aria-label="' + esc(label) + '"' : '') + '>'; }
function readF(sel, min, max, allowBlank) {
  var e = $(sel), raw = e.value.trim(), v = +raw;
  if (raw === '' && allowBlank) { e.removeAttribute('aria-invalid'); return ''; }
  if (raw === '' || !isFinite(v) || v < min || v > max) { e.setAttribute('aria-invalid', 'true'); return null; }
  e.removeAttribute('aria-invalid'); return v;
}
function tryBox(html) { return '<div class="tryit"><h3>Try it</h3>' + html + '</div>'; }
function answerRow(p, label) { return '<div class="row">' + numIn(p + 'a', '', 0, 1e15, label) + '<button class="btn small" id="' + p + 'c">Check</button><button class="btn alt small" id="' + p + 'h">Hint</button></div><div class="feedback" id="' + p + 'fb" aria-live="polite"></div>'; }
function readAnswer(sel) { var raw = $(sel).value.trim().replace(/,/g, ''); return raw === '' ? NaN : +raw; }
function evList(id, ev, how) {
  return ev.map(function (e, i) { return '<li data-t="' + e.t + '"><span class="evmark" aria-hidden="true">○</span> <b>' + e.what + '</b> at t = ' + fmtT(e.t, 4) + (how && e.how ? ' <span class="cmdnote">(' + e.how + ')</span>' : '') + ' <button class="btn alt small" data-ev="' + i + '">Show</button></li>'; }).join('');
}
function markEvents(box, tc, tot) {
  $$('li', box).forEach(function (li) { var done = tc >= +li.getAttribute('data-t') - tot * 1e-9; li.querySelector('.evmark').textContent = done ? '✓' : '○'; li.querySelector('.evmark').className = 'evmark' + (done ? ' yes' : ''); });
}

/* Lesson 1: a bit is a slice of time */
var L1_TASK_RATES = [2, 4, 5, 8, 20, 25, 40, 50, 125, 200, 250, 400, 500];
function l1() {
  var s = lessonState.l1, t = lessonState.task || (lessonState.task = { r: pick(L1_TASK_RATES) });
  lessonText(1, 'A bit is a slice of time', {
    intro: '<p><b>Bandwidth</b> is how many bits per second a link puts on the wire. 1 Mbps (megabit per second) is 10⁶ bits per second. Each bit lasts <b>1 ÷ bandwidth</b> seconds: its <b>bit width</b>.</p>' +
      '<p>A faster link makes each bit shorter. It does not make the signal travel faster. Switch the figure to <b>On the wire</b> to see each bit\'s length in meters.</p>',
    more: '<p>At 1 Mbps (megabit per second) a bit lasts 1 µs (one microsecond, a millionth of a second). At 2 Mbps it lasts 0.5 µs. At 1 Gbps (gigabit per second, 10⁹ bits per second) it lasts 1 ns (one nanosecond, a billionth of a second).</p>' +
      '<p><b>Why a bit has a length.</b> While Host A is still sending a bit, the start of that bit is already travelling down the wire. When the bit is finished, its start is speed × bit width away. So one bit is speed ÷ bandwidth long.</p>' +
      '<p>At 1 Mbps on copper cable a bit is 230 m (meters) long, more than two football fields. At 1 Gbps it is 23 cm (centimeters), shorter than a ruler.</p>' +
      '<p><b>Bits and bytes.</b> A lowercase b is a bit and an uppercase B is a byte, which is 8 bits. Sizes here are decimal: 1 KB (kilobyte) = 1,000 bytes and 1 MB (megabyte) = 10⁶ bytes. Memory and some programs count in powers of 2: 1 KiB (kibibyte) = 1,024 bytes and 1 MiB (mebibyte) = 1,048,576 bytes. The unit converter under the figure shows both.</p>',
    terms: [['Bandwidth', 'how many bits per second a link can put on the wire'], ['Mbps and Gbps', 'megabits (10⁶) and gigabits (10⁹) per second'], ['Bit width', 'how long one bit lasts: 1 ÷ bandwidth'],
      ['µs and ns', 'microsecond (a millionth of a second) and nanosecond (a billionth of a second)'], ['Length on the wire', 'how far one bit stretches along the wire: signal speed ÷ bandwidth'],
      ['Signal speed', 'about 2.0 × 10⁸ m/s (meters per second) in fiber, 2.3 × 10⁸ m/s in copper cable, and 3.0 × 10⁸ m/s by radio'],
      ['b and B', 'a bit, and a byte (8 bits)'], ['KB and MB', 'kilobyte (1,000 bytes) and megabyte (10⁶ bytes)'], ['KiB and MiB', 'kibibyte (1,024 bytes) and mebibyte (1,048,576 bytes)']],
    ctl: '<div class="row"><label>Bandwidth <select id="l1rate">' + rateOptions(s.rate) + '</select></label><label>Compare with <select id="l1mult">' + [2, 4, 10].map(function (m) { return '<option value="' + m + '"' + (m === s.mult ? ' selected' : '') + '>' + m + ' times faster</option>'; }).join('') + '</select></label></div>' +
      '<div class="row"><label>Medium <select id="l1med">' + mediumOptions(s.medium) + '</select></label></div>'
  });
  setTry('<p>A link runs at <b>' + t.r + ' Mbps</b>. How long is one bit, in <b>ns</b> (nanoseconds, billionths of a second)?</p>' + answerRow('l1', 'Bit width in nanoseconds'));
  $('#lfig').innerHTML = '<div class="card"><div class="segs" role="group" aria-label="Figure view"><button id="l1vtime" aria-pressed="' + (s.view === 'time') + '">⏱ In time</button><button id="l1vwire" aria-pressed="' + (s.view === 'wire') + '">📏 On the wire</button></div>' +
    '<div id="l1ptime"' + (s.view === 'time' ? '' : ' hidden') + '><p class="figtitle">Eight bits at two bandwidths, on the same time axis</p><div class="fig"><svg id="l1svg" role="img" aria-label="The bits 10110010 at two bandwidths; the faster link packs more bits into the same time"></svg></div>' +
    '<ul class="legend"><li><i style="background:#CFE6F0;border:1px solid #00A2D7"></i>chosen bandwidth</li><li><i style="background:#E7E1FF;border:1px solid #7B61FF"></i>faster link</li></ul></div>' +
    '<div id="l1pwire"' + (s.view === 'wire' ? '' : ' hidden') + '><p class="figtitle">The same bits on the wire, in meters</p><div class="scrub"><button class="btn small" id="l1go">▶ Watch the bits move</button>' + speedHTML() + '</div><p class="cmdnote" id="l1slow"></p><div class="fig"><svg id="l1space" role="img" aria-label="The bits laid out along the wire with a ruler in meters and an everyday object for scale; both rows move at the same speed"></svg></div>' +
    '<ul class="legend"><li><i style="background:#9DB3C1;height:9px"></i>the wire</li><li><i style="background:#13A88A;height:4px"></i>an everyday object, for scale</li></ul></div>' +
    '<div class="calcgrid" id="l1stats"></div></div>' +
    figFold('Unit converter: bits, bytes, KB and KiB', '<div class="row"><label>Size ' + numIn('l1cv', s.cv, 0, 1e15, 'Size') + '</label><select id="l1cu" aria-label="Unit">' + sizeUnitOptions(s.cu) + '</select></div><div class="calcgrid" id="l1conv"></div>');
  function view(v) { s.view = v; $('#l1ptime').hidden = v !== 'time'; $('#l1pwire').hidden = v !== 'wire'; $('#l1vtime').setAttribute('aria-pressed', String(v === 'time')); $('#l1vwire').setAttribute('aria-pressed', String(v === 'wire')); }
  function upd() {
    s.rate = +$('#l1rate').value; s.mult = +$('#l1mult').value; s.medium = $('#l1med').value;
    drawBits($('#l1svg'), s.rate, s.mult);
    drawBitSpace($('#l1space'), { rate: s.rate, mult: s.mult, medium: s.medium, phase: 0 });
    $('#l1slow').textContent = 'Both rows move at the signal speed, slowed down about ' + fmtN(6 * s.rate / 4, 2) + ' times at 1×.';
    $('#l1stats').innerHTML = stat('Bit width at ' + fmtRate(s.rate), fmtT(bitWidth(s.rate)), '1 ÷ ' + fmtRate(s.rate) + '; at ' + fmtRate(s.rate * s.mult) + ': ' + fmtT(bitWidth(s.rate * s.mult))) +
      stat('Length of one bit on ' + MEDIUM_NAME[s.medium], fmtLen(bitLength(s.rate, s.medium)), fmtN(SPEED[s.medium]) + ' m/s ÷ ' + fmtRate(s.rate));
  }
  function conv() {
    var v = readF('#l1cv', 0, 1e15); if (v === null) return; s.cv = v; s.cu = $('#l1cu').value; var b = v * unitBits(s.cu);
    $('#l1conv').innerHTML = stat('Bits', fmtN(b, 6)) + stat('Bytes', fmtN(b / 8, 6)) + stat('KB and KiB', fmtN(b / 8e3, 5) + ' KB', fmtN(b / 8192, 5) + ' KiB') + stat('MB and MiB', fmtN(b / 8e6, 5) + ' MB', fmtN(b / 8388608, 5) + ' MiB');
  }
  $('#l1vtime').onclick = function () { view('time'); }; $('#l1vwire').onclick = function () { view('wire'); };
  $('#l1rate').onchange = upd; $('#l1mult').onchange = upd; $('#l1med').onchange = upd;
  $('#l1go').onclick = function () { var ok = lessonAlive(), b = this; b.disabled = true; animateS(6000, function (f) { drawBitSpace($('#l1space'), { rate: s.rate, mult: s.mult, medium: s.medium, phase: 4 * f }); }, ok).then(function () { b.disabled = false; }); };
  $('#l1cv').oninput = conv; $('#l1cu').onchange = conv;
  var ans = 1000 / t.r;
  $('#l1c').onclick = function () {
    var v = readAnswer('#l1a'), fb = $('#l1fb');
    if (near(v, ans)) lessonDone(fb, 'Right: 1 ÷ (' + t.r + ' × 10⁶ bits per second) = ' + fmtN(ans) + ' ns. Every bit on this link lasts ' + fmtN(ans) + ' ns.');
    else if (near(v, ans / 1000)) wrong(fb, 'That is the right size in µs (microseconds). The task asks for ns: 1 µs = 1,000 ns.');
    else if (near(v, t.r)) wrong(fb, 'That is the bandwidth itself. The bit width is 1 ÷ bandwidth.');
    else wrong(fb, 'Not yet. Choose a bandwidth above and read the bit width under the figure, then work out the same thing for ' + t.r + ' Mbps.');
  };
  $('#l1h').onclick = function () { note($('#l1fb'), '💡 At 1 Mbps a bit lasts 1 µs = 1,000 ns. At ' + t.r + ' Mbps it lasts ' + t.r + ' times less.'); };
  upd(); conv();
}

/* Lesson 2: three parts of latency. Every part of the task's answer is at least 5% of it, so an answer that leaves one out is never accepted. */
function l2Task() {
  var t, T, P, a;
  do { t = { size: pick([500, 1000, 1500, 9000]), bw: pick([10e6, 100e6]), distKm: rnd(2, 50) * 100, q: pick([0, 1, 2, 5]) }; T = t.size * 8 / t.bw * 1e3; P = t.distKm / 200; a = t.q + T + P; }
  while (T < 0.05 * a || P < 0.05 * a || (t.q > 0 && t.q < 0.05 * a));
  return t;
}
var L2_PRESETS = {
  lan: { name: 'A 1500-byte packet on 100 m of Ethernet at 1 Gbps', size: 1500, bw: 1e9, distKm: 0.1, medium: 'copper', q: 0 },
  wan: { name: 'A 1500-byte packet across 4,000 km of fiber at 100 Mbps', size: 1500, bw: 100e6, distKm: 4000, medium: 'fiber', q: 0 },
  sat: { name: 'A 1500-byte packet up to a satellite and down (71,572 km) at 45 Mbps', size: 1500, bw: 45e6, distKm: 71572, medium: 'radio', q: 0 },
  big: { name: 'A 1 MB file across 1,000 km of fiber at 10 Mbps', size: 1e6, bw: 10e6, distKm: 1000, medium: 'fiber', q: 0 }
};
function l2() {
  var s = lessonState.l2, t = lessonState.task || (lessonState.task = l2Task());
  var tT = t.size * 8 / t.bw * 1e3, tP = t.distKm / 200, ans = t.q + tT + tP;
  lessonText(2, 'Three parts of latency', {
    intro: '<p>The <b>latency</b> of a packet is the time from when it is ready to send until its last bit arrives. It has three parts:</p>' +
      '<p class="soft formula">Latency = Queue + Transmit + Propagation</p>' +
      '<ul class="list"><li><b>Queue:</b> waiting in a buffer behind other packets.</li><li><b>Transmit</b> = size ÷ bandwidth: putting every bit on the wire.</li><li><b>Propagation</b> = distance ÷ signal speed: one bit crossing the link.</li></ul>' +
      '<p>Press <b>Send</b> and follow the first bit and the last bit. The packet has arrived only when its <b>last bit</b> arrives.</p>',
    more: '<p><b>Reading the figure.</b> Host A\'s box empties as its bits leave, and Host B\'s box fills. The amber block is the first bit and the dark block is the last bit. The link is drawn thicker when its bandwidth is higher.</p>' +
      '<p>The line under the link marks the four moments in time order. Press <b>Show</b> next to a moment to jump to it.</p>' +
      '<p><b>Which comes first?</b> The last bit leaves Host A one transmit time after the first. The first bit reaches Host B one propagation delay after it leaves. If the transmit time is longer than the propagation delay, the first bit arrives before the last bit leaves.</p>' +
      '<p>Signals travel at about 2.0 × 10⁸ m/s (meters per second) in fiber, 2.3 × 10⁸ m/s in copper cable, and 3.0 × 10⁸ m/s by radio. The folded time diagram under the figure shows the same journey with time running down the page.</p>',
    terms: [['Latency', 'the time from when a packet is ready to send until its last bit arrives'], ['Queue (queuing delay)', 'time spent waiting in a buffer behind other packets'],
      ['Transmit time', 'the time to put every bit on the wire: size ÷ bandwidth'], ['Propagation delay', 'the time one bit takes to cross the link: distance ÷ signal speed'],
      ['ms', 'millisecond, a thousandth of a second'], ['km', 'kilometer, 1,000 m (meters)'], ['Mbps and Gbps', 'megabits (10⁶) and gigabits (10⁹) per second'],
      ['First bit and last bit', 'the first and the last bit of the packet to leave Host A'], ['Time diagram', 'a figure with the hosts across the top and time running down the page']],
    ctl: '<div class="row"><label>Example <select id="l2p"><option value="">choose…</option>' + Object.keys(L2_PRESETS).map(function (k) { return '<option value="' + k + '">' + esc(L2_PRESETS[k].name) + '</option>'; }).join('') + '</select></label></div>' +
      '<div class="row"><label>Size ' + numIn('l2s', s.size, 1, 1e12, 'Size in bytes') + ' bytes</label><label>Bandwidth <select id="l2bw">' + rateOptions(s.bw) + '</select></label></div>' +
      '<div class="row"><label>Distance ' + numIn('l2d', s.distKm, 0, 1e7, 'Distance in kilometers') + ' km</label><label>Medium <select id="l2m">' + mediumOptions(s.medium) + '</select></label><label>Queue ' + numIn('l2q', s.q, 0, 1e6, 'Queuing delay in milliseconds') + ' ms</label></div>'
  });
  setTry('<p>A <b>' + fmt(t.size) + '-byte</b> packet waits <b>' + t.q + ' ms</b> in a queue, then crosses <b>' + fmt(t.distKm) + ' km</b> of fiber at <b>' + fmtRate(t.bw) + '</b>. What is its latency, in <b>ms</b>?</p>' + answerRow('l2', 'Latency in milliseconds'));
  $('#lfig').innerHTML = '<div class="card"><p class="figtitle">The packet travels from Host A to Host B</p>' + stripHTML('l2') +
    '<div class="fig"><svg id="l2jour" role="img" aria-label="Host A sends the packet bit by bit; the bits travel along the link with the first and last bit marked; Host B receives them"></svg></div>' +
    '<ul class="legend"><li><i style="background:#CFE6F0;border:1px solid #00A2D7"></i>the packet\'s bits</li><li><i style="background:#F5A524"></i>first bit</li><li><i style="background:#0B3D5C"></i>last bit</li><li><i style="background:#13A88A;border-radius:50%;width:12px"></i>a moment that has happened</li></ul>' +
    '<p class="figtitle">The four moments</p><ol class="log" id="l2ev" aria-live="polite"></ol></div>' +
    figFold('The same journey on a time diagram (time runs down)', stripHTML('l2b') + '<div class="fig"><svg id="l2st" role="img" aria-label="Space-time diagram: Host A sends one packet to Host B"></svg></div>' + ST_LEGEND +
      '<p class="cmdnote">The height of the band at Host A is the transmit time. Its slope is the propagation delay.</p>') +
    figFold('The numbers: queue, transmit, and propagation', '<div class="calcgrid" id="l2stats"></div><p class="figtitle">Where the latency comes from</p><div class="fig"><svg id="l2bar" role="img" aria-label="Bar split into queue, transmit, and propagation"></svg></div>');
  var curL = null, evKey = '';
  var tl = new Timeline({ strips: ['l2', 'l2b'], st: $('#l2st'), detail: true, alive: lessonAlive(), ms: 6000,
    extra: function (tc, r) {
      var h = r.hops[0], ev = linkEvents(h), key = ev.map(function (e) { return e.k + ':' + e.t; }).join();
      drawJourney($('#l2jour'), { h: h, tc: tc, dist: curL ? curL.dist : undefined });
      if (key !== evKey) {   // rebuild the list only when the link changes
        evKey = key;
        $('#l2ev').innerHTML = evList('l2ev', ev, true);
        $$('[data-ev]', $('#l2ev')).forEach(function (b) { b.onclick = function () { var e = ev[+b.getAttribute('data-ev')]; tl.jump(h.end ? e.t / h.end : 1); }; });
      }
      markEvents($('#l2ev'), tc, h.end);
    } });
  function upd() {
    var size = readF('#l2s', 1, 1e12), d = readF('#l2d', 0, 1e7), q = readF('#l2q', 0, 1e6); if (size === null || d === null || q === null) return;
    s.size = size; s.distKm = d; s.q = q; s.bw = +$('#l2bw').value; s.medium = $('#l2m').value;
    var L = { bw: s.bw, dist: d * 1000, medium: s.medium, q: q / 1000 }, bits = size * 8, r = pathTimes(bits, [L]).hops[0];
    curL = L; tl.set(['Host A', 'Host B'], [L], bits);
    $('#l2stats').innerHTML = stat('Queue', fmtT(r.q)) + stat('Transmit', fmtT(r.T), fmtN(bits) + ' bits ÷ ' + fmtRate(s.bw)) + stat('Propagation', fmtT(r.P), fmtDist(d * 1000) + ' ÷ ' + fmtN(SPEED[s.medium]) + ' m/s') + stat('Latency', fmtT(r.end), r.T > r.P ? 'transmit is the biggest part' : 'propagation is the biggest part', true);
    drawBar($('#l2bar'), [{ name: 'Queue', v: r.q, fill: C.amberSoft, line: C.amber }, { name: 'Transmit', v: r.T, fill: C.panel, line: C.brand }, { name: 'Propagation', v: r.P, fill: '#E7E1FF', line: '#7B61FF' }]);
  }
  $('#l2p').onchange = function () { var P = L2_PRESETS[this.value]; if (!P) return; $('#l2s').value = P.size; $('#l2bw').value = P.bw; $('#l2d').value = P.distKm; $('#l2m').value = P.medium; $('#l2q').value = P.q; upd(); tl.play(); };
  ['#l2s', '#l2d', '#l2q'].forEach(function (id) { $(id).oninput = upd; }); $('#l2bw').onchange = upd; $('#l2m').onchange = upd;
  $('#l2c').onclick = function () {
    var v = readAnswer('#l2a'), fb = $('#l2fb');
    if (near(v, ans)) lessonDone(fb, 'Right: ' + t.q + ' ms (queue) + ' + fmtN(tT) + ' ms (transmit: ' + fmt(t.size * 8) + ' bits ÷ ' + fmtRate(t.bw) + ') + ' + fmtN(tP) + ' ms (propagation: ' + fmt(t.distKm) + ' km ÷ 2 × 10⁸ m/s) = ' + fmtN(ans) + ' ms.');
    else if (t.q > 0 && near(v, ans - t.q)) wrong(fb, 'Close. Did you leave out the time in the queue?');
    else if (near(v, tP + t.q) || near(v, tP)) wrong(fb, 'You have the propagation part. The packet also needs time to be put on the wire.');
    else if (near(v, 2 * ans) || near(v, 2 * (tT + tP) + t.q)) wrong(fb, 'That looks like a round trip. Latency here is one way, from Host A to Host B.');
    else if (near(v, t.q + t.size / t.bw * 1e3 + tP)) wrong(fb, 'Check the transmit part: the size is in bytes, and the bandwidth is in bits per second.');
    else wrong(fb, 'Not yet. Type the task\'s numbers into the boxes above, then read the last moment\'s time or open <b>The numbers</b> under the figure.');
  };
  $('#l2h').onclick = function () { note($('#l2fb'), '💡 Transmit = ' + fmt(t.size) + ' × 8 bits ÷ ' + fmtRate(t.bw) + '. Propagation = ' + fmt(t.distKm) + ',000 m ÷ 2 × 10⁸ m/s. Then add the queue.'); };
  upd();
}

/* Lesson 3: which part dominates? */
var L3_SIZES = [[1e4, '10 KB'], [1e5, '100 KB'], [1e6, '1 MB'], [1e7, '10 MB'], [1e8, '100 MB'], [1e9, '1 GB']];
function l3Task() {
  var a, b, sz, la, lb;
  do {
    a = { bw: pick([100e6, 1e9]), d: 0.25 }; b = { bw: pick([10e6, 45e6]), d: pick([0.01, 0.02, 0.03]) }; sz = pick(L3_SIZES);
    la = a.d + sz[0] * 8 / a.bw; lb = b.d + sz[0] * 8 / b.bw;
  } while (Math.max(la, lb) / Math.min(la, lb) < 1.3);
  return { a: a, b: b, sz: sz, win: la < lb ? 1 : 2, la: la, lb: lb };
}
function l3() {
  var s = lessonState.l3, t = lessonState.task || (lessonState.task = l3Task());
  lessonText(3, 'Which part dominates?', {
    intro: '<p>The propagation delay is fixed by the distance, but the transmit time grows with the message size. So which link is faster depends on what you send.</p>' +
      '<p>Compare a satellite link (fast but far) with a ground link (slower but close). Move the <b>message size</b> and watch the two curves cross.</p>',
    more: '<p><b>Small messages:</b> the transmit time is tiny, so the latency is about the propagation delay. More bandwidth hardly helps. The transfer is <b>latency-bound</b>.</p>' +
      '<p><b>Large messages:</b> the transmit time dominates, so bandwidth matters most. The transfer is <b>bandwidth-bound</b>.</p>' +
      '<p>Transmit and propagation are equal when size ÷ bandwidth = delay, that is, when the size equals <b>delay × bandwidth</b>. That product is the subject of the next lesson.</p>' +
      '<p><b>Reading the plot.</b> Both axes are logarithmic: each grid step is 10 times more. A flat part of a curve means the delay dominates; a rising part means the transmit time dominates.</p>',
    terms: [['Latency', 'one-way delay (propagation) plus transmit time, here with no queue'], ['One-way delay', 'the time one bit takes to cross the link'], ['Transmit time', 'size ÷ bandwidth'],
      ['Latency-bound', 'the delay is the bigger part, so more bandwidth hardly helps'], ['Bandwidth-bound', 'the transmit time is the bigger part, so bandwidth matters most'],
      ['Logarithmic scale', 'each equal step on the axis is 10 times more'], ['ms', 'millisecond, a thousandth of a second'], ['Mbps and Gbps', 'megabits (10⁶) and gigabits (10⁹) per second'],
      ['KB, MB, GB', 'kilobyte (1,000 bytes), megabyte (10⁶ bytes), gigabyte (10⁹ bytes)']],
    ctl: '<div class="row"><b style="color:#00A2D7">Link 1</b><label>Bandwidth <select id="l3ba">' + rateOptions(s.bwA) + '</select></label><label>One-way delay ' + numIn('l3da', s.dA, 0, 1e6, 'Link 1 one-way delay in milliseconds') + ' ms</label></div>' +
      '<div class="row"><b style="color:#7B61FF">Link 2</b><label>Bandwidth <select id="l3bb">' + rateOptions(s.bwB) + '</select></label><label>One-way delay ' + numIn('l3db', s.dB, 0, 1e6, 'Link 2 one-way delay in milliseconds') + ' ms</label></div>' +
      '<div class="row"><label>Message size <input type="range" id="l3sz" min="2" max="9" step="0.1" value="' + s.lsize + '"></label><b class="mono" id="l3szv"></b></div>'
  });
  setTry('<p>Link 1: <b>' + fmtRate(t.a.bw) + '</b>, one-way delay <b>250 ms</b>. Link 2: <b>' + fmtRate(t.b.bw) + '</b>, one-way delay <b>' + t.b.d * 1000 + ' ms</b>. Which one delivers a <b>' + t.sz[1] + '</b> message first?</p>' +
    '<div class="row"><button class="btn small alt" id="l3c1">Link 1</button><button class="btn small alt" id="l3c2">Link 2</button><button class="btn alt small" id="l3h">Hint</button></div><div class="feedback" id="l3fb" aria-live="polite"></div>');
  $('#lfig').innerHTML = '<div class="card"><p class="figtitle">Latency for each message size</p><p class="cmdnote">Both axes are logarithmic: each grid step is 10 times more.</p><div class="fig"><svg id="l3svg" role="img" aria-label="Latency against message size for two links, on logarithmic scales"></svg></div>' +
    '<ul class="legend"><li><i style="background:#00A2D7"></i>Link 1</li><li><i style="background:#7B61FF"></i>Link 2</li><li><i style="background:#fff;border:1px dashed #5B6B78"></i>same latency</li></ul><div class="calcgrid" id="l3stats"></div></div>';
  function lat(bw, d, B) { return d + B * 8 / bw; }
  function upd() {
    var da = readF('#l3da', 0, 1e6), db = readF('#l3db', 0, 1e6); if (da === null || db === null) return;
    s.dA = da; s.dB = db; s.bwA = +$('#l3ba').value; s.bwB = +$('#l3bb').value; s.lsize = +$('#l3sz').value;
    var B = Math.pow(10, s.lsize), A = { bw: s.bwA, d: da / 1000 }, Bk = { bw: s.bwB, d: db / 1000 };
    $('#l3szv').textContent = fmtBytes(B * 8, false, 3);
    var fa = function (x) { return lat(A.bw, A.d, x); }, fb = function (x) { return lat(Bk.bw, Bk.d, x); };
    var ys = [fa(100), fb(100), fa(1e9), fb(1e9)].filter(function (v) { return v > 0; }), ylo = Math.pow(10, Math.floor(Math.log10(Math.min.apply(null, ys)))), yhi = Math.pow(10, Math.ceil(Math.log10(Math.max.apply(null, ys))));
    if (yhi / ylo < 100) ylo = yhi / 100;
    var vl = [], cross = (A.d - Bk.d) / (8 / Bk.bw - 8 / A.bw);
    if (isFinite(cross) && cross > 100 && cross < 1e9) vl.push({ x: cross, label: 'same at ' + fmtBytes(cross * 8, false, 3) });
    var la = fa(B), lb = fb(B);
    drawPlot($('#l3svg'), { x: [100, 1e9], y: [ylo, yhi], xlab: 'message size', ylab: 'latency', xfmt: function (v) { return fmtBytes(v * 8, false, 1).replace(' bytes', ' B'); }, yfmt: function (v) { return fmtT(v, 1); },
      series: [{ pts: logPts(100, 1e9, fa), color: C.brand }, { pts: logPts(100, 1e9, fb), color: '#7B61FF' }], vlines: vl,
      marks: [{ x: B, y: la, color: C.brand, label: fmtT(la, 3), ha: 'right' }, { x: B, y: lb, color: '#7B61FF', label: fmtT(lb, 3), dy: -0.17 }] });
    var w = la < lb ? 'Link 1' : lb < la ? 'Link 2' : 'a tie';
    $('#l3stats').innerHTML = stat('Link 1', fmtT(la), fmtT(A.d) + ' + ' + fmtT(B * 8 / A.bw) + ' transmit') + stat('Link 2', fmtT(lb), fmtT(Bk.d) + ' + ' + fmtT(B * 8 / Bk.bw) + ' transmit') + stat('First to deliver', w, 'for ' + fmtBytes(B * 8, false, 3), true);
  }
  $('#l3da').oninput = upd; $('#l3db').oninput = upd; $('#l3ba').onchange = upd; $('#l3bb').onchange = upd; $('#l3sz').oninput = upd;
  function check(k) {
    var fb = $('#l3fb');
    var why = 'Link 1 takes ' + fmtT(t.a.d) + ' + ' + fmtT(t.sz[0] * 8 / t.a.bw) + ' = ' + fmtT(t.la) + '. Link 2 takes ' + fmtT(t.b.d) + ' + ' + fmtT(t.sz[0] * 8 / t.b.bw) + ' = ' + fmtT(t.lb) + '.';
    if (k === t.win) lessonDone(fb, 'Right. ' + why + (t.win === 2 ? ' The message is small enough that the satellite\'s long delay dominates.' : ' The message is big enough that bandwidth dominates.'));
    else wrong(fb, 'Not this time. Set the two links and the size above to the task\'s values, then compare the two latencies under the figure.');
  }
  $('#l3c1').onclick = function () { check(1); }; $('#l3c2').onclick = function () { check(2); };
  $('#l3h').onclick = function () { note($('#l3fb'), '💡 For each link, add the one-way delay and the transmit time (size × 8 ÷ bandwidth).'); };
  upd();
}

/* Lesson 4: the pipe */
var L4_RTTS = [10, 20, 40, 50, 80, 100, 200], L4_BWS = [10, 45, 100, 1000];
function l4() {
  var s = lessonState.l4, t = lessonState.task || (lessonState.task = { rtt: pick(L4_RTTS), bw: pick(L4_BWS) }), ans = t.rtt * t.bw / 8;
  lessonText(4, 'The pipe: delay × bandwidth', {
    intro: '<p>Picture the link as a pipe. Its <b>length</b> is the one-way delay and its <b>width</b> is the bandwidth. Its volume, <b>delay × bandwidth</b>, is how many bits are on the link at once.</p>' +
      '<p>Press <b>Send</b>. The pipe fills, stays full while the message streams through, then empties. The transfer is complete when the last bit reaches Host B.</p>' +
      '<p>The <b>Show</b> and <b>Window</b> controls are for the round trip, when acknowledgments come back; <b>Show more</b> explains them.</p>',
    more: '<p>For example, 50 ms (milliseconds) × 45 Mbps (megabits per second) = 2.25 × 10⁶ bits, about 281 KB (kilobytes). Host A has put 2.25 million bits on the wire before the first one arrives.</p>' +
      '<p><b>The round trip.</b> A sender usually waits for an ACK (acknowledgment) from the receiver. The first ACK can come back only one RTT (round-trip time) after the first bit leaves. To keep the pipe full until then, the sender must be allowed <b>RTT × bandwidth</b> bits in flight. That allowance is its <b>window</b>. Choose <b>a round trip</b> to watch the ACK come back.</p>' +
      '<p><b>A small window.</b> With a window smaller than RTT × bandwidth, Host A sends one window, waits for the ACK, and sends the next. Part of the pipe sits empty, and the throughput drops to <b>window ÷ RTT</b>, however fast the link is.</p>' +
      '<p><b>Width is not bit width.</b> A wider pipe puts more bits on the wire each second, so each bit lasts a <i>shorter</i> time. Width and length are drawn on logarithmic scales: each step of 10 times more bandwidth (or delay) adds the same width (or length).</p>' +
      '<p><b>The controls.</b> Leave the window blank for no limit; a window matters only in a round trip. Leave the message blank to keep sending without an end. When you quote a delay × bandwidth product, say which delay you mean: one way or the RTT.</p>',
    terms: [['Delay × bandwidth', 'how many bits fit on the link at once: the pipe\'s volume'], ['One-way delay', 'the time one bit takes to cross the link: the pipe\'s length'], ['Bandwidth', 'bits per second the link carries: the pipe\'s width'],
      ['RTT', 'round-trip time: there and back, twice the one-way delay here'], ['ACK', 'acknowledgment: a short message from the receiver saying what has arrived'],
      ['Window', 'how many bits the sender may have in flight before it must wait for an ACK'], ['In flight', 'sent but not yet acknowledged'], ['Throughput', 'the rate a transfer really gets, in bits per second'],
      ['ms', 'millisecond, a thousandth of a second'], ['Mb and Mbps', 'megabits (10⁶ bits) and megabits per second'], ['KB and MB', 'kilobyte (1,000 bytes) and megabyte (10⁶ bytes)']],
    ctl: '<div class="row"><label>One-way delay ' + numIn('l4d', s.dMs, 0.001, 1e6, 'One-way delay in milliseconds') + ' ms</label><label>Bandwidth <select id="l4bw">' + rateOptions(s.bw) + '</select></label></div>' +
      '<div class="row"><label>Message ' + numIn('l4m', s.msg, 0, 1e12, 'Message size') + '</label><select id="l4mu" aria-label="Message size unit">' + sizeUnitOptions(s.msgu) + '</select></div>' +
      '<div class="row"><label>Show <select id="l4mode"><option value="one"' + (s.mode === 'one' ? ' selected' : '') + '>one way</option><option value="rtt"' + (s.mode === 'rtt' ? ' selected' : '') + '>a round trip</option></select></label><label>Window ' + numIn('l4w', s.winKB, 0, 1e12, 'Window in kilobytes') + ' KB</label></div>'
  });
  setTry('<p>A path has an <b>RTT of ' + t.rtt + ' ms</b> and a bandwidth of <b>' + t.bw + ' Mbps</b>. How many <b>KB</b> must the sender be allowed to have in flight to keep the pipe full?</p>' + answerRow('l4', 'Window in kilobytes'));
  $('#lfig').innerHTML = '<div class="card"><p class="figtitle">The link as a pipe</p>' + stripHTML('l4') + '<div class="fig"><svg id="l4svg" role="img" aria-label="A pipe whose length is the delay and whose width is the bandwidth, filled with blocks of bits"></svg></div>' +
    '<ul class="legend"><li><i style="background:#00A2D7"></i>bits in flight</li><li><i style="background:#F5A524"></i>the first bit</li><li><i style="background:#fff;border:1px solid #9DB3C1"></i>empty part of the pipe</li><li><i style="background:#13A88A"></i>acknowledgment (ACK)</li></ul>' +
    '<div class="calcgrid" id="l4key"></div></div>' +
    figFold('More numbers for this pipe', '<div class="calcgrid" id="l4stats"></div>');
  var D = 0, tEnd = 0, pl;
  function draw(frac) {
    var w = s.winKB, winBits = w === '' ? null : w * 8000, Sbits = s.msg === '' || s.msg <= 0 ? Infinity : s.msg * unitBits(s.msgu);
    drawPipe($('#l4svg'), { delay: D, bw: s.bw, mode: s.mode, win: s.mode === 'rtt' ? winBits : null, size: Sbits, binary: /i/.test(s.msgu), tc: frac * tEnd });
    return 't = ' + fmtT(frac * tEnd, 4);
  }
  function upd() {
    var d = readF('#l4d', 0.001, 1e6), w = readF('#l4w', 0, 1e12, true), m = readF('#l4m', 0, 1e12, true); if (d === null || w === null || m === null) return;
    s.dMs = d; s.winKB = w; s.bw = +$('#l4bw').value; s.mode = $('#l4mode').value; s.msg = m; s.msgu = $('#l4mu').value;
    D = d / 1000; var rtt = 2 * D, one = dxb(D, s.bw), two = dxb(rtt, s.bw), winBits = w === '' ? null : w * 8000;
    var Sbits = m === '' || m <= 0 ? Infinity : m * unitBits(s.msgu), Wuse = s.mode === 'rtt' && winBits !== null ? winBits : Infinity;
    var sch = Sbits < Infinity ? pipeSchedule(D, s.bw, Wuse, Sbits) : null;
    tEnd = sch ? sch.done : s.mode === 'rtt' ? rtt : D;
    var thr = winBits === null ? s.bw : windowThroughput(winBits, s.bw, rtt);
    var tWin = stat('RTT × bandwidth', fmtBits(two), fmtBytes(two, false) + ': the window that fills the pipe', true),
      tThr = stat('Throughput with this window', fmtRate(thr), winBits === null ? 'no limit: the full bandwidth' : 'window ÷ RTT = ' + fmtN(100 * thr / s.bw, 3) + '% of the link'),
      tDone = sch ? stat('Message complete at', fmtT(sch.done), 'delay + ' + (sch.iv.length > 1 ? sch.iv.length + ' windows, one per RTT' : 'transmit time') + ' · throughput ' + fmtRate(Sbits / sch.done, 3), true) : '';
    $('#l4key').innerHTML = stat('Pipe volume (delay × bandwidth)', fmtBits(one), fmtBytes(one, false) + ' on the link') + (sch ? tDone : tWin);
    $('#l4stats').innerHTML = stat('One-way delay × bandwidth', fmtBits(one), fmtBytes(one, false) + ' on the link') + tWin + stat('In 1500-byte packets', fmtN(two / 12000, 4), 'packets per RTT') + tThr + tDone;
    if (pl) pl.show();
  }
  pl = new Player({ strips: ['l4'], ms: 7000, alive: lessonAlive(), draw: draw });
  $('#l4d').oninput = upd; $('#l4w').oninput = upd; $('#l4m').oninput = upd; $('#l4mu').onchange = upd; $('#l4bw').onchange = upd; $('#l4mode').onchange = upd;
  $('#l4c').onclick = function () {
    var v = readAnswer('#l4a'), fb = $('#l4fb');
    if (near(v, ans)) lessonDone(fb, 'Right: ' + t.rtt + ' ms × ' + t.bw + ' Mbps = ' + fmt(t.rtt * t.bw) + ' kilobits, and ÷ 8 = ' + fmtN(ans) + ' KB. With less than that, the sender stalls before the first acknowledgment returns.');
    else if (near(v, ans * 8)) wrong(fb, 'That is in kilobits. Divide by 8 for bytes.');
    else if (near(v, ans / 2)) wrong(fb, 'That fills the pipe one way. The sender must keep sending until an acknowledgment comes back: a full round trip.');
    else if (near(v, ans * 1000) || near(v, ans / 1000)) wrong(fb, 'Check the units: ms × Mbps gives kilobits.');
    else wrong(fb, 'Not yet. Set a one-way delay of ' + t.rtt / 2 + ' ms and ' + t.bw + ' Mbps above and read RTT × bandwidth under <b>More numbers</b>.');
  };
  $('#l4h').onclick = function () { note($('#l4fb'), '💡 Window = RTT × bandwidth. ms × Mbps gives kilobits (10³ bits); then divide by 8 for kilobytes.'); };
  upd();
}

/* Lesson 5: bandwidth is not throughput. The task always has a throughput clearly below the bandwidth (at most 90%), so answering with the bandwidth is never accepted. */
function l5Task() { var t; do { t = { mb: pick([1, 2, 5, 10, 25, 100]), bw: pick([10, 45, 100, 1000]), rtt: pick([20, 40, 50, 80, 100, 200]) }; } while (t.mb * 8 / (t.rtt / 1000 + t.mb * 8 / t.bw) > 0.9 * t.bw); return t; }
function l5() {
  var s = lessonState.l5, t = lessonState.task || (lessonState.task = l5Task());
  var tt = t.mb * 8 / t.bw, ans = t.mb * 8 / (t.rtt / 1000 + tt);
  lessonText(5, 'Bandwidth is not throughput', {
    intro: '<p><b>Bandwidth</b> is what a link can carry. <b>Throughput</b> is what a transfer actually gets: its size ÷ its transfer time.</p>' +
      '<p class="soft formula">Transfer time = RTT + Size ÷ Bandwidth</p>' +
      '<p>Press <b>Send</b>. The request goes out, the pipe stays empty for one RTT (round-trip time), then the file streams in at the full bandwidth.</p>',
    more: '<p><b>Why the RTT (round-trip time)?</b> The request must reach Host B, and the first data must come back, before anything arrives. Then the data takes size ÷ bandwidth to transmit.</p>' +
      '<p><b>Example.</b> Fetch a 1 MB (megabyte) file over a 1 Gbps (gigabit per second) link with a 100 ms (millisecond) RTT. Transmitting 8 × 10⁶ bits takes 8 ms, so the transfer takes 108 ms and the throughput is about 74 Mbps, not 1 Gbps. Ten times the bandwidth would save only 7.2 ms. This transfer is <b>latency-bound</b>: shorten the RTT, not the transmit time.</p>' +
      '<p>Real TCP (Transmission Control Protocol) transfers also need a handshake and start slowly, so they take even longer than this.</p>' +
      '<p>The folded figures under the main one show how the link is used over time and the throughput for every bandwidth.</p>',
    terms: [['Bandwidth', 'how many bits per second a link can carry: the pipe\'s width'], ['Latency', 'how long one packet takes from host to host: the pipe\'s length, plus any waiting'],
      ['Throughput', 'how many bits per second a transfer actually delivers, from start to finish. It is never more than the slowest link\'s bandwidth'],
      ['Delay × bandwidth', 'how many bits fit in the pipe: its volume'], ['RTT', 'round-trip time: there and back'], ['Transfer time', 'RTT + size ÷ bandwidth'],
      ['Latency-bound', 'the RTT is the bigger part, so more bandwidth hardly helps'], ['TCP', 'Transmission Control Protocol, which most downloads use'],
      ['MB and Mb', 'megabyte (10⁶ bytes) and megabit (10⁶ bits)'], ['Mbps and Gbps', 'megabits (10⁶) and gigabits (10⁹) per second'], ['ms', 'millisecond, a thousandth of a second']],
    ctl: '<div class="row"><label>Size ' + numIn('l5s', s.size, 0.000001, 1e9, 'Size') + '</label><select id="l5u" aria-label="Size unit">' + sizeUnitOptions(s.unit) + '</select></div>' +
      '<div class="row"><label>Bandwidth <select id="l5bw">' + rateOptions(s.bw) + '</select></label><label>RTT ' + numIn('l5r', s.rtt, 0, 1e6, 'Round-trip time in milliseconds') + ' ms</label></div>'
  });
  setTry('<p>A <b>' + t.mb + ' MB</b> file is fetched over a <b>' + t.bw + ' Mbps</b> link with an <b>RTT of ' + t.rtt + ' ms</b>. What is the effective throughput, in <b>Mbps</b>?</p>' + answerRow('l5', 'Throughput in megabits per second'));
  $('#lfig').innerHTML = '<div class="card"><p class="figtitle">The download, from request to completion</p>' + stripHTML('l5') +
    '<div class="fig"><svg id="l5xfer" role="img" aria-label="Host A sends a request; Host B sends the file back through the pipe; the transfer completes when the last bit arrives"></svg></div>' +
    '<ul class="legend"><li><i style="background:#F5A524"></i>the request</li><li><i style="background:#CFE6F0;border:1px solid #00A2D7"></i>the file\'s data</li><li><i style="background:#13A88A;border-radius:50%;width:12px"></i>a moment that has happened</li></ul>' +
    '<div class="calcgrid" id="l5key"></div></div>' +
    figFold('Step through the five moments', '<ol class="log" id="l5ev" aria-live="polite"></ol><p class="cmdnote">The request is tiny, so its transmit time is left out.</p>') +
    figFold('Bandwidth versus throughput, over time', stripHTML('l5b') + '<div class="fig"><svg id="l5use" role="img" aria-label="Rate over time: nothing during the first RTT, then the full bandwidth; the dashed line is the average rate, the throughput"></svg></div>' +
      '<ul class="legend"><li><i style="background:#CFE6F0;border:1px solid #00A2D7"></i>data arriving at the full bandwidth</li><li><i style="background:#fff;border:1px dashed #9DB3C1"></i>waiting: no data yet</li><li><i style="background:#D98A00;height:3px"></i>throughput: the average rate</li></ul>' +
      '<p class="cmdnote">The box\'s height is the bandwidth. Spread the same bits over the whole transfer time and you get the throughput.</p>') +
    figFold('Throughput for every bandwidth', '<p class="cmdnote">Both axes are logarithmic: each grid step is 10 times more.</p><div class="fig"><svg id="l5svg" role="img" aria-label="Effective throughput against bandwidth on logarithmic scales, with the ceiling set by size divided by RTT"></svg></div>' +
      '<ul class="legend"><li><i style="background:#00A2D7"></i>effective throughput</li><li><i style="background:#fff;border:1px dashed #5B6B78"></i>throughput = bandwidth</li><li><i style="background:#fff;border:1px dashed #D98A00"></i>ceiling: size ÷ RTT</li></ul><div class="calcgrid" id="l5stats"></div>' +
      '<p class="figtitle">Where the transfer time goes</p><div class="fig"><svg id="l5bar" role="img" aria-label="Bar split into RTT and transmit time"></svg></div>');
  var cur = null, evKey = '', pl;
  function draw(frac) {   // the transfer, the moments, and the bandwidth-versus-throughput figure, at the same moment
    if (!cur) return '';
    var tot = cur.rtt + cur.trans, tc = frac * tot, ev = transferEvents(cur), key = ev.map(function (e) { return e.k + ':' + e.t; }).join();
    drawTransfer($('#l5xfer'), { bits: cur.bits, bw: cur.bw, rtt: cur.rtt, binary: cur.binary, tc: tc });
    drawUsage($('#l5use'), { rtt: cur.rtt, trans: cur.trans, bw: cur.bw, thr: cur.thr, tc: tc });
    if (key !== evKey) {
      evKey = key;
      $('#l5ev').innerHTML = evList('l5ev', ev, false);
      $$('[data-ev]', $('#l5ev')).forEach(function (b) { b.onclick = function () { var e = ev[+b.getAttribute('data-ev')], T0 = cur.rtt + cur.trans; pl.jump(T0 ? e.t / T0 : 1); }; });
    }
    markEvents($('#l5ev'), tc, tot);
    return 't = ' + fmtT(tc, 4);
  }
  function upd() {
    var v = readF('#l5s', 0.000001, 1e9), r = readF('#l5r', 0, 1e6); if (v === null || r === null) return;
    s.size = v; s.unit = $('#l5u').value; s.bw = +$('#l5bw').value; s.rtt = r;
    var bits = v * unitBits(s.unit), R = r / 1000, x = transfer(bits, s.bw, R), fn = function (b) { return transfer(bits, b, R).thr; };
    var series = [{ pts: logPts(1e3, 1e11, fn), color: C.brand }, { pts: [[1e3, 1e3], [1e11, 1e11]], color: C.muted, lw: 1.2, dash: [4, 3] }];
    if (R > 0) series.push({ pts: [[1e3, bits / R], [1e11, bits / R]], color: C.oneway, lw: 1.2, dash: [4, 3] });
    drawPlot($('#l5svg'), { x: [1e3, 1e11], y: [1e3, 1e11], xlab: 'link bandwidth', ylab: 'effective throughput', xfmt: function (b) { return fmtRate(b, 1); }, yfmt: function (b) { return fmtRate(b, 1); },
      series: series, marks: [{ x: s.bw, y: x.thr, color: C.navy, label: fmtRate(x.thr, 3), ha: x.thr > 1e10 ? 'right' : 'left', dy: -0.2 }] });
    var x10 = transfer(bits, s.bw * 10, R);
    var tTime = stat('Transfer time', fmtT(x.time), 'RTT + transmit (' + fmtT(x.trans) + ')'), tThr = stat('Effective throughput', fmtRate(x.thr), fmtN(100 * x.thr / s.bw, 3) + '% of the bandwidth', true),
      tKind = stat('This transfer is', R > x.trans ? 'latency-bound' : 'bandwidth-bound', R > x.trans ? 'the RTT is the bigger part' : 'the transmit time is the bigger part');
    $('#l5key').innerHTML = tTime + tThr + tKind;
    $('#l5stats').innerHTML = stat('Transmit time', fmtT(x.trans), fmtBits(bits) + ' ÷ ' + fmtRate(s.bw)) + tTime + tThr + tKind + stat('With 10 times the bandwidth', fmtT(x10.time), 'saves ' + fmtT(x.time - x10.time, 3));
    drawBar($('#l5bar'), [{ name: 'RTT', v: R, fill: '#E7E1FF', line: '#7B61FF' }, { name: 'Transmit', v: x.trans, fill: C.panel, line: C.brand }]);
    cur = { bits: bits, bw: s.bw, rtt: R, binary: /i/.test(s.unit), thr: x.thr, trans: x.trans };
    if (pl) pl.show();
  }
  pl = new Player({ strips: ['l5', 'l5b'], ms: 6000, alive: lessonAlive(), draw: draw });
  $('#l5s').oninput = upd; $('#l5r').oninput = upd; $('#l5u').onchange = upd; $('#l5bw').onchange = upd;
  $('#l5c').onclick = function () {
    var v = readAnswer('#l5a'), fb = $('#l5fb');
    if (near(v, ans)) lessonDone(fb, 'Right: transmitting ' + t.mb * 8 + ' Mb at ' + t.bw + ' Mbps takes ' + fmtT(tt) + '. Add the ' + t.rtt + ' ms RTT: ' + fmtT(t.rtt / 1000 + tt) + '. Throughput = ' + t.mb * 8 + ' Mb ÷ ' + fmtT(t.rtt / 1000 + tt) + ' = ' + fmtN(ans) + ' Mbps.');
    else if (near(v, t.bw)) wrong(fb, 'That is the link\'s bandwidth. The transfer also spends one RTT before data arrives.');
    else if (near(v, t.mb * 8 / (t.rtt / 1000))) wrong(fb, 'You divided by the RTT only. The transfer time also includes the transmit time.');
    else if (near(v, ans / 8)) wrong(fb, 'That is in MB per second. The task asks for megabits per second.');
    else wrong(fb, 'Not yet. Type the task into the boxes above and read the throughput under the figure.');
  };
  $('#l5h').onclick = function () { note($('#l5fb'), '💡 ' + t.mb + ' MB = ' + t.mb * 8 + ' Mb. Transfer time = ' + t.rtt + ' ms + ' + t.mb * 8 + ' Mb ÷ ' + t.bw + ' Mbps. Throughput = ' + t.mb * 8 + ' Mb ÷ transfer time.'); };
  upd();
}

/* Lesson 6: across a switch and a router */
var L6_NAMES = ['Host A', 'Switch', 'Router', 'Host B'];
function l6Task() {
  var bws = [pick([10e6, 100e6, 1e9]), pick([100e6, 1e9]), pick([10e6, 100e6])], ds = [pick([50, 100]), pick([1000, 5000, 20000]), pick([100e3, 500e3, 1000e3])];
  var links = [{ bw: bws[0], dist: ds[0], medium: 'copper', q: 0 }, { bw: bws[1], dist: ds[1], medium: 'fiber', q: 0 }, { bw: bws[2], dist: ds[2], medium: 'fiber', q: 0 }];
  var ans = pathTimes(12000, links).total, once = ans - 12000 / bws[1] - 12000 / bws[2];
  if (ans - once < 0.05 * ans) return l6Task();   // counting the transmit time only once must give a clearly wrong answer
  return { links: links, ans: ans };
}
function pingFmt(ms) { return ms >= 99.95 ? String(Math.round(ms)) : ms >= 9.995 ? ms.toFixed(1) : ms >= 1 ? ms.toFixed(2) : ms.toFixed(3); }
function pingRun(size, links, qs, qr, n, dest) {   // Linux ping output; queues are random between 0 and their maximum, each way
  var lines = [], rtts = [], pay = size - 28;
  lines.push('PING ' + dest + ' (' + dest + ') ' + pay + '(' + size + ') bytes of data.');
  for (var i = 1; i <= n; i++) {
    var base = 0; links.forEach(function (L) { base += 2 * (size * 8 / L.bw + propDelay(L.dist, L.medium)); });
    var q = Math.random() * qs + Math.random() * qr + Math.random() * qs + Math.random() * qr, ms = base * 1000 + q;
    rtts.push(ms); lines.push((size - 20) + ' bytes from ' + dest + ': icmp_seq=' + i + ' ttl=63 time=' + pingFmt(ms) + ' ms');
  }
  var mn = Math.min.apply(null, rtts), mx = Math.max.apply(null, rtts), avg = rtts.reduce(function (a, b) { return a + b; }, 0) / n, sq = rtts.reduce(function (a, b) { return a + b * b; }, 0) / n, md = Math.sqrt(Math.max(0, sq - avg * avg));
  lines.push('', '--- ' + dest + ' ping statistics ---', n + ' packets transmitted, ' + n + ' received, 0% packet loss, time ' + Math.round((n - 1) * 1000 + rtts[n - 1]) + 'ms', 'rtt min/avg/max/mdev = ' + [mn, avg, mx, md].map(function (v) { return v.toFixed(3); }).join('/') + ' ms');
  return { lines: lines, rtts: rtts };
}
function l6() {
  var s = lessonState.l6, t = lessonState.task || (lessonState.task = l6Task());
  lessonText(6, 'Across a switch and a router', {
    intro: '<p>Switches and routers <b>store and forward</b>: each receives the whole packet before it sends it on. So every link adds its own transmit time and propagation delay.</p>' +
      '<p>The <b>slowest link</b> is the bottleneck, drawn as the thinnest line. Press <b>Send</b> to watch one packet cross the path.</p>',
    more: '<p class="soft formula">Latency = sum over the links of (Queue + Transmit + Propagation)</p>' +
      '<p>The bottleneck sets the highest throughput the path can give, however wide the other links are. Its transmit time is usually the biggest part.</p>' +
      '<p><b>Queues and jitter.</b> Queues grow and shrink with other traffic, so one packet waits longer than the next. That is why ping times vary from line to line. The variation is called <b>jitter</b>. The single packet in the figure waits the full queue at each device; the pings wait a random part of it, each way.</p>' +
      '<p>A real ping time also includes the time the hosts take to answer. It is small on a fast computer and larger in a VM (virtual machine).</p>',
    terms: [['Store and forward', 'a switch or router receives the whole packet before it sends it on the next link'], ['Bottleneck', 'the slowest link on the path; it limits the throughput'],
      ['Queue', 'time a packet waits in a device\'s buffer behind other packets'], ['Jitter', 'how much the delay varies from one packet to the next'],
      ['Ping', 'a command that sends small packets to a host and prints each RTT'], ['RTT', 'round-trip time: there and back'],
      ['TTL', 'Time To Live: a counter in each packet that every router lowers by 1'], ['VM', 'virtual machine: a computer running inside another computer'],
      ['ms', 'millisecond, a thousandth of a second'], ['m and km', 'meter and kilometer (1,000 m)'], ['Mbps and Gbps', 'megabits (10⁶) and gigabits (10⁹) per second']],
    ctl: '<div class="row"><label>Packet size ' + numIn('l6s', s.size, 64, 65535, 'Packet size in bytes', 1) + ' bytes</label></div>' +
      '<div class="links">' + s.links.map(function (L, i) { return '<div class="linkbox"><b>Link ' + (i + 1) + ': ' + L6_NAMES[i] + ' → ' + L6_NAMES[i + 1] + '</b><label>Bandwidth <select id="l6b' + i + '">' + rateOptions(L.bw) + '</select></label><label>Length ' + numIn('l6d' + i, L.dist / 1000, 0, 1e6, 'Link ' + (i + 1) + ' length in kilometers') + ' km</label><label>Medium <select id="l6m' + i + '">' + mediumOptions(L.medium) + '</select></label></div>'; }).join('') + '</div>' +
      '<details class="fold"><summary>Queues at the switch and the router</summary><div class="row"><label>At the switch, up to ' + numIn('l6qs', s.qs, 0, 1e4, 'Queue at the switch in milliseconds') + ' ms</label><label>at the router, up to ' + numIn('l6qr', s.qr, 0, 1e4, 'Queue at the router in milliseconds') + ' ms</label></div></details>'
  });
  setTry('<p>A <b>1500-byte</b> packet crosses three links with no queuing: <b>' + t.links.map(function (L) { return fmtRate(L.bw) + ' over ' + fmtDist(L.dist) + ' of ' + MEDIUM_NAME[L.medium]; }).join('</b>, then <b>') + '</b>. What is its latency from Host A to Host B, in <b>ms</b>?</p>' + answerRow('l6', 'Latency in milliseconds'));
  $('#lfig').innerHTML = '<div class="card"><p class="figtitle">One packet from Host A to Host B</p>' + stripHTML('l6') +
    '<div class="fig"><svg id="l6wire" role="img" aria-label="One packet crossing a switch and a router at the chosen time"></svg></div>' +
    '<ul class="legend"><li><i style="background:#CFE6F0;border:1px solid #00A2D7"></i>the packet\'s bits</li><li><i style="background:#9DB3C1;height:9px"></i>a thicker link has more bandwidth</li></ul><div class="calcgrid" id="l6key"></div></div>' +
    figFold('The same packet on a time diagram (time runs down)', stripHTML('l6b') + '<div class="fig"><svg id="l6st" role="img" aria-label="Space-time diagram: one packet crossing a switch and a router"></svg></div>' + ST_LEGEND) +
    figFold('The delay on each link', '<div class="calcgrid" id="l6stats"></div>') +
    figFold('Ping Host B from Host A', '<div class="row"><button class="btn small" id="l6ping">▶ Run 5 pings</button></div><div class="term" id="l6term" aria-live="polite"><span class="d">Press Run 5 pings.</span></div><p class="cmdnote">Linux output. Host B is at 192.168.20.20; the router lowers the TTL (Time To Live) from 64 to 63. Each RTT (round-trip time) is the request and the reply crossing all three links, plus the queues.</p>') +
    figFold('Measure it on your own computers', '<div id="l6cmds"></div>');
  var tl = new Timeline({ strips: ['l6', 'l6b'], wire: $('#l6wire'), st: $('#l6st'), detail: false, alive: lessonAlive() }), links = [];
  function upd() {
    var size = readF('#l6s', 64, 65535), qs = readF('#l6qs', 0, 1e4), qr = readF('#l6qr', 0, 1e4); if (size === null || qs === null || qr === null) return;
    size = Math.round(size);
    var ls = []; for (var i = 0; i < 3; i++) { var d = readF('#l6d' + i, 0, 1e6); if (d === null) return; ls.push({ bw: +$('#l6b' + i).value, dist: d * 1000, medium: $('#l6m' + i).value }); }
    s.size = size; s.links = ls; s.qs = qs; s.qr = qr;
    links = ls.map(function (L, i) { return { bw: L.bw, dist: L.dist, medium: L.medium, q: i === 1 ? qs / 1000 : i === 2 ? qr / 1000 : 0 }; });
    tl.set(L6_NAMES, links, size * 8);
    var r = pathTimes(size * 8, links), bott = 0, bi = 0; links.forEach(function (L, i) { if (size * 8 / L.bw > bott) { bott = size * 8 / L.bw; bi = i; } });
    var noQ = pathTimes(size * 8, links.map(function (L) { return { bw: L.bw, dist: L.dist, medium: L.medium, q: 0 }; })).total;
    var tLat = stat('Latency from Host A to Host B', fmtT(r.total), 'without queues: ' + fmtT(noQ), true), tBot = stat('Bottleneck', 'Link ' + (bi + 1) + ': ' + fmtRate(links[bi].bw), 'the most the path can carry');
    $('#l6key').innerHTML = tLat + tBot;
    $('#l6stats').innerHTML = r.hops.map(function (h, i) { return stat('Link ' + (i + 1), fmtT(h.q + h.T + h.P, 3), (h.q ? 'queue ' + fmtT(h.q, 3) + ' + ' : '') + 'transmit ' + fmtT(h.T, 3) + ' + propagation ' + fmtT(h.P, 3)); }).join('') + tLat + tBot;
  }
  $('#l6s').oninput = upd; $('#l6qs').oninput = upd; $('#l6qr').oninput = upd;
  for (var i = 0; i < 3; i++) { $('#l6b' + i).onchange = upd; $('#l6d' + i).oninput = upd; $('#l6m' + i).onchange = upd; }
  $('#l6ping').onclick = function () {
    var run = pingRun(s.size, s.links, s.qs, s.qr, 5, '192.168.20.20'), term = $('#l6term'), b = this, ok = lessonAlive(), k = 0;
    b.disabled = true; term.innerHTML = '<span class="d">$ ping -c 5 -s ' + (s.size - 28) + ' 192.168.20.20</span>\n' + esc(run.lines[0]);
    (function next() {
      if (!ok()) { b.disabled = false; return; }
      k++; if (k > run.lines.length - 1) { b.disabled = false; return; }
      term.innerHTML += '\n' + esc(run.lines[k]); setTimeout(next, reduceMotion ? 0 : (k <= 5 ? 450 : 120));
    })();
  };
  renderCommands($('#l6cmds'));
  $('#l6c').onclick = function () {
    var v = readAnswer('#l6a') / 1000, fb = $('#l6fb'), cut = 12000 / t.links[0].bw, P = 0;
    t.links.forEach(function (L) { P += propDelay(L.dist, L.medium); });
    var r = pathTimes(12000, t.links);
    if (near(v, t.ans)) lessonDone(fb, 'Right: ' + r.hops.map(function (h) { return '(' + fmtT(h.T, 3) + ' + ' + fmtT(h.P, 3) + ')'; }).join(' + ') + ' = ' + fmtN(t.ans * 1000) + ' ms. Every link transmits the whole packet again.');
    else if (near(v, cut + P) || near(v, P + 12000 / Math.min(t.links[0].bw, t.links[1].bw, t.links[2].bw))) wrong(fb, 'You counted the transmit time once. With store and forward, every link transmits the whole packet again.');
    else if (near(v, 2 * t.ans)) wrong(fb, 'That is a round trip. The task asks for one way.');
    else if (near(v, t.ans * 1000) || near(v, t.ans / 1000)) wrong(fb, 'Check your units: the answer is in milliseconds.');
    else wrong(fb, 'Not yet. Type the task\'s links into the boxes above, set the queues to 0, and read the latency under the figure.');
  };
  $('#l6h').onclick = function () { note($('#l6fb'), '💡 For each link: 12,000 bits ÷ its bandwidth, plus its length ÷ the signal speed. Add the three links.'); };
  upd();
}
