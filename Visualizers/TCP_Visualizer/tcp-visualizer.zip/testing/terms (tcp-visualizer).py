"""Terms check: in every lesson, the Lesson map, and the Calculator, each acronym's first use in the
text a student reads (visible text first, then each folded section) must come with its meaning
nearby. Figure labels, commands, captures, and tool output are skipped."""
import asyncio, sys, pathlib, re
from playwright.async_api import async_playwright
URL = pathlib.Path(sys.argv[1]).resolve().as_uri()
TERMS = {
 'TCP': r'Transmission Control Protocol', 'IP': r'Internet Protocol', 'SYN': r'synchroni[sz]e', 'ACK': r'acknowledg', 'FIN': r'finish',
 'RST': r'reset', 'PSH': r'push', 'ISN': r'initial sequence number', 'MSS': r'Maximum Segment Size', 'SACK': r'Selective Acknowledg',
 'RTT': r'round-trip time', 'RTO': r'retransmission time', 'SRTT': r'smoothed', 'RTTVAR': r'variation', 'MSL': r'Maximum Segment Lifetime',
 'RFC': r'Request for Comments', 'RACK': r'Recent ACKnowledg', 'MTU': r'Maximum Transmission Unit', 'SND.UNA': r'oldest unacknowledged',
 'SND.NXT': r'next byte to send', 'RCV.NXT': r'next byte .{0,20}expect', 'Seq': r'sequence', 'Len': r'length', 'URG': r'urgent',
 'ECE': r'congestion', 'CWR': r'congestion', 'TLP': r'tail loss probe', 'SLE': r'left edge', 'SRE': r'right edge', 'ms': r'ms', 'NOP': r'no.operation|padding'}
JS = r"""() => {
  const skip = el => el.closest('svg, code, .term, .cmd, .pkts, .player, .sbadge span, .legend, .mono, select, option');
  const out = { open: '', folds: [] };
  function textOf(root, inFold) {
    let s = '';
    const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let n; while ((n = w.nextNode())) { const p = n.parentElement; if (!p || skip(p)) continue;
      const d = p.closest('details'); if (!inFold && d && !d.open && !p.closest('summary')) continue; s += n.textContent + ' '; }
    return s;
  }
  const roots = ['#lmap', '#ltext', '#lfig', '#ltask', '#calcRoot'].map(q => document.querySelector(q)).filter(e => e && !e.hidden && e.offsetParent !== null);
  roots.forEach(r => { out.open += textOf(r, false);
    r.querySelectorAll('details').forEach(d => { if (!d.open && !d.parentElement.closest('details')) out.folds.push([d.querySelector('summary') ? d.querySelector('summary').textContent : '', textOf(d, true)]); }); });
  return out; }"""
def check(tag, text, seen, probs):
    for t, exp in TERMS.items():
        if t in seen or t == 'ms' or (t == 'TCP' and not tag.startswith('map')): continue  # TCP: the app's own name, spelled out on the start screen and the map
        m = re.search(r'(?<![A-Za-z_.])' + re.escape(t) + r'(?![A-Za-z_])', text)
        if not m: continue
        win = text[max(0, m.start() - 400): m.end() + 120]
        if not re.search(exp, win, re.I): probs.append(f'{tag}: {t} used without its meaning: "...{text[max(0,m.start()-40):m.end()+40].strip()}..."')
        seen.add(t)
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
        pg = await b.new_page(viewport={'width': 1366, 'height': 900}); probs = []
        pages = [('map', '?mode=learn&lesson=map')] + [(f'lesson {i}', f'?mode=learn&lesson={i}') for i in range(1, 9)] + [('calculator', '?mode=calc')]
        for tag, q in pages:
            await pg.goto(URL + q); await pg.wait_for_timeout(400)
            r = await pg.evaluate(JS); seen = set()
            check(tag, r['open'], seen, probs)
            for summ, txt in r['folds']:
                check(tag + ' / ' + summ.strip()[:40], txt, set(seen), probs)
        for x in probs: print(x)
        print('PROBLEMS', len(probs)); await b.close()
asyncio.run(main())
