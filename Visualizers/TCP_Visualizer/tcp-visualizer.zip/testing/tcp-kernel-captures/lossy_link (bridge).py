# Userspace "lossy link": forwards Ethernet frames between ha and hb, with delay and chosen drops.
import socket, select, struct, sys, time, heapq, json
args = json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}
delay = args.get('delay', 0.02)          # one-way seconds
drop_data_a = set(args.get('drop_data_a', []))   # Nth new data segment from A (1-based), first transmission only
drop_ack_b = set(args.get('drop_ack_b', []))     # Nth pure ACK from B
drop_syn = args.get('drop_syn', False)
drop_synack = args.get('drop_synack', 0)
log = open(args.get('log', '/dev/null'), 'w')
ETH_P_ALL = 3
s = {}
for n in ('ha', 'hb'):
    k = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.htons(ETH_P_ALL)); k.bind((n, 0)); s[n] = k
other = {'ha': 'hb', 'hb': 'ha'}
q = []; seq = 0; seen = set(); ndata = 0; nack = 0; nsa = 0
def tcpinfo(f):
    if len(f) < 34 or f[12:14] != b'\x08\x00' or f[23] != 6: return None
    ihl = (f[14] & 15) * 4; tl = struct.unpack('!H', f[16:18])[0]; t = 14 + ihl
    sq, ak = struct.unpack('!II', f[t+4:t+12]); off = (f[t+12] >> 4) * 4; fl = f[t+13]
    return dict(seq=sq, ack=ak, flags=fl, plen=tl - ihl - off)
t0 = time.time()
while True:
    to = max(0, q[0][0] - time.time()) if q else 1.0
    r, _, _ = select.select(list(s.values()), [], [], to)
    for k in r:
        f, addr = k.recvfrom(65535)
        if addr[2] == socket.PACKET_OUTGOING: continue
        n = addr[0]; ti = tcpinfo(f); drop = False
        if ti:
            syn = ti['flags'] & 2; ackf = ti['flags'] & 16
            if n == 'ha' and syn and drop_syn: drop = True
            if n == 'hb' and syn and ackf:
                nsa += 1
                if nsa <= drop_synack: drop = True
            if n == 'ha' and ti['plen'] > 0 and ti['seq'] not in seen:
                seen.add(ti['seq']); ndata += 1
                if ndata in drop_data_a: drop = True
            if n == 'hb' and ti['plen'] == 0 and not syn and not (ti['flags'] & 1):
                nack += 1
                if nack in drop_ack_b: drop = True
            log.write('%.4f %s %s %s\n' % (time.time() - t0, n, 'DROP' if drop else 'fwd', ti)); log.flush()
        if not drop:
            seq += 1; heapq.heappush(q, (time.time() + delay, seq, other[n], f))
    while q and q[0][0] <= time.time():
        _, _, n, f = heapq.heappop(q); s[n].send(f)
