(function () {
'use strict';
var APP_ID = 'bandwidth-latency-visualizer';

/* ===================================================== small helpers */
var $ = function (s, r) { return (r || document).querySelector(s); };
var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
function rnd(a, b) { return a + Math.floor(Math.random() * (b - a + 1)); }
function pick(a) { return a[Math.floor(Math.random() * a.length)]; }
function shuffle(a) { a = a.slice(); for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
var reduceMotion = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);

/* storage that never throws (some embeds block it) */
var store = {
  get: function (k, d) { try { var v = window.localStorage.getItem(APP_ID + '.' + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
  set: function (k, v) { try { window.localStorage.setItem(APP_ID + '.' + k, JSON.stringify(v)); } catch (e) { /* ignore */ } }
};

/* ===================================================== the model
   Latency = Queue + Transmit + Propagation. Transmit = bits / bandwidth. Propagation = distance / signal speed.
   Times are in seconds, sizes in bits, bandwidth in bits per second, distances in meters. */
var SPEED = { fiber: 2.0e8, copper: 2.3e8, radio: 3.0e8 };
var MEDIA = [['fiber', 'Fiber (2.0 × 10⁸ m/s)'], ['copper', 'Copper cable (2.3 × 10⁸ m/s)'], ['radio', 'Radio or vacuum (3.0 × 10⁸ m/s)']];
var MEDIUM_NAME = { fiber: 'fiber', copper: 'copper cable', radio: 'radio' };
var SIZE_UNITS = [['b', 1, 'bits'], ['B', 8, 'bytes'], ['KB', 8e3, 'KB (1,000 bytes)'], ['MB', 8e6, 'MB (10⁶ bytes)'], ['GB', 8e9, 'GB (10⁹ bytes)'],
  ['KiB', 8 * 1024, 'KiB (1,024 bytes)'], ['MiB', 8 * 1048576, 'MiB (2²⁰ bytes)'], ['GiB', 8 * 1073741824, 'GiB (2³⁰ bytes)']];
var RATE_UNITS = [['bps', 1], ['kbps', 1e3], ['Mbps', 1e6], ['Gbps', 1e9]];
function unitBits(u) { for (var i = 0; i < SIZE_UNITS.length; i++) if (SIZE_UNITS[i][0] === u) return SIZE_UNITS[i][1]; return null; }
function rateMult(u) { for (var i = 0; i < RATE_UNITS.length; i++) if (RATE_UNITS[i][0] === u) return RATE_UNITS[i][1]; return null; }

function propDelay(dist, medium) { return dist / SPEED[medium]; }
function transDelay(bits, bw) { return bits / bw; }
function bitWidth(bw) { return 1 / bw; }
function bitLength(bw, medium) { return SPEED[medium] / bw; }
function dxb(delay, bw) { return delay * bw; }
/* one packet across a path; each link: { bw, dist, medium, q } where q is the queuing delay at the device that sends onto that link */
function pathTimes(bits, links) {
  var t = 0, hops = [];
  links.forEach(function (L) {
    var P = L.P !== undefined ? L.P : propDelay(L.dist, L.medium), T = transDelay(bits, L.bw), q = L.q || 0;
    hops.push({ ready: t, q: q, start: t + q, T: T, P: P, bw: L.bw, firstIn: t + q + P, end: t + q + T + P });
    t = t + q + T + P;
  });
  return { hops: hops, total: t };
}
/* n equal packets sent back to back: the last one arrives one bottleneck transmit time after the one before it */
function messageTime(bits, n, links) {
  var first = pathTimes(bits, links).total, bott = 0;
  links.forEach(function (L) { bott = Math.max(bott, bits / L.bw); });
  return first + (n - 1) * bott;
}
function transfer(bits, bw, rtt) { var t = rtt + bits / bw; return { trans: bits / bw, time: t, thr: bits / t }; }
function windowThroughput(winBits, bw, rtt) { return Math.min(bw, winBits / rtt); }
/* 0 at 1 kbps, 1 at 100 Gbps: used to draw bandwidth as width on a logarithmic scale */
function bwFrac(bw) { return clamp((Math.log10(bw) - 3) / 8, 0, 1); }
function near(v, a, rel) { return isFinite(v) && Math.abs(v - a) <= Math.max(1e-12, (rel || 0.01) * Math.abs(a)); }

/* ===================================================== formatting */
function group(s) { var p = String(s).split('.'); p[0] = p[0].replace(/\B(?=(\d{3})+(?!\d))/g, ','); return p.join('.'); }
function fmtN(v, sig) {
  if (!isFinite(v)) return '—'; if (v === 0) return '0';
  var n = Number(v.toPrecision(sig || 4)), a = Math.abs(n);
  if (a >= 1e21 || a < 1e-6) return n.toExponential(2);
  return group(String(n));
}
function fmt(v) { return group(String(v)); }
function fmtT(s, sig) {
  if (!isFinite(s)) return '—'; if (s === 0) return '0 s'; var a = Math.abs(s);
  if (a < 1e-6) return fmtN(s * 1e9, sig) + ' ns'; if (a < 1e-3) return fmtN(s * 1e6, sig) + ' µs';
  if (a < 1) return fmtN(s * 1e3, sig) + ' ms'; return fmtN(s, sig) + ' s';
}
function fmtMs(s, sig) { return fmtN(s * 1e3, sig) + ' ms'; }
function fmtBits(b, sig) {
  var a = Math.abs(b);
  if (a < 1e3) return fmtN(b, sig) + ' bits'; if (a < 1e6) return fmtN(b / 1e3, sig) + ' kb'; if (a < 1e9) return fmtN(b / 1e6, sig) + ' Mb';
  if (a < 1e12) return fmtN(b / 1e9, sig) + ' Gb'; return fmtN(b / 1e12, sig) + ' Tb';
}
function fmtBytes(bits, binary, sig) {
  var B = bits / 8, a = Math.abs(B), k = binary ? 1024 : 1000, u = binary ? ['KiB', 'MiB', 'GiB', 'TiB'] : ['KB', 'MB', 'GB', 'TB'];
  if (a < k) return fmtN(B, sig) + ' bytes';
  for (var i = 0; i < 4; i++) { var d = Math.pow(k, i + 1); if (a < d * k || i === 3) return fmtN(B / d, sig) + ' ' + u[i]; }
}
function fmtRate(bps, sig) {
  var a = Math.abs(bps);
  if (a < 1e3) return fmtN(bps, sig) + ' bps'; if (a < 1e6) return fmtN(bps / 1e3, sig) + ' kbps'; if (a < 1e9) return fmtN(bps / 1e6, sig) + ' Mbps';
  return fmtN(bps / 1e9, sig) + ' Gbps';
}
function fmtBitsW(b, sig) { return b > 0 && b < 1 ? 'less than 1 bit' : fmtBits(b, sig); }
/* a length with a sensible unit, for bits on the wire */
function fmtLen(m) { var a = Math.abs(m); return a === 0 ? '0 m' : a < 0.01 ? fmtN(m * 1000, 3) + ' mm' : a < 1 ? fmtN(m * 100, 3) + ' cm' : a < 1000 ? fmtN(m, 3) + ' m' : fmtN(m / 1000, 3) + ' km'; }
function fmtDist(m) { return m < 1000 ? fmtN(m, 6) + ' m' : fmtN(m / 1000, 6) + ' km'; }

/* ===================================================== theme colors for figures */
var C = { brand: '#00A2D7', navy: '#0B3D5C', ink: '#1B2A35', panel: '#CFE6F0', soft: '#EAF5FA', gray: '#E4E4E4', amber: '#F5A524', amberSoft: '#FDF0D5', ok: '#13A88A', bad: '#E5484D', oneway: '#D98A00', white: '#FFFFFF', muted: '#5B6B78', wire: '#9DB3C1' };
var BAND = [0, 1, 3, 4];
var CAT = [
  { line: '#00A2D7', fill: '#CFE6F0' }, { line: '#7B61FF', fill: '#E7E1FF' },
  { line: '#E08B00', fill: '#FCE9C6' }, { line: '#13A88A', fill: '#D3F1E8' }, { line: '#D6457A', fill: '#F9DCE7' }
];

/* ===================================================== figure library (inches, y up, sizes in points) */
var NS = 'http://www.w3.org/2000/svg', figN = 0;
function el(tag, at, parent) { var e = document.createElementNS(NS, tag); if (at) for (var k in at) if (at[k] !== null && at[k] !== undefined) e.setAttribute(k, at[k]); if (parent) parent.appendChild(e); return e; }
function r4(v) { return Math.round(v * 10000) / 10000; }
function Fig(svg, x0, x1, y0, y1, k) {
  while (svg.firstChild) svg.removeChild(svg.firstChild);
  svg.setAttribute('viewBox', '0 0 ' + r4(x1 - x0) + ' ' + r4(y1 - y0));
  this.svg = svg; this.x0 = x0; this.y1 = y1; this.k = k || 1.2; this.id = 'f' + (++figN);
  var defs = el('defs', null, svg);
  this.defs = defs; this.markers = {};
  this.root = el('g', { 'font-family': 'Segoe UI, system-ui, -apple-system, Helvetica Neue, Roboto, Arial, sans-serif' }, svg);
}
Fig.prototype.X = function (x) { return r4(x - this.x0); };
Fig.prototype.Y = function (y) { return r4(this.y1 - y); };
Fig.prototype.pt = function (v) { return r4(v / 72); };
Fig.prototype.g = function (p) { return el('g', null, p || this.root); };
Fig.prototype.rect = function (x, y, w, h, o) {
  o = o || {};
  return el('rect', { x: this.X(x), y: this.Y(y + h), width: r4(Math.max(0, w)), height: r4(Math.max(0, h)), rx: o.rx ? r4(o.rx) : null, fill: o.fill || C.white,
    stroke: o.stroke || C.brand, 'stroke-width': this.pt(o.lw || 1.1), 'stroke-dasharray': o.dash ? o.dash.map(this.pt, this).join(' ') : null, 'fill-opacity': o.opacity }, o.parent || this.root);
};
Fig.prototype.slab = function (x, y, w, h, o) {   // the slab box: thin outline, heavy top and right edges
  o = o || {};
  var g = this.g(o.parent);
  g.box = this.rect(x, y, w, h, { fill: o.fill || C.white, stroke: o.stroke || C.brand, lw: 1.1, parent: g });
  el('path', { d: 'M' + this.X(x) + ' ' + this.Y(y + h) + 'H' + this.X(x + w) + 'V' + this.Y(y), fill: 'none', stroke: o.stroke || C.brand,
    'stroke-width': this.pt(o.thick || 3.4), 'stroke-linecap': 'square' }, g);
  if (o.text) this.text(x + w / 2, y + h / 2, o.text, { fs: o.fs || 10, bold: o.bold, parent: g });
  return g;
};
Fig.prototype.line = function (x1, y1, x2, y2, o) {
  o = o || {};
  return el('line', { x1: this.X(x1), y1: this.Y(y1), x2: this.X(x2), y2: this.Y(y2), stroke: o.color || C.ink, 'stroke-width': this.pt(o.lw || 1.3),
    'stroke-dasharray': o.dash ? o.dash.map(this.pt, this).join(' ') : null, 'stroke-linecap': o.cap || null }, o.parent || this.root);
};
Fig.prototype.poly = function (pts, o) {
  o = o || {}; var self = this;
  return el(o.closed ? 'polygon' : 'polyline', { points: pts.map(function (p) { return self.X(p[0]) + ',' + self.Y(p[1]); }).join(' '), fill: o.fill || 'none', stroke: o.color || C.ink,
    'stroke-width': this.pt(o.lw || 1.5), 'stroke-dasharray': o.dash ? o.dash.map(this.pt, this).join(' ') : null, 'stroke-linejoin': 'round', 'fill-opacity': o.opacity }, o.parent || this.root);
};
Fig.prototype.arrow = function (x1, y1, x2, y2, o) {
  if (o && o.both) { var mx = (x1 + x2) / 2, my = (y1 + y2) / 2, oo = { color: o.color, lw: o.lw }; this.arrow(mx, my, x1, y1, oo); return this.arrow(mx, my, x2, y2, oo); }
  var col = (o && o.color) || C.ink, mid = this.markers[col];
  if (!mid) {   // one arrowhead per color, so the head always matches its line
    mid = this.markers[col] = this.id + 'a' + Object.keys(this.markers).length;
    var m = el('marker', { id: mid, viewBox: '0 0 10 10', refX: 10, refY: 5, markerWidth: 0.13, markerHeight: 0.13, markerUnits: 'userSpaceOnUse', orient: 'auto' }, this.defs);
    el('path', { d: 'M0 0L10 5L0 10z', fill: col }, m);
  }
  var l = this.line(x1, y1, x2, y2, o); l.setAttribute('marker-end', 'url(#' + mid + ')'); return l;
};
Fig.prototype.text = function (x, y, s, o) {   // centered on y; no dominant-baseline, so every browser places it the same
  o = o || {};
  var size = (o.fs || 9.5) * this.k / 72, lh = size * 1.3, lines = String(s).split('\n'), n = lines.length;
  var t = el('text', { 'font-size': r4(size), fill: o.color || C.ink, 'fill-opacity': o.opacity, 'text-anchor': o.ha === 'left' ? 'start' : o.ha === 'right' ? 'end' : 'middle',
    'font-style': o.italic ? 'italic' : null, 'font-weight': o.bold ? 'bold' : null, transform: o.rot ? 'rotate(' + o.rot + ' ' + this.X(x) + ' ' + this.Y(y) + ')' : null }, o.parent || this.root);
  var yc = this.Y(y), self = this;
  lines.forEach(function (ln, i) { var ts = el('tspan', { x: self.X(x), y: r4(yc + (i - (n - 1) / 2) * lh + size * 0.35) }, t); ts.textContent = ln; });
  return t;
};
Fig.prototype.tw = function (s, fs) { return String(s).length * (fs * this.k / 72) * 0.55; };
Fig.prototype.label = function (x, y, s, o) {   // text on a white patch, for labels that sit on lines
  o = o || {}; var w = this.tw(s, o.fs || 8.5) + 0.12, hh = (o.fs || 8.5) * this.k / 72 * 1.5, x0 = o.ha === 'left' ? x - 0.06 : o.ha === 'right' ? x - w + 0.06 : x - w / 2;
  this.rect(x0, y - hh / 2, w, hh, { fill: o.bg || '#fff', stroke: o.bg || '#fff', lw: 0.1, rx: 0.05, parent: o.parent });
  return this.text(x, y, s, o);
};

function copyText(t, btn) {
  function done(ok) { var o = btn.textContent; btn.textContent = ok ? 'Copied' : 'Select it'; setTimeout(function () { btn.textContent = o; }, 1200); }
  try { if (navigator.clipboard && window.isSecureContext) { navigator.clipboard.writeText(t).then(function () { done(true); }, function () { fallback(); }); return; } } catch (e) { /* fall through */ }
  fallback();
  function fallback() { var ta = document.createElement('textarea'); ta.value = t; ta.style.position = 'fixed'; ta.style.opacity = '0'; document.body.appendChild(ta); ta.select(); var ok = false; try { ok = document.execCommand('copy'); } catch (e) { ok = false; } document.body.removeChild(ta); done(ok); }
}

/* runs step(frac) from 0 to 1 over ms milliseconds; stops when alive() turns false */
function animate(ms, step, alive) {
  return new Promise(function (resolve) {
    if (reduceMotion || ms <= 0) { step(1); resolve(); return; }
    var t0 = null;
    function frame(ts) {
      if (!alive()) { resolve(); return; }
      if (t0 === null) t0 = ts;
      var f = Math.min(1, (ts - t0) / ms); step(f);
      if (f < 1) window.requestAnimationFrame(frame); else resolve();
    }
    window.requestAnimationFrame(frame);
  });
}

/* ===================================================== points */
var progress = store.get('progress', null);
if (!progress || typeof progress !== 'object') progress = {};
progress.xp = progress.xp || 0; progress.lessons = progress.lessons || {}; progress.badges = progress.badges || {}; progress.best = progress.best || {};
function showXP(pop) { var x = $('#xp'); x.innerHTML = '★ ' + progress.xp + '<span class="pl"> points</span>'; if (pop && !reduceMotion) { x.classList.remove('pop'); void x.offsetWidth; x.classList.add('pop'); } }
function addXP(n) { progress.xp += n; store.set('progress', progress); showXP(true); }

/* ===================================================== figures */
/* node column centers shared by the wire figure and the space-time figure */
function columns(n) { var a = 1.9, b = n === 2 ? 7.2 : 8.1, xs = []; for (var i = 0; i < n; i++) xs.push(n === 1 ? (a + b) / 2 : a + (b - a) * i / (n - 1)); return xs; }

/* The hosts and links, with the packet's bits on each link at time tc */
function drawWire(svg, o) {
  var names = o.names, hops = o.hops, tc = o.tc, n = names.length, xs = columns(n), f = new Fig(svg, 0, 10, 0, 2.3, 1.55), W = n > 3 ? 0.95 : 1.1, H = 0.56, yc = 1.42, onLinks = [];
  for (var i = 0; i < n - 1; i++) {
    var xa = xs[i] + W / 2, xb = xs[i + 1] - W / 2, L = xb - xa, h = hops[i], lk = o.links[i];
    var th = 1.5 + 11 * bwFrac(lk.bw), ph = th / 72 + 0.08;   // a link with more bandwidth is drawn thicker
    f.line(xa, yc, xb, yc, { color: C.wire, lw: th, cap: 'butt' });
    f.text((xa + xb) / 2, yc + 0.6, fmtRate(lk.bw) + '\n' + (lk.dist !== undefined ? fmtDist(lk.dist) : fmtT(h.P)), { fs: 7.4, color: C.muted });
    var sent = clamp(tc - h.start, 0, h.T), got = clamp(tc - h.start - h.P, 0, h.T), onWire = (sent - got) * h.bw;
    if (h.P > 0 && onWire > 1e-9) {
      var f1 = clamp((tc - h.start) / h.P, 0, 1), f2 = clamp((tc - h.start - h.T) / h.P, 0, 1);
      var x1 = xa + f2 * L, x2 = xa + f1 * L; if (x2 - x1 < 0.04) { x1 = Math.max(xa, x2 - 0.04); }
      f.rect(x1, yc - ph / 2, x2 - x1, ph, { fill: C.panel, stroke: C.brand, lw: 1.3 });
      if (x2 - x1 < 0.2) {   // a packet too short to see at this scale: point at it
        f.poly([[(x1 + x2) / 2, yc + ph / 2 + 0.04], [(x1 + x2) / 2 - 0.07, yc + ph / 2 + 0.18], [(x1 + x2) / 2 + 0.07, yc + ph / 2 + 0.18]], { closed: true, fill: C.amber, color: '#B86E00', lw: 0.8 });
      }
      onLinks.push((n > 2 ? 'link ' + (i + 1) + ': ' : '') + (onWire < 1 ? 'less than 1 bit (one bit is longer than the link)' : fmtBits(onWire, 3)));
    }
  }
  xs.forEach(function (x, i) {
    f.slab(x - W / 2, yc - H / 2, W, H, { text: names[i], fs: 8.6, bold: true });
    var st = '', col = C.muted, hin = hops[i - 1], hout = hops[i];
    if (i === 0) {
      if (tc < hout.start) { st = 'waiting in\nthe queue'; col = C.oneway; }
      else if (tc < hout.start + hout.T) st = 'sending:\n' + Math.floor(100 * (tc - hout.start) / hout.T) + '% sent';
      else st = 'all bits\nsent';
    } else {
      if (tc < hin.firstIn) st = '';
      else if (tc < hin.end) st = 'receiving:\n' + Math.floor(100 * (tc - hin.firstIn) / hin.T) + '%';
      else if (i === n - 1) { st = '✓ whole\npacket arrived'; col = C.ok; }
      else if (tc < hout.start) { st = 'stored, waiting\nto send'; col = C.oneway; }
      else if (tc < hout.start + hout.T) st = 'forwarding:\n' + Math.floor(100 * (tc - hout.start) / hout.T) + '% sent';
      else st = 'all bits\nsent';
    }
    if (st) f.text(x, yc - H / 2 - 0.3, st, { fs: 7.2, color: col, bold: col !== C.muted });
  });
  f.text(5, 0.12, onLinks.length ? 'Bits on the wire now: ' + onLinks.join(', ') : 'No bits on the wire right now.', { fs: 7.8, bold: !!onLinks.length, color: C.navy });
}

function wrapText(t, n) { var out = [], line = ''; t.split(' ').forEach(function (w) { if (line && (line + ' ' + w).length > n) { out.push(line); line = w; } else line = line ? line + ' ' + w : w; }); out.push(line); return out.join('\n'); }
/* Numbered moments on a time axis from xa (t = 0) to xb (t = tot). Done moments are green; the amber marker is now. */
function eventAxis(f, xa, xb, Y0, ev, tc, tot) {
  var L = xb - xa, last = -9, lvl = 0;
  f.line(xa, Y0, xb, Y0, { lw: 1 });
  f.text(xa - 0.12, Y0, 'time', { fs: 7.4, color: C.muted, ha: 'right' });
  f.text(xa, Y0 - 0.2, '0', { fs: 7.2, color: C.muted }); f.text(xb, Y0 - 0.2, fmtT(tot, 3), { fs: 7.2, color: C.muted });
  ev.forEach(function (e, i) {
    var x = xa + L * (tot ? e.t / tot : 0); lvl = x - last < 0.22 ? lvl + 1 : 0; last = x;
    var y = Y0 + 0.02 + (lvl > 2 ? 1 : lvl) * 0.25, done = tc >= e.t - tot * 1e-9;
    if (lvl > 2) x += 0.24 * (lvl - 2);   // many moments at the same time: put the extra ones beside the stack
    if (lvl) f.line(x, Y0, x, y - 0.1, { color: C.wire, lw: 0.8 });
    el('circle', { cx: f.X(x), cy: f.Y(y), r: 0.1, fill: done ? C.ok : '#fff', stroke: done ? C.ok : C.navy, 'stroke-width': f.pt(1) }, f.root);
    f.text(x, y, String(i + 1), { fs: 6.8, bold: true, color: done ? '#fff' : C.navy });
  });
  var xc = xa + L * clamp(tot ? tc / tot : 1, 0, 1);
  f.poly([[xc, Y0 - 0.02], [xc - 0.07, Y0 - 0.14], [xc + 0.07, Y0 - 0.14]], { closed: true, fill: C.amber, color: '#B86E00', lw: 0.6 });
}
/* The four moments of one packet on one link, in time order. */
function linkEvents(h) {
  return [
    { t: h.start, what: 'The first bit leaves Host A', how: h.q > 0 ? 'queue' : 'right away, with no queue' },
    { t: h.start + h.T, what: 'The last bit leaves Host A', how: (h.q > 0 ? 'queue + ' : '') + 'transmit' },
    { t: h.firstIn, what: 'The first bit reaches Host B', how: (h.q > 0 ? 'queue + ' : '') + 'propagation' },
    { t: h.end, what: 'The last bit reaches Host B: the packet has arrived', how: (h.q > 0 ? 'queue + ' : '') + 'transmit + propagation = latency' }
  ].map(function (e, i) { e.k = i; return e; }).sort(function (a, b) { return a.t - b.t || a.k - b.k; });
}

/* The message's journey on one link: bits drain out of Host A, travel as a train, and fill Host B.
   The train's length on the link is to scale (transmit time ÷ propagation delay), with a minimum so it stays visible. */
function drawJourney(svg, o) {
  var h = o.h, tc = o.tc, tot = h.end || 1, f = new Fig(svg, 0, 10, 0, 3.35, 1.55);
  var A0 = 0.1, AW = 1.5, B0 = 8.4, xa = A0 + AW, xb = B0, L = xb - xa, yc = 2.3, th = 0.18 + 0.4 * bwFrac(h.bw);
  var sent = h.T > 0 ? clamp((tc - h.start) / h.T, 0, 1) : (tc >= h.start ? 1 : 0), got = h.T > 0 ? clamp((tc - h.firstIn) / h.T, 0, 1) : (tc >= h.firstIn ? 1 : 0);
  [[A0, 'Host A', 1 - sent, 'to send'], [B0, 'Host B', got, 'received']].forEach(function (b, j) {
    f.slab(b[0], yc - 0.62, AW, 1.24, {});
    f.text(b[0] + AW / 2, yc + 0.38, b[1], { fs: 8.8, bold: true, color: C.navy });
    f.rect(b[0] + 0.15, yc - 0.12, AW - 0.3, 0.22, { fill: '#fff', stroke: C.wire, lw: 0.8 });
    if (b[2] > 0) f.rect(b[0] + 0.15, yc - 0.12, (AW - 0.3) * b[2], 0.22, { fill: j ? '#D3F1E8' : C.panel, stroke: j ? C.ok : C.brand, lw: 0.8 });
    f.text(b[0] + AW / 2, yc - 0.38, Math.round(100 * b[2]) + '% ' + b[3], { fs: 7.6, bold: true, color: j ? '#0B7A64' : C.navy });
  });
  f.rect(xa, yc - th / 2, L, th, { fill: C.bg || '#F4F8FB', stroke: C.wire, lw: 1 });
  f.text((xa + xb) / 2, 3.18, 'Link: ' + fmtRate(h.bw) + (o.dist !== undefined ? ' · ' + fmtDist(o.dist) : '') + ' · transmit ' + fmtT(h.T, 3) + ' · propagation ' + fmtT(h.P, 3), { fs: 7.4, color: C.muted });
  var scaled = false, status;
  if (h.P > 0) {
    var f1 = (tc - h.start) / h.P, f2 = (tc - h.start - h.T) / h.P, c1 = clamp(f2, 0, 1), c2 = clamp(f1, 0, 1);
    var eps = Math.max(1e-15, tot * 1e-9);   // rounding allowance that grows with the total time
    if (tc > h.start + eps && tc < h.end - eps) {   // some bits have left Host A and not all have reached Host B
      var x1 = xa + c1 * L, x2 = xa + c2 * L;
      if (x2 - x1 < 0.3) { scaled = true; if (c2 >= 1) x1 = Math.max(xa, x2 - 0.3); else if (c1 <= 0) x2 = Math.min(xb, x1 + 0.3); else x1 = Math.max(xa, x2 - 0.3); }
      f.rect(x1, yc - th / 2 + 0.03, x2 - x1, th - 0.06, { fill: C.panel, stroke: C.brand, lw: 1 });
      var nst = Math.min(60, Math.max(3, Math.round((x2 - x1) / 0.07)));
      for (var i = 1; i < nst; i++) { var xx = x1 + (x2 - x1) * i / nst; f.line(xx, yc - th / 2 + 0.05, xx, yc + th / 2 - 0.05, { color: C.brand, lw: 0.4 }); }
      if (tc > h.start + eps && tc < h.firstIn - eps) {   // the first bit is on the link
        f.rect(x2 - 0.06, yc - th / 2 + 0.03, 0.06, th - 0.06, { fill: C.amber, stroke: '#B86E00', lw: 0.8 });
        f.arrow(x2 - 0.03, yc + th / 2 + 0.2, x2 - 0.03, yc + th / 2 + 0.03, { lw: 1, color: '#B86E00' });
        f.label(clamp(x2 - 0.03, xa + 0.32, xb - 0.32), yc + th / 2 + 0.32, 'first bit', { fs: 7.6, bold: true, color: '#B86E00' });
      }
      if (tc >= h.start + h.T - eps && tc < h.end - eps) {   // the last bit has left Host A and is on the link
        f.rect(x1, yc - th / 2 + 0.03, 0.06, th - 0.06, { fill: C.navy, stroke: C.navy, lw: 0.8 });
        f.arrow(x1 + 0.03, yc - th / 2 - 0.2, x1 + 0.03, yc - th / 2 - 0.03, { lw: 1, color: C.navy });
        f.label(clamp(x1 + 0.03, xa + 0.32, xb - 0.32), yc - th / 2 - 0.32, 'last bit', { fs: 7.6, bold: true, color: C.navy });
      }
    }
  }
  if (tc <= 0 && h.start <= 0) status = 'Nothing has been sent yet. Press Send to start Host A sending.';
  else if (tc < h.start) status = 'The packet waits in Host A\'s queue. No bit has left yet.';
  else if (h.P === 0) status = tc >= h.end ? 'With no distance, every bit arrived the moment it left. The packet has arrived.' : 'With no distance, each bit arrives the moment it leaves.';
  else if (tc < h.start + h.T && tc < h.firstIn) status = 'Bits leave Host A one after another. The first bit is still on its way.';
  else if (tc < h.start + h.T) status = 'The first bit has arrived, but Host A is still sending: this packet is longer than the link.';
  else if (tc < h.firstIn) status = 'Every bit has left Host A. The whole packet is on the link, and the first bit has not arrived yet.';
  else if (tc < h.end) status = 'Host B is receiving. It has the packet only when the last bit arrives.';
  else status = '✓ The last bit has arrived. Latency = ' + fmtT(h.end, 4) + '.';
  f.text(5, 1.25, wrapText(status, 80) + (scaled ? '\n(The bits are drawn longer than to scale, so you can see them.)' : ''), { fs: 7.6, bold: true, color: tc >= h.end ? '#0B7A64' : C.navy });
  eventAxis(f, xa, xb, 0.42, linkEvents(h), tc, tot);
}

/* clip a polygon (points [x, t]) to t <= tc */
function clipT(pts, tc) {
  var out = [];
  for (var i = 0; i < pts.length; i++) {
    var a = pts[i], b = pts[(i + 1) % pts.length], ina = a[1] <= tc, inb = b[1] <= tc;
    if (ina) out.push(a);
    if (ina !== inb) { var r = (tc - a[1]) / (b[1] - a[1]); out.push([a[0] + r * (b[0] - a[0]), tc]); }
  }
  return out;
}

/* Time runs down the page. Each band is the packet: its height at the sender is the transmit time, its slope is the propagation delay. */
function drawSpaceTime(svg, o) {
  var names = o.names, hops = o.hops, n = names.length, xs = o.detail ? [2.8, 7.2] : columns(n), tMax = o.tMax || hops[hops.length - 1].end || 1, tc = o.tc;
  var f = new Fig(svg, 0, 10, 0, 4.4, 1.55), top = 3.7, bot = names.length > 2 ? 0.68 : 0.45;
  function Y(t) { return top - (top - bot) * t / tMax; }
  xs.forEach(function (x, i) { f.text(x, 4.13, names[i], { fs: 8.6, bold: true, color: C.navy }); f.line(x, top, x, bot - 0.08, { color: C.ink, lw: 1.2 }); });
  f.arrow(0.4, top, 0.4, bot - 0.05, { lw: 1 }); f.text(0.22, (top + bot) / 2, 'time', { fs: 8, rot: -90, color: C.muted });
  hops.forEach(function (h, i) {
    var xa = xs[i], xb = xs[i + 1];
    if (h.q > 0 && h.ready <= tc) f.rect(xa - 0.09, Y(Math.min(h.start, tc)), 0.18, Y(h.ready) - Y(Math.min(h.start, tc)), { fill: C.amberSoft, stroke: C.amber, lw: 1 });
    var quad = [[xa, h.start], [xb, h.start + h.P], [xb, h.end], [xa, h.start + h.T]], cl = clipT(quad, tc);
    if (cl.length > 2) f.poly(cl.map(function (p) { return [p[0], Y(p[1])]; }), { closed: true, fill: CAT[BAND[i % 4]].fill, color: CAT[BAND[i % 4]].line, lw: 1.3 });
    f.poly(quad.map(function (p) { return [p[0], Y(p[1])]; }), { closed: true, color: CAT[BAND[i % 4]].line, lw: 0.6, dash: [2, 2] });
  });
  if (tc < tMax * 0.999) f.line(0.55, Y(tc), 9.9, Y(tc), { color: C.amber, lw: 1.6, dash: [5, 3] });
  var last = hops[hops.length - 1], thin = hops.some(function (h) { return h.T < tMax * 0.012; });
  if (o.detail) {   // one link: label each part
    var h = hops[0], xa = xs[0], xb = xs[1];
    var yq = (Y(0) + Y(h.start)) / 2, ytr = (Y(h.start) + Y(h.start + h.T)) / 2;
    if (h.q > 0) { yq = Math.min(yq, top - 0.12); ytr = Math.min(ytr, yq - 0.26); f.label(xa - 0.2, yq, 'Queue ' + fmtT(h.q, 3), { fs: 7.6, ha: 'right', color: C.oneway, bold: true }); }
    else ytr = Math.min(ytr, top - 0.12);
    ytr = Math.max(ytr, bot + 0.15);
    f.line(xa - 0.14, Y(h.start), xa - 0.14, Y(h.start + h.T), { color: C.navy, lw: 1.4 });
    f.label(xa - 0.2, ytr, 'Transmit ' + fmtT(h.T, 3), { fs: 7.6, ha: 'right', color: C.navy, bold: true });
    var ex = (xa + xb) / 2, ey = (Y(h.start) + Y(h.start + h.P)) / 2, steep = (Y(h.start) - Y(h.start + h.P)) / (xb - xa) > 0.25;
    if (steep) f.label(ex + 0.18, ey + 0.12, 'Propagation ' + fmtT(h.P, 3), { fs: 7.6, bold: true, color: C.navy, ha: 'left' });
    else f.text(ex, ey + 0.24, 'Propagation ' + fmtT(h.P, 3), { fs: 7.6, bold: true, color: C.navy });
    var yl = Y(h.end) - 0.02, yf = Math.max(Y(h.firstIn), yl + 0.2);
    f.text(xb + 0.15, yf, 'first bit arrives ' + fmtT(h.firstIn, 3), { fs: 7.4, ha: 'left' });
    f.text(xb + 0.15, yl, 'last bit arrives ' + fmtT(h.end, 3), { fs: 7.4, ha: 'left', bold: true });
  } else {
    f.text(xs[n - 1] + 0.12, Y(last.end), fmtT(last.end, 3), { fs: 7.4, ha: 'left', bold: true });
    f.text(5, 0.17 + 0.25, 'Whole packet held at: ' + hops.map(function (h, i) { return names[i + 1] + ' ' + fmtT(h.end, 3); }).join(' · '), { fs: 7.4, color: C.muted });
  }
  f.text(0.4, top + 0.17, 't = 0', { fs: 7.2, color: C.muted });
  f.text(5, 0.17 - (n > 2 ? 0 : 0), 'Latency: ' + fmtT(last.end, 4) + (n > 2 ? ' from Host A to Host B' : '') + (thin ? '   (a band that looks like a line has a transmit time too short to see at this scale)' : ''), { fs: 8, bold: true, color: C.navy });
}

/* stacked bar of the delay parts */
function drawBar(svg, parts) {
  var f = new Fig(svg, 0, 10, 0, 1.15, 1.5), tot = 0, x = 0.3, W = 9.4;
  parts.forEach(function (p) { tot += p.v; });
  if (tot <= 0) return;
  parts.forEach(function (p) {
    var w = W * p.v / tot; if (w <= 0) return;
    f.rect(x, 0.62, w, 0.38, { fill: p.fill, stroke: p.line, lw: 1 });
    if (w > f.tw(p.name, 7.8) + 0.15) f.text(x + w / 2, 0.81, p.name, { fs: 7.8, bold: true });
    x += w;
  });
  f.text(5, 0.26, parts.map(function (p) { return p.name + ' ' + fmtT(p.v, 3) + ' (' + fmtN(100 * p.v / tot, 3) + '%)'; }).join('    '), { fs: 7.8 });
}

/* the link as a pipe: length = delay, width = bandwidth, volume = delay × bandwidth */
/* When Host A sends a message of S bits on a link with one-way delay D, bandwidth bw, and window W (round-trip mode):
   it sends one window per round trip, at the full bandwidth; with no window limit it sends without a pause.
   Returns the sending intervals, when the last bit leaves (te) and when it reaches Host B (done). */
function pipeSchedule(D, bw, W, S) {
  var iv = [], left = S, k = 0;
  if (!(W < Infinity) || W >= bw * 2 * D) iv.push([0, S / bw]);
  else while (left > 0 && k < 100000) { var b = Math.min(W, left); iv.push([k * 2 * D, k * 2 * D + b / bw]); left -= b; k++; }
  var te = iv.length ? iv[iv.length - 1][1] : 0;
  return { iv: iv, te: te, done: te + D };
}
function sentBy(iv, t, bw) { var s = 0; iv.forEach(function (x) { if (t > x[0]) s += (Math.min(t, x[1]) - x[0]) * bw; }); return s; }
function sendingDuring(iv, a, b) { for (var i = 0; i < iv.length; i++) if (iv[i][0] < b && iv[i][1] > a) return true; return false; }
function sendingAt(iv, t) { for (var i = 0; i < iv.length; i++) if (t >= iv[i][0] && t < iv[i][1]) return true; return false; }
/* the pipe: a cylinder whose columns of blocks light up where bits are; has(c) says whether column c holds bits */
function drawCylinder(f, x0, L, yc, H, rows, N, has, hi) {
  var yb = yc - H / 2;
  f.rect(x0, yb, L, H, { fill: C.soft, stroke: C.navy, lw: 1.2 });
  el('ellipse', { cx: f.X(x0 + L), cy: f.Y(yc), rx: r4(Math.min(0.14, H / 3)), ry: r4(H / 2), fill: '#DDEFF6', stroke: C.navy, 'stroke-width': f.pt(1.2) }, f.root);
  el('ellipse', { cx: f.X(x0), cy: f.Y(yc), rx: r4(Math.min(0.14, H / 3)), ry: r4(H / 2), fill: C.navy, stroke: C.navy, 'stroke-width': f.pt(1.2) }, f.root);
  var cw = L / N, rh = (H - 0.08) / rows;
  for (var c = 0; c < N; c++) {
    var on = has(c), hl = on && hi === c;
    for (var r = 0; r < rows; r++) f.rect(x0 + c * cw + 0.02, yb + 0.04 + r * rh + 0.015, cw - 0.04, rh - 0.03, { fill: hl ? C.amber : on ? C.brand : '#fff', stroke: hl ? '#B86E00' : on ? C.navy : C.wire, lw: 0.5, rx: 0.02 });
  }
}
function doneBanner(f, xm, y, text) {
  var w = f.tw(text, 8.4) + 0.4;
  f.rect(xm - w / 2, y - 0.2, w, 0.4, { fill: C.okSoft || '#E1F5EF', stroke: C.ok, lw: 1.6, rx: 0.08 });
  f.text(xm, y, text, { fs: 8.4, bold: true, color: '#0B7A64' });
}
function hostBar(f, x, w, y, frac, label, done) {
  f.rect(x, y - 0.07, w, 0.14, { fill: '#fff', stroke: C.wire, lw: 0.7 });
  if (frac > 0) f.rect(x, y - 0.07, w * frac, 0.14, { fill: done ? '#D3F1E8' : C.panel, stroke: done ? C.ok : C.brand, lw: 0.7 });
  f.text(x + w / 2, y - 0.22, (done ? '✓ ' : '') + label, { fs: 7, bold: true, color: done ? '#0B7A64' : C.navy });
}
function drawPipe(svg, o) {
  /* The link as a pipe: length = one-way delay, width = bandwidth (both logarithmic), volume = delay × bandwidth.
     Host A sends a message of o.size bits (or keeps sending if o.size is Infinity). The pipe fills; at t = delay the first
     bit reaches Host B and the pipe is full; it stays full while the message streams, then empties after the last bit leaves.
     The transfer is complete when the last bit reaches Host B. In round-trip mode acknowledgments come back, and a window W
     makes Host A send one window per round trip. */
  var D = o.delay, bw = o.bw, rtt = o.mode === 'rtt', R = 2 * D, S = o.size > 0 ? o.size : Infinity;
  var V = bw * D, W = rtt && o.win !== null && o.win !== undefined && o.win !== '' ? o.win : Infinity;
  var sch = pipeSchedule(D, bw, W, S), finite = S < Infinity, tEnd = finite ? sch.done : (rtt ? R : D);
  if (!finite && W < Infinity) { sch = pipeSchedule(D, bw, W, W); tEnd = R; }   // no message size: one window, up to the first acknowledgment
  var tc = o.tc === undefined ? tEnd : clamp(o.tc, 0, tEnd), eps = Math.max(1e-15, tEnd * 1e-9);
  var iv = finite || W < Infinity ? sch.iv : [[0, Infinity]];
  var f = new Fig(svg, 0, 10, 0, 3.95, 1.5), L = 1.4 + 5.0 * clamp((Math.log10(D) + 6) / 6, 0, 1), H = 0.2 + 0.9 * bwFrac(bw);
  var yc = 2.2, yb = yc - H / 2, yt = yc + H / 2, x0 = 1.65, x1 = x0 + L, rows = 1 + Math.round(4 * bwFrac(bw)), N = Math.max(5, Math.round(L / 0.24));
  var sent = Math.min(sentBy(iv, tc, bw), S), got = Math.min(sentBy(iv, tc - D, bw), S), on = sent - got, done = finite && tc >= sch.done - eps;
  f.slab(0.1, yc - 0.34, 0.98, 0.68, { text: 'Host A', fs: 8.2, bold: true });
  f.slab(x1 + 0.38, yc - 0.34, 0.98, 0.68, { text: 'Host B', fs: 8.2, bold: true, fill: done ? '#E1F5EF' : '#fff' });
  if (finite) {
    hostBar(f, 0.14, 0.9, yc - 0.6, 1 - sent / S, Math.round(100 * (1 - sent / S)) + '% to send', false);
    hostBar(f, x1 + 0.42, 0.9, yc - 0.6, got / S, Math.round(100 * got / S) + '% received', done);
  }
  // The first bit leaves at t = 0 and is at fraction tc / D of the pipe: amber marks the column it is in, the leading lit column.
  var front = tc > 0 && tc < D ? clamp(Math.ceil(tc / D * N - 1e-9) - 1, 0, N - 1) : -1;
  drawCylinder(f, x0, L, yc, H, rows, N, function (c) { var a = tc - (c + 1) / N * D, b = tc - c / N * D; return b > 0 && sendingDuring(iv, Math.max(0, a), b); }, tc < D ? front : -1);
  if (done) { var bt = '✓ Transfer complete: all ' + fmtBytes(S, o.binary, 3) + ' arrived'; if (f.tw(bt, 8.4) + 0.4 < L - 0.1) doneBanner(f, (x0 + x1) / 2, yc, bt); else { var bw2 = f.tw(bt, 8.4) + 0.4; doneBanner(f, Math.min(9.9 - bw2 / 2, x1 + 1.55 + bw2 / 2), yc, bt); } }
  // length: a time ruler on top
  var yr = yt + 0.3;
  f.line(x0, yr, x1, yr, { lw: 1 });
  [0, 0.5, 1].forEach(function (q) { var xq = x0 + q * L; f.line(xq, yr - 0.06, xq, yr + 0.06, { lw: 1 }); f.text(xq, yr + 0.18, fmtT(q * D, 3), { fs: 7.2, color: C.muted }); });
  var lt = 'length = one-way delay = ' + fmtT(D, 3) + ' (the time one bit takes to cross)', lw2 = f.tw(lt, 8) / 2 + 0.1;
  f.text(clamp((x0 + x1) / 2, lw2, 10 - lw2), yr + 0.42, lt, { fs: 8, bold: true, color: C.navy });
  f.arrow(x0 - 0.3, yc, x0 - 0.3, yt + 0.02, { lw: 1, color: '#B86E00' }); f.arrow(x0 - 0.3, yc, x0 - 0.3, yb - 0.02, { lw: 1, color: '#B86E00' });
  f.text(0.1, 3.78, 'width = bandwidth = ' + fmtRate(bw, 3) + ' (bits put in per second)', { fs: 8, bold: true, ha: 'left', color: '#B86E00' });
  // acknowledgments come back on a return path
  var ya = yb - 0.36;
  if (rtt) {
    f.line(x1, ya, x0, ya, { color: C.wire, lw: 1.2, dash: [4, 3] });
    f.text((x0 + x1) / 2, ya - 0.17, 'acknowledgments come back this way: another ' + fmtT(D, 3), { fs: 7.2, color: C.muted });
    if (tc >= D && !(done && tc >= sch.done + D)) { var ph = ((tc - D) % R + R) % R; if (ph < D && sendingAt(iv, tc - D - ph)) { var xk = x1 - L * ph / D; f.rect(xk - 0.17, ya - 0.08, 0.34, 0.16, { fill: C.ok, stroke: '#0B7A64', lw: 0.8, rx: 0.04 }); f.text(xk, ya, 'ACK', { fs: 6.6, bold: true, color: '#fff' }); } }
  }
  f.text(5, 0.82, 't = ' + fmtT(tc, 3) + '  ·  sent: ' + fmtBitsW(sent, 3) + '  ·  on the link: ' + fmtBitsW(on, 3) + '  ·  arrived at Host B: ' + fmtBitsW(got, 3), { fs: 7.6, color: C.navy });
  var st, col = C.navy, waiting = !sendingAt(iv, tc) && sent < S && tc > 0;
  if (done) { st = 'The transfer is complete at t = ' + fmtT(sch.done, 3) + ': one delay for the first bit (' + fmtT(D, 3) + ') plus ' + fmtT(sch.te, 3) + ' to send it all' + (W < Infinity && sch.iv.length > 1 ? ', in ' + sch.iv.length + ' windows, one per round trip' : '') + '. Throughput = ' + fmtRate(S / sch.done, 3) + '.'; col = '#0B7A64'; }
  else if (finite && tc >= sch.te) st = 'Host A has sent the last bit. The pipe empties as the last bits travel to Host B.';
  else if (waiting) { st = 'Host A has used up its window (' + fmtBytes(W, o.binary, 3) + ') and waits for an acknowledgment. Part of the pipe goes empty.'; col = '#B86E00'; }
  else if (tc <= 0) st = 'Nothing has been sent yet. Press Send to start Host A sending' + (finite ? ' the ' + fmtBytes(S, o.binary, 3) + ' message.' : '.');
  else if (tc < D) st = 'The first bit (amber) is on its way. Host A keeps putting bits in behind it.';
  else if (V < 1) st = 'The first bit has reached Host B before Host A finished sending it: one bit is longer than this whole link.';
  else if (!rtt && !finite) { st = 'The first bit has reached Host B. The pipe is full: ' + fmtBits(V, 3) + ' (' + fmtBytes(V, o.binary, 3) + ') on the link = delay × bandwidth.'; col = '#0B7A64'; }
  else if (!rtt) st = 'The pipe is full: ' + fmtBytes(V, o.binary, 3) + ' on the link (delay × bandwidth). It stays full while the rest of the message streams through.';
  else if (tc < R) st = 'Host B acknowledges the first bit. The acknowledgment needs another ' + fmtT(D, 3) + ' to come back, and Host A keeps sending.';
  else if (!finite) { st = 'The acknowledgment arrives after one RTT. Host A has sent ' + fmtBytes(sent, o.binary, 3) + (sent >= bw * R * 0.999 ? ' = RTT × bandwidth: the window that keeps the pipe full.' : ', less than RTT × bandwidth (' + fmtBytes(bw * R, o.binary, 3) + '), so throughput is only ' + fmtRate(W / R, 3) + '.'); col = sent >= bw * R * 0.999 ? '#0B7A64' : '#B86E00'; }
  else st = 'Acknowledgments keep coming back, and Host A keeps the pipe full.';
  f.text(5, 0.42, wrapText(st, 100), { fs: 7.8, bold: true, color: col });
  f.text(5, 0.12, 'pipe volume = delay × bandwidth = ' + (V < 1 ? 'less than 1 bit' : fmtBits(V, 3) + ' = ' + fmtBytes(V, o.binary, 3)) + (rtt ? '  ·  RTT × bandwidth = ' + fmtBitsW(2 * V, 3) : '') + (finite ? '  ·  message ' + fmtBytes(S, o.binary, 3) : ''), { fs: 7.2, color: C.muted });
}

/* how a transfer uses the link over time: height = rate, so area = bits.
   Bandwidth is the height of the box; throughput is the average height over the whole transfer. */
function drawUsage(svg, o) {
  var f = new Fig(svg, 0, 10, 0, 2.75, 1.5), X0 = 1.25, X1 = 9.55, Y0 = 0.62, Y1 = 2.12, tot = o.rtt + o.trans;
  if (tot <= 0) return;
  function PX(t) { return X0 + (X1 - X0) * t / tot; }
  function PY(r) { return Y0 + (Y1 - Y0) * r / o.bw; }
  var xr = PX(o.rtt), yt = PY(o.thr), ty = yt > (Y0 + Y1) / 2 ? Y0 + 0.36 : Y1 - 0.36, ly = yt + 0.17 > Y1 - 0.05 ? yt - 0.17 : yt + 0.17;
  if (o.rtt > 0) {
    f.rect(X0, Y0, xr - X0, Y1 - Y0, { fill: '#fff', stroke: C.wire, lw: 0.8, dash: [3, 2] });
    if (xr - X0 > 1.5) f.text((X0 + xr) / 2, ty, 'waiting one RTT:\nno data arrives yet', { fs: 7.6, color: C.muted });
  }
  f.rect(xr, Y0, X1 - xr, Y1 - Y0, { fill: C.panel, stroke: C.brand, lw: 1.2 });
  if (X1 - xr > 1.6) f.text((xr + X1) / 2, ty, 'data arrives at\nthe full bandwidth', { fs: 7.6, bold: true, color: C.navy });
  else f.text(X1, Y1 + 0.17, 'data at the full bandwidth ↓', { fs: 7.4, bold: true, color: C.navy, ha: 'right' });
  f.line(X0, yt, X1, yt, { color: C.oneway, lw: 2.2, dash: [6, 3] });
  if (X1 - xr > 3) f.label(X1 - 0.08, ly, 'throughput = average rate = ' + fmtRate(o.thr, 3), { fs: 7.8, bold: true, color: '#B86E00', ha: 'right' });
  else f.label(X0 + 0.12, ly, 'throughput = average rate = ' + fmtRate(o.thr, 3), { fs: 7.8, bold: true, color: '#B86E00', ha: 'left' });
  f.line(X0, Y0, X1 + 0.1, Y0, { lw: 1 }); f.line(X0, Y0, X0, Y1 + 0.2, { lw: 1 });
  f.text(X0 - 0.08, Y1, fmtRate(o.bw, 3), { fs: 7.4, ha: 'right', bold: true }); f.text(X0 - 0.08, Y1 - 0.2, 'bandwidth', { fs: 7, ha: 'right', color: C.muted });
  f.text(X0 - 0.08, Y0, '0', { fs: 7.4, ha: 'right' });
  f.text(X0, Y0 - 0.2, '0', { fs: 7.2, color: C.muted });
  if (o.rtt > 0 && xr - X0 > 0.5 && X1 - xr > 0.5) f.text(xr, Y0 - 0.2, fmtT(o.rtt, 3), { fs: 7.2, color: C.muted });
  f.text(X1, Y0 - 0.2, fmtT(tot, 3), { fs: 7.2, color: C.muted, bold: true });
  f.text((X0 + X1) / 2, 0.14, 'time from the request to the last bit (rate goes up the page)', { fs: 7.4, color: C.muted });
  f.text(5.4, 2.55, 'Both shapes hold the same number of bits: the blue box and the area under the amber line.', { fs: 7.4, color: C.muted });
  if (o.tc !== undefined && o.tc < tot * 0.999) {   // the moment shown in the transfer animation
    var xt = PX(clamp(o.tc, 0, tot));
    f.line(xt, Y0, xt, Y1 + 0.12, { color: C.amber, lw: 1.8, dash: [4, 2] });
  }
}

/* Eight bits at two bandwidths laid out along the wire, in meters. Both rows move at the same signal speed;
   phase (0 to 1 per slow bit time) slides them along. */
var SCALE_OBJECTS = [[0.001, 'a grain of sand'], [0.007, 'a grain of rice'], [0.02, 'a coin'], [0.3, 'a ruler'], [1.8, 'a person'], [12, 'a bus'], [100, 'a football field'], [828, 'the tallest building'], [5000, 'a 5 km run'], [42195, 'a marathon'], [1e6, 'a long drive'], [4e6, 'a continent']];
function drawBitSpace(svg, o) {
  var f = new Fig(svg, 0, 10, 0, 3.05, 1.5), X0 = 1.6, X1 = 9.7, Lb = bitLength(o.rate, o.medium), S = 8 * Lb, w1 = (X1 - X0) / 8, shift = (o.phase || 0) * w1, pat = [1, 0, 1, 1, 0, 0, 1, 0];
  [[o.rate, 2.15, 1, C.panel, C.brand, C.navy], [o.rate * o.mult, 1.3, o.mult, '#E7E1FF', '#7B61FF', '#7B61FF']].forEach(function (r) {
    var w = w1 / r[2], k = Math.floor(shift / w), x = X0 - w + (shift - k * w);
    f.line(X0, r[1] + 0.2, X1, r[1] + 0.2, { color: C.wire, lw: 9, cap: 'butt' });
    f.text(X0 - 0.12, r[1] + 0.28, fmtRate(r[0]), { fs: 8, bold: true, ha: 'right', color: r[5] });
    f.text(X0 - 0.12, r[1] + 0.08, 'bit = ' + fmtLen(Lb / r[2]), { fs: 7, ha: 'right', color: C.muted });
    for (var sidx = 0; x < X1; sidx++, x += w) {
      var a = Math.max(x, X0), b = Math.min(x + w, X1); if (b <= a) continue;
      var v = pat[(((sidx - k) % 8) + 8) % 8];
      f.rect(a, r[1] + 0.04, b - a, 0.32, { fill: v ? r[3] : '#fff', stroke: r[4], lw: 0.7 });
      if (w > 0.3 && b - a > 0.2) f.text((a + b) / 2, r[1] + 0.2, String(v), { fs: 7.4, bold: true });
    }
  });
  // one bit, measured
  f.arrow(X1 - w1, 2.72, X1, 2.72, { lw: 1, both: true, color: C.navy });
  f.label(X1 - w1 / 2, 2.88, 'one bit = ' + fmtLen(Lb), { fs: 7.6, bold: true, color: C.navy });
  // the ruler in meters
  var yr = 0.85;
  f.line(X0, yr, X1, yr, { lw: 1 });
  for (var i = 0; i <= 8; i++) { var xi = X0 + i * w1; f.line(xi, yr - 0.05, xi, yr + 0.05, { lw: 1 }); if (i % 2 === 0) f.text(xi, yr - 0.19, fmtLen(i * Lb), { fs: 7, color: C.muted }); }
  f.text(X0 - 0.12, yr, 'distance', { fs: 7.2, color: C.muted, ha: 'right' });
  var ob = null; SCALE_OBJECTS.forEach(function (x) { if (x[0] <= S && x[0] >= S / 60) ob = x; });
  if (ob) {
    var xe = X0 + (X1 - X0) * ob[0] / S, yo = 0.32;
    f.line(X0, yo, xe, yo, { color: C.ok, lw: 2.2 }); f.line(X0, yo - 0.07, X0, yo + 0.07, { color: C.ok, lw: 1.4 }); f.line(xe, yo - 0.07, xe, yo + 0.07, { color: C.ok, lw: 1.4 });
    if (xe < 6.5) f.text(xe + 0.1, yo, 'for scale: ' + ob[1] + ' (' + fmtLen(ob[0]) + ')', { fs: 7.4, bold: true, color: '#0B7A64', ha: 'left' });
    else f.text(X0, yo + 0.18, 'for scale: ' + ob[1] + ' (' + fmtLen(ob[0]) + ')', { fs: 7.4, bold: true, color: '#0B7A64', ha: 'left' });
  }
  f.text(5.65, 0.12, 'Both rows move along the wire at the same speed (' + fmtN(SPEED[o.medium]) + ' m/s). The faster link\'s bits are shorter, not faster.', { fs: 7.2, color: C.muted });
}

/* A file transfer through the pipe: the request goes from Host A to Host B, the data comes back at the full bandwidth,
   and the transfer completes when the last bit reaches Host A at t = RTT + size ÷ bandwidth. */
function transferEvents(o) {
  var T = o.bits / o.bw, h = o.rtt / 2;
  return [
    { t: 0, what: 'Host A sends its request' },
    { t: h, what: 'The request reaches Host B, which starts sending' },
    { t: o.rtt, what: 'The first data bit reaches Host A' },
    { t: h + T, what: 'Host B puts the last bit on the link' },
    { t: o.rtt + T, what: 'The last bit reaches Host A: the transfer is complete' }
  ].map(function (e, i) { e.k = i; return e; }).sort(function (a, b) { return a.t - b.t || a.k - b.k; });
}
function drawTransfer(svg, o) {
  var T = o.bits / o.bw, hD = o.rtt / 2, tot = o.rtt + T, tc = clamp(o.tc, 0, tot), eps = Math.max(1e-15, tot * 1e-9);
  var f = new Fig(svg, 0, 10, 0, 3.5, 1.55), A0 = 0.1, AW = 1.5, B0 = 8.4, xa = A0 + AW, xb = B0, L = xb - xa, yc = 2.4, th = 0.18 + 0.4 * bwFrac(o.bw);
  var doneX = tc >= o.rtt + T - Math.max(1e-15, (o.rtt + T) * 1e-9);
  var sentF = T > 0 ? clamp((tc - hD) / T, 0, 1) : (tc >= hD ? 1 : 0), gotF = T > 0 ? clamp((tc - o.rtt) / T, 0, 1) : (tc >= o.rtt ? 1 : 0);
  [[A0, 'Host A\n(downloads)', gotF, 'received', '#D3F1E8', C.ok, '#0B7A64'], [B0, 'Host B\n(server)', 1 - sentF, 'still to send', C.panel, C.brand, C.navy]].forEach(function (b) {
    f.slab(b[0], yc - 0.62, AW, 1.24, { fill: doneX && b[0] === A0 ? '#E1F5EF' : '#fff' });
    f.text(b[0] + AW / 2, yc + 0.36, b[1], { fs: 7.8, bold: true, color: C.navy });
    f.rect(b[0] + 0.15, yc - 0.12, AW - 0.3, 0.22, { fill: '#fff', stroke: C.wire, lw: 0.8 });
    if (b[2] > 0) f.rect(b[0] + 0.15, yc - 0.12, (AW - 0.3) * b[2], 0.22, { fill: b[4], stroke: b[5], lw: 0.8 });
    f.text(b[0] + AW / 2, yc - 0.38, (doneX && b[0] === A0 ? '✓ ' : '') + Math.round(100 * b[2]) + '% ' + b[3], { fs: 7.4, bold: true, color: b[6] });
  });
  var H = 0.24 + 0.5 * bwFrac(o.bw), rows = 1 + Math.round(3 * bwFrac(o.bw)), x0p = xa + 0.25, Lp = L - 0.5, N = Math.max(6, Math.round(Lp / 0.24)), done = tc >= tot - eps;
  f.text((xa + xb) / 2, 3.33, 'Link: ' + fmtRate(o.bw) + ' · one-way delay ' + fmtT(hD, 3) + ' · file ' + fmtBytes(o.bits, o.binary, 3) + ' · transmit ' + fmtT(T, 3), { fs: 7.4, color: C.muted });
  // a column holds data if Host B was sending during the times whose bits are now at that column (data flows from right to left)
  drawCylinder(f, x0p, Lp, yc, H, rows, N, function (c) {
    if (hD <= 0) return false;
    var pA = c / N, pB = (c + 1) / N, a = tc - (1 - pA) * hD, b = tc - (1 - pB) * hD;   // send times for the column's two edges
    return Math.min(b, hD + T) > Math.max(a, hD) && b > hD;
  }, -1);
  if (hD > 0 && tc > hD + eps && tc < tot - eps) f.text((xa + xb) / 2, yc - H / 2 - 0.18, '← the file\'s data at ' + fmtRate(o.bw), { fs: 7.4, bold: true, color: C.navy });
  if (done) doneBanner(f, (xa + xb) / 2, yc, '✓ Transfer complete: all ' + fmtBytes(o.bits, o.binary, 3) + ' received');
  // the request, travelling right just above the pipe
  var yq = yc + H / 2 + 0.2;
  f.line(x0p, yq, x0p + Lp, yq, { color: C.wire, lw: 0.8, dash: [3, 3] });
  if (hD > 0 && tc < hD - eps) { var xq = clamp(x0p + Lp * tc / hD, x0p + 0.32, x0p + Lp - 0.32); f.rect(xq - 0.28, yq - 0.08, 0.56, 0.16, { fill: C.amber, stroke: '#B86E00', lw: 0.8, rx: 0.04 }); f.text(xq, yq, 'request', { fs: 6.6, bold: true }); }
  var got = gotF * o.bits, st;
  if (tc <= 0) st = 'Host A is about to send its request for the file. Press Send to start.';
  else if (tc < hD - eps) st = 'The request is on its way to Host B. The pipe carries no data yet.';
  else if (tc < o.rtt - eps) st = 'Host B is sending. The first data has not reached Host A yet: Host A has received nothing.';
  else if (tc < tot - eps) st = 'Data is arriving at the full bandwidth. Host A has ' + Math.round(100 * gotF) + '% of the file.';
  else st = '✓ Transfer complete at t = ' + fmtT(tot, 4) + '. Throughput = ' + fmtBytes(o.bits, o.binary, 3) + ' ÷ ' + fmtT(tot, 3) + ' = ' + fmtRate(o.bits / tot, 3) + ' (bandwidth ' + fmtRate(o.bw, 3) + ').';
  f.text(5, 1.32, wrapText(st, 90), { fs: 7.8, bold: true, color: tc >= tot - eps ? '#0B7A64' : C.navy });
  f.text(5, 0.98, 't = ' + fmtT(tc, 3) + '  ·  received: ' + fmtBytes(got, o.binary, 3) + '  ·  average rate so far: ' + (tc > 0 ? fmtRate(got / tc, 3) : '0 bps'), { fs: 7.4, color: C.muted });
  eventAxis(f, xa, xb, 0.42, transferEvents(o), tc, tot);
}

/* log-log line plot */
function drawPlot(svg, o) {
  var f = new Fig(svg, 0, 10, 0, 4.3, 1.45), X0 = 1.35, X1 = 9.55, Y0 = 0.8, Y1 = 3.95;
  var lx0 = Math.log10(o.x[0]), lx1 = Math.log10(o.x[1]), ly0 = Math.log10(o.y[0]), ly1 = Math.log10(o.y[1]);
  function PX(v) { return X0 + (X1 - X0) * (Math.log10(v) - lx0) / (lx1 - lx0); }
  function PY(v) { return Y0 + (Y1 - Y0) * (clamp(Math.log10(v), ly0 - 0.5, ly1 + 0.5) - ly0) / (ly1 - ly0); }
  f.rect(X0, Y0, X1 - X0, Y1 - Y0, { fill: '#fff', stroke: C.wire, lw: 0.8 });
  for (var d = Math.ceil(lx0); d <= Math.floor(lx1); d++) { var xx = PX(Math.pow(10, d)); f.line(xx, Y0, xx, Y1, { color: C.gray, lw: 0.6 }); f.text(xx, Y0 - 0.2, o.xfmt(Math.pow(10, d)), { fs: 7.2, color: C.muted }); }
  for (var e = Math.ceil(ly0); e <= Math.floor(ly1); e++) { var yy = PY(Math.pow(10, e)); f.line(X0, yy, X1, yy, { color: C.gray, lw: 0.6 }); f.text(X0 - 0.08, yy, o.yfmt(Math.pow(10, e)), { fs: 7.2, color: C.muted, ha: 'right' }); }
  f.text((X0 + X1) / 2, 0.2, o.xlab, { fs: 8, bold: true }); f.text(0.17, (Y0 + Y1) / 2, o.ylab, { fs: 8, bold: true, rot: -90 });
  var clipId = f.id + 'c', cp = el('clipPath', { id: clipId }, f.svg.firstChild); el('rect', { x: f.X(X0), y: f.Y(Y1), width: r4(X1 - X0), height: r4(Y1 - Y0) }, cp);
  var g = el('g', { 'clip-path': 'url(#' + clipId + ')' }, f.root);
  (o.vlines || []).forEach(function (v) { var xx = PX(v.x); f.line(xx, Y0, xx, Y1, { color: v.color || C.muted, lw: 1, dash: [4, 3], parent: g }); f.label(xx, Y1 - 0.15 - (v.dy || 0), v.label, { fs: 7.2, color: v.color || C.muted, bold: true, parent: g }); });
  o.series.forEach(function (s) { f.poly(s.pts.map(function (p) { return [PX(p[0]), PY(p[1])]; }), { color: s.color, lw: s.lw || 2, dash: s.dash, parent: g }); });
  var used = [];
  (o.marks || []).forEach(function (m) {
    var mx = PX(m.x), my = PY(m.y);
    el('circle', { cx: f.X(mx), cy: f.Y(my), r: 0.07, fill: m.color, stroke: '#fff', 'stroke-width': f.pt(1.2) }, g);
    if (!m.label) return;
    var ha = mx > X1 - 1.6 ? 'right' : 'left', lx = mx + (ha === 'right' ? -0.14 : 0.14), ly = clamp(my + (m.dy || 0.18), Y0 + 0.16, Y1 - 0.16);
    used.forEach(function (u) { if (Math.abs(u - ly) < 0.26) ly = u + (ly >= u ? 0.26 : -0.26); });
    ly = clamp(ly, Y0 + 0.16, Y1 - 0.16); used.push(ly);
    f.label(lx, ly, m.label, { fs: 7.4, ha: ha, bold: true, color: m.color, parent: g });
  });
}
function logPts(a, b, fn, n) { var out = [], la = Math.log10(a), lb = Math.log10(b); n = n || 80; for (var i = 0; i <= n; i++) { var x = Math.pow(10, la + (lb - la) * i / n); out.push([x, fn(x)]); } return out; }

/* eight bits on a time axis, at two rates */
function drawBits(svg, rate, mult) {
  var f = new Fig(svg, 0, 10, 0, 2.55, 1.5), X0 = 1.6, X1 = 9.7, span = 8 / rate, pat = [1, 0, 1, 1, 0, 0, 1, 0];
  [[rate, 1.75], [rate * mult, 0.95]].forEach(function (r, j) {
    var n = Math.round(span * r[0]), w = (X1 - X0) / n;
    f.text(X0 - 0.12, r[1] + 0.2, fmtRate(r[0]), { fs: 8.2, bold: true, ha: 'right', color: j ? '#7B61FF' : C.navy });
    for (var i = 0; i < n; i++) {
      var b = pat[i % 8];
      f.rect(X0 + i * w, r[1], w, 0.4, { fill: b ? (j ? '#E7E1FF' : C.panel) : '#fff', stroke: j ? '#7B61FF' : C.brand, lw: 0.8 });
      if (w > 0.28) f.text(X0 + (i + 0.5) * w, r[1] + 0.2, String(b), { fs: 7.6, bold: true });
    }
  });
  f.line(X0, 0.62, X1, 0.62, { color: C.ink, lw: 1 });
  for (var i = 0; i <= 8; i++) { var x = X0 + (X1 - X0) * i / 8; f.line(x, 0.57, x, 0.67, { color: C.ink, lw: 1 }); if (i % 2 === 0) f.text(x, 0.38, fmtT(i / rate, 3), { fs: 7.2, color: C.muted }); }
  f.text((X0 + X1) / 2, 0.12, 'time', { fs: 7.6, color: C.muted });
  f.label(X0 + (X1 - X0) / 16, 2.38, '← one bit: ' + fmtT(1 / rate, 3), { fs: 7.6, bold: true, ha: 'left', color: C.navy });
}

/* start screen: the pipe */
function drawHero() {
  var f = new Fig($('#heroFig'), 0, 7.2, 0, 4, 1.55);
  f.slab(0.15, 1.5, 1.05, 0.9, { text: 'Host A', fill: '#fff', fs: 8.6, bold: true });
  f.slab(6.0, 1.5, 1.05, 0.9, { text: 'Host B', fill: '#fff', fs: 8.6, bold: true });
  f.rect(1.25, 1.55, 4.7, 0.8, { fill: 'rgba(255,255,255,0.18)', stroke: '#fff', lw: 1.4, rx: 0.4 });
  for (var i = 0; i < 14; i++) f.rect(1.45 + i * 0.31, 1.68, 0.24, 0.54, { fill: i < 10 ? (i % 3 === 2 ? C.amber : '#fff') : 'rgba(255,255,255,0.15)', stroke: '#fff', lw: 0.6, rx: 0.04 });
  f.arrow(1.3, 2.75, 5.9, 2.75, { color: '#fff', lw: 1.2, both: true });
  f.text(3.6, 3.05, 'length = delay', { fs: 9, bold: true, color: '#fff' });
  f.arrow(3.6, 1.45, 3.6, 0.95, { color: '#fff', lw: 1 });
  f.text(3.6, 0.7, 'width = bandwidth', { fs: 9, bold: true, color: '#FCE9C6' });
  f.text(3.6, 0.3, 'bits in flight = delay × bandwidth', { fs: 8.2, color: '#CFE6F0' });
}

/* ===================================================== commands (Linux and Windows) */
var cmdState = { os: 'linux', dest: '192.168.20.20', iface: 'eth0' };
function commandList(os, dest, iface) {
  if (os === 'linux') return [
    ['Measure the round-trip time'],
    ['ping -c 5 ' + dest, 'Sends 5 echo requests and prints each RTT, then the minimum, average, maximum, and mdev (how much the RTT varies).'],
    ['ping -c 5 -s 1400 ' + dest, 'The same with 1400-byte payloads. On a slow link the extra transmit time shows up in the RTT; at 1 Gbps it is only about 11 µs per link each way.'],
    ['Find the link speed'],
    ['cat /sys/class/net/' + iface + '/speed', 'Prints the adapter\'s link speed in Mbps. In a virtual machine this is the virtual adapter\'s speed, not the real cable\'s: check the host or the switch instead.'],
    ['ip -s link show dev ' + iface, 'Shows the bytes and packets this adapter has sent and received so far. Run it twice to see how much moved in between.'],
    ['Measure throughput between two Linux hosts'],
    ['nc -l 5000 > /dev/null', 'Run this on the receiver first: listen on TCP port 5000 and throw the data away.'],
    ['dd if=/dev/zero bs=1M count=100 | nc -N ' + dest + ' 5000', 'Run this on the sender: send 100 MiB (here 1M means 2²⁰ bytes). When it ends, dd prints the bytes, the time, and the rate in MB/s; multiply by 8 for Mbps. Expect a little less than the slowest link\'s rate, because headers use part of it.'],
    ['Add delay or limit the rate, then undo it (needs sudo)'],
    ['sudo tc qdisc add dev ' + iface + ' root netem delay 50ms', 'Adds 50 ms of delay to every packet this host sends on ' + iface + '. A ping to the other host takes about 50 ms longer.'],
    ['sudo tc qdisc add dev ' + iface + ' root tbf rate 10mbit burst 32kbit latency 400ms', 'Instead of the delay: limits what this host sends on ' + iface + ' to 10 Mbps. Only one of these two can be in place at a time.'],
    ['tc qdisc show dev ' + iface, 'Shows what is in place on ' + iface + ' now.'],
    ['sudo tc qdisc del dev ' + iface + ' root', 'Undo: removes the added delay or rate limit and returns ' + iface + ' to normal.']
  ];
  return [
    ['Measure the round-trip time'],
    ['ping -n 5 ' + dest, 'Sends 5 echo requests and prints each time, then the minimum, maximum, and average. On a local network Windows often prints time<1ms.'],
    ['ping -n 5 -l 1400 ' + dest, 'The same with 1400-byte payloads, to see the extra transmit time on a slow link.'],
    ['Find the link speed (PowerShell)'],
    ['Get-NetAdapter | Select-Object Name, Status, LinkSpeed', 'Lists each adapter with its link speed, for example 1 Gbps. A cable with a damaged pair often links at 100 Mbps instead.'],
    ['Get-NetAdapterStatistics', 'Shows the bytes each adapter has sent and received so far. Run it twice to see how much moved in between.'],
    ['Watch throughput'],
    ['taskmgr', 'Opens Task Manager. Choose Performance, then the Ethernet or Wi-Fi adapter, to watch the send and receive rate while a transfer runs. Windows has no built-in command that sends a test stream.'],
    ['Add delay'],
    ['', 'Windows has no built-in command to add delay or limit the rate. Use a Linux host for that part.']
  ];
}
function renderCommands(box) {
  var list = commandList(cmdState.os, cmdState.dest || 'HOST_B', cmdState.iface || 'eth0');
  box.innerHTML = '<div class="row"><label>Other host\'s address <input type="text" class="cmd-dest" size="16" spellcheck="false" value="' + esc(cmdState.dest) + '"></label>' +
    (cmdState.os === 'linux' ? '<label>Interface <input type="text" class="cmd-if" size="8" spellcheck="false" value="' + esc(cmdState.iface) + '"></label>' : '') + '</div>' +
    '<p class="cmdnote">Find your interface\'s name with <code>ip link show</code> (Linux). Every command only looks, except the ones marked sudo, which change settings until you undo them.</p>' +
    '<div class="cmdtabs" role="group" aria-label="Operating system"><button data-os="linux" aria-pressed="' + (cmdState.os === 'linux') + '">Linux</button><button data-os="win" aria-pressed="' + (cmdState.os === 'win') + '">Windows</button></div>' +
    list.map(function (c) {
      if (c.length === 1) return '<p class="cmdgroup">' + esc(c[0]) + '</p>';
      if (!c[0]) return '<p class="cmdnote">' + esc(c[1]) + '</p>';
      return '<div class="cmd"><code>' + esc(c[0]) + '</code><button type="button" data-copy="' + esc(c[0]) + '">Copy</button></div><p class="cmdnote">' + esc(c[1]) + '</p>';
    }).join('');
  $$('[data-os]', box).forEach(function (b) { b.onclick = function () { cmdState.os = b.getAttribute('data-os'); renderCommands(box); }; });
  $$('[data-copy]', box).forEach(function (b) { b.onclick = function () { copyText(b.getAttribute('data-copy'), b); }; });
  var d = $('.cmd-dest', box), i = $('.cmd-if', box);
  d.onchange = function () { cmdState.dest = d.value.trim().replace(/[^\w.:-]/g, '') || '192.168.20.20'; renderCommands(box); };
  if (i) i.onchange = function () { cmdState.iface = i.value.trim().replace(/[^\w.:-]/g, '') || 'eth0'; renderCommands(box); };
}

/* shared option lists */
function sizeUnitOptions(sel) { return SIZE_UNITS.map(function (u) { return '<option value="' + u[0] + '"' + (u[0] === sel ? ' selected' : '') + '>' + u[2] + '</option>'; }).join(''); }
function rateUnitOptions(sel) { return RATE_UNITS.map(function (u) { return '<option value="' + u[0] + '"' + (u[0] === sel ? ' selected' : '') + '>' + u[0] + '</option>'; }).join(''); }
function mediumOptions(sel) { return MEDIA.map(function (m) { return '<option value="' + m[0] + '"' + (m[0] === sel ? ' selected' : '') + '>' + m[1] + '</option>'; }).join(''); }
var RATE_CHOICES = [[1e3, '1 kbps'], [56e3, '56 kbps'], [1e6, '1 Mbps'], [10e6, '10 Mbps'], [45e6, '45 Mbps'], [100e6, '100 Mbps'], [1e9, '1 Gbps'], [10e9, '10 Gbps'], [100e9, '100 Gbps']];
function rateOptions(sel) { return RATE_CHOICES.map(function (r) { return '<option value="' + r[0] + '"' + (r[0] === sel ? ' selected' : '') + '>' + r[1] + '</option>'; }).join(''); }
function stat(k, v, s, hl) { return '<div class="stat' + (hl ? ' hl' : '') + '"><div class="k">' + k + '</div><div class="v">' + v + '</div>' + (s ? '<div class="s">' + s + '</div>' : '') + '</div>'; }
