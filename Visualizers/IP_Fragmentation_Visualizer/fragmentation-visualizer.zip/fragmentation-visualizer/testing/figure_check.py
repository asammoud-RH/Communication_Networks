import asyncio, pathlib
from playwright.async_api import async_playwright
import sys
URL = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else pathlib.Path(__file__).parent.parent / 'fragmentation-visualizer.html').resolve().as_uri()
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
        pg = await b.new_page(viewport={'width':1280,'height':900})
        await pg.goto(URL+'?mode=learn&lesson=6'); await pg.wait_for_timeout(300)
        await pg.select_option('#l6mode','do'); await pg.wait_for_timeout(200)
        await (await pg.query_selector('#l6svg')).screenshot(path='l6-fig-static.png')
        await pg.evaluate("(()=>{const r=document.querySelector('#l6sp');r.value='0.5';r.dispatchEvent(new Event('input'))})()")
        await pg.click('#l6go'); await pg.wait_for_timeout(2900)
        await (await pg.query_selector('#l6svg')).screenshot(path='l6-fig-icmp.png')
        await pg.goto(URL+'?mode=calc&size=1392&kind=ping&mtus=1500-1400-532-1500&df=1'); await pg.wait_for_timeout(300)
        await (await pg.query_selector('#c_path')).screenshot(path='calc-fig.png')
        await b.close()
asyncio.run(main())
