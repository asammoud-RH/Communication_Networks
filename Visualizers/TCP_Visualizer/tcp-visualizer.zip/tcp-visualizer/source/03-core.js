
/* =====================================================================
   PAGE HELPERS, FIGURE LIBRARY, AND SHARED FIGURES
   ===================================================================== */
var $ = function (s, r) { return (r || document).querySelector(s); };
var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
function rnd(a, b) { return a + Math.floor(Math.random() * (b - a + 1)); }
function pick(a) { return a[Math.floor(Math.random() * a.length)]; }
function shuffle(a) { a = a.slice(); for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
function fmt(n) { return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ','); }
function ms(t) { return (Math.round(t * 10) / 10) + ' ms'; }
var reduceMotion = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
var store = {
  get: function (k, d) { try { var v = window.localStorage.getItem(APP_ID + '.' + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
  set: function (k, v) { try { window.localStorage.setItem(APP_ID + '.' + k, JSON.stringify(v)); } catch (e) { /* storage blocked */ } }
};
/* one animation speed for every animated diagram; every player bar has the same slider */
var SPEEDS = [0.25, 0.5, 1, 2, 4], SPEED_TXT = ['¼×', '½×', '1×', '2×', '4×'];
var animSpeed = SPEEDS.indexOf(store.get('speed', 0.5)) >= 0 ? store.get('speed', 0.5) : 0.5;   // starts at half speed
function speedCtl() {
  var k = SPEEDS.indexOf(animSpeed);
  return '<label class="speed" title="Animation speed"><span>Speed</span><input type="range" min="0" max="4" step="1" value="' + k + '" aria-label="Animation speed" aria-valuetext="' + SPEED_TXT[k] + '"><b>' + SPEED_TXT[k] + '</b></label>';
}
function bindSpeed(root) {
  $$('.speed input', root).forEach(function (r) {
    r.oninput = function () {
      var k = +r.value; animSpeed = SPEEDS[k]; store.set('speed', animSpeed);
      $$('.speed input').forEach(function (o) { o.value = k; o.setAttribute('aria-valuetext', SPEED_TXT[k]); o.nextSibling.textContent = SPEED_TXT[k]; });
    };
  });
}

var progress = store.get('progress', null);
if (!progress || typeof progress !== 'object') progress = {};
progress.xp = progress.xp || 0; progress.lessons = progress.lessons || {}; progress.badges = progress.badges || {}; progress.best = progress.best || {};
function showXP(pop) { var x = $('#xp'); x.textContent = '★ ' + progress.xp + ' points'; if (pop && !reduceMotion) { x.classList.remove('pop'); void x.offsetWidth; x.classList.add('pop'); } }
function addXP(n) { progress.xp += n; store.set('progress', progress); showXP(true); }
var OS = store.get('os', 'linux'); if (OS !== 'windows') OS = 'linux';
var osListeners = [];
function setOS(o) {
  OS = o === 'windows' ? 'windows' : 'linux'; store.set('os', OS);
  $$('[data-os]').forEach(function (b) { b.setAttribute('aria-pressed', String(b.getAttribute('data-os') === OS)); });
  osListeners = osListeners.filter(function (f) { try { return f() !== false; } catch (e) { return false; } });
}
function spell(state) { return SPELL[OS][state] || state; }
function toolName() { return OS === 'linux' ? 'ss' : 'netstat'; }

function copyText(t, btn) {
  function done(ok) { var o = btn.textContent; btn.textContent = ok ? 'Copied' : 'Select it'; setTimeout(function () { btn.textContent = o; }, 1200); }
  try { if (navigator.clipboard && window.isSecureContext) { navigator.clipboard.writeText(t).then(function () { done(true); }, function () { fallback(); }); return; } } catch (e) { /* fall through */ }
  fallback();
  function fallback() { var ta = document.createElement('textarea'); ta.value = t; ta.style.position = 'fixed'; ta.style.opacity = '0'; document.body.appendChild(ta); ta.select(); var ok = false; try { ok = document.execCommand('copy'); } catch (e) { ok = false; } document.body.removeChild(ta); done(ok); }
}

/* ===================================================== theme colors for figures */
var C = { brand: '#00A2D7', navy: '#0B3D5C', ink: '#1B2A35', panel: '#CFE6F0', soft: '#EAF5FA', gray: '#E4E4E4', amber: '#F5A524', ok: '#13A88A', bad: '#E5484D',
  white: '#FFFFFF', muted: '#5B6B78', violet: '#7B61FF', violetSoft: '#E7E1FF', amberDark: '#E08B00', amberSoft: '#FCE9C6', okSoft: '#D3F1E8', rose: '#D6457A', roseSoft: '#F9DCE7' };

/* ===================================================== figure library (inches, y up, sizes in points) */
var NS = 'http://www.w3.org/2000/svg', figN = 0;
function el(tag, at, parent) { var e = document.createElementNS(NS, tag); if (at) for (var k in at) if (at[k] !== null && at[k] !== undefined) e.setAttribute(k, at[k]); if (parent) parent.appendChild(e); return e; }
function r4(v) { return Math.round(v * 10000) / 10000; }
function Fig(svg, x0, x1, y0, y1, k) {
  while (svg.firstChild) svg.removeChild(svg.firstChild);
  svg.setAttribute('viewBox', '0 0 ' + r4(x1 - x0) + ' ' + r4(y1 - y0));
  this.svg = svg; this.x0 = x0; this.y1 = y1; this.k = k || 1.2; this.id = 'f' + (++figN);
  var defs = el('defs', null, svg);
  var self = this;
  [['a', C.ink], ['c', C.brand], ['v', C.violet], ['m', C.muted], ['r', C.bad], ['o', C.amberDark], ['t', C.ok], ['w', '#fff'], ['n', C.navy]].forEach(function (p) {
    var m = el('marker', { id: self.id + p[0], viewBox: '0 0 10 10', refX: 10, refY: 5, markerWidth: 0.12, markerHeight: 0.12, markerUnits: 'userSpaceOnUse', orient: 'auto' }, defs);
    el('path', { d: 'M0 0L10 5L0 10z', fill: p[1] }, m);
  });
  this.root = el('g', { 'font-family': 'Segoe UI, system-ui, -apple-system, Helvetica Neue, Roboto, Arial, sans-serif' }, svg);
}
Fig.prototype.X = function (x) { return r4(x - this.x0); };
Fig.prototype.Y = function (y) { return r4(this.y1 - y); };
Fig.prototype.pt = function (v) { return r4(v / 72); };
Fig.prototype.g = function (p) { return el('g', null, p || this.root); };
Fig.prototype.rect = function (x, y, w, h, o) {
  o = o || {};
  return el('rect', { x: this.X(x), y: this.Y(y + h), width: r4(Math.max(0, w)), height: r4(Math.max(0, h)), rx: o.rx ? r4(o.rx) : null, fill: o.fill || C.white,
    stroke: o.stroke || C.brand, 'stroke-width': this.pt(o.lw || 1.1), 'stroke-dasharray': o.dash ? o.dash.map(this.pt, this).join(' ') : null, opacity: o.opacity }, o.parent || this.root);
};
Fig.prototype.slab = function (x, y, w, h, o) {
  o = o || {};
  var g = this.g(o.parent);
  g.box = this.rect(x, y, w, h, { fill: o.fill || C.white, stroke: o.stroke || C.brand, lw: 1.1, parent: g });
  el('path', { d: 'M' + this.X(x) + ' ' + this.Y(y + h) + 'H' + this.X(x + w) + 'V' + this.Y(y), fill: 'none', stroke: o.stroke || C.brand,
    'stroke-width': this.pt(o.thick || 3.4), 'stroke-linecap': 'square' }, g);
  if (o.text) this.text(x + w / 2, y + h / 2, o.text, { fs: o.fs || 10, bold: o.bold, parent: g, color: o.color });
  return g;
};
Fig.prototype.line = function (x1, y1, x2, y2, o) {
  o = o || {};
  return el('line', { x1: this.X(x1), y1: this.Y(y1), x2: this.X(x2), y2: this.Y(y2), stroke: o.color || C.ink, 'stroke-width': this.pt(o.lw || 1.3),
    'stroke-dasharray': o.dash ? o.dash.map(this.pt, this).join(' ') : null, 'stroke-linecap': o.cap || null, opacity: o.opacity }, o.parent || this.root);
};
Fig.prototype.poly = function (pts, o) {
  o = o || {}; var self = this;
  return el('polyline', { points: pts.map(function (p) { return self.X(p[0]) + ',' + self.Y(p[1]); }).join(' '), fill: o.fill || 'none', stroke: o.color || C.ink,
    'stroke-width': this.pt(o.lw || 1.5), 'stroke-dasharray': o.dash ? o.dash.map(this.pt, this).join(' ') : null, 'stroke-linejoin': 'round' }, o.parent || this.root);
};
Fig.prototype.arrow = function (x1, y1, x2, y2, o) { o = o || {}; var l = this.line(x1, y1, x2, y2, o); l.setAttribute('marker-end', 'url(#' + this.id + (o.mk || 'a') + ')'); return l; };
Fig.prototype.circle = function (x, y, r, o) { o = o || {}; return el('circle', { cx: this.X(x), cy: this.Y(y), r: r4(r), fill: o.fill || C.brand, stroke: o.stroke || 'none', 'stroke-width': this.pt(o.lw || 1) }, o.parent || this.root); };
Fig.prototype.text = function (x, y, s, o) {
  o = o || {};
  var size = (o.fs || 9.5) * this.k / 72, lh = size * 1.3, lines = String(s).split('\n'), n = lines.length;
  var t = el('text', { 'font-size': r4(size), fill: o.color || C.ink, 'fill-opacity': o.opacity, 'text-anchor': o.ha === 'left' ? 'start' : o.ha === 'right' ? 'end' : 'middle',
    'font-style': o.italic ? 'italic' : null, 'font-weight': o.bold ? 'bold' : null, 'font-family': o.mono ? 'Consolas, SF Mono, Menlo, DejaVu Sans Mono, monospace' : null }, o.parent || this.root);
  var yc = this.Y(y), self = this;
  lines.forEach(function (ln, i) { var ts = el('tspan', { x: self.X(x), y: r4(yc + (i - (n - 1) / 2) * lh + size * 0.35) }, t); ts.textContent = ln; });
  return t;
};
Fig.prototype.tw = function (s, fs, mono) { return String(s).length * (fs * this.k / 72) * (mono ? 0.6 : 0.55); };
Fig.prototype.label = function (x, y, s, o) {
  o = o || {}; var w = this.tw(s, o.fs || 8.5, o.mono) + 0.12, hh = (o.fs || 8.5) * this.k / 72 * 1.5;
  var x0 = o.ha === 'left' ? x - 0.06 : o.ha === 'right' ? x - w + 0.06 : x - w / 2;
  this.rect(x0, y - hh / 2, w, hh, { fill: o.bg || '#fff', stroke: o.border || o.bg || '#fff', lw: o.border ? 0.8 : 0.1, rx: 0.05, parent: o.parent });
  return this.text(x, y, s, o);
};

/* ===================================================== the ladder (timeline) diagram */
var KIND_COLOR = { syn: C.violet, fin: C.violet, data: C.brand, ack: C.muted, wupd: C.ok, probe: C.ok, rst: C.bad };
function segColor(sg) { return sg.retx ? C.amberDark : (KIND_COLOR[sg.kind] || C.ink); }
function segMarker(sg) { return sg.retx ? 'o' : sg.kind === 'data' ? 'c' : sg.kind === 'syn' || sg.kind === 'fin' ? 'v' : sg.kind === 'rst' ? 'r' : sg.kind === 'ack' ? 'm' : 't'; }
/* do two rotated label boxes touch? (separating-axis test) */
function rectsHit(P, Q) {
  function corners(R) { var vx = -R.uy, vy = R.ux; return [[R.cx + R.ux * R.hw + vx * R.hh, R.cy + R.uy * R.hw + vy * R.hh], [R.cx - R.ux * R.hw + vx * R.hh, R.cy - R.uy * R.hw + vy * R.hh], [R.cx - R.ux * R.hw - vx * R.hh, R.cy - R.uy * R.hw - vy * R.hh], [R.cx + R.ux * R.hw - vx * R.hh, R.cy + R.uy * R.hw - vy * R.hh]]; }
  var A = corners(P), B = corners(Q), axes = [[P.ux, P.uy], [-P.uy, P.ux], [Q.ux, Q.uy], [-Q.uy, Q.ux]];
  for (var k = 0; k < 4; k++) {
    var ax = axes[k], pa = A.map(function (c) { return c[0] * ax[0] + c[1] * ax[1]; }), pb = B.map(function (c) { return c[0] * ax[0] + c[1] * ax[1]; });
    if (Math.min(Math.max.apply(null, pa), Math.max.apply(null, pb)) <= Math.max(Math.min.apply(null, pa), Math.min.apply(null, pb))) return false;
  }
  return true;
}
function arrowText(sg, cap) {
  var t, lab = labelOf(cap, sg.n) || '';
  if (sg.f.R) t = 'RST';
  else if (sg.kind === 'syn') t = sg.f.A ? 'SYN + ACK' : 'SYN';
  else if (sg.len > 0) t = 'data, ' + sg.len + ' bytes' + (sg.f.F ? ' + FIN' : '');
  else if (sg.f.F) t = 'FIN';
  else if (sg.kind === 'probe') t = 'window probe';
  else if (sg.kind === 'wupd') t = 'window update';
  else t = /Dup ACK/.test(lab) ? 'duplicate ACK' : 'ACK';
  return (sg.retx ? '↻ ' : '') + t;
}
function ladderLines(run, sg, cap, raw, hide) {
  var h = (hide && hide[sg.n]) || {}, lab = labelOf(cap, sg.n);
  var l1 = '#' + sg.n + ' · ' + ms(sg.tSend);
  if (sg.retx) l1 += sg.retx === 'fast' ? ' · fast resend' : sg.retx === 'dup' ? ' · resent (SYN came again)' : sg.retx === 'partial' ? ' · resent (partial ACK)' : ' · resent (timeout)';
  else if (sg.kind === 'probe') l1 += ' · window probe';
  else if (lab.indexOf('ZeroWindow') >= 0) l1 += ' · zero window';
  else if (lab.indexOf('Window Update') >= 0 || sg.kind === 'wupd') l1 += ' · window update';
  else if (lab.indexOf('Dup ACK') >= 0) l1 += ' · duplicate ACK';
  var l2 = '[' + flagText(sg.f) + '] Len=' + (h.len ? '?' : sg.len) + (sg.f.R && !sg.f.A ? '' : ' Win=' + (h.win ? '?' : sg.winBytes));
  var l3 = 'Seq=' + (h.seq ? '?' : segSeq(sg, raw)) + (sg.f.A ? ' Ack=' + (h.ack ? '?' : segAck(sg, raw)) : '');
  var out = [l1, l2, l3];
  if (sg.opts) out.push('MSS=' + sg.opts.mss + (sg.opts.sackPerm ? ' SACK_PERM' : '') + (sg.opts.ws !== null ? ' WS=' + Math.pow(2, sg.opts.ws) : ''));
  else if (sg.sack && sg.sack.length) out.push('SACK ' + sg.sack.slice(0, raw ? 1 : 2).map(function (b) { return (raw ? m32(sg.peerIss + b[0]) : b[0]) + '–' + (raw ? m32(sg.peerIss + b[1]) : b[1]); }).join(', ') + (sg.sack.length > (raw ? 1 : 2) ? ' …' : ''));
  return out;
}
/* Layout of the timeline. Every segment falls the same height D, so all arrows are parallel and a reply
   starts exactly where the segment that caused it arrives. The send positions solve a set of
   "y_j >= y_i + c" constraints (longest path): label spacing on each side, cause before effect, and
   "sent while the other segment was still on its way" above that segment's arrival. */
function ladderLayout(run, tMax) {
  var segs = run.segs.filter(function (s) { return s.tSend <= tMax + 1e-9; }), n = segs.length;
  var CAP = Math.max(3.2 * run.cfg.delay, 60), GAP = 0.62, EPS = 0.14, Y0 = 1.05;
  function nl(sg) { return sg.opts || (sg.sack && sg.sack.length) ? 4 : 3; }
  function solve(D) {
    var cons = [], breaks = [], i, j;
    for (i = 0; i < n; i++) {
      var si = segs[i];
      // label spacing with the previous send on the same side
      for (j = i - 1; j >= 0; j--) if (segs[j].from === si.from) { cons.push([j, i, nl(segs[j]) === 4 ? 0.9 : 0.7]); break; }
      // keep sends in time order, and mark long silences with a break
      if (i > 0) {
        var lastT = segs[i - 1].tSend, lastK = i - 1, lastArr = false;
        for (j = 0; j < i; j++) if (!segs[j].lost && segs[j].tArr <= si.tSend + 1e-9 && segs[j].tArr > lastT) { lastT = segs[j].tArr; lastK = j; lastArr = true; }
        if (si.tSend - lastT > CAP) { cons.push([lastK, i, (lastArr ? D : 0) + GAP]); breaks.push({ k: lastK, arr: lastArr, i: i, t0: lastT, t1: si.tSend }); }
      }
      // cause and effect across the two sides
      for (j = 0; j < n; j++) {
        var a = segs[j]; if (a.lost || a.to !== si.from || j === i) continue;
        if (a.tArr <= si.tSend + 1e-9) cons.push([j, i, D]);
        else if (si.tSend >= a.tSend - 1e-9) cons.push([i, j, EPS - D]);
      }
    }
    var y = []; for (i = 0; i < n; i++) y.push(Y0);
    for (var it = 0; it <= n + 2; it++) {
      var changed = false;
      cons.forEach(function (c) { var v = y[c[0]] + c[2]; if (v > y[c[1]] + 1e-9) { y[c[1]] = v; changed = true; } });
      if (!changed) return { y: y, breaks: breaks };
      if (it === n + 2) return null;
    }
    return null;
  }
  var D = 0.95, sol = null;
  for (var tries = 0; tries < 12 && !sol; tries++) { sol = solve(D); if (!sol) D += 0.3; }
  var ys = {}, ya = {}, events = { A: [], B: [] }, end = Y0 + 0.5;
  segs.forEach(function (sg, i) {
    ys[sg.n] = sol.y[i]; ya[sg.n] = sol.y[i] + D;
    events[sg.from].push([sg.tSend, sol.y[i]]); if (!sg.lost) events[sg.to].push([sg.tArr, sol.y[i] + D]);
    end = Math.max(end, sol.y[i] + D * (sg.lost ? 0.55 : 1) + 0.55);
  });
  var brk = sol.breaks.map(function (b) { var d0 = sol.y[b.k] + (b.arr ? D : 0); return { t0: b.t0, t1: b.t1, d0: d0, d1: sol.y[b.i] }; });
  /* where a side's state change goes: at the send or arrival at that moment, else just after its last event */
  function yAt(side, t) {
    var best = null, last = Y0 - 0.2;
    events[side].forEach(function (e) { if (Math.abs(e[0] - t) < 1e-6) best = best === null ? e[1] : Math.max(best, e[1]); else if (e[0] < t) last = Math.max(last, e[1]); });
    return best !== null ? best : last + 0.3;
  }
  var lateStates = [];
  ['A', 'B'].forEach(function (sd) { run.states[sd].forEach(function (x) { if (x.t > 0 && x.t <= tMax && !events[sd].some(function (e) { return Math.abs(e[0] - x.t) < 1e-6; }) && events[sd].every(function (e) { return e[0] < x.t; }) && x.t - Math.max.apply(null, events[sd].map(function (e) { return e[0]; }).concat([0])) > CAP) lateStates.push(x.t); }); });
  if (lateStates.length) { var tl = Math.min.apply(null, lateStates), lastAll = Math.max.apply(null, segs.map(function (s) { return s.lost ? s.tSend : s.tArr; }).concat([0])); brk.push({ t0: lastAll, t1: tl, d0: end - 0.45, d1: end - 0.45 + GAP }); end += GAP + 0.3; }
  function yState(side, t) {
    if (lateStates.length && t >= Math.min.apply(null, lateStates)) return end - 0.55;
    return yAt(side, t);
  }
  function yNow(T) { var v = Y0 - 0.2; ['A', 'B'].forEach(function (sd) { events[sd].forEach(function (e) { if (e[0] <= T + 1e-9) v = Math.max(v, e[1]); }); }); return v; }
  return { ys: ys, ya: ya, D: D, breaks: brk, end: end, yState: yState, yNow: yNow };
}
/* o: { T: show up to time T, raw, hide: {n: {seq,ack,len,win}}, click: true, tMax, cap } */
function drawLadder(svg, run, o) {
  o = o || {};
  var T = o.T === undefined || o.T === null ? Infinity : o.T, raw = !!o.raw, cap = o.cap || capture(run, { raw: raw });
  var tMax = o.tMax || Infinity;
  var L = ladderLayout(run, tMax);
  var W = 9.2, xA = 3.05, xB = 6.15, H = Math.max(2.4, L.end + 0.2);
  var f = new Fig(svg, 0, W, 0, H, 1.3), Yd = function (d) { return H - d; };
  svg.setAttribute('aria-label', 'Timeline of the connection: Host A on the left, Host B on the right, time runs down. ' + run.segs.length + ' segments.');
  // hosts and their timelines
  f.slab(xA - 0.75, H - 0.62, 1.5, 0.46, { text: 'Host A (client)', fs: 8.5, bold: true });
  f.slab(xB - 0.75, H - 0.62, 1.5, 0.46, { text: 'Host B (server)', fs: 8.5, bold: true });
  var dEnd = L.end;
  f.line(xA, Yd(0.85), xA, Yd(dEnd), { color: C.navy, lw: 2 });
  f.line(xB, Yd(0.85), xB, Yd(dEnd), { color: C.navy, lw: 2 });
  f.text(W / 2, Yd(0.8), 'time runs down ↓', { fs: 7, color: C.muted, italic: true });
  L.breaks.forEach(function (b) {
    var ym = Yd((b.d0 + b.d1) / 2);
    [xA, xB].forEach(function (x) { f.rect(x - 0.08, ym - 0.1, 0.16, 0.2, { fill: '#fff', stroke: '#fff', lw: 0.1 }); f.line(x - 0.1, ym - 0.03, x + 0.1, ym + 0.05, { color: C.navy, lw: 1.2 }); f.line(x - 0.1, ym - 0.11, x + 0.1, ym - 0.03, { color: C.navy, lw: 1.2 }); });
    var gap = b.t1 - b.t0;
    f.text(W / 2, ym, '… ' + (gap >= 1000 ? (Math.round(gap / 100) / 10) + ' s' : Math.round(gap) + ' ms') + ' later …', { fs: 7.5, color: C.muted, italic: true });
  });
  // timers: a dashed bracket from the first send of a sequence number to its resend by timeout
  run.segs.forEach(function (sg) {
    if (sg.retx !== 'rto' || sg.tSend > T + 1e-9 || sg.tSend > tMax) return;
    var first = null; run.segs.forEach(function (p) { if (!first && p.from === sg.from && p.seq === sg.seq && (p.len === sg.len || p.f.S) && p.n < sg.n) first = p; });
    if (!first) return;
    var prev = null; run.segs.forEach(function (p) { if (p.from === sg.from && p.seq === sg.seq && p.n < sg.n) prev = p; });
    var x = sg.from === 'A' ? xA + 0.12 : xB - 0.12, y0 = Yd(L.ys[prev.n]), y1 = Yd(L.ys[sg.n]);
    f.line(x, y0 - 0.04, x, y1 + 0.04, { color: C.amberDark, lw: 1.2, dash: [2, 2] });
    f.line(x - 0.05, y1 + 0.04, x + 0.05, y1 + 0.04, { color: C.amberDark, lw: 1.2 });
  });
  // segments
  /* things an arrow label must not cover, the same at every moment: state tags, break notes, "lost" marks */
  var placedLabels = [];
  function box(cx, cy, hw, hh) { placedLabels.push({ cx: f.X(cx), cy: f.Y(cy), ux: 1, uy: 0, hw: hw, hh: hh }); }
  ['A', 'B'].forEach(function (sd) {
    var x = sd === 'A' ? xA + 0.07 : xB - 0.07, lastD = -9;
    run.states[sd].forEach(function (st, i) {
      if (i === 0 || st.t > tMax) return;
      var d = L.yState(sd, st.t); if (d - lastD < 0.2) d = lastD + 0.2; lastD = d;
      var w = f.tw(st.s, 6.8) + 0.12, x0 = sd === 'A' ? x - 0.06 : x - w + 0.06;
      box(x0 + w / 2, Yd(d) - 0.1, w / 2 + 0.02, 0.1);
    });
  });
  L.breaks.forEach(function (b) { var gap = b.t1 - b.t0, t = '… ' + (gap >= 1000 ? (Math.round(gap / 100) / 10) + ' s' : Math.round(gap) + ' ms') + ' later …'; box(W / 2, Yd((b.d0 + b.d1) / 2), f.tw(t, 7.5) / 2 + 0.03, 0.08); });
  run.segs.forEach(function (sg) {
    if (!sg.lost || sg.tSend > tMax) return;
    var x0 = sg.from === 'A' ? xA : xB, x1 = sg.from === 'A' ? xB : xA, y0 = Yd(L.ys[sg.n]), y1 = Yd(L.ya[sg.n]), xe = x0 + (x1 - x0) * 0.55, ye = y0 + (y1 - y0) * 0.55, w = f.tw('lost', 7.5);
    box(sg.from === 'A' ? xe - 0.12 - w / 2 : xe + 0.12 + w / 2, ye - 0.2, w / 2 + 0.02, 0.08);
    box(xe, ye, 0.1, 0.1);   // the cross itself
  });
  run.segs.forEach(function (sg) {
    if (sg.tSend > T + 1e-9 || sg.tSend > tMax) return;
    var g = f.g(); if (o.click) { g.setAttribute('data-n', sg.n); g.setAttribute('role', 'button'); g.setAttribute('tabindex', '0'); g.setAttribute('aria-label', 'Segment ' + sg.n + (sg.lost ? ', lost. Click to deliver it.' : '. Click to lose it.')); }
    var x0 = sg.from === 'A' ? xA : xB, x1 = sg.from === 'A' ? xB : xA, y0 = Yd(L.ys[sg.n]), y1 = Yd(L.ya[sg.n]);
    var col = segColor(sg), mk = segMarker(sg);
    var frac = 1;
    if (sg.lost) frac = 0.55;
    var tNowFrac = T >= sg.tArr ? 1 : (T - sg.tSend) / (sg.tArr - sg.tSend);
    var fr = Math.min(frac, Math.max(0, tNowFrac));
    var xe = x0 + (x1 - x0) * fr, ye = y0 + (y1 - y0) * fr;
    if (o.click) f.line(x0, y0, x0 + (x1 - x0) * frac, y0 + (y1 - y0) * frac, { color: '#fff', lw: 9, parent: g, opacity: 0.01 });
    if (fr >= frac - 1e-9 && !sg.lost) f.arrow(x0, y0, xe, ye, { color: col, lw: o.hl === sg.n ? 2.8 : 1.6, mk: mk, parent: g });
    else {
      f.line(x0, y0, xe, ye, { color: sg.lost ? C.bad : col, lw: 1.6, dash: sg.lost ? [4, 2.5] : null, parent: g });
      if (sg.lost && fr >= frac - 1e-9) { f.line(xe - 0.08, ye - 0.08, xe + 0.08, ye + 0.08, { color: C.bad, lw: 2.2, parent: g }); f.line(xe - 0.08, ye + 0.08, xe + 0.08, ye - 0.08, { color: C.bad, lw: 2.2, parent: g }); }
      else if (fr < 1) f.circle(xe, ye, 0.06, { fill: col, parent: g });
    }
    if (o.arrowLabels !== false) {   // what the segment carries, written along its arrow near the sender, where it touches no other label
      var atxt = arrowText(sg, cap), sdx = f.X(x1) - f.X(x0), sdy = f.Y(y1) - f.Y(y0), sl = Math.sqrt(sdx * sdx + sdy * sdy) || 1;
      var ang = Math.atan2(sdy, sdx) * 180 / Math.PI; if (ang > 90) ang -= 180; if (ang < -90) ang += 180;
      var nx = -sdy / sl, ny = sdx / sl; if (ny > 0) { nx = -nx; ny = -ny; }
      var ux = Math.cos(ang * Math.PI / 180), uy = Math.sin(ang * Math.PI / 180), hw = f.tw(atxt, 7) / 2 * 1.05 + 0.02, hh = 0.07;
      var fracs = sg.lost ? [0.27, 0.2, 0.34, 0.42, 0.13] : [0.36, 0.27, 0.46, 0.2, 0.55, 0.64, 0.72, 0.13, 0.8, 0.31, 0.41, 0.5, 0.6, 0.68, 0.24];
      var offs = [0.075, -0.075, 0.17, -0.17], best = null, bestHits = 1e9;
      for (var oi = 0; oi < offs.length && bestHits; oi++) for (var ti = 0; ti < fracs.length && bestHits; ti++) {   // nearest free spot; else the least crowded
        var lfr = fracs[ti]; if (lfr > frac) continue;
        var cx = f.X(x0 + (x1 - x0) * lfr) + offs[oi] * nx, cy = f.Y(y0 + (y1 - y0) * lfr) + offs[oi] * ny;
        var R = { cx: cx, cy: cy, ux: ux, uy: uy, hw: hw, hh: hh, fr: lfr };
        var hits = placedLabels.filter(function (P) { return rectsHit(P, R); }).length;
        if (hits < bestHits) { best = R; bestHits = hits; }
      }
      if (bestHits) best = null;   // nowhere free: leave this label out (the text beside the host still names the segment)
      else placedLabels.push(best);
      if (best && fr >= best.fr) {
        var at = f.text(0, 0, atxt, { fs: 7, bold: true, color: sg.lost ? C.bad : col === C.muted ? '#3E4C57' : col, parent: g });
        at.firstChild.setAttribute('x', r4(best.cx)); at.firstChild.setAttribute('y', r4(best.cy + 7 * 1.3 / 72 * 0.35));
        at.setAttribute('transform', 'rotate(' + r4(ang) + ' ' + r4(best.cx) + ' ' + r4(best.cy) + ')');
        at.setAttribute('stroke', '#fff'); at.setAttribute('stroke-width', f.pt(2.6)); at.setAttribute('paint-order', 'stroke'); at.setAttribute('class', 'arrowlab');
      }
    }
    if (sg.lost && fr >= frac - 1e-9) f.text(xe + (sg.from === 'A' ? -0.12 : 0.12), ye - 0.2, 'lost', { fs: 7.5, color: C.bad, bold: true, ha: sg.from === 'A' ? 'right' : 'left', parent: g });
    var lines = ladderLines(run, sg, cap, raw, o.hide), lx = sg.from === 'A' ? xA - 0.12 : xB + 0.12, ha = sg.from === 'A' ? 'right' : 'left';
    var fs = 7.6, lh = fs * 1.3 * 1.3 / 72;
    f.text(lx, y0 + lh, lines[0], { fs: 7, color: sg.retx ? C.amberDark : C.muted, ha: ha, parent: g, bold: !!sg.retx });
    f.text(lx, y0, lines[1], { fs: fs, color: col === C.muted ? C.ink : col, bold: true, ha: ha, parent: g, mono: true });
    f.text(lx, y0 - lh, lines[2], { fs: fs, color: C.ink, ha: ha, parent: g, mono: true });
    if (lines[3]) f.text(lx, y0 - 2 * lh, lines[3], { fs: 7, color: C.muted, ha: ha, parent: g, mono: true });
  });
  // state pills
  ['A', 'B'].forEach(function (sd) {
    var x = sd === 'A' ? xA + 0.07 : xB - 0.07, lastD = -9;
    run.states[sd].forEach(function (s, i) {
      if (i === 0 || s.t > T + 1e-9 || s.t > tMax) return;
      var d = L.yState(sd, s.t); if (d - lastD < 0.2) d = lastD + 0.2; lastD = d;
      f.label(x, Yd(d) - 0.1, s.s, { fs: 6.8, ha: sd === 'A' ? 'left' : 'right', bold: true, color: sd === 'A' ? '#00658A' : '#4B32C9', bg: sd === 'A' ? '#E3F4FA' : '#EEE9FF', border: sd === 'A' ? C.brand : C.violet });
    });
  });
  if (T < Infinity && T >= 0) { var yT = Yd(L.yNow(T)); f.line(0.1, yT, W - 0.1, yT, { color: C.amber, lw: 0.9, dash: [3, 3] }).setAttribute('class', 'nowline'); f.label(0.15, yT, ms(T), { fs: 6.8, ha: 'left', color: '#7a4c00', bg: C.amberSoft }); }
  return f;
}
var LADDER_LEGEND = '<ul class="legend"><li><i style="background:#00A2D7"></i>data</li><li><i style="background:#5B6B78"></i>ACK only</li><li><i style="background:#7B61FF"></i>SYN or FIN</li><li><i style="background:#E08B00"></i>resent</li><li><i style="background:#13A88A"></i>window probe or update</li><li><i style="background:#E5484D"></i>RST, or lost (✕)</li></ul>';

/* ===================================================== the TCP state diagram */
/* ===================================================== the TCP state-transition diagram
   Boxes are the states of ONE end of a connection; each arc is labeled event/action. */
/* Layout follows the classic diagram, drawn on a 1310 × 1215 grid (y down) and mapped to inches. */
function smX(px) { return r4(0.3 + px * 0.0058); }
function smY(py) { return r4(7.42 - py * 0.0058); }
var SM_PX = { CLOSED: [620, 41], LISTEN: [620, 288], SYN_RCVD: [123, 488], SYN_SENT: [1106, 488], ESTABLISHED: [620, 688],
  FIN_WAIT_1: [123, 853], CLOSE_WAIT: [1121, 853], FIN_WAIT_2: [123, 1024], CLOSING: [620, 1024], LAST_ACK: [1121, 1024], TIME_WAIT: [620, 1175], END: [1121, 1175] };
var SM_BOX = {};
Object.keys(SM_PX).forEach(function (k) { SM_BOX[k] = [smX(SM_PX[k][0]), smY(SM_PX[k][1])]; });
var SM_W = 1.41, SM_H = 0.43, SM_DY = 0;
/* [from, to, label, path on the grid, label x, label y (grid), label alignment, label angle]
   A path is a start point followed by straight steps [x, y] and curves [c1x, c1y, c2x, c2y, x, y]. */
var SM_ARCS = [
  ['CLOSED', 'LISTEN', 'Passive open', [[580, 78], [580, 250]], 566, 158, 'right'],
  ['LISTEN', 'CLOSED', 'Close', [[657, 250], [657, 78]], 668, 158, 'left'],
  ['CLOSED', 'SYN_SENT', 'Active open/SYN', [[744, 20], [1040, 20, 1176, 150, 1176, 330], [1176, 449]], 1056, 106, 'left'],
  ['SYN_SENT', 'CLOSED', 'Close', [[1052, 449], [1052, 330], [1052, 150, 950, 66, 746, 66]], 930, 197, 'mid'],
  ['LISTEN', 'SYN_RCVD', 'SYN/SYN + ACK', [[580, 326], [580, 440, 520, 470, 380, 470], [247, 470]], 365, 420, 'mid'],
  ['LISTEN', 'SYN_SENT', 'Send/SYN', [[652, 326], [652, 440, 720, 470, 860, 470], [983, 470]], 808, 423, 'mid'],
  ['SYN_SENT', 'SYN_RCVD', 'SYN/SYN + ACK', [[983, 488], [247, 488]], 618, 467, 'mid'],
  ['SYN_RCVD', 'ESTABLISHED', 'ACK', [[245, 507], [460, 507], [560, 507, 580, 560, 580, 649]], 442, 550, 'mid'],
  ['SYN_SENT', 'ESTABLISHED', 'SYN + ACK/ACK', [[985, 507], [780, 507], [680, 507, 655, 560, 655, 649]], 845, 547, 'mid'],
  ['SYN_RCVD', 'FIN_WAIT_1', 'Close/FIN', [[123, 526], [123, 814]], 134, 660, 'left'],
  ['ESTABLISHED', 'FIN_WAIT_1', 'Close/FIN', [[580, 726], [580, 820, 480, 837, 330, 837], [247, 837]], 402, 803, 'mid'],
  ['ESTABLISHED', 'CLOSE_WAIT', 'FIN/ACK', [[655, 726], [655, 820, 760, 853, 900, 853], [997, 853]], 790, 803, 'mid'],
  ['FIN_WAIT_1', 'FIN_WAIT_2', 'ACK', [[123, 891], [123, 985]], 134, 927, 'left'],
  ['FIN_WAIT_1', 'CLOSING', 'FIN/ACK', [[245, 873], [500, 873], [600, 873, 618, 910, 618, 985]], 415, 902, 'mid'],
  ['FIN_WAIT_1', 'TIME_WAIT', 'ACK + FIN/ACK', [[230, 891], [494, 1150]], 372, 990, 'mid', -44.5],
  ['FIN_WAIT_2', 'TIME_WAIT', 'FIN/ACK', [[123, 1062], [123, 1120, 160, 1172, 300, 1172], [496, 1172]], 295, 1147, 'mid'],
  ['CLOSING', 'TIME_WAIT', 'ACK', [[618, 1062], [618, 1136]], 630, 1087, 'left'],
  ['CLOSE_WAIT', 'LAST_ACK', 'Close/FIN', [[1121, 891], [1121, 985]], 1132, 928, 'left'],
  ['LAST_ACK', 'END', 'ACK', [[1121, 1062], [1121, 1136]], 1132, 1087, 'left'],
  ['TIME_WAIT', 'END', 'Timeout after two\nsegment lifetimes', [[745, 1172], [997, 1172]], 862, 1084, 'mid']
];
/* the drawn path (SVG "d" pieces in grid units) and sample points in inches, for traces and markers */
SM_ARCS.forEach(function (e) {
  var spec = e[3], pts = [[smX(spec[0][0]), smY(spec[0][1])]], cur = spec[0];
  for (var i = 1; i < spec.length; i++) {
    var q = spec[i];
    if (q.length === 2) { pts.push([smX(q[0]), smY(q[1])]); cur = q; continue; }
    for (var k = 1; k <= 16; k++) {
      var u = k / 16, v = 1 - u, b0 = v * v * v, b1 = 3 * v * v * u, b2 = 3 * v * u * u, b3 = u * u * u;
      pts.push([smX(b0 * cur[0] + b1 * q[0] + b2 * q[2] + b3 * q[4]), smY(b0 * cur[1] + b1 * q[1] + b2 * q[3] + b3 * q[5])]);
    }
    cur = [q[4], q[5]];
  }
  e.spec = spec; e.pts = pts; e.lx = smX(e[4]); e.ly = smY(e[5]);
});
var SM_ITALIC = { 'Passive open': 1, Close: 1, 'Active open': 1, Send: 1 };
function smArc(from, to) {
  if (to === 'CLOSED' && (from === 'LAST_ACK' || from === 'TIME_WAIT')) to = 'END';
  for (var i = 0; i < SM_ARCS.length; i++) if (SM_ARCS[i][0] === from && SM_ARCS[i][1] === to) return SM_ARCS[i];
  return null;
}
function smBoxOf(run, side, T) {   // which box a side is in: the bottom CLOSED once it closed normally
  var st = run.states[side].filter(function (x) { return x.t <= T + 1e-9; });
  if (!st.length) return 'CLOSED';
  var cur = st[st.length - 1].s;
  if (cur !== 'CLOSED' || st.length < 2) return cur;
  var prev = st[st.length - 2].s; return prev === 'LAST_ACK' || prev === 'TIME_WAIT' ? 'END' : 'CLOSED';
}
/* the transitions each side makes in (t0, t1]: [{side, from, to, t, arc}] */
function smSteps(run, t0, t1) {
  var out = [];
  ['A', 'B'].forEach(function (sd) {
    var st = run.states[sd];
    for (var i = 1; i < st.length; i++) if (st[i].t > t0 + 1e-9 && st[i].t <= t1 + 1e-9) out.push({ side: sd, from: st[i - 1].s, to: st[i].s, t: st[i].t, arc: smArc(st[i - 1].s, st[i].s) });
  });
  return out.sort(function (a, b) { return a.t - b.t; });
}
var smAnim = 0;
/* o: { prevT: the moment shown before, so the step from prevT to T can be animated } */
function drawStateMachine(svg, run, T, o) {
  o = o || {}; T = T === undefined || T === null ? Infinity : T;
  var f = new Fig(svg, 0, 8.2, 0, 7.95, 1.4), Yo = SM_DY;
  var cur = { A: smBoxOf(run, 'A', T), B: smBoxOf(run, 'B', T) };
  svg.setAttribute('aria-label', 'TCP state-transition diagram. Host A is in ' + stateAt(run, 'A', T) + ' and Host B is in ' + stateAt(run, 'B', T) + '.');
  var used = { A: {}, B: {} };
  ['A', 'B'].forEach(function (sd) { smSteps(run, -1, T).forEach(function (x) { if (x.side === sd && x.arc) used[sd][x.arc[0] + '>' + x.arc[1]] = true; }); });
  var prevT = o.prevT === undefined || o.prevT === null ? Infinity : o.prevT;
  var now = prevT < T ? smSteps(run, prevT, T) : [], hot = {};
  now.forEach(function (x) { if (x.arc) hot[x.arc[0] + '>' + x.arc[1]] = true; });
  function P(p, dx, dy) { return [p[0] + (dx || 0), p[1] + Yo + (dy || 0)]; }
  // arcs
  function dOf(e) {
    var sp = e.spec, d = 'M' + f.X(smX(sp[0][0])) + ' ' + f.Y(smY(sp[0][1]));
    for (var i = 1; i < sp.length; i++) {
      var q = sp[i];
      d += q.length === 2 ? 'L' + f.X(smX(q[0])) + ' ' + f.Y(smY(q[1]))
        : 'C' + f.X(smX(q[0])) + ' ' + f.Y(smY(q[1])) + ' ' + f.X(smX(q[2])) + ' ' + f.Y(smY(q[3])) + ' ' + f.X(smX(q[4])) + ' ' + f.Y(smY(q[5]));
    }
    return d;
  }
  function smLabel(e, o) {   // event in italics when it is a call by the program or a timer; the action after "/" upright
    var g = el('g', null, f.root), lab = e[2], fs = 7.6, size = fs * f.k / 72;
    var parts = lab.indexOf('\n') >= 0 ? [[lab, true]] : lab.indexOf('/') >= 0 ? [[lab.split('/')[0], !!SM_ITALIC[lab.split('/')[0]]], ['/' + lab.split('/')[1], false]] : [[lab, !!SM_ITALIC[lab]]];
    var lines = lab.split('\n'), w = 0;
    lines.forEach(function (ln) { w = Math.max(w, f.tw(ln, fs)); });
    var ha = e[6] === 'mid' ? null : e[6], x = e.lx, y = e.ly, hh = size * 1.3 * lines.length + size * 0.25;
    var x0 = ha === 'left' ? x - 0.04 : ha === 'right' ? x - w - 0.04 : x - w / 2 - 0.04;
    f.rect(x0, y - hh / 2, w + 0.08, hh, { fill: o.bg, stroke: o.bg, lw: 0.1, rx: 0.05, parent: g });
    if (lines.length > 1) f.text(x, y, lab, { fs: fs, ha: ha, italic: true, bold: o.bold, color: o.color, parent: g });
    else {
      var t = f.text(x, y, '', { fs: fs, ha: ha, bold: o.bold, color: o.color, parent: g }), ts = t.firstChild;
      parts.forEach(function (p) { var sp = el('tspan', { 'font-style': p[1] ? 'italic' : null }, ts); sp.textContent = p[0]; });
    }
    if (e[7]) g.setAttribute('transform', 'rotate(' + e[7] + ' ' + f.X(x) + ' ' + f.Y(y) + ')');
  }
  SM_ARCS.forEach(function (e) {
    var key = e[0] + '>' + e[1], ua = used.A[key], ub = used.B[key], pts = e.pts;
    var col = hot[key] ? C.amberDark : ua || ub ? C.ink : '#8FA6B4';
    el('path', { d: dOf(e), fill: 'none', stroke: col, 'stroke-width': f.pt(hot[key] ? 2.4 : 1.1), 'marker-end': 'url(#' + f.id + (hot[key] ? 'o' : ua || ub ? 'a' : 'm') + ')' }, f.root);
    function trace(c, off) {
      var tp = pts.map(function (p, i) {   // shift the path sideways by off
        var a = pts[Math.max(0, i - 1)], b = pts[Math.min(pts.length - 1, i + 1)], dx = b[0] - a[0], dy = b[1] - a[1], L = Math.sqrt(dx * dx + dy * dy) || 1;
        return [p[0] - dy / L * off, p[1] + dx / L * off];
      });
      f.poly(tp, { color: c, lw: 3, dash: null }).setAttribute('opacity', '0.75');
    }
    if (ua) trace(C.brand, 0.055); if (ub) trace(C.violet, -0.055);
  });
  if (o.clickable) SM_ARCS.forEach(function (e) {   // wide invisible targets: click an arrow to take it
    var key = e[0] + '>' + e[1], lab = e[2].replace('\n', ' ');
    var g = el('path', { d: dOf(e), fill: 'none', stroke: 'transparent', 'stroke-width': f.pt(14), 'data-arc': key, tabindex: '0', role: 'button', class: 'arcbtn',
      'aria-label': 'Arrow ' + (e[0] === 'END' ? 'CLOSED' : e[0]) + ' to ' + (e[1] === 'END' ? 'CLOSED' : e[1]) + ', ' + lab + ': show a connection that takes it' }, f.root);
    var t = el('title', null, g); t.textContent = lab + ': click to take this arrow';
  });
  SM_ARCS.forEach(function (e) {   // labels on top of every line
    var key = e[0] + '>' + e[1], ua = used.A[key], ub = used.B[key];
    smLabel(e, { bold: !!hot[key], color: hot[key] ? '#8a4b00' : ua || ub ? C.ink : C.muted, bg: hot[key] ? C.amberSoft : '#fff' });
  });
  // boxes
  Object.keys(SM_BOX).forEach(function (n) {
    var b = SM_BOX[n], isA = cur.A === n, isB = cur.B === n;
    var fill = isA && isB ? '#DCD6FF' : isA ? '#BFE8F7' : isB ? C.violetSoft : '#fff';
    f.slab(b[0] - SM_W / 2, b[1] + Yo - SM_H / 2, SM_W, SM_H, { text: n === 'END' ? 'CLOSED' : n, fs: 8.4, bold: isA || isB, fill: fill, stroke: isB && !isA ? C.violet : C.brand });
  });
  f.text(0.1, 7.78, 'event/action', { fs: 7, ha: 'left', italic: true, color: C.muted });
  f.text(0.1, 0.18, 'RST in any state → CLOSED (not drawn)', { fs: 7, ha: 'left', italic: true, color: C.muted });
  // the markers for Host A and Host B, moving along the arcs of this step
  var tokens = {};
  ['A', 'B'].forEach(function (sd) {
    var b = SM_BOX[cur[sd]], home = [b[0] + (sd === 'A' ? -SM_W / 2 - 0.02 : SM_W / 2 + 0.02), b[1] + Yo + SM_H / 2];
    var g = el('g', null, f.root);
    var c = el('circle', { r: 0.15, fill: sd === 'A' ? C.brand : C.violet, stroke: '#fff', 'stroke-width': f.pt(1.5) }, g);
    var t = el('text', { 'font-size': r4(8 * f.k / 72), 'text-anchor': 'middle', fill: '#fff', 'font-weight': 'bold' }, g); t.textContent = sd;
    tokens[sd] = { g: g, c: c, t: t, home: home };
    place(sd, home);
  });
  function place(sd, p) { var k = tokens[sd]; k.c.setAttribute('cx', f.X(p[0])); k.c.setAttribute('cy', f.Y(p[1])); k.t.setAttribute('x', f.X(p[0])); k.t.setAttribute('y', r4(f.Y(p[1]) + 0.035)); }
  var moves = {};
  now.forEach(function (x) {   // a path from the old box through the arc to the new box
    if (!moves[x.side]) moves[x.side] = [];
    var b0 = SM_BOX[x.from === 'CLOSED' ? 'CLOSED' : x.from], b1 = SM_BOX[x.arc ? x.arc[1] : x.to];
    var pts = [[b0[0], b0[1] + Yo]].concat(x.arc ? x.arc.pts : []).concat([[b1[0], b1[1] + Yo]]);
    moves[x.side] = moves[x.side].concat(pts);
  });
  var my = ++smAnim, sides = Object.keys(moves);
  if (!sides.length || reduceMotion) return f;
  sides.forEach(function (sd) { moves[sd].push(tokens[sd].home); });
  function along(pts, u) {   // point at fraction u of the path length
    var L = [0]; for (var i = 1; i < pts.length; i++) L.push(L[i - 1] + Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]));
    var d = u * L[L.length - 1];
    for (var j = 1; j < pts.length; j++) if (d <= L[j]) { var w = (d - L[j - 1]) / ((L[j] - L[j - 1]) || 1); return [pts[j - 1][0] + w * (pts[j][0] - pts[j - 1][0]), pts[j - 1][1] + w * (pts[j][1] - pts[j - 1][1])]; }
    return pts[pts.length - 1];
  }
  var t0 = null, dur = 900 / animSpeed;
  function frame(ts) {
    if (my !== smAnim) return;
    if (t0 === null) t0 = ts;
    var u = Math.min(1, (ts - t0) / dur), e = u < 0.5 ? 2 * u * u : 1 - Math.pow(-2 * u + 2, 2) / 2;
    sides.forEach(function (sd) { place(sd, along(moves[sd], e)); });
    if (u < 1) window.requestAnimationFrame(frame);
  }
  sides.forEach(function (sd) { place(sd, moves[sd][0]); });
  window.requestAnimationFrame(frame);
  return f;
}
/* short meanings for the terms a student meets; a lesson lists the ones it uses */
var GLOSS = [
  ['TCP', /\bTCP\b/, 'Transmission Control Protocol: delivers a stream of bytes reliably and in order.'],
  ['IP', /\bIP\b/, 'Internet Protocol: carries each packet from host to host, with no promise it arrives.'],
  ['SYN', /\bSYN/, 'synchronize: the flag of the segments that open a connection.'],
  ['ACK', /\bACK/, 'acknowledgment: the flag that says the Ack field is valid.'],
  ['FIN', /\bFIN/, 'finish: "no more data from me".'],
  ['RST', /\bRST\b/, 'reset: ends a connection at once, for example when nothing listens on the port.'],
  ['PSH', /\bPSH\b/, 'push: asks the receiver to hand the data to its program now.'],
  ['Seq', /\bSeq\b/, 'sequence number: the number of the first data byte in a segment.'],
  ['Ack', /\bAck\b/, 'acknowledgment number: the next byte the sender of this segment expects.'],
  ['Len', /\bLen\b/, 'data length: the number of data bytes in a segment.'],
  ['ISN', /\bISN/, 'initial sequence number: the random number each side starts counting from.'],
  ['MSS', /\bMSS\b/, 'Maximum Segment Size: the most data one segment may carry.'],
  ['SACK', /\bSACK/, 'Selective Acknowledgment: lists blocks that arrived after a gap, so only the holes are resent.'],
  ['RTT', /\bRTT\b/, 'round-trip time: from sending a segment to getting its ACK.'],
  ['SRTT', /\bSRTT\b/, 'smoothed RTT: a running average of the round-trip times.'],
  ['RTTVAR', /\bRTTVAR\b/, 'RTT variation: how much the round-trip times jump around.'],
  ['RTO', /\bRTO\b/, 'retransmission timeout: how long the sender waits for an ACK before it resends.'],
  ['MSL', /\bMSL\b/, 'Maximum Segment Lifetime: how long a segment may live in the network.'],
  ['RFC', /\bRFC\b/, 'Request for Comments: the numbered documents that define Internet standards.'],
  ['MTU', /\bMTU\b/, 'Maximum Transmission Unit: the biggest packet a link carries.'],
  ['SND.UNA', /SND\.UNA/, 'the oldest unacknowledged byte: sent, but not yet acknowledged.'],
  ['SND.NXT', /SND\.NXT/, 'the next byte to send.'],
  ['RCV.NXT', /RCV\.NXT/, 'the next byte the receiver expects.'],
  ['Window', /\bwindow\b/i, 'the free buffer space a receiver advertises: how many more bytes it can take.']
];
function termsList(text) {
  var used = GLOSS.filter(function (g) { return g[1].test(text); });
  return used.length ? '<ul class="list terms">' + used.map(function (g) { return '<li><b>' + g[0] + '</b>: ' + g[2] + '</li>'; }).join('') + '</ul>' : '';
}
var SM_LEGEND = '<ul class="legend"><li><i style="background:#00A2D7"></i>path taken by Host A (marker A)</li><li><i style="background:#7B61FF"></i>path taken by Host B (marker B)</li><li><i style="background:#E08B00"></i>arc taken in this step</li></ul>';
var EV_TEXT = { 'Passive open': 'its program listens (passive open)', 'Active open': 'its program connects (active open)', Close: 'its program calls close', Send: 'its program sends data',
  SYN: 'a SYN arrives', ACK: 'an ACK arrives', 'SYN + ACK': 'a SYN + ACK arrives', FIN: 'a FIN arrives', 'ACK + FIN': 'a FIN arrives that also ACKs its own FIN', 'Timeout after two segment lifetimes': 'the TIME_WAIT timer (2 × MSL) runs out' };
var ACT_TEXT = { SYN: 'it sends a SYN', 'SYN + ACK': 'it sends SYN + ACK', ACK: 'it sends an ACK', FIN: 'it sends a FIN' };
/* plain-language list of the transitions in this step */
function smStepText(run, prevT, T) {
  if (T !== null && T !== undefined && T < 0) {
    var DO = { SYN_SENT: 'connects', LISTEN: 'listens on a port' };
    function first(sd) { var x = run.states[sd].filter(function (y) { return y.s !== 'CLOSED'; })[0]; return x ? DO[x.s] || 'starts' : 'does nothing'; }
    return '<p><b>Before the connection:</b> both hosts are CLOSED. Next, Host B\'s program ' + first('B') + ', and Host A\'s program ' + first('A') + '. Press ▶ to take the first step.</p>';
  }
  if (T === null || T === undefined) return '<p class="cmdnote">Step through the timeline to see each transition. Showing the whole connection: the colored traces are the paths each side took.</p>';
  var st = smSteps(run, prevT === null || prevT === undefined || prevT > T ? -1 : prevT, T);
  if (prevT === null || prevT === undefined || prevT > T) st = smSteps(run, T - 1e-6, T);
  if (!st.length) return '<p class="cmdnote">No state changes at ' + ms(T) + '. The segments on the wire are still moving.</p>';
  return '<ul class="list">' + st.map(function (x) {
    var lab = x.arc ? x.arc[2].replace('\n', ' ') : '', ev = lab.split('/')[0], act = lab.split('/')[1];
    var why = x.arc ? 'Arc <b>' + esc(lab) + '</b>: ' + (EV_TEXT[ev] || ev) + (act ? ', so ' + (ACT_TEXT[act] || 'it sends ' + act) : '') + '.' : (x.to === 'CLOSED' ? 'A reset (RST), or the program gave up: not an arc in the diagram.' : '');
    return '<li><b style="color:' + (x.side === 'A' ? '#00658A' : '#4B32C9') + '">Host ' + x.side + '</b>: ' + x.from + ' → <b>' + (x.to) + '</b> at ' + ms(x.t) + '. ' + why + '</li>';
  }).join('') + '</ul>';
}

/* ===================================================== loss view: A's segments and what B has, at time T */
function lossState(run, T) {
  var Tm = T === undefined || T === null ? Infinity : T;
  var A2B = run.segs.filter(function (g) { return g.from === 'A' && g.len > 0; });
  var boxes = A2B.filter(function (g) { return !g.retx; }).sort(function (a, b) { return a.seq - b.seq; }).map(function (g, i) { return { k: i + 1, s: g.seq, e: g.seq + g.len }; });
  function covers(g, bx) { return g.seq <= bx.s && g.seq + g.len >= bx.e; }
  var ackA = 1;
  run.segs.forEach(function (g) { if (g.from === 'B' && g.f.A && !g.f.S && !g.lost && g.tArr <= Tm + 1e-9) ackA = Math.max(ackA, g.ack); });
  boxes.forEach(function (bx) {
    bx.sent = A2B.some(function (g) { return covers(g, bx) && g.tSend <= Tm + 1e-9; });
    bx.arrived = A2B.some(function (g) { return covers(g, bx) && !g.lost && g.tArr <= Tm + 1e-9; });
    bx.resends = A2B.filter(function (g) { return g.retx && covers(g, bx) && g.tSend <= Tm + 1e-9; });
    bx.acked = bx.e <= ackA;
  });
  var rcvNxt = boxes.length ? boxes[0].s : 1;
  for (var i = 0; i < boxes.length && boxes[i].arrived; i++) rcvNxt = boxes[i].e;
  boxes.forEach(function (bx) {
    var later = boxes.some(function (o) { return o.s > bx.s && o.arrived; });
    bx.b = bx.arrived ? (bx.e <= rcvNxt ? 'inorder' : 'held') : (later ? 'missing' : 'notyet');
  });
  var acks = run.segs.filter(function (g) { return g.from === 'B' && g.f.A && !g.f.S && g.len === 0 && g.tSend <= Tm + 1e-9; });
  var dup = 0;
  if (acks.length) { var last = acks[acks.length - 1].ack; for (var j = acks.length - 1; j >= 0 && acks[j].ack === last; j--) dup++; dup--; }
  var got = acks.filter(function (g) { return !g.lost && g.tArr <= Tm + 1e-9; }), dupA = 0;
  if (got.length) { var lastA = got[got.length - 1].ack; for (var q = got.length - 1; q >= 0 && got[q].ack === lastA; q--) dupA++; dupA--; }
  var lastB = run.segs.filter(function (g) { return g.from === 'B' && g.f.A && g.tSend <= Tm + 1e-9; }).pop();
  var resent = A2B.filter(function (g) { return g.retx && g.tSend <= Tm + 1e-9; });
  return { boxes: boxes, rcvNxt: rcvNxt, ackA: ackA, dup: Math.max(0, dup), dupA: Math.max(0, dupA), sack: lastB && lastB.sack ? lastB.sack : [], resent: resent };
}
var LOSS_WHY = { fast: 'fast retransmit, after the third duplicate ACK', rto: 'the retransmission timer ran out', partial: 'a partial ACK pointed at this hole' };
function lossCaption(run, T) {
  var L = lossState(run, T), bx = L.boxes;
  if (!bx.some(function (x) { return x.sent; })) return 'A has not sent any data yet. Step forward.';
  var hole = bx.filter(function (x) { return x.b === 'missing'; })[0], held = bx.filter(function (x) { return x.b === 'held'; }).length;
  if (hole) {
    var r = hole.resends[hole.resends.length - 1];
    return '<b>Segment ' + hole.k + '</b> (bytes ' + hole.s + '–' + (hole.e - 1) + ') is missing. B holds the ' + held + ' later segment' + (held === 1 ? '' : 's') + ' but can only ask for byte <b>' + hole.s + '</b> again' +
      (L.dup ? ': <b>' + L.dup + ' duplicate ACK' + (L.dup === 1 ? '' : 's') + '</b> so far.' : '.') +
      (L.sack.length ? ' Each one also lists the bytes B holds (SACK, the violet bracket).' : '') + ' ' +
      (r ? 'A has resent segment ' + hole.k + ' (' + LOSS_WHY[r.retx] + ').' : L.dup >= 3 && L.dupA < 3 ? 'The third duplicate ACK is on its way: when it reaches A, A resends segment ' + hole.k + ' at once (fast retransmit).' : 'A resends when a third duplicate ACK reaches it, or when its timer runs out.');
  }
  if (bx.every(function (x) { return x.arrived; })) return 'Every segment arrived. B\'s Ack is <b>' + L.rcvNxt + '</b>: it has bytes 1 to ' + (L.rcvNxt - 1) + '.' + (L.resent.length ? ' It took ' + L.resent.length + ' resend' + (L.resent.length === 1 ? '' : 's') + '.' : '');
  var lost = bx.filter(function (x) { return x.sent && !x.arrived; });
  return 'No gap at B yet: each segment arrives in order and B\'s Ack moves forward.' + (run.segs.some(function (g) { return g.from === 'A' && g.len > 0 && g.lost && g.tSend <= (T === null || T === undefined ? Infinity : T) + 1e-9; }) ? ' A segment was lost on the way, but B cannot tell until a later one arrives.' : '');
}
function drawLossView(svg, run, T) {
  var L = lossState(run, T), n = Math.max(1, L.boxes.length);
  var W = 8.6, x0 = 1.45, gap = 0.08, bw = (W - x0 - 0.2 - gap * (n - 1)) / n, H = 2.75;
  var f = new Fig(svg, 0, W, 0, H, 1.3);
  svg.setAttribute('aria-label', 'Segments Host A sent and what Host B has received. ' + lossCaption(run, T).replace(/<[^>]+>/g, ''));
  var yA = 1.85, yB = 0.75, h = 0.5;
  f.text(0.1, yA + h / 2, 'Host A\nsent', { fs: 8, ha: 'left', bold: true, color: C.navy });
  f.text(0.1, yB + h / 2, 'Host B\nhas', { fs: 8, ha: 'left', bold: true, color: C.navy });
  var AF = { acked: ['#E1F5EF', C.ok], wait: ['#D6F0FA', C.brand], notsent: ['#F1F4F6', '#B8C6CF'] };
  var BF = { inorder: ['#E1F5EF', C.ok], held: ['#EEEAFF', C.violet], missing: ['#FDE8E9', C.bad], notyet: ['#F1F4F6', '#B8C6CF'] };
  L.boxes.forEach(function (bx, i) {
    var x = x0 + i * (bw + gap);
    var a = bx.acked ? 'acked' : bx.sent ? 'wait' : 'notsent';
    f.rect(x, yA, bw, h, { fill: AF[a][0], stroke: bx.resends.length ? C.amberDark : AF[a][1], lw: bx.resends.length ? 2.4 : 1, rx: 0.04 });
    f.text(x + bw / 2, yA + h / 2 + 0.07, String(bx.k) + (bx.resends.length ? ' ↻' : ''), { fs: 8.5, bold: true, color: bx.resends.length ? '#8a4b00' : C.ink });
    f.text(x + bw / 2, yA + h / 2 - 0.12, 'Seq ' + bx.s, { fs: 6.4, color: C.muted, mono: true });
    var b = BF[bx.b];
    f.rect(x, yB, bw, h, { fill: b[0], stroke: b[1], lw: bx.b === 'missing' ? 1.6 : 1, dash: bx.b === 'missing' ? [3, 2] : null, rx: 0.04 });
    f.text(x + bw / 2, yB + h / 2 + 0.07, bx.b === 'missing' ? '✕' : String(bx.k), { fs: 8.5, bold: true, color: bx.b === 'missing' ? C.bad : C.ink });
    f.text(x + bw / 2, yB + h / 2 - 0.12, bx.b === 'held' ? 'held' : bx.b === 'missing' ? 'missing' : bx.b === 'inorder' ? 'in order' : '', { fs: 6.4, color: C.muted });
  });
  // B's Ack: points at the first byte it still needs
  var k = 0; while (k < L.boxes.length && L.boxes[k].s < L.rcvNxt) k++;
  var xa = k < L.boxes.length ? x0 + k * (bw + gap) : x0 + L.boxes.length * (bw + gap) - gap;
  f.arrow(xa, 0.22, xa, yB - 0.03, { color: C.navy, lw: 1.4, mk: 'n' });
  var atxt = 'B\'s Ack = ' + L.rcvNxt + (k < L.boxes.length ? ' (the next byte it needs)' : ' (all received)'), right = xa + 0.08 + f.tw(atxt, 7.4) > W - 0.1;
  f.text(right ? xa - 0.08 : xa + 0.08, 0.2, atxt, { fs: 7.4, ha: right ? 'right' : 'left', bold: true, color: C.navy });
  // SACK blocks over the held runs
  L.sack.forEach(function (bl) {
    var i0 = -1, i1 = -1;
    L.boxes.forEach(function (bx, i) { if (bx.s >= bl[0] && bx.e <= bl[1]) { if (i0 < 0) i0 = i; i1 = i; } });
    if (i0 < 0) return;
    var xs = x0 + i0 * (bw + gap), xe = x0 + i1 * (bw + gap) + bw, yb = yB + h + 0.1;
    f.poly([[xs, yb - 0.04], [xs, yb], [xe, yb], [xe, yb - 0.04]], { color: C.violet, lw: 1.2 });
    f.label((xs + xe) / 2, yb + 0.13, 'SACK ' + bl[0] + '–' + (bl[1] - 1), { fs: 6.6, color: C.violet, bg: '#fff' });
  });
  return f;
}
var LOSS_LEGEND = '<ul class="legend"><li><i style="background:#E1F5EF;border:1px solid #13A88A"></i>acknowledged / arrived in order</li><li><i style="background:#D6F0FA;border:1px solid #00A2D7"></i>sent, waiting for an ACK</li><li><i style="background:#EEEAFF;border:1px solid #7B61FF"></i>held out of order</li><li><i style="background:#FDE8E9;border:1px dashed #E5484D"></i>missing (a gap)</li><li><i style="background:#fff;border:2px solid #E08B00"></i>↻ resent</li></ul>';
function lossStats(run, T) {
  var L = lossState(run, T);
  return '<div class="calcgrid">' + stat('B\'s Ack (next byte it needs)', String(L.rcvNxt)) + stat('Duplicate ACKs in a row', String(L.dup), L.dup >= 3) + stat('Segments resent', String(L.resent.length), L.resent.length > 0) + '</div>';
}
/* ===================================================== byte ribbons: A's send buffer and B's receive buffer */
function drawRibbons(svg, run, T) {
  var sn = snapAt(run, T === undefined || T === null ? Infinity : T), A = sn.A, B = sn.B;
  var maxB = Math.max(A.dataEnd, A.sndUna + A.sndWnd, B.rcvNxt + B.free, 2);
  var W = 8.6, x0 = 0.35, w = W - 0.75, sc = w / (maxB - 1);
  var f = new Fig(svg, 0, W, 0, 3.55, 1.3);
  function X(b) { return x0 + (Math.max(1, Math.min(maxB, b)) - 1) * sc; }
  function seg(y, a, b, fill, stroke, txt, h) { if (b <= a) return; f.rect(X(a), y, X(b) - X(a), h || 0.42, { fill: fill, stroke: stroke || '#fff', lw: 0.8 }); if (txt && X(b) - X(a) > f.tw(txt, 7) + 0.08) f.text((X(a) + X(b)) / 2, y + (h || 0.42) / 2, txt, { fs: 7, bold: true }); }
  // sender
  f.text(x0, 3.33, 'Host A send side (bytes 1 to ' + Math.max(0, A.dataEnd - 1) + ' written by the application)', { fs: 8, bold: true, ha: 'left', color: C.navy });
  var yS = 2.55, una = Math.max(1, A.sndUna), nxt = Math.max(1, Math.min(A.sndNxt, A.dataEnd)), right = una + A.sndWnd, end = A.dataEnd;
  f.rect(x0, yS, w, 0.42, { fill: '#F6F8FA', stroke: '#C9D6DE', lw: 0.8 });
  seg(yS, 1, una, C.okSoft, null, 'ACKed');
  seg(yS, una, nxt, '#9ADCF2', null, 'in flight');
  seg(yS, nxt, Math.min(end, right), C.amberSoft, null, 'may send');
  seg(yS, Math.max(nxt, right), end, C.gray, null, 'must wait');
  if (A.sndWnd >= 0 && A.state !== 'CLOSED' && A.state !== 'SYN_SENT') {
    var bx0 = X(una), bx1 = X(right);
    f.line(bx0, yS + 0.52, bx1, yS + 0.52, { color: C.amberDark, lw: 1.4 }); f.line(bx0, yS + 0.45, bx0, yS + 0.59, { color: C.amberDark, lw: 1.4 }); f.line(bx1, yS + 0.45, bx1, yS + 0.59, { color: C.amberDark, lw: 1.4 });
    f.label(Math.min(Math.max((bx0 + bx1) / 2, x0 + 1.1), W - 1.2), yS + 0.62, 'window B advertised: ' + A.sndWnd, { fs: 7, color: '#7a4c00' });
  }
  var pA = [['SND.UNA = ' + una, X(una)], ['SND.NXT = ' + nxt, X(nxt)]];
  ptrLabels(f, pA, yS - 0.02, W);
  // receiver
  f.text(x0, 1.45, 'Host B receive side (buffer of ' + B.rbuf + ' bytes)', { fs: 8, bold: true, ha: 'left', color: C.navy });
  var yR = 0.68, read = B.readTotal + 1, rn = Math.max(1, B.rcvNxt - (B.finRcvd ? 1 : 0)), rr = B.rcvNxt + B.free;
  f.rect(x0, yR, w, 0.42, { fill: '#F6F8FA', stroke: '#C9D6DE', lw: 0.8 });
  seg(yR, 1, read, C.gray, null, 'read by app');
  seg(yR, read, rn, '#9ADCF2', null, 'waiting for app');
  if (B.state !== 'CLOSED' && B.state !== 'LISTEN') f.rect(X(Math.max(1, B.rcvNxt)), yR, X(rr) - X(Math.max(1, B.rcvNxt)), 0.42, { fill: '#fff', stroke: C.ok, lw: 1, dash: [3, 2] });
  B.ooo.forEach(function (o) { seg(yR, o[0], o[1], C.violetSoft, C.violet, 'out of order'); });
  if (B.state !== 'CLOSED' && B.state !== 'LISTEN') {
    var cx0 = X(Math.max(1, B.rcvNxt)), cx1 = X(rr);
    f.line(cx0, yR + 0.52, cx1, yR + 0.52, { color: C.ok, lw: 1.4 }); f.line(cx0, yR + 0.45, cx0, yR + 0.59, { color: C.ok, lw: 1.4 }); f.line(cx1, yR + 0.45, cx1, yR + 0.59, { color: C.ok, lw: 1.4 });
    f.label(Math.min(Math.max((cx0 + cx1) / 2, x0 + 1.1), W - 1.2), yR + 0.62, 'free space = window to advertise: ' + B.free, { fs: 7, color: '#0b6b58' });
  }
  ptrLabels(f, [['RCV.NXT = ' + Math.max(1, B.rcvNxt), X(Math.max(1, B.rcvNxt))]], yR - 0.02, W);
  svg.setAttribute('aria-label', 'Host A: SND.UNA ' + una + ', SND.NXT ' + nxt + ', window ' + A.sndWnd + '. Host B: RCV.NXT ' + B.rcvNxt + ', ' + B.unread + ' bytes waiting, free ' + B.free + '.');
  return f;
}
function ptrLabels(f, list, y, W) {
  var lastR = -9, row = 0;
  list.sort(function (a, b) { return a[1] - b[1]; }).forEach(function (p) {
    var w = f.tw(p[0], 7, true) + 0.15, x = Math.min(Math.max(p[1], w / 2 + 0.05), W - w / 2 - 0.05);
    row = x - w / 2 < lastR ? row + 1 : 0;
    var yy = y - 0.17 - row * 0.24;
    f.line(p[1], y, p[1], yy + 0.08, { color: C.navy, lw: 0.9 });
    f.label(x, yy, p[0], { fs: 7, mono: true, color: C.navy });
    lastR = x + w / 2;
  });
}
var RIBBON_LEGEND = '<ul class="legend"><li><i style="background:#D3F1E8"></i>acknowledged</li><li><i style="background:#9ADCF2"></i>in flight or waiting for the app</li><li><i style="background:#FCE9C6"></i>may send now</li><li><i style="background:#E4E4E4"></i>must wait, or already read</li><li><i style="background:#E7E1FF;border:1px solid #7B61FF"></i>out of order</li></ul>';
function windowStats(run, T) {
  var s = snapAt(run, T === undefined || T === null ? Infinity : T), A = s.A, B = s.B, infl = Math.max(0, A.sndNxt - A.sndUna), usable = Math.max(0, A.sndUna + A.sndWnd - A.sndNxt);
  return '<p class="cmdnote">SND.UNA: the oldest unacknowledged byte. SND.NXT: the next byte to send. RCV.NXT: the next byte B expects.</p><div class="calcgrid">' + stat('Bytes in flight (SND.NXT − SND.UNA)', fmt(infl)) + stat('Window B last advertised', fmt(A.sndWnd)) +
    stat('Usable window (may send now)', fmt(usable), usable === 0 && A.dataEnd > A.sndNxt) + stat('Bytes waiting for B\'s application', fmt(B.unread)) + stat('B\'s free buffer', fmt(B.free), B.free === 0) + '</div>' +
    '';
}
function stat(k, v, hl) { return '<div class="stat' + (hl ? ' hl' : '') + '"><div class="k">' + k + '</div><div class="v">' + v + '</div></div>'; }

/* ===================================================== the header figure */
function drawHeader(svg, h) {
  var bw = 0.235, x0 = 0.5, W = x0 + 32 * bw + 0.3, optLines = wrapText(h.optText || '', 58), rows = 5 + (h.hdr > 20 ? 1 : 0) + 1, rh = 0.62, extra = h.hdr > 20 ? (optLines.length - 1) * 0.2 : 0, Ht = 0.55 + rows * rh + extra + 0.15;
  var f = new Fig(svg, 0, W, 0, Ht, 1.4);
  svg.setAttribute('aria-label', 'TCP header with field values');
  var top = Ht - 0.45;
  [0, 4, 8, 16, 24, 31].forEach(function (b) { f.text(x0 + (b + 0.5) * bw, top + 0.18, String(b), { fs: 6.8, color: C.muted }); });
  f.text(x0 - 0.25, top + 0.18, 'bit', { fs: 6.8, color: C.muted });
  function cell(r, b0, nb, name, val, fill, o) {
    o = o || {};
    var y = top - (r + 1) * rh, x = x0 + b0 * bw, w = nb * bw;
    f.rect(x, y, w, rh, { fill: fill || '#fff', stroke: C.brand, lw: 1 });
    if (o.small) { f.text(x + w / 2, y + rh * 0.68, name, { fs: 6.6, color: C.muted }); f.text(x + w / 2, y + rh * 0.3, val, { fs: 7.2, bold: true, mono: true }); }
    else { f.text(x + w / 2, y + rh * 0.7, name, { fs: 7, color: C.muted }); f.text(x + w / 2, y + rh * 0.3, val, { fs: 8.6, bold: true, mono: true, color: o.color }); }
  }
  cell(0, 0, 16, 'Source port', String(h.sport), '#fff'); cell(0, 16, 16, 'Destination port', String(h.dport), '#fff');
  cell(1, 0, 32, 'Sequence number' + (h.seqNote ? ' (' + h.seqNote + ')' : ''), String(h.seq), C.soft);
  cell(2, 0, 32, 'Acknowledgment number' + (h.f.A ? '' : ' (not used: ACK flag is 0)'), String(h.ack), C.soft, { color: h.f.A ? null : C.muted });
  cell(3, 0, 4, 'Hdr len', h.hdr / 4 + ' = ' + h.hdr + ' B', C.amberSoft, { small: true }); cell(3, 4, 4, 'Reserved', '0', '#fff', { small: true });
  [['C', 'CWR'], ['E', 'ECE'], ['U', 'URG'], ['A', 'ACK'], ['P', 'PSH'], ['R', 'RST'], ['S', 'SYN'], ['F', 'FIN']].forEach(function (fl, i) {
    var on = h.f[fl[0]] ? 1 : 0; cell(3, 8 + i, 1, fl[1].charAt(0), String(on), on ? '#BFE8F7' : '#fff', { small: true });
  });
  cell(3, 16, 16, 'Window' + (h.winNote ? ' (' + h.winNote + ')' : ''), String(h.win), '#fff');
  cell(4, 0, 16, 'Checksum', h.csumText || '0x' + (h.csum || 0).toString(16).toUpperCase().padStart(4, '0'), '#fff'); cell(4, 16, 16, 'Urgent pointer', '0', '#fff');
  var r = 5;
  if (h.hdr > 20) {
    var yo = top - (r + 1) * rh - extra, ho = rh + extra;
    f.rect(x0, yo, 32 * bw, ho, { fill: C.violetSoft, stroke: C.brand, lw: 1 });
    f.text(x0 + 16 * bw, yo + ho - 0.13, 'Options: ' + (h.hdr - 20) + ' bytes', { fs: 7, color: C.muted });
    f.text(x0 + 16 * bw, yo + (ho - 0.2) / 2, optLines.join('\n'), { fs: 8.2, bold: true, mono: true });
    r++;
  }
  var yd = top - (r + 1) * rh - extra;
  f.rect(x0, yd, 32 * bw, rh, { fill: '#F6F8FA', stroke: C.brand, lw: 1 }); f.text(x0 + 16 * bw, yd + rh * 0.7, 'Data (payload)', { fs: 7, color: C.muted }); f.text(x0 + 16 * bw, yd + rh * 0.3, h.len + ' bytes', { fs: 8.6, bold: true, mono: true });
  return f;
}
function wrapText(s, n) {
  var parts = String(s).split(/, /), out = [], cur = '';
  parts.forEach(function (p) { var t = cur ? cur + ', ' + p : p; if (t.length > n && cur) { out.push(cur + ','); cur = p; } else cur = t; });
  if (cur) out.push(cur); return out.length ? out : [''];
}
/* turn a simulated segment into header fields */
function segHeader(run, sg, raw) {
  var o = [];
  if (sg.opts) { o.push('MSS ' + sg.opts.mss); if (sg.opts.sackPerm) o.push('SACK (Selective Acknowledgment) permitted'); if (sg.opts.ts) o.push('Timestamps'); if (sg.opts.ws !== null) o.push('Window Scale ' + sg.opts.ws); }
  else { if (sg.hdr >= 32 && run.cfg.ts) o.push('NOP, NOP, Timestamps'); if (sg.sack && sg.sack.length) o.push('SACK ' + sg.sack.map(function (b) { return (raw ? m32(sg.peerIss + b[0]) : b[0]) + '–' + (raw ? m32(sg.peerIss + b[1]) : b[1]); }).join(', ')); }
  return { sport: sg.from === 'A' ? run.ports.A : run.ports.B, dport: sg.from === 'A' ? run.ports.B : run.ports.A, seq: raw ? m32(sg.iss + sg.seq) : sg.seq, ack: sg.f.A ? (raw ? m32(sg.peerIss + sg.ack) : sg.ack) : 0,
    seqNote: raw ? 'raw' : 'relative', hdr: sg.hdr, f: sg.f, win: sg.win, winNote: sg.scaled && run.cfg.ws > 0 ? '× ' + Math.pow(2, run.cfg.ws) + ' = ' + sg.winBytes + ' bytes' : '', csumText: 'computed by the sender', optText: o.join(', '), len: sg.len };
}

/* ===================================================== RTT and RTO plot */
function drawRtoPlot(svg, series, rtoMin) {
  var n = series.length, W = 8, H = 3.6, x0 = 0.85, x1 = W - 0.3, y0 = 0.55, y1 = H - 0.3;
  var mx = 0; series.forEach(function (s) { mx = Math.max(mx, s.R, s.rto || 0); }); mx = Math.max(mx, rtoMin || 0) * 1.12 || 100;
  var step = [10, 20, 25, 50, 100, 200, 250, 500, 1000, 2000, 5000].filter(function (s) { return mx / s <= 6; })[0] || 10000;
  var f = new Fig(svg, 0, W, 0, H, 1.3);
  function X(i) { return x0 + (n > 1 ? (i / (n - 1)) : 0.5) * (x1 - x0 - 0.3) + 0.15; }
  function Y(v) { return y0 + v / mx * (y1 - y0); }
  for (var v = 0; v <= mx; v += step) { f.line(x0, Y(v), x1, Y(v), { color: '#E1EAF0', lw: 0.8 }); f.text(x0 - 0.08, Y(v), String(v), { fs: 7, ha: 'right', color: C.muted }); }
  f.line(x0, y0, x0, y1, { color: C.ink, lw: 1 }); f.line(x0, y0, x1, y0, { color: C.ink, lw: 1 });
  f.text(0.22, (y0 + y1) / 2, 'ms', { fs: 7.5, color: C.muted });
  series.forEach(function (s, i) { f.text(X(i), y0 - 0.17, String(i + 1), { fs: 7, color: C.muted }); });
  f.text((x0 + x1) / 2, 0.12, 'sample number', { fs: 7.5, color: C.muted });
  if (rtoMin) { f.line(x0, Y(rtoMin), x1, Y(rtoMin), { color: C.bad, lw: 1, dash: [4, 3] }); f.label(x1 - 0.9, Y(rtoMin) + 0.13, 'minimum RTO ' + rtoMin + ' ms', { fs: 6.8, color: C.bad }); }
  var ps = [], pr = [];
  series.forEach(function (s, i) { if (s.srtt !== null && s.srtt !== undefined) { ps.push([X(i), Y(s.srtt)]); pr.push([X(i), Y(s.rto)]); } });
  if (ps.length > 1) { f.poly(ps, { color: C.brand, lw: 2 }); f.poly(pr, { color: C.amberDark, lw: 2 }); }
  ps.forEach(function (p) { f.circle(p[0], p[1], 0.04, { fill: C.brand }); }); pr.forEach(function (p) { f.circle(p[0], p[1], 0.04, { fill: C.amberDark }); });
  series.forEach(function (s, i) {
    if (s.skipped) { f.circle(X(i), Y(s.R), 0.07, { fill: '#fff', stroke: C.muted, lw: 1.2 }); f.line(X(i) - 0.07, Y(s.R) - 0.07, X(i) + 0.07, Y(s.R) + 0.07, { color: C.muted, lw: 1.2 }); }
    else f.circle(X(i), Y(s.R), 0.07, { fill: C.ink });
  });
  svg.setAttribute('aria-label', 'Round-trip samples with the smoothed RTT and the RTO after each one.');
  return f;
}
var RTO_LEGEND = '<ul class="legend"><li><i style="background:#1B2A35;border-radius:50%;width:12px"></i>RTT sample</li><li><i style="background:#fff;border:1px solid #5B6B78;border-radius:50%;width:12px"></i>sample skipped (Karn\'s rule)</li><li><i style="background:#00A2D7"></i>SRTT (smoothed RTT)</li><li><i style="background:#E08B00"></i>RTO</li></ul>';

/* ===================================================== a run player: step through time */
function makePlayer(box, run, render, opt) {
  opt = opt || {};
  var times = [opt.statesOnly ? -1 : 0];
  if (!opt.statesOnly) run.segs.forEach(function (s) { times.push(s.tSend); if (!s.lost) times.push(s.tArr); });
  ['A', 'B'].forEach(function (sd) { run.states[sd].forEach(function (x) { times.push(x.t); }); });
  times.sort(function (a, b) { return a - b; });
  var u = []; times.forEach(function (t) { if (!u.length || t - u[u.length - 1] > 1e-6) u.push(t); }); times = u;
  var i = opt.start === 'first' ? 0 : times.length - 1, timer = null, token = 0, bars = [];
  function label() { return i === times.length - 1 ? (opt.statesOnly ? 'the whole connection' : 'all ' + run.segs.length + ' segments') : (times[i] < 0 ? 'before the connection' : 't = ' + ms(times[i])) + ' (step ' + (i + 1) + ' of ' + times.length + ')'; }
  /* one set of controls; every figure that changes over time gets its own copy, all in step */
  function attach(bx) {
    if (!bx) return;
    bx.innerHTML = '<div class="player" role="group" aria-label="Step through time">' +
      '<button class="btn alt small" data-p="first" aria-label="Go to the start">⏮</button><button class="btn alt small" data-p="prev" aria-label="One step back">◀</button>' +
      '<button class="btn small" data-p="play">▶ Play</button><button class="btn alt small" data-p="next" aria-label="One step forward">▶</button><button class="btn alt small" data-p="last" aria-label="Show everything">⏭</button>' +
      '<input type="range" min="0" max="' + (times.length - 1) + '" value="' + i + '" aria-label="Moment in time">' + speedCtl() + '<span class="now"' + (bars.length ? '' : ' aria-live="polite"') + '></span></div>';
    bindSpeed(bx);
    var bar = { rng: $('input', bx), now: $('.now', bx), play: $('[data-p=play]', bx) };
    $('[data-p=first]', bx).onclick = function () { stop(); i = 0; show(); };
    $('[data-p=prev]', bx).onclick = function () { stop(); i = Math.max(0, i - 1); show(); };
    $('[data-p=next]', bx).onclick = function () { stop(); i = Math.min(times.length - 1, i + 1); show(); };
    $('[data-p=last]', bx).onclick = function () { stop(); i = times.length - 1; show(); };
    bar.play.onclick = play;
    bar.rng.oninput = function () { stop(); i = +bar.rng.value; show(); };
    bars.push(bar);
    bar.rng.value = i; bar.now.textContent = label();
  }
  function show() { var t = label(); bars.forEach(function (b) { b.rng.value = i; b.now.textContent = t; }); render(i === times.length - 1 && !opt.statesOnly ? null : times[i]); }
  function setPlay(txt) { bars.forEach(function (b) { b.play.textContent = txt; }); }
  function stop() { token++; if (timer) clearTimeout(timer); timer = null; setPlay('▶ Play'); }
  function play() {
    if (timer) { stop(); return; }
    if (i >= times.length - 1) i = 0;
    var my = ++token; setPlay('❚❚ Pause');
    (function tick() { if (my !== token) return; show(); if (i >= times.length - 1) { stop(); return; } i++; timer = setTimeout(tick, (reduceMotion ? 900 : (opt.statesOnly ? 1500 : 420)) / animSpeed); })();
  }
  attach(box);
  show();
  function seekTime(t, animate) {   // go to the step at time t; with animate, land one step before and then move
    var k = 0; while (k < times.length - 1 && times[k] < t - 1e-6) k++;
    stop(); i = Math.max(0, animate ? k - 1 : k); show();
    if (animate && k > 0) { var my = ++token; setTimeout(function () { if (my !== token) return; i = k; show(); }, 450 / animSpeed); }
  }
  return { stop: stop, show: show, attach: attach, seekTime: seekTime, setLast: function () { stop(); i = times.length - 1; show(); }, play: play };
}

/* ===================================================== the Wireshark-style capture list */
function packetList(run, T, raw) {
  var cap = capture(run, { raw: raw }), Tm = T === null || T === undefined ? Infinity : T;
  var lostA = run.segs.filter(function (s) { return s.lost && s.from === 'A'; }).length, lostB = run.segs.filter(function (s) { return s.lost && s.from === 'B'; }).length;
  var h = '<ol class="pkts" aria-label="Capture taken at Host A">' + cap.map(function (fr) {
    var fut = fr.t > Tm + 1e-9;
    return '<li class="' + (fut ? 'future' : '') + '"><span class="d">' + String(fr.no).padStart(3, ' ') + '  ' + (fr.t / 1000).toFixed(3) + '  ' + fr.src + ' → ' + fr.dst + '  TCP ' + String(fr.sg.frame).padStart(4, ' ') + '  </span>' +
      (fr.label ? '<span class="lab' + (/Retrans|ZeroWindow|not captured|Dup/.test(fr.label) ? ' bad' : '') + '">[' + esc(fr.label) + ']</span> ' : '') + esc(fr.info) +
      (fr.sg.lost ? ' <span class="lost">(lost after it left A)</span>' : '') + '</li>';
  }).join('') + '</ol>';
  if (lostB) h += '<p class="cmdnote">This capture is taken at Host A, like running Wireshark on Host A. ' + lostB + ' segment' + (lostB > 1 ? 's' : '') + ' that B sent ' + (lostB > 1 ? 'were' : 'was') + ' lost on the way, so ' + (lostB > 1 ? 'they never appear' : 'it never appears') + ' here.</p>';
  else if (lostA) h += '<p class="cmdnote">This capture is taken at Host A, so segments A sent appear even if they were lost later on the path.</p>';
  else h += '<p class="cmdnote">Captured at Host A, as Wireshark on Host A would show it (frame lengths include the 14-byte Ethernet header).</p>';
  return h;
}
function stateBadges(run, T) {
  var Tm = T === null || T === undefined ? Infinity : T, a = stateAt(run, 'A', Tm), b = stateAt(run, 'B', Tm);
  return '<div class="badges2"><div class="sbadge"><b>Host A: ' + a + '</b><span>' + toolName() + ' shows: ' + spell(a) + '</span></div><div class="sbadge b"><b>Host B: ' + b + '</b><span>' + toolName() + ' shows: ' + spell(b) + '</span></div></div>';
}
function eventList(run, T) {
  var Tm = T === null || T === undefined ? Infinity : T;
  if (!run.log.length) return '';
  return '<ol class="events">' + run.log.map(function (l) { return '<li class="' + (l.t > Tm + 1e-9 ? 'future' : '') + '"><b>' + ms(l.t) + '</b> ' + esc(l.text) + '</li>'; }).join('') + '</ol>';
}

/* ===================================================== commands panel */
var CMDS = {
  states: { linux: [['ss -tan', 'List every TCP socket with its state (-t TCP, -a all, -n numbers instead of names).'], ['ss -tan state time-wait', 'Show only connections in TIME_WAIT.'], ['ss -tln', 'Show only listening sockets (-l).']],
    windows: [['netstat -an -p tcp', 'List every TCP connection with its state (-a all, -n numbers, -p tcp).'], ['Get-NetTCPConnection -State TimeWait', 'PowerShell: show only connections in TIME_WAIT.'], ['Get-NetTCPConnection -State Listen', 'PowerShell: show listening sockets.']] },
  inside: { linux: [['ss -ti dst ADDR', 'Show TCP internals for connections to ADDR: mss (maximum segment size), rtt (smoothed round-trip time/variation in ms), rto (retransmission timeout), rcv_space, and retransmission counts.'], ['ss -tm', 'Show the socket buffer memory (-m).']],
    windows: [['Get-NetTCPSetting -SettingName Internet', 'PowerShell: show settings such as InitialRto, MinRto, and MaxSynRetransmissions. Windows has no built-in per-connection view like ss -ti.']] },
  settings: { linux: [['sysctl net.ipv4.tcp_sack net.ipv4.tcp_timestamps net.ipv4.tcp_window_scaling', 'Show whether SACK (Selective Acknowledgment), Timestamps, and Window Scale are on (1) or off (0).'], ['sysctl net.ipv4.tcp_syn_retries net.ipv4.tcp_rmem', 'How many times a SYN (synchronize, the opening segment) is resent, and the receive buffer sizes (min, default, max).']],
    windows: [['netsh interface tcp show global', 'Show Windows TCP settings, such as window auto-tuning and timestamps.']] },
  connect: { linux: [['nc -l 5000', 'Server: listen on port 5000 (nc is netcat). Stop it with Ctrl+C.'], ['nc ADDR 5000', 'Client: connect to ADDR port 5000. What you type is sent when you press Enter.'], ['nc -zv ADDR 5000', 'Open and close a connection at once (-z) and report the result (-v).'], ['nc -zv ADDR 5001', 'Try a port where nothing listens: you get "Connection refused" (an RST, reset, segment).']],
    windows: [['Test-NetConnection -ComputerName ADDR -Port 5000', 'PowerShell: open a TCP connection to ADDR port 5000 and report TcpTestSucceeded.']] },
  zero: { linux: [['nc -l 5000 | (sleep 60; cat > /dev/null)', 'Receiver that does not read for 60 seconds, so its buffer fills and it advertises a zero window.'], ['dd if=/dev/zero bs=1M count=50 | nc ADDR 5000', 'Sender: push 50 MB of zeros to ADDR (dd copies data; bs is the block size).']],
    windows: [] },
  loss: { linux: [['sudo tc qdisc add dev IFACE root netem loss 10%', 'Drop 10% of the packets leaving IFACE (tc changes traffic control; netem emulates a bad network; needs sudo).'], ['sudo tc qdisc change dev IFACE root netem delay 100ms loss 5%', 'Change it to 100 ms of delay and 5% loss.'], ['sudo tc qdisc del dev IFACE root', 'Undo: remove the emulation from IFACE.']],
    windows: [] },
  wireshark: { linux: [['tcp.port == 5000', 'Wireshark display filter: only this connection\'s port.'], ['tcp.flags.syn == 1 || tcp.flags.fin == 1 || tcp.flags.reset == 1', 'Only opening and closing segments, and resets.'], ['tcp.analysis.retransmission || tcp.analysis.fast_retransmission', 'Only resent segments.'], ['tcp.analysis.duplicate_ack', 'Only duplicate ACKs (acknowledgments).'], ['tcp.analysis.zero_window || tcp.analysis.window_update', 'Zero windows and window updates.']],
    windows: [['tcp.port == 5000', 'Wireshark display filter: only this connection\'s port.'], ['tcp.flags.syn == 1 || tcp.flags.fin == 1 || tcp.flags.reset == 1', 'Only opening and closing segments, and resets.'], ['tcp.analysis.retransmission || tcp.analysis.fast_retransmission', 'Only resent segments.'], ['tcp.analysis.duplicate_ack', 'Only duplicate ACKs (acknowledgments).'], ['tcp.analysis.zero_window || tcp.analysis.window_update', 'Zero windows and window updates.']] }
};
var CMD_NOTES = {
  zero: { windows: 'Windows has no built-in way to make a slow reader or a sender from the command line. Run the two Linux commands on two Linux computers, or a Linux receiver and any sender.' },
  loss: { windows: 'Windows has no built-in tool to add loss or delay. Use a Linux computer on the path, or a Linux virtual machine as one end.' }
};
function cmdPanel(box, keys, intro) {
  function render() {
    var h = (intro ? '<p class="cmdnote">' + intro + '</p>' : '') + '<div class="cmdtabs" role="group" aria-label="System"><button data-c="linux" aria-pressed="' + (OS === 'linux') + '">Linux</button><button data-c="windows" aria-pressed="' + (OS === 'windows') + '">Windows</button></div>';
    keys.forEach(function (k) {
      var list = CMDS[k][OS] || [];
      if (CMD_NOTES[k] && CMD_NOTES[k][OS]) h += '<p class="cmdnote">' + CMD_NOTES[k][OS] + '</p>';
      list.forEach(function (c) { h += '<p class="cmdnote" style="margin:8px 0 0">' + esc(c[1]) + '</p><div class="cmd"><code>' + esc(c[0]) + '</code><button type="button">Copy</button></div>'; });
    });
    box.innerHTML = h;
    $$('.cmd button', box).forEach(function (b) { b.onclick = function () { copyText(b.previousElementSibling.textContent, b); }; });
    $$('[data-c]', box).forEach(function (b) { b.onclick = function () { setOS(b.getAttribute('data-c')); }; });
  }
  render(); osListeners.push(function () { if (!document.body.contains(box)) return false; render(); });
}
