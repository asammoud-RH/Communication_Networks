# Bandwidth and Latency Visualizer: build plan (approved November 9, 2026; version 1.1 changes at the end)

Catalog entry #2 (delay, throughput, and the delay × bandwidth product). Built from `app-template.html`, following every item in `App Requirements.md`, including the naming and independence ruling.

- **Name and files:** Bandwidth and Latency Visualizer, `claude/Interactive tools/bandwidth-latency-visualizer/bandwidth-latency-visualizer.html` and `README.md`
- **APP_ID:** `bandwidth-latency-visualizer`. Test object: `window.BandwidthLatencyVisualizer`
- **One concept:** how long a message takes to get from one host to another, and how many bits are on the link while it travels.

## 1. Goal

Students learn to:
- convert between bits and bytes, and between decimal (10^6) and binary (2^20) units;
- find the bit width (1/bandwidth) and how many meters one bit occupies on the wire;
- split latency into propagation, transmit, and queuing delay, and say which one dominates;
- compute the delay × bandwidth product and explain it as bits in flight, and the window needed to keep the pipe full;
- compute transfer time and effective throughput, and tell latency-bound from bandwidth-bound transfers;
- measure round-trip time (RTT), link speed, and throughput with real commands.

## 2. Model

- Latency = Propagation + Transmit + Queue. Propagation = Distance / Speed. Transmit = Size / Bandwidth.
- Signal speed: 3.0×10^8 m/s in a vacuum (and radio), 2.3×10^8 m/s in copper cable, 2.0×10^8 m/s in fiber.
- Transfer time = RTT + Size / Bandwidth. Effective throughput = Size / Transfer time. A note says this ignores TCP slow start and the handshake.
- RTT defaults to 2 × one-way propagation and can be edited.
- Units: bandwidth is always decimal (1 Mbps = 10^6 bit/s). Data sizes default to decimal (1 MB = 10^6 bytes), with a switch to binary (1 MiB = 2^20 bytes).
- Store-and-forward: each switch or router transmits the whole packet again, so each link adds its own transmit and propagation delay, plus the device's queuing delay.
- The 1 MB file over 1 Gbps with 100 ms RTT (about 74 Mbps effective with decimal units) appears as a plain example.

## 3. Learn mode: six lessons

1. **A bit is a slice of time.** Bit width at two rates; length of one bit on the wire. Try it: bit width at a generated rate.
2. **Three parts of latency.** Space-time diagram (Host A and Host B timelines; the packet as a slanted band whose thickness is the transmit time and whose slope is the propagation time); animation of the first and last bit. Try it: the one-way latency.
3. **Which part dominates?** Latency versus message size for two links. Try it: which link delivers a given file first.
4. **The pipe: delay × bandwidth (core lesson).** Pipe with length = delay and width = bandwidth, filling with bits; one-way and RTT versions; the window needed to keep the pipe full. Try it: bytes in flight or the window needed.
5. **Bandwidth is not throughput.** Transfer time, effective throughput, latency-bound versus bandwidth-bound. Try it: effective throughput.
6. **Across a switch and a router, with queues.** Host A, Switch, Router, Host B; store-and-forward per hop, queuing delay and jitter over a run of pings; the commands panel. Try it: the end-to-end delay of a packet across the path.

## 4. Calculator

- Inputs: message size and unit, one to four links (each with rate, distance or delay, medium, and queuing delay at its sender), optional RTT override, decimal or binary sizes.
- Presets: local Ethernet, cross-country fiber, satellite, Wi-Fi, home broadband.
- Stat tiles: bit width, each delay component, one-way latency, RTT, delay × bandwidth (one-way and RTT, bits and bytes), transfer time, effective throughput, utilization, latency-bound or bandwidth-bound.
- Figures: space-time diagram, the pipe, a stacked bar of the delay parts. Commands panel.

## 5. Challenge

- **Easy:** unit conversions, bit width, propagation delay, transmit delay.
- **Medium:** total latency, RTT from distance, bit length in meters, delay × bandwidth in bytes, which part dominates.
- **Hard:** effective throughput, window needed to fill the pipe, store-and-forward over several links, latency-bound versus bandwidth-bound comparison.
- Badges: First round, Perfect 10, On fire, Speed runner, Scholar, Pipe filler, Unit master, Bottleneck finder.

## 6. Commands (bench-test on the shipped Lubuntu image)

- RTT. Linux: `ping -c 5 ADDR`, `ping -c 5 -s 1400 ADDR`. Windows: `ping -n 5 ADDR`, `ping -n 5 -l 1400 ADDR`.
- Link speed. Windows (main): PowerShell `Get-NetAdapter | Select-Object Name, LinkSpeed`. Linux: `cat /sys/class/net/IFACE/speed`, with a note that a virtual machine reports its virtual adapter, not the real cable.
- Throughput (Linux): receiver `nc -l 5000 > /dev/null`; sender `dd if=/dev/zero bs=1M count=100 | nc ADDR 5000` (dd prints the rate). Windows has no built-in equivalent; the app says so.
- Add delay and undo (Linux, sudo): `sudo tc qdisc add dev IFACE root netem delay 50ms`, undo `sudo tc qdisc del dev IFACE root`.

## 7. Link parameters

`mode=learn|calc|challenge`, `lesson=1..6`, `level=E|M|H`; Calculator: `size`, `unit`, `bw` (bit/s), `dist` (m), `medium`, `rtt` (ms).

## 8. Testing

- Logic test: independent Python with exact fractions; hundreds of rounds per level re-checked.
- Real kernel: network namespaces with netem delay and rate; ping RTTs and transfer times compared with the model.
- Smoke and click-through tests; screenshots at 1280 and 390 pixels.

## 9. Decisions

- Name: Bandwidth and Latency Visualizer (instructor, November 9, 2026).
- Not yet answered, so the build uses these defaults: decimal sizes with a binary switch; Lesson 6 on multiple hops kept; `tc netem` included with a bench-test note; released as a self-check (Requirement 31) until the instructor says whether graded work covers this topic.
- The "Why is my transfer slow?" Troubleshoot-it scenario waits for the decision on the shared component (Troubleshooting skills plan, open question 4).

## 10. Version 1.1 (November 9, 2026, instructor's requests)

- Bandwidth is drawn as width wherever it appears: thicker links in every wire figure (the bottleneck is the thinnest), and a pipe whose width follows the bandwidth and whose length follows the delay (both logarithmic).
- Throughput is added as its own idea: a "bandwidth versus throughput" figure (rate over time: nothing during the RTT, then the full bandwidth; the throughput is the average), a list of the four terms that get mixed up (bandwidth, latency, throughput, delay × bandwidth), and a terms question in the Easy Challenge.
- Every figure is checked for overlapping and clipped text in many states, and looked at, before release (`testing/figure_check.py`).
