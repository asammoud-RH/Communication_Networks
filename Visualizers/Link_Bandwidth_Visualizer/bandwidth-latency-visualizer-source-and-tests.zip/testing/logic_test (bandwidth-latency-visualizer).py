"""Logic test for Bandwidth and Latency Visualizer.

Re-checks the app's model and every generated Challenge answer against an
independent Python implementation that uses exact fractions.

  1. Model: pathTimes, messageTime, transfer, and the bit and pipe formulas,
     on random inputs. messageTime is checked against an event simulation of
     packets moving through store-and-forward links.
  2. Challenge: N rounds per level; each question's answer key is recomputed
     from its inputs (q.p). Choice questions must have one right answer, no
     duplicate choices, and a clear winner.
  3. Completion codes round-trip, and an edited code is rejected.

Usage:
  python3 "logic_test (bandwidth-latency-visualizer).py" path/to/bandwidth-latency-visualizer.html [rounds]
"""
import asyncio, json, os, random, sys, pathlib
from fractions import Fraction as F
from playwright.async_api import async_playwright

APP = pathlib.Path(sys.argv[1]).resolve()
ROUNDS = int(sys.argv[2]) if len(sys.argv) > 2 else 150
SPEED = {'fiber': F(2 * 10**8), 'copper': F(23 * 10**7), 'radio': F(3 * 10**8)}
fails = []


def check(cond, msg):
    if not cond:
        fails.append(msg)


def close(a, b, rel=1e-9):
    return abs(float(a) - float(b)) <= rel * max(1e-12, abs(float(b)))


def Fx(x):
    return F(str(x)) if isinstance(x, float) else F(x)


# ---------- independent model ----------
def one_packet(bits, links):  # links: (bw, dist, medium, q_seconds)
    t = F(0)
    for bw, d, m, q in links:
        t += q + F(bits) / bw + F(d) / SPEED[m]
    return t


def simulate(bits, n, links):
    """Event simulation: each link is a FIFO transmitter; q is a pure delay before the packet joins the link's queue."""
    arrive = [F(0)] * n  # time each packet is fully held by the current node
    for bw, d, m, q in links:
        T, P, free = F(bits) / bw, F(d) / SPEED[m], F(0)
        out = []
        for a in arrive:
            start = max(a + q, free)
            free = start + T
            out.append(free + P)
        arrive = out
    return arrive[-1]


def key(p):
    k = p['kind']
    if k == 'mb2mbit': return F(p['n']) * 8
    if k == 'kib': return F(p['n']) * 1024
    if k == 'mbps2mbs': return F(p['n']) / 8
    if k == 'mib': return F(p['n']) * 2**20
    if k == 'bitw_us': return 1 / F(p['r'])
    if k == 'bitw_ns': return 1 / F(p['r'])
    if k == 'prop':
        t = Fx(p['m']) / SPEED[p['medium']]
        return t * 1000 if p['unit'] == 'ms' else t * 10**6
    if k == 'trans_us': return F(p['s']) * 8 / F(p['b'])
    if k == 'lat':
        T = F(p['s']) * 8 / (F(p['b']) * 1000); P = F(p['d']) * 1000 / SPEED['fiber'] * 1000; a = F(p['q']) + T + P
        check(T >= a / 20 and P >= a / 20 and (p['q'] == 0 or F(p['q']) >= a / 20), f'lat: a part is under 5% {p}')
        return a
    if k == 'lat_unused': return F(p['q']) + F(p['s']) * 8 / (F(p['b']) * 1000) + F(p['d']) * 1000 / SPEED['fiber'] * 1000
    if k == 'rtt': return 2 * F(p['d']) * 1000 / SPEED['fiber'] * 1000
    if k == 'bitlen': return SPEED[p['medium']] / (F(p['b']) * 10**6)
    if k == 'dxb': return F(p['d']) / 1000 * F(p['b']) * 10**6 / 8 / 1000
    if k == 'onwire': return F(p['d']) * 1000 / SPEED['fiber'] * F(p['b']) * 10**6
    if k == 'thr':
        bits = F(p['mb']) * 8 * 10**6; t = F(p['r']) / 1000 + bits / (F(p['b']) * 10**6)
        check(bits / t / 10**6 <= F(9, 10) * F(p['b']), f'throughput too close to the bandwidth {p}')
        return bits / t / 10**6
    if k == 'win': return F(p['r']) / 1000 * F(p['b']) * 10**6 / 8 / 1000
    if k == 'winthr': return min(F(p['b']), F(p['w']) * 8000 / (F(p['r']) / 1000) / 10**6)
    if k == 'path':
        tot = one_packet(12000, [(Fx(bw), Fx(d), 'fiber', Fx(q) / 1000) for bw, d, q in p['links']])
        extra = sum(F(12000) / Fx(bw) for bw, d, q in p['links'][1:])
        check(extra >= tot / 20, f'path: transmit counted once is within 5% {p}')
    if k == 'path': return one_packet(12000, [(Fx(bw), Fx(d), 'fiber', Fx(q) / 1000) for bw, d, q in p['links']]) * 1000
    if k == 'msg': return simulate(12000, p['n'], [(Fx(p['b1']), Fx(p['d1']), 'fiber', F(0)), (Fx(p['b2']), Fx(p['d2']), 'fiber', F(0))]) * 1000
    if k == 'saved': return (F(p['mb']) * 8 / F(p['b1']) - F(p['mb']) * 8 / F(p['b2'])) * 1000
    raise KeyError(k)


def choice_key(p):
    k = p['kind']
    if k == 'compare':
        a, b = Fx(p['a']), Fx(p['b']); check(a != b, 'compare tie'); return p['la'] if a > b else p['lb']
    if k == 'dom':
        T = Fx(p['s']) * 8 / Fx(p['b']); P = Fx(p['d']) / SPEED[p['medium']]
        check(max(T, P) / min(T, P) >= 3, f'dom not clear {p}'); return 'Transmit' if T > P else 'Propagation'
    if k == 'faster':
        bits = Fx(p['mb']) * 8 * 10**6; b = Fx(p['b']) * 10**6; r = Fx(p['r']) / 1000
        a = r + bits / (10 * b); c = r / 2 + bits / b
        check(max(a, c) / min(a, c) >= F(6, 5), f'faster not clear {p}'); return '10 times the bandwidth' if a < c else 'Half the RTT'
    if k == 'term':
        return ['Bandwidth', 'Throughput', 'Latency', 'Delay × bandwidth', 'Jitter'][p['i']]
    raise KeyError(k)


async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.launch(executable_path=os.environ.get('CHROME', '/usr/bin/google-chrome'), args=['--no-sandbox'])
        pg = await b.new_page()
        await pg.goto(APP.as_uri())
        V = 'window.BandwidthLatencyVisualizer'

        # 1. model on random inputs
        cases = []
        for _ in range(2000):
            k = random.randint(1, 4)
            links = [[random.choice([1e3, 56e3, 1e6, 10e6, 45e6, 100e6, 1e9, 10e9, 3e6 * random.randint(1, 50)]), random.choice([0, 1, 100, 2300, 1e5, 4e6, 7.1572e7, random.randint(0, 10**7)]),
                      random.choice(list(SPEED)), random.choice([0, 0, 0.001, 0.0025, 0.01])] for _ in range(k)]
            cases.append({'bits': random.choice([8, 512, 12000, 72000, 8e6, random.randint(1, 10**9)]), 'n': random.choice([1, 2, 5, 37, 100]), 'links': links,
                          'rtt': random.choice([0, 0.001, 0.02, 0.1, 0.25]), 'win': random.choice([8000, 512000, 1e6])})
        res = await pg.evaluate("""(cs) => { const M = window.BandwidthLatencyVisualizer; return cs.map(c => { const L = c.links.map(l => ({ bw: l[0], dist: l[1], medium: l[2], q: l[3] }));
          const bw = L[0].bw; return { one: M.pathTimes(c.bits, L).total, msg: M.messageTime(c.bits, c.n, L), tr: M.transfer(c.bits, bw, c.rtt), wt: c.rtt > 0 ? M.windowThroughput(c.win, bw, c.rtt) : null,
          bw: M.bitWidth(bw), bl: M.bitLength(bw, L[0].medium), dx: M.dxb(c.rtt, bw) }; }); }""", cases)
        for c, r in zip(cases, res):
            L = [(Fx(bw), Fx(d), m, Fx(q)) for bw, d, m, q in c['links']]
            bits, bw0, rtt = Fx(c['bits']), L[0][0], Fx(c['rtt'])
            check(close(r['one'], one_packet(bits, L)), f"pathTimes {c}")
            check(close(r['msg'], simulate(bits, c['n'], L)), f"messageTime {c} app {r['msg']} sim {float(simulate(bits, c['n'], L))}")
            t = rtt + bits / bw0
            check(close(r['tr']['time'], t) and close(r['tr']['thr'], bits / t) and close(r['tr']['trans'], bits / bw0), f'transfer {c}')
            if r['wt'] is not None: check(close(r['wt'], min(bw0, Fx(c['win']) / rtt)), f'window {c}')
            check(close(r['bw'], 1 / bw0) and close(r['bl'], SPEED[L[0][2]] / bw0) and close(r['dx'], rtt * bw0), f'bit/pipe {c}')
        print('model cases:', len(cases))

        # 2. challenge keys
        counts = {}
        for lvl in 'EMH':
            qs = await pg.evaluate(f"""(n) => {{ const out = []; for (let i = 0; i < n; i++) out.push(...{V}.makeRound('{lvl}', 10).map(q => ({{ p: q.p, input: q.input, answer: q.answer, choices: q.choices || null, unit: q.unit || null, text: q.text, explain: q.explain, hint: q.hint }}))); return out; }}""", ROUNDS)
            for q in qs:
                k = q['p']['kind']; counts[k] = counts.get(k, 0) + 1
                check(q['text'] and q['explain'] and q['hint'], f'missing text {q}')
                check('pod' not in (q['text'] + q['explain'] + q['hint']).lower(), 'the word pod')
                if q['input'] == 'number':
                    check(close(q['answer'], key(q['p'])), f"{lvl} {k} app {q['answer']} python {float(key(q['p']))} {q['p']}")
                    check(q['answer'] > 0, f'nonpositive answer {q}')
                else:
                    ch = q['choices']; check(len(set(ch)) == len(ch), f'duplicate choices {ch}')
                    check(ch[q['answer']] == choice_key(q['p']), f"{lvl} {k} app {ch[q['answer']]} python {choice_key(q['p'])} {q['p']}")
            print(f'level {lvl}: {len(qs)} questions re-checked')
        print('question kinds:', dict(sorted(counts.items())))

        # 3. ping output and codes
        pr = await pg.evaluate(f"""() => {{ const r = {V}.pingRun(1500, [{{ bw: 100e6, dist: 100, medium: 'copper' }}, {{ bw: 1e9, dist: 20000, medium: 'fiber' }}, {{ bw: 10e6, dist: 500000, medium: 'fiber' }}], 0, 0, 5, '192.168.20.20'); return r; }}""")
        base = 2 * one_packet(12000, [(F(100 * 10**6), F(100), 'copper', F(0)), (F(10**9), F(20000), 'fiber', F(0)), (F(10**7), F(500000), 'fiber', F(0))]) * 1000
        check(all(close(x, base) for x in pr['rtts']), f"ping without queues {pr['rtts']} vs {float(base)}")
        check(pr['lines'][0] == 'PING 192.168.20.20 (192.168.20.20) 1472(1500) bytes of data.', pr['lines'][0])
        check(pr['lines'][1].startswith('1480 bytes from 192.168.20.20: icmp_seq=1 ttl=63 time='), pr['lines'][1])
        cd = await pg.evaluate(f"{V}.code('H', 134, 9, 10)")
        ok = await pg.evaluate(f"{V}.checkCode('{cd}')")
        bad = await pg.evaluate(f"{V}.checkCode('{cd.replace('134', '154')}')")
        check(ok and ok['score'] == 134 and bad is False, f'codes {cd} {ok} {bad}')
        print('ping line:', pr['lines'][1], '| code', cd, 'valid:', bool(ok), 'edited rejected:', bad is False)
        await b.close()
    print('FAILURES', len(fails))
    for f in fails[:20]: print('  ', f)


asyncio.run(main())
