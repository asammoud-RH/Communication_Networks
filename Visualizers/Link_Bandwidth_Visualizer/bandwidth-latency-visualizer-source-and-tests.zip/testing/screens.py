# Screenshot every lesson, the calculator and the challenge at laptop and phone size (full page).
import asyncio, sys, os
from playwright.async_api import async_playwright
H, OUT = sys.argv[1], sys.argv[2]
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch()
        for name, vp in [('laptop', {'width': 1366, 'height': 768}), ('phone', {'width': 390, 'height': 844})]:
            pg = await b.new_page(viewport=vp)
            shots = [('map', 'mode=learn&lesson=0')] + [('l%d' % i, 'mode=learn&lesson=%d' % i) for i in range(1, 7)] + [('calc', 'mode=calc'), ('chal', 'mode=challenge'), ('home', '')]
            for tag, q in shots:
                await pg.goto('file://' + H + ('?' + q if q else ''))
                await pg.wait_for_timeout(400)
                await pg.screenshot(path=os.path.join(OUT, '%s-%s.png' % (name, tag)), full_page=True)
                await pg.screenshot(path=os.path.join(OUT, '%s-%s-fold.png' % (name, tag)), full_page=False)
            await pg.close()
        await b.close()
asyncio.run(main())
