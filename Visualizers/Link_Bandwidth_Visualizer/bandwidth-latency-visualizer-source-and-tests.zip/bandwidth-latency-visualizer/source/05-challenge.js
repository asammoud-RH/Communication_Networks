
/* ===================================================== CHALLENGE: question generators
   Each question carries p: its kind and inputs, so the logic test can re-check the answer independently.
   Number answers are right within 1%. */
function numQ(tag, text, answer, unit, hint, explain, p) { return { tag: tag, text: text, input: 'number', answer: answer, unit: unit, hint: hint, explain: explain, p: p }; }
function choiceQ(tag, text, right, wrongs, hint, explain, p) {
  var ch = [right]; wrongs.forEach(function (w) { if (ch.indexOf(w) < 0) ch.push(w); });
  ch = shuffle(ch); return { tag: tag, text: text, input: 'choice', choices: ch, answer: ch.indexOf(right), hint: hint, explain: explain, p: p };
}
var KM_FIBER = function () { return rnd(1, 60) * 100; };
/* Easy */
function unitQ() {
  var v = rnd(1, 4);
  if (v === 1) { var n = pick([2, 5, 12, 25, 40, 100, 250]); return numQ('unit', 'A file is <b>' + n + ' MB</b>. How many <b>megabits (Mb)</b> is that?', n * 8, 'Mb', 'A byte is 8 bits.', n + ' MB × 8 = ' + n * 8 + ' Mb.', { kind: 'mb2mbit', n: n }); }
  if (v === 2) { var k = pick([2, 4, 8, 16, 64, 100]); return numQ('unit', 'How many <b>bytes</b> are in <b>' + k + ' KiB</b>?', k * 1024, 'bytes', 'KiB is a binary unit: powers of 2.', '1 KiB = 1,024 bytes, so ' + k + ' KiB = ' + fmt(k * 1024) + ' bytes.', { kind: 'kib', n: k }); }
  if (v === 3) { var r = pick([8, 40, 100, 160, 1000]); return numQ('unit', 'A link carries <b>' + r + ' Mbps</b>. How many <b>MB per second</b> is that?', r / 8, 'MB/s', 'Divide bits by 8 to get bytes.', r + ' Mbps ÷ 8 = ' + fmtN(r / 8) + ' MB/s.', { kind: 'mbps2mbs', n: r }); }
  var m = pick([1, 2, 4, 10]); return numQ('unit', 'How many <b>bytes</b> are in <b>' + m + ' MiB</b>?', m * 1048576, 'bytes', '1 MiB = 2²⁰ bytes.', '1 MiB = 1,048,576 bytes, so ' + m + ' MiB = ' + fmt(m * 1048576) + ' bytes.', { kind: 'mib', n: m });
}
var COMPARE = [
  [['1 MB', 8e6], ['1 MiB', 8 * 1048576]], [['100 Mbps', 100e6], ['10 MB per second', 80e6]], [['1 Gb', 1e9], ['100 MB', 8e8]],
  [['64 KiB', 8 * 65536], ['65 KB', 8 * 65000]], [['1 Gbps', 1e9], ['100 MB per second', 8e8]], [['500 kb', 5e5], ['64 KB', 512000]]
];
function compareQ() {
  var c = pick(COMPARE), a = c[0], b = c[1], right = a[1] > b[1] ? a[0] : b[0], other = right === a[0] ? b[0] : a[0];
  return choiceQ('unit', 'Which is <b>bigger</b>: <b>' + a[0] + '</b> or <b>' + b[0] + '</b>?', right, [other], 'Turn both into bits. MB and KB are powers of 10; MiB and KiB are powers of 2. A lowercase b is a bit.',
    a[0] + ' = ' + fmtN(a[1], 6) + ' bits and ' + b[0] + ' = ' + fmtN(b[1], 6) + ' bits, so ' + right + ' is bigger.', { kind: 'compare', a: a[1], b: b[1], la: a[0], lb: b[0] });
}
function bitWidthQ() {
  if (Math.random() < 0.6) { var r = pick([1, 2, 4, 5, 10, 20, 25, 50, 100]); return numQ('bit', 'A link runs at <b>' + r + ' Mbps</b>. How long does one bit last, in <b>µs</b> (microseconds)?', 1 / r, 'µs', 'Bit width = 1 ÷ bandwidth. At 1 Mbps it is 1 µs.', '1 ÷ ' + r + ' Mbps = ' + fmtN(1 / r) + ' µs.', { kind: 'bitw_us', r: r }); }
  var g = pick([1, 2, 10, 25, 40, 100]); return numQ('bit', 'A link runs at <b>' + g + ' Gbps</b>. How long does one bit last, in <b>ns</b> (nanoseconds)?', 1 / g, 'ns', 'Bit width = 1 ÷ bandwidth. At 1 Gbps it is 1 ns.', '1 ÷ ' + g + ' Gbps = ' + fmtN(1 / g) + ' ns.', { kind: 'bitw_ns', r: g });
}
function propQ() {
  var v = rnd(1, 3);
  if (v === 1) { var d = KM_FIBER(); return numQ('prop', 'What is the propagation delay over <b>' + fmt(d) + ' km of fiber</b> (2 × 10⁸ m/s), in <b>ms</b>?', d / 200, 'ms', 'Propagation = distance ÷ speed. Fiber covers 200 km per ms.', fmt(d * 1000) + ' m ÷ 2 × 10⁸ m/s = ' + fmtN(d / 200) + ' ms.', { kind: 'prop', m: d * 1000, medium: 'fiber', unit: 'ms' }); }
  if (v === 2) { var m = pick([23, 46, 115, 230, 460, 690]); return numQ('prop', 'What is the propagation delay over <b>' + m + ' m of copper cable</b> (2.3 × 10⁸ m/s), in <b>µs</b>?', m / 230, 'µs', 'Copper covers 230 m per µs.', m + ' m ÷ 2.3 × 10⁸ m/s = ' + fmtN(m / 230) + ' µs.', { kind: 'prop', m: m, medium: 'copper', unit: 'us' }); }
  var km = pick([35786, 36000, 30000, 15000, 3000]); return numQ('prop', 'A radio signal travels <b>' + fmt(km) + ' km</b> (3 × 10⁸ m/s). What is the propagation delay, in <b>ms</b>?', km / 300, 'ms', 'Radio covers 300 km per ms.', fmt(km * 1000) + ' m ÷ 3 × 10⁸ m/s = ' + fmtN(km / 300) + ' ms.', { kind: 'prop', m: km * 1000, medium: 'radio', unit: 'ms' });
}
function transQ() {
  var s = pick([64, 500, 1000, 1500, 9000]), b = pick([1, 10, 100, 1000]);
  return numQ('trans', 'How long does it take to transmit a <b>' + fmt(s) + '-byte</b> packet at <b>' + fmtRate(b * 1e6) + '</b>, in <b>µs</b>?', s * 8 / b, 'µs', 'Transmit = size in bits ÷ bandwidth. Bits ÷ Mbps gives µs.', fmt(s) + ' × 8 = ' + fmt(s * 8) + ' bits, and ' + fmt(s * 8) + ' ÷ ' + fmtRate(b * 1e6) + ' = ' + fmtN(s * 8 / b) + ' µs.', { kind: 'trans_us', s: s, b: b });
}
var TERMS = [
  ['Bandwidth', 'how many bits per second a link can carry'],
  ['Throughput', 'how many bits per second a transfer actually delivers, measured from start to finish'],
  ['Latency', 'how long one packet takes to get from one host to the other'],
  ['Delay × bandwidth', 'how many bits fit on the link at one time'],
  ['Jitter', 'how much the delay changes from one packet to the next']
];
function termQ() {
  var i = rnd(0, TERMS.length - 1), others = shuffle(TERMS.filter(function (t, j) { return j !== i; }).map(function (t) { return t[0]; })).slice(0, 3);
  return choiceQ('term', 'Which term means <b>' + TERMS[i][1] + '</b>?', TERMS[i][0], others, 'In the pipe picture: width, length, volume, the rate you actually get, and how much the waiting changes.',
    TERMS[i][0] + ' is ' + TERMS[i][1] + '. ' + (i === 0 ? 'It is the pipe\'s width, set by the link.' : i === 1 ? 'It is never more than the slowest link\'s bandwidth, and waiting for the RTT makes it lower.' : i === 2 ? 'It adds up queue, transmit, and propagation delay.' : i === 3 ? 'It is the pipe\'s volume.' : 'Queues that grow and shrink cause it.'), { kind: 'term', i: i });
}
/* Medium */
function latQ() {
  var s, b, d, q, T, P;
  do { s = pick([500, 1000, 1500, 9000]); b = pick([10, 100, 1000]); d = rnd(1, 50) * 100; q = pick([0, 1, 2, 5]); T = s * 8 / b / 1000; P = d / 200; }
  while (T < 0.05 * (q + T + P) || P < 0.05 * (q + T + P) || (q > 0 && q < 0.05 * (q + T + P)));   // leaving out any part gives a clearly wrong answer
  return numQ('lat', 'A <b>' + fmt(s) + '-byte</b> packet waits <b>' + q + ' ms</b> in a queue, then crosses <b>' + fmt(d) + ' km of fiber</b> at <b>' + fmtRate(b * 1e6) + '</b>. What is its latency, in <b>ms</b>?', q + T + P, 'ms',
    'Add the queue, the transmit time (bits ÷ bandwidth), and the propagation delay (200 km per ms in fiber).', q + ' + ' + fmtN(T) + ' (transmit) + ' + fmtN(P) + ' (propagation) = ' + fmtN(q + T + P) + ' ms.', { kind: 'lat', s: s, b: b, d: d, q: q });
}
function rttQ() {
  var d = rnd(1, 20) * 500;
  return numQ('prop', 'Two hosts are <b>' + fmt(d) + ' km</b> apart over fiber. Ignoring transmit and queuing time, what is the <b>RTT</b> (round-trip time), in <b>ms</b>?', d / 100, 'ms', 'A round trip crosses the distance twice. Fiber covers 200 km per ms.',
    '2 × ' + fmt(d) + ' km ÷ 200 km per ms = ' + fmtN(d / 100) + ' ms.', { kind: 'rtt', d: d });
}
function bitLenQ() {
  var b = pick([1, 10, 100, 1000, 10000]), med = pick(['copper', 'fiber']), v = SPEED[med] / (b * 1e6);
  return numQ('bit', 'How long is one bit on <b>' + MEDIUM_NAME[med] + '</b> (' + (med === 'fiber' ? '2.0' : '2.3') + ' × 10⁸ m/s) at <b>' + fmtRate(b * 1e6) + '</b>, in <b>meters</b>?', v, 'm', 'Bit length = signal speed ÷ bandwidth.',
    fmtN(SPEED[med]) + ' m/s ÷ ' + fmtN(b * 1e6) + ' bits/s = ' + fmtN(v) + ' m per bit.', { kind: 'bitlen', b: b, medium: med });
}
function dxbQ() {
  var d = pick([5, 10, 20, 25, 40, 50, 80, 100]), b = pick([10, 45, 100, 1000]);
  return numQ('pipe', 'A link has a one-way delay of <b>' + d + ' ms</b> and a bandwidth of <b>' + b + ' Mbps</b>. How many <b>KB</b> fit in the pipe (one-way delay × bandwidth)?', d * b / 8, 'KB', 'ms × Mbps gives kilobits. Divide by 8 for kilobytes.',
    d + ' ms × ' + b + ' Mbps = ' + fmt(d * b) + ' kb, and ÷ 8 = ' + fmtN(d * b / 8) + ' KB.', { kind: 'dxb', d: d, b: b });
}
function onWireQ() {
  var d = rnd(1, 20) * 100, b = pick([10, 100, 1000]), v = d * 1000 / 2e8 * b * 1e6;
  return numQ('pipe', 'A sender sends without a pause over <b>' + fmt(d) + ' km of fiber</b> at <b>' + fmtRate(b * 1e6) + '</b>. How many <b>bits</b> are on the link at once?', v, 'bits', 'Bits on the link = propagation delay × bandwidth.',
    'Propagation = ' + fmtN(d / 200) + ' ms, and ' + fmtN(d / 200) + ' ms × ' + fmtRate(b * 1e6) + ' = ' + fmt(v) + ' bits.', { kind: 'onwire', d: d, b: b });
}
function domQ() {
  var s, b, d, med, T, P;
  do { s = pick([64, 500, 1500, 9000, 1e5, 1e6]); b = pick([1e6, 10e6, 100e6, 1e9, 10e9]); med = pick(['fiber', 'copper']); d = pick([0.1, 1, 10, 100, 1000, 5000]) * 1000; T = s * 8 / b; P = d / SPEED[med]; } while (Math.max(T, P) / Math.min(T, P) < 3);
  var right = T > P ? 'Transmit' : 'Propagation';
  return choiceQ('lat', 'A <b>' + fmtBytes(s * 8, false) + '</b> message crosses <b>' + fmtDist(d) + ' of ' + MEDIUM_NAME[med] + '</b> at <b>' + fmtRate(b) + '</b>. Which delay is bigger?', right, ['Transmit', 'Propagation', 'They are about equal'],
    'Work out both: size × 8 ÷ bandwidth, and distance ÷ signal speed.', 'Transmit = ' + fmtT(T) + ' and propagation = ' + fmtT(P) + ', so ' + right.toLowerCase() + ' dominates.', { kind: 'dom', s: s, b: b, d: d, medium: med });
}
/* Hard */
function thrQ() {
  var mb, b, r, t, v;
  do { mb = pick([1, 2, 5, 10, 25, 100]); b = pick([10, 45, 100, 1000]); r = pick([20, 40, 50, 80, 100, 200]); t = r / 1000 + mb * 8 / b; v = mb * 8 / t; } while (v > 0.9 * b);   // never answerable with the bandwidth itself
  return numQ('thr', 'A <b>' + mb + ' MB</b> file is fetched over a <b>' + fmtRate(b * 1e6) + '</b> link with an <b>RTT of ' + r + ' ms</b>. What is the effective throughput, in <b>Mbps</b>?', v, 'Mbps', 'Transfer time = RTT + size ÷ bandwidth. Throughput = size ÷ transfer time.',
    'Transfer time = ' + r + ' ms + ' + mb * 8 + ' Mb ÷ ' + b + ' Mbps = ' + fmtT(t) + '. Throughput = ' + mb * 8 + ' Mb ÷ ' + fmtT(t) + ' = ' + fmtN(v) + ' Mbps.', { kind: 'thr', mb: mb, b: b, r: r });
}
function windowQ() {
  if (Math.random() < 0.5) {
    var r = pick([10, 20, 40, 50, 80, 100, 200]), b = pick([10, 45, 100, 1000]);
    return numQ('pipe', 'A path has an <b>RTT of ' + r + ' ms</b> and a bandwidth of <b>' + b + ' Mbps</b>. How big a window, in <b>KB</b>, does the sender need to keep the pipe full?', r * b / 8, 'KB', 'The sender must keep sending for a whole RTT: window = RTT × bandwidth.',
      r + ' ms × ' + b + ' Mbps = ' + fmt(r * b) + ' kb = ' + fmtN(r * b / 8) + ' KB.', { kind: 'win', r: r, b: b });
  }
  var w = pick([16, 32, 64, 128]), rr = pick([10, 20, 50, 100, 200]), bb = 1000, v = w * 8 / rr;
  return numQ('pipe', 'A sender may have only <b>' + w + ' KB</b> in flight. The path has an <b>RTT of ' + rr + ' ms</b> and a bandwidth of <b>1 Gbps</b>. What is the most throughput it can get, in <b>Mbps</b>?', v, 'Mbps', 'Each RTT the sender can send one window. Throughput = window ÷ RTT.',
    w + ' KB = ' + w * 8 + ' kb, and ' + w * 8 + ' kb ÷ ' + rr + ' ms = ' + fmtN(v) + ' Mbps: far below the 1 Gbps link.', { kind: 'winthr', w: w, r: rr, b: bb });
}
function pathQ() {
  var k = pick([2, 3]), links = [], q = [0];
  for (var i = 0; i < k; i++) links.push({ bw: pick([10e6, 100e6, 1e9]), dist: pick([0.1, 1, 10, 100, 500, 1000]) * 1000, medium: 'fiber', q: 0 });
  for (var j = 1; j < k; j++) { var qq = pick([0, 0, 1, 2]); links[j].q = qq / 1000; q.push(qq); }
  var tot = pathTimes(12000, links).total * 1000, names = PATH_NAMES[k], extra = 0;
  for (var m = 1; m < k; m++) extra += 12000 / links[m].bw * 1000;
  if (extra < 0.05 * tot) return pathQ();   // counting the transmit time only once must give a clearly wrong answer
  return numQ('path', 'A <b>1500-byte</b> packet goes ' + links.map(function (L, i) { return (i ? (L.q ? 'waits <b>' + q[i] + ' ms</b> at the ' + names[i] + ', then ' : 'then ') : '') + 'crosses <b>' + fmtDist(L.dist) + ' of fiber</b> at <b>' + fmtRate(L.bw) + '</b>'; }).join(', ') + '. Every device stores and forwards. What is the latency from Host A to Host B, in <b>ms</b>?', tot, 'ms',
    'For each link add the queue, 12,000 bits ÷ bandwidth, and length ÷ 2 × 10⁸ m/s.', pathTimes(12000, links).hops.map(function (h) { return fmtT(h.q + h.T + h.P, 4); }).join(' + ') + ' = ' + fmtN(tot) + ' ms.', { kind: 'path', links: links.map(function (L) { return [L.bw, L.dist, L.q * 1000]; }) });
}
function msgQ() {
  var n = pick([5, 10, 20, 100]), b1 = pick([100e6, 1e9]), b2 = pick([10e6, 100e6]), d1 = pick([100, 1000]), d2 = pick([10e3, 100e3, 1000e3]);
  var links = [{ bw: b1, dist: d1, medium: 'fiber', q: 0 }, { bw: b2, dist: d2, medium: 'fiber', q: 0 }], first = pathTimes(12000, links).total, bott = 12000 / Math.min(b1, b2), v = messageTime(12000, n, links) * 1000;
  return numQ('path', 'Host A sends <b>' + n + ' packets of 1500 bytes</b> back to back to a router over <b>' + fmtDist(d1) + '</b> at <b>' + fmtRate(b1) + '</b>. The router sends them on over <b>' + fmtDist(d2) + '</b> at <b>' + fmtRate(b2) + '</b>. All fiber. When does the last packet reach Host B, in <b>ms</b>?', v, 'ms',
    'The first packet takes the full store-and-forward time. After that, one packet arrives every bottleneck transmit time.', 'The first arrives at ' + fmtT(first, 4) + '. The rest follow every ' + fmtT(bott, 3) + ' (the slower link): ' + fmtT(first, 4) + ' + ' + (n - 1) + ' × ' + fmtT(bott, 3) + ' = ' + fmtN(v) + ' ms.', { kind: 'msg', n: n, b1: b1, b2: b2, d1: d1, d2: d2 });
}
function fasterQ() {
  var mb, b, r, a, c;
  do { mb = pick([0.01, 0.1, 1, 10, 100]); b = pick([10, 100, 1000]); r = pick([10, 50, 100, 200]); a = r / 1000 + mb * 8 / (10 * b); c = r / 2000 + mb * 8 / b; } while (Math.max(a, c) / Math.min(a, c) < 1.2);
  var right = a < c ? '10 times the bandwidth' : 'Half the RTT';
  return choiceQ('thr', 'You fetch a <b>' + fmtBytes(mb * 8e6, false) + '</b> file over <b>' + b + ' Mbps</b> with an <b>RTT of ' + r + ' ms</b>. Which makes the transfer finish sooner?', right, ['10 times the bandwidth', 'Half the RTT'],
    'Transfer time = RTT + size ÷ bandwidth. Which part is bigger now?', '10 times the bandwidth: ' + fmtT(a) + '. Half the RTT: ' + fmtT(c) + '. ' + (a < c ? 'The transfer is bandwidth-bound.' : 'The transfer is latency-bound.'), { kind: 'faster', mb: mb, b: b, r: r });
}
function savedQ() {
  var mb = pick([1, 10, 100, 500]), b1 = pick([10, 50, 100]), b2 = b1 * pick([2, 4, 10]), r = pick([20, 50, 100]), v = (mb * 8 / b1 - mb * 8 / b2) * 1000;
  return numQ('thr', 'A <b>' + mb + ' MB</b> transfer with an <b>RTT of ' + r + ' ms</b> moves from a <b>' + b1 + ' Mbps</b> link to a <b>' + b2 + ' Mbps</b> link. How many <b>ms</b> sooner does it finish?', v, 'ms', 'The RTT is the same before and after. Only the transmit time changes.',
    mb * 8 + ' Mb ÷ ' + b1 + ' Mbps − ' + mb * 8 + ' Mb ÷ ' + b2 + ' Mbps = ' + fmtN(v) + ' ms. The RTT cancels out.', { kind: 'saved', mb: mb, b1: b1, b2: b2, r: r });
}
var GEN = {
  E: [unitQ, compareQ, bitWidthQ, propQ, transQ, termQ],
  M: [latQ, rttQ, bitLenQ, dxbQ, onWireQ, domQ],
  H: [thrQ, windowQ, pathQ, msgQ, fasterQ, savedQ]
};
function makeRound(level, n) {
  var out = [], bag = [];
  while (out.length < n) { if (!bag.length) bag = shuffle(GEN[level].slice()); out.push(bag.pop()()); }
  return out;
}

/* ===================================================== CHALLENGE: play */
var BADGES = [
  { id: 'first', b: '🎯', t: 'First round', d: 'Finish a challenge round' },
  { id: 'perfect', b: '💯', t: 'Perfect 10', d: 'Answer all ten questions right' },
  { id: 'streak', b: '🔥', t: 'On fire', d: 'Five right answers in a row' },
  { id: 'unit', b: '📐', t: 'Unit master', d: 'Three or more unit and bit questions right in a round, with none missed' },
  { id: 'pipe', b: '🛢️', t: 'Pipe filler', d: 'Every delay × bandwidth question right in a round (at least two)' },
  { id: 'bottleneck', b: '🧭', t: 'Bottleneck finder', d: 'Three path or throughput questions right in a Hard round' },
  { id: 'sprint', b: '⚡', t: 'Speed runner', d: 'Eight right answers in a sprint' },
  { id: 'learned', b: '📘', t: 'Scholar', d: 'Finish all six lessons' }
];
function earn(id) { if (progress.badges[id]) return false; progress.badges[id] = Date.now(); store.set('progress', progress); return true; }
function renderShelf() {
  $('#badgeShelf').innerHTML = BADGES.map(function (b) { return '<span class="badge' + (progress.badges[b.id] ? '' : ' locked') + '" title="' + esc(b.d) + '"><span class="b" aria-hidden="true">' + b.b + '</span>' + b.t + '<span class="sr" style="position:absolute;left:-9999px">' + (progress.badges[b.id] ? ' (earned)' : ' (not yet earned)') + '</span></span>'; }).join('');
  var best = progress.best; $('#bestLine').textContent = 'Best scores: Easy ' + (best.E || 0) + ', Medium ' + (best.M || 0) + ', Hard ' + (best.H || 0) + (best.S ? ', Sprint ' + best.S : '');
}
var game = null;
function startRound() {
  var level = ($('.level[aria-pressed=true]') || $('.level')).getAttribute('data-level'), sprint = $('#sprint').checked;
  game = { level: level, sprint: sprint, qs: makeRound(level, sprint ? 40 : 10), i: 0, score: 0, streak: 0, bestStreak: 0, right: 0, answered: 0, log: [], tags: {}, ends: sprint ? Date.now() + 120000 : 0, timer: null };
  $('#ch-setup').hidden = true; $('#ch-end').hidden = true; $('#ch-play').hidden = false;
  $('#q_timerbar').hidden = !sprint;
  if (sprint) game.timer = setInterval(tick, 250);
  showQ();
}
function tick() {
  if (!game) return; var left = game.ends - Date.now();
  $('#q_timer').style.width = Math.max(0, left / 1200) + '%';
  if (left <= 0) { clearInterval(game.timer); endRound(); }
}
function chips() {
  $('#q_n').textContent = game.sprint ? 'Answered ' + game.answered : 'Question ' + Math.min(game.i + 1, game.qs.length) + ' of ' + game.qs.length;
  $('#q_score').textContent = '★ ' + game.score;
  $('#q_streak').textContent = '🔥 streak ' + game.streak;
}
function showQ() {
  if (!game) return; chips();
  var q = game.qs[game.i], body = $('#q_body'); q.hinted = false;
  var answerUI = q.input === 'choice'
    ? '<div class="choices">' + q.choices.map(function (c, i) { return '<button class="choice" data-i="' + i + '">' + esc(c) + '</button>'; }).join('') + '</div>'
    : '<div class="row"><input type="number" step="any" id="q_in" aria-label="Your answer in ' + esc(q.unit) + '"><span>' + esc(q.unit) + '</span><button class="btn" id="q_ok">Check</button></div>';
  body.innerHTML = '<p class="qtext">' + q.text + '</p>' + answerUI +
    '<div class="row"><button class="btn alt small" id="q_hint">Hint (−3)</button></div><div class="feedback" id="q_fb" aria-live="polite"></div><div class="row" id="q_nextrow" hidden><button class="btn amber" id="q_next">Next →</button></div>';
  $('#q_hint').onclick = function () { if (q.hinted || q.done) return; q.hinted = true; var fb = $('#q_fb'); fb.className = 'feedback'; fb.style.background = 'var(--amber-soft)'; fb.innerHTML = '💡 ' + q.hint; };
  if (q.input === 'choice') $$('.choice', body).forEach(function (b) { b.onclick = function () { answer(+b.getAttribute('data-i'), b); }; });
  else { $('#q_ok').onclick = function () { answer(readAnswer('#q_in')); }; $('#q_in').onkeydown = function (e) { if (e.key === 'Enter') answer(readAnswer('#q_in')); }; $('#q_in').focus(); }
  $('#q_next').onclick = nextQ;
}
function rightText(q) { return q.input === 'choice' ? q.choices[q.answer] : fmtN(q.answer, 4) + ' ' + q.unit; }
function answer(v, btn) {
  var q = game.qs[game.i]; if (q.done) return;
  if (q.input === 'number' && !isFinite(v)) { var f0 = $('#q_fb'); f0.className = 'feedback'; f0.style.background = ''; f0.innerHTML = 'Type a number first.'; return; }
  q.done = true;
  var ok = q.input === 'choice' ? v === q.answer : near(v, q.answer, 0.01), fb = $('#q_fb'); fb.style.background = '';
  game.answered++;
  if (ok) {
    game.right++; game.streak++; game.bestStreak = Math.max(game.bestStreak, game.streak);
    var pts = 10 + Math.min(game.streak - 1, 5) * 2 - (q.hinted ? 3 : 0); game.score += pts;
    game.tags[q.tag] = (game.tags[q.tag] || 0) + 1;
    fb.className = 'feedback ok pop'; fb.innerHTML = '<b>Correct! +' + pts + '</b>' + (game.streak >= 3 ? ' 🔥 ' + game.streak + ' in a row' : '') + '<br>' + q.explain;
  } else {
    game.streak = 0; game.tags[q.tag + '_miss'] = 1;
    fb.className = 'feedback bad'; fb.innerHTML = '<b>Not quite.</b> The answer is <b>' + esc(rightText(q)) + '</b>.<br>' + q.explain;
  }
  game.log.push({ q: q.text, ok: ok, right: rightText(q) });
  if (q.input === 'choice') $$('#q_body .choice').forEach(function (b, i) { b.disabled = true; if (i === q.answer) b.classList.add('right'); else if (b === btn) b.classList.add('wrong'); });
  else { $('#q_in').disabled = true; $('#q_ok').disabled = true; }
  $('#q_hint').disabled = true; $('#q_nextrow').hidden = false; $('#q_next').focus(); chips();
}
function nextQ() { game.i++; if (game.i >= game.qs.length || (game.sprint && Date.now() > game.ends)) endRound(); else showQ(); }
function code(level, score, right, total) {   // completion code with a checksum (deters casual editing; not secure)
  var s = 'BL|' + level + '|' + score + '|' + right + '|' + total, h = 2166136261;
  for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
  return level + score + '-' + right + 'of' + total + '-' + (h % 1679616).toString(36).toUpperCase().padStart(4, '0');
}
function checkCode(c) {
  var m = /^([EMHS])(\d+)-(\d+)of(\d+)-([0-9A-Z]{4})$/.exec(String(c).trim().toUpperCase().replace('OF', 'of'));
  if (!m) return null; return code(m[1], +m[2], +m[3], +m[4]) === m[0] ? { level: m[1], score: +m[2], right: +m[3], total: +m[4] } : false;
}
function endRound() {
  if (!game) return; clearInterval(game.timer);
  var g = game, total = g.sprint ? g.answered : g.qs.length, pct = total ? g.right / total : 0, stars = pct >= 0.9 ? 3 : pct >= 0.7 ? 2 : pct >= 0.5 ? 1 : 0;
  var lvl = g.sprint ? 'S' : g.level, fresh = [];
  if (g.answered && earn('first')) fresh.push('first');
  if (!g.sprint && g.right === 10 && earn('perfect')) fresh.push('perfect');
  if (g.bestStreak >= 5 && earn('streak')) fresh.push('streak');
  if ((g.tags.unit || 0) + (g.tags.bit || 0) >= 3 && !g.tags.unit_miss && !g.tags.bit_miss && earn('unit')) fresh.push('unit');
  if ((g.tags.pipe || 0) >= 2 && !g.tags.pipe_miss && earn('pipe')) fresh.push('pipe');
  if (g.level === 'H' && !g.sprint && (g.tags.path || 0) + (g.tags.thr || 0) >= 3 && earn('bottleneck')) fresh.push('bottleneck');
  if (g.sprint && g.right >= 8 && earn('sprint')) fresh.push('sprint');
  var newBest = g.score > (progress.best[lvl] || 0); if (newBest) progress.best[lvl] = g.score;
  store.set('progress', progress); addXP(g.score);
  var cd = code(lvl, g.score, g.right, total), lname = { E: 'Easy', M: 'Medium', H: 'Hard', S: 'Sprint' }[lvl];
  $('#ch-play').hidden = true; var end = $('#ch-end'); end.hidden = false;
  end.innerHTML = '<h2>' + (stars === 3 ? 'Outstanding!' : stars === 2 ? 'Great work!' : stars === 1 ? 'Good start!' : 'Keep practicing!') + '</h2>' +
    '<div class="stars" aria-label="' + stars + ' of 3 stars">' + '★★★'.slice(0, stars) + '<span style="color:#D3E3EC">' + '★★★'.slice(0, 3 - stars) + '</span></div>' +
    '<p style="font-size:19px"><b>' + g.score + ' points</b> · ' + g.right + ' of ' + total + ' right · best streak ' + g.bestStreak + (newBest ? ' · <span class="oneway">new best for ' + lname + '!</span>' : '') + '</p>' +
    (fresh.length ? '<h3>New badges</h3><div class="badges">' + fresh.map(function (id) { var b = BADGES.filter(function (x) { return x.id === id; })[0]; return '<span class="badge pop"><span class="b">' + b.b + '</span>' + b.t + '</span>'; }).join('') + '</div>' : '') +
    '<h3>Completion code</h3><p>If you are asked for it, copy this code.</p><span class="code" id="ccode">' + cd + '</span> <button class="btn alt small" id="ccopy">Copy</button>' +
    '<div class="row" style="margin-top:16px"><button class="btn amber" id="again">Play again</button>' + (g.level !== 'H' ? '<button class="btn" id="harder">Try ' + (g.level === 'E' ? 'Medium' : 'Hard') + '</button>' : '') + '<button class="btn alt" id="toLearn">Review the lessons</button></div>' +
    '<details><summary>Review your answers</summary><ol class="list">' + g.log.map(function (l) { return '<li>' + (l.ok ? '<span class="yes">✓</span> ' : '<span class="no">✗</span> ') + l.q + ' <i>Answer: ' + esc(l.right) + '</i></li>'; }).join('') + '</ol></details>';
  $('#ccopy').onclick = function () { copyText(cd, $('#ccopy')); };
  $('#again').onclick = function () { startRound(); };
  if ($('#harder')) $('#harder').onclick = function () { setLevel(g.level === 'E' ? 'M' : 'H'); startRound(); };
  $('#toLearn').onclick = function () { go('learn'); };
  if (stars === 3) burst();
  game = null; renderShelf(); writeLink();
}
function burst() {
  if (reduceMotion) return;
  var b = document.createElement('div'); b.className = 'burst'; b.setAttribute('aria-hidden', 'true');
  for (var i = 0; i < 40; i++) { var s = document.createElement('span'); s.textContent = pick(['★', '✦', '●', '▲']); s.style.left = rnd(0, 100) + '%'; s.style.color = pick(['#00A2D7', '#F5A524', '#13A88A', '#7B61FF']); s.style.animationDelay = (Math.random() * 0.6) + 's'; b.appendChild(s); }
  document.body.appendChild(b); setTimeout(function () { if (b.parentNode) b.parentNode.removeChild(b); }, 2800);
}
function setLevel(l) { $$('.level').forEach(function (b) { b.setAttribute('aria-pressed', String(b.getAttribute('data-level') === l)); }); }

/* ===================================================== navigation and links */
var VIEWS = ['home', 'learn', 'calc', 'challenge'], current = 'home', calcShown = false;
function go(mode) {
  current = VIEWS.indexOf(mode) >= 0 ? mode : 'home';
  lessonState.token++;
  VIEWS.forEach(function (v) { $('#view-' + v).hidden = v !== current; });
  $$('.modes button').forEach(function (b) { b.setAttribute('aria-pressed', String(b.getAttribute('data-mode') === current)); });
  if (current === 'learn') openLesson(lessonState.i);
  if (current === 'challenge') { if (game) { clearInterval(game.timer); game = null; } $('#ch-setup').hidden = false; $('#ch-play').hidden = true; $('#ch-end').hidden = true; renderShelf(); }
  if (current === 'calc') calcShow();
  window.scrollTo(0, 0); writeLink();
}
function writeLink() {
  try {
    var q = new URLSearchParams(); q.set('mode', current);
    if (current === 'learn') q.set('lesson', lessonState.i + 1);   // 0 is the lesson map
    if (current === 'calc') { var s = calcState; q.set('size', s.size); q.set('unit', s.unit); q.set('bw', s.bw); q.set('dist', s.dist); q.set('medium', s.medium); if (s.q) q.set('q', s.q); if (s.rtt !== '') q.set('rtt', s.rtt); }
    if (current === 'challenge') q.set('level', ($('.level[aria-pressed=true]') || $('.level')).getAttribute('data-level'));
    if (window.history && history.replaceState) history.replaceState(null, '', location.pathname + '?' + q.toString());
  } catch (e) { /* some embeds block history changes */ }
}
function readLink() {
  var q; try { q = new URLSearchParams(location.search); } catch (e) { return null; }
  if (q.get('lesson') !== null && q.get('lesson') !== '') lessonState.i = clamp((+q.get('lesson') || 0) - 1, -1, LESSONS.length - 1);   // lesson=0 opens the lesson map
  if (/^[EMH]$/.test(q.get('level') || '')) setLevel(q.get('level'));
  function num(k, lo, hi) { var raw = q.get(k); if (raw === null || raw === '') return null; var v = +raw; return isFinite(v) && v >= lo && v <= hi ? v : null; }
  var v;
  if ((v = num('size', 0, 1e15)) !== null) calcState.size = v;
  if (unitBits(q.get('unit') || '')) calcState.unit = q.get('unit');
  if ((v = num('bw', 1e-9, 1e15)) !== null) calcState.bw = v;
  if ((v = num('dist', 0, 1e12)) !== null) calcState.dist = v;
  if (SPEED[q.get('medium') || '']) calcState.medium = q.get('medium');
  if ((v = num('q', 0, 1e9)) !== null) calcState.q = v;
  if ((v = num('rtt', 0, 1e9)) !== null) calcState.rtt = v;
  return q.get('mode');
}

/* ===================================================== start */
function init() {
  var mode = readLink();   // read the link before anything rewrites it
  drawHero(); showXP(false); calcInit(); renderShelf();
  $$('.modes button').forEach(function (b) { b.onclick = function () { go(b.getAttribute('data-mode')); }; });
  $$('[data-go]').forEach(function (b) { b.onclick = function () { go(b.getAttribute('data-go')); }; });
  $('#home').onclick = function () { go('home'); };
  $$('.level').forEach(function (b) { b.onclick = function () { setLevel(b.getAttribute('data-level')); writeLink(); }; });
  $('#ch-start').onclick = startRound;
  $('#q_quit').onclick = function () { endRound(); };
  $('#resetProgress').onclick = function () { progress = { xp: 0, lessons: {}, badges: {}, best: {} }; store.set('progress', progress); showXP(false); renderShelf(); if (current === 'learn') renderStepper(); };
  $('#verifyBtn').onclick = function () { var r = checkCode($('#verifyIn').value); $('#verifyOut').innerHTML = r ? '<span class="yes">Valid:</span> ' + { E: 'Easy', M: 'Medium', H: 'Hard', S: 'Sprint' }[r.level] + ', ' + r.score + ' points, ' + r.right + ' of ' + r.total + ' right.' : '<span class="no">Not a valid code.</span>'; };
  go(VIEWS.indexOf(mode) >= 0 ? mode : 'home');
}
init();
window.BandwidthLatencyVisualizer = { SPEED: SPEED, propDelay: propDelay, transDelay: transDelay, bitWidth: bitWidth, bitLength: bitLength, dxb: dxb, pathTimes: pathTimes, messageTime: messageTime, transfer: transfer, windowThroughput: windowThroughput,
  pingRun: pingRun, GEN: GEN, makeRound: makeRound, code: code, checkCode: checkCode, near: near,
  currentQuestion: function () { return game ? { input: game.qs[game.i].input, answer: game.qs[game.i].answer } : null; } };
})();
</script>
</body>
</html>
