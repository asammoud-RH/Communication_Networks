"""Logic test for TCP Visualizer.

Runs the app in headless Chrome and checks its model with independent code:
  1. Random connections (the Calculator's model): every byte delivered once and in order,
     every ACK equal to an independent receiver's RCV.NXT, the sender inside the advertised
     window, contiguous sequence numbers, every loss repaired, fast retransmit only after
     three duplicate ACKs, timeouts no sooner than the minimum RTO, legal state changes.
  2. Wireshark: the app's capture is rebuilt as a pcap with Scapy and read back with tshark;
     the app's Info text and labels must match tshark's.
  3. Real kernel: the app's handshake, close, RST, zero-window, and duplicate-ACK lines are
     compared with captures taken from a real Linux kernel (test/*.pcap).
  4. Every Challenge generator: hundreds of rounds re-checked by independent formulas.
  5. The RFC 6298 estimator (exact fractions) and the header decoder (Scapy).
Usage: python3 logic_test.py ../tcp-visualizer.html
"""
import asyncio, json, random, re, subprocess, sys, pathlib, tempfile
from fractions import Fraction as F
from playwright.async_api import async_playwright
from scapy.all import Ether, IP, TCP, wrpcap, raw

APP = pathlib.Path(sys.argv[1]).resolve(); URL = APP.as_uri(); HERE = pathlib.Path(__file__).parent / 'tcp-kernel-captures'
MOD = 2 ** 32
fails = []
def fail(msg):
    fails.append(msg)
    if len(fails) < 400: print('FAIL', msg)

LEGAL = {('CLOSED', 'SYN_SENT'), ('CLOSED', 'LISTEN'), ('LISTEN', 'SYN_RCVD'), ('SYN_SENT', 'ESTABLISHED'), ('SYN_SENT', 'SYN_RCVD'), ('SYN_SENT', 'CLOSED'),
         ('SYN_RCVD', 'ESTABLISHED'), ('ESTABLISHED', 'FIN_WAIT_1'), ('ESTABLISHED', 'CLOSE_WAIT'), ('FIN_WAIT_1', 'FIN_WAIT_2'), ('FIN_WAIT_1', 'CLOSING'),
         ('FIN_WAIT_1', 'TIME_WAIT'), ('FIN_WAIT_2', 'TIME_WAIT'), ('CLOSING', 'TIME_WAIT'), ('CLOSE_WAIT', 'LAST_ACK'), ('LAST_ACK', 'CLOSED'), ('TIME_WAIT', 'CLOSED'),
         ('ESTABLISHED', 'CLOSED'), ('CLOSE_WAIT', 'CLOSED'), ('FIN_WAIT_1', 'CLOSED'), ('FIN_WAIT_2', 'CLOSED'), ('LAST_ACK', 'CLOSED'), ('CLOSING', 'CLOSED'), ('SYN_RCVD', 'CLOSED'), ('LISTEN', 'CLOSED')}

def rand_cfg(rng):
    a = rng.choice([0, 50, 100, 250, 600, 1000, 2500])
    b = rng.choice([0, 0, 30, 400])
    mss = rng.choice([100, 100, 536, 1460])
    read = rng.choice(['now', 'now', 'now', 'pause'])
    cfg = dict(isnA=rng.randrange(MOD), isnB=rng.randrange(MOD), mssA=mss, mssB=mss, ts=rng.random() < 0.4, sack=rng.random() < 0.7, ws=rng.choice([-1, -1, 0, 3, 7]),
               rbufA=rng.choice([400, 1000, 4000, 65536]), rbufB=rng.choice([300, 400, 1000, 4000, 65536]), delay=rng.choice([5, 20, 50, 120]), rate=rng.choice([160, 1000, 10000]),
               dack=rng.random() < 0.5, nagle=rng.random() < 0.2, rtoMin=rng.choice([1000, 200]), writes=[], readB={'kind': 'now'} if read == 'now' else {'kind': 'pause', 'until': rng.choice([1500, 3000])})
    if a: cfg['writes'].append({'side': 'A', 'at': 0, 'bytes': a})
    if not a: b = 0
    if b: cfg['writes'].append({'side': 'B', 'onRead': a, 'bytes': b})
    cl = rng.choice(['a', 'a', 'both', 'none', 'b'])
    if cl == 'a': cfg['closeA'] = {'kind': 'afterWrites'} if a else {'kind': 'at', 'at': 300}; cfg['closeB'] = {'kind': 'onFin', 'delay': rng.choice([0, 0, 200])}
    elif cl == 'both': cfg['closeA'] = {'kind': 'at', 'at': 4000}; cfg['closeB'] = {'kind': 'at', 'at': 4000}
    elif cl == 'b': cfg['closeB'] = {'kind': 'at', 'at': 5000}; cfg['closeA'] = {'kind': 'onFin', 'delay': 0}
    else: cfg['closeA'] = {'kind': 'never'}; cfg['closeB'] = {'kind': 'never'}
    nseg = 3 + (a // max(1, mss - 12)) + 4
    cfg['lose'] = sorted(rng.sample(range(1, nseg + 6), rng.choice([0, 0, 1, 1, 2, 3])))
    return cfg, a, b

SIM_JS = """(cfg) => { const r = TCPVisualizer.simulate(cfg), cap = TCPVisualizer.capture(r, {});
  return { segs: r.segs.map(s => ({ n: s.n, from: s.from, to: s.to, tEmit: s.tEmit, tSend: s.tSend, tArr: s.tArr, lost: s.lost, seq: s.seq, ack: s.ack === undefined ? null : s.ack, f: s.f, len: s.len,
    win: s.win, winBytes: s.winBytes, kind: s.kind, retx: s.retx || null, sack: s.sack, hdr: s.hdr, frame: s.frame, opts: s.opts || null, iss: s.iss, peerIss: s.peerIss, scaled: s.scaled })),
    states: r.states, end: r.end, ports: r.ports, cap: cap.map(f => ({ n: f.sg.n, t: f.t, label: f.label, info: f.info })) }; }"""

def check_run(cfg, a, b, r, tag):
    segs = r['segs']
    # state changes are legal
    for side in 'AB':
        st = r['states'][side]
        for i in range(1, len(st)):
            if (st[i - 1]['s'], st[i]['s']) not in LEGAL: fail(f'{tag}: illegal {side} {st[i-1]["s"]} -> {st[i]["s"]}')
    reset = any(s['f'].get('R') for s in segs)
    established = any(s['f'].get('S') and s['f'].get('A') and not s['lost'] for s in segs)
    # independent receiver model per direction: ACK numbers and delivery
    for X, Y in (('A', 'B'), ('B', 'A')):
        arr = sorted([s for s in segs if s['from'] == X and not s['lost']], key=lambda s: (s['tArr'], s['n']))
        got = set(); rcv = None; fin_at = None
        def advance():
            nonlocal rcv
            while rcv in got: rcv += 1
            if fin_at is not None and rcv == fin_at: rcv += 1
        ai = 0
        for e in sorted([s for s in segs if s['from'] == Y], key=lambda s: s['n']):
            before = rcv
            while ai < len(arr) and arr[ai]['tArr'] < e['tEmit'] - 1e-9:
                s = arr[ai]; ai += 1
                if s['f'].get('S'): rcv = 1 if rcv is None else rcv; continue
                if rcv is None or s['f'].get('R'): continue
                for k in range(s['seq'], s['seq'] + s['len']): got.add(k)
                if s['f'].get('F'): fin_at = s['seq'] + s['len']
                advance()
            before = rcv
            same = []
            j = ai
            while j < len(arr) and abs(arr[j]['tArr'] - e['tEmit']) < 1e-9: same.append(arr[j]); j += 1
            # what RCV.NXT would be after the arrivals at exactly the same moment
            g2 = set(got); r2 = rcv; f2 = fin_at
            for s in same:
                if s['f'].get('S'): r2 = 1 if r2 is None else r2; continue
                if r2 is None or s['f'].get('R'): continue
                for k in range(s['seq'], s['seq'] + s['len']): g2.add(k)
                if s['f'].get('F'): f2 = s['seq'] + s['len']
                while r2 in g2: r2 += 1
                if f2 is not None and r2 == f2: r2 += 1
            if e['f'].get('A') and not (e['f'].get('R') and not e['f'].get('S') and e['kind'] == 'rst' and e['hdr'] == 20):
                if e['ack'] not in (before, r2):
                    if cfg['readB']['kind'] == 'now' or Y == 'A':
                        fail(f'{tag}: {Y} seg #{e["n"]} Ack={e["ack"]} but independent RCV.NXT is {before} / {r2}')
        # delivery
        sent = a if X == 'A' else b
        end = r['end'][Y]
        if sent and established and not reset and cfg['readB']['kind'] == 'now' and cfg['closeB']['kind'] != 'at':
            if end['delivered'] != sent: fail(f'{tag}: {Y} received {end["delivered"]} of {sent} bytes')
    # sender stays inside the advertised window; sequence numbers contiguous; retransmits repeat old data
    for X, Y in (('A', 'B'), ('B', 'A')):
        mine = [s for s in segs if s['from'] == X]
        theirs = sorted([s for s in segs if s['from'] == Y and not s['lost'] and s['f'].get('A')], key=lambda s: (s['tArr'], s['n']))
        nxt = 1; sent_ranges = set()
        for s in mine:
            if s['f'].get('S') or s['f'].get('R') or s['kind'] == 'probe': continue
            if s['len'] > 0 or s['f'].get('F'):
                if not s['retx']:
                    if s['seq'] != nxt: fail(f'{tag}: {X} seg #{s["n"]} Seq={s["seq"]}, expected {nxt}')
                    nxt = s['seq'] + s['len'] + (1 if s['f'].get('F') else 0)
                    sent_ranges.add((s['seq'], s['len']))
                elif s['seq'] >= nxt: fail(f'{tag}: {X} resend #{s["n"]} of unsent data Seq={s["seq"]}')
            if s['len'] > 0:
                known = [t for t in theirs if t['tArr'] <= s['tEmit'] + 1e-9]
                if known:
                    k = known[-1]; right = max(t['ack'] + t['winBytes'] for t in known if not t['f'].get('S')) if any(not t['f'].get('S') for t in known) else k['ack'] + k['winBytes']
                    if s['seq'] + s['len'] > right: fail(f'{tag}: {X} seg #{s["n"]} ends at {s["seq"] + s["len"]}, past the window edge {right}')
        # every lost data segment is resent (unless the connection was reset or never finished)
        if not reset:
            for s in mine:
                if s['lost'] and s['len'] > 0 and not any(t['retx'] and t['seq'] <= s['seq'] < t['seq'] + max(1, t['len']) and t['n'] > s['n'] for t in mine):
                    if r['end'][Y]['delivered'] < s['seq'] + s['len'] - 1: fail(f'{tag}: lost {X} seg #{s["n"]} never repaired')
        # fast retransmit only after 3 duplicate ACKs; timeouts no sooner than the minimum
        for s in mine:
            if s['retx'] == 'fast':
                dups = [t for t in theirs if t['tArr'] <= s['tEmit'] + 1e-9 and t['ack'] <= s['seq'] and t['len'] == 0 and not t['f'].get('F') and not t['f'].get('S')]
                if len([t for t in dups if t['ack'] == s['seq']]) < 3 and not any(t['sack'] for t in dups): fail(f'{tag}: fast resend #{s["n"]} without three duplicate ACKs')
            if s['retx'] == 'rto':
                prev = [t for t in mine if t['n'] < s['n'] and t['seq'] == s['seq'] and (t['len'] > 0 or t['f'].get('S') or t['f'].get('F'))]
                if prev and not prev[-1]['retx'] in ('fast', 'partial') and s['tEmit'] - prev[-1]['tEmit'] < min(cfg['rtoMin'], 1000) - 1e-6: fail(f'{tag}: timeout resend #{s["n"]} after only {s["tEmit"] - prev[-1]["tEmit"]} ms')

def pcap_for(r, path):
    pk = []
    for f in r['cap']:
        s = next(x for x in r['segs'] if x['n'] == f['n'])
        src, dst = ('10.0.0.1', '10.0.0.2') if s['from'] == 'A' else ('10.0.0.2', '10.0.0.1')
        sp, dp = (r['ports']['A'], r['ports']['B']) if s['from'] == 'A' else (r['ports']['B'], r['ports']['A'])
        flags = ''.join(c for c, k in (('F', 'F'), ('S', 'S'), ('R', 'R'), ('P', 'P'), ('A', 'A')) if s['f'].get(k))
        opts = []
        if s['opts']:
            o = s['opts']; opts.append(('MSS', o['mss']))
            if o['sackPerm'] and o['ts']: opts += [('SAckOK', b''), ('Timestamp', (12345, 0 if s['from'] == 'A' else 777))]
            elif o['ts']: opts += [('NOP', None), ('NOP', None), ('Timestamp', (12345, 0))]
            elif o['sackPerm']: opts += [('NOP', None), ('NOP', None), ('SAckOK', b'')]
            if o['ws'] is not None: opts += [('NOP', None), ('WScale', o['ws'])]
        else:
            if s['hdr'] - 20 - (4 + 8 * len(s['sack']) if s['sack'] else 0) == 12: opts += [('NOP', None), ('NOP', None), ('Timestamp', (12345, 777))]
            if s['sack']: opts += [('NOP', None), ('NOP', None), ('SAck', tuple(v for bl in s['sack'] for v in ((s['peerIss'] + bl[0]) % MOD, (s['peerIss'] + bl[1]) % MOD)))]
        seq = (s['iss'] + s['seq']) % MOD; ack = (s['peerIss'] + s['ack']) % MOD if s['f'].get('A') else 0
        p = Ether() / IP(src=src, dst=dst) / TCP(sport=sp, dport=dp, seq=seq, ack=ack, flags=flags, window=s['win'], options=opts) / (b'x' * s['len'])
        if len(p[TCP]) - s['len'] != s['hdr']: fail(f'pcap: seg #{s["n"]} header {len(p[TCP]) - s["len"]} != app {s["hdr"]}')
        p.time = 1762700000 + f['t'] / 1000; pk.append(p)
    wrpcap(str(path), pk)

def tshark_info(path):
    out = subprocess.run(['tshark', '-r', str(path), '-T', 'fields', '-e', '_ws.col.Info', '-e', 'frame.len'], capture_output=True, text=True).stdout
    return [l.split('\t') for l in out.strip().split('\n') if l]

def norm(s): return re.sub(r' TSval=\d+ TSecr=\d+| TSval TSecr', '', s).strip()

def check_tshark(r, tag):
    with tempfile.TemporaryDirectory() as d:
        p = pathlib.Path(d) / 'x.pcap'; pcap_for(r, p); rows = tshark_info(p)
    for f, (info, flen) in zip(r['cap'], rows):
        s = next(x for x in r['segs'] if x['n'] == f['n'])
        mine = norm(('[' + f['label'] + '] ' if f['label'] else '') + f['info'])
        theirs = norm(info)
        if int(flen) != s['frame']: fail(f'{tag}: frame #{f["n"]} length {s["frame"]} vs tshark {flen}')
        if mine != theirs: fail(f'{tag}: capture line differs\n   app:    {mine}\n   tshark: {theirs}')

async def main():
    rng = random.Random(7)
    async with async_playwright() as p:
        br = await p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
        pg = await br.new_page(); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto(URL); await pg.wait_for_timeout(300)
        # 1 and 2: random connections
        N = int(sys.argv[2]) if len(sys.argv) > 2 else 400
        for i in range(N):
            cfg, a, b = rand_cfg(rng)
            r = await pg.evaluate(SIM_JS, cfg)
            check_run(cfg, a, b, r, f'run {i}')
            if i < 400: check_tshark(r, f'run {i}')
        print(f'1-2. {N} random connections checked (400 also against tshark)')
        # presets and lessons through tshark
        for name in await pg.evaluate('Object.keys(TCPVisualizer.PRESETS)'):
            cfg = await pg.evaluate("(k) => TCPVisualizer.calcCfg(TCPVisualizer.calcReset(k))", name)
            r = await pg.evaluate(SIM_JS, cfg); check_tshark(r, 'preset ' + name)
        print('    every Calculator preset matches tshark')
        # Lesson 8 paths: every arrow of the state diagram, through tshark, with legal state changes only
        B8 = dict(mssA=100, mssB=100, rbufA=400, rbufB=400, delay=50, rate=160, closeA={'kind': 'never'}, closeB={'kind': 'never'})
        def path_cfg(op, cl):
            o = dict(B8, dack=(cl == 'three'), writes=[{'side': 'A', 'at': 0, 'bytes': 100}]); t = 500
            if op == 'simopen': o.update(simOpen=True, listen=False, writes=[])
            if op == 'sendFirst': o.update(openA='passive', sendFromListen=True, writes=[{'side': 'B', 'at': 200, 'bytes': 100}]); t = 700
            if op == 'listenQuit': o.update(openA='none', writes=[], closeB={'kind': 'at', 'at': 300}); return o
            if op == 'giveUp': o.update(writes=[], lose=[1], closeA={'kind': 'at', 'at': 600, 'now': True}); return o
            o.update({'aFirst': dict(closeA={'kind': 'at', 'at': t}, closeB={'kind': 'onFin', 'delay': 300}), 'bFirst': dict(closeB={'kind': 'at', 'at': t}, closeA={'kind': 'onFin', 'delay': 300}),
                      'three': dict(closeA={'kind': 'at', 'at': t}, closeB={'kind': 'onFin', 'delay': 0}), 'both': dict(closeA={'kind': 'at', 'at': t}, closeB={'kind': 'at', 'at': t}),
                      'early': dict(closeA={'kind': 'at', 'at': 70, 'now': True}, closeB={'kind': 'onFin', 'delay': 300})}[cl])
            return o
        arcs = set()
        for op in ['normal', 'simopen', 'sendFirst']:
            for cl in ['aFirst', 'bFirst', 'three', 'both'] + (['early'] if op == 'simopen' else []):
                r = await pg.evaluate(SIM_JS, path_cfg(op, cl)); check_tshark(r, f'path {op}/{cl}')
                for side in 'AB':
                    st = [x['s'] for x in r['states'][side]]
                    for i in range(1, len(st)):
                        arcs.add((st[i - 1], st[i]))
                        if (st[i - 1], st[i]) not in LEGAL | {('LISTEN', 'SYN_SENT'), ('SYN_RCVD', 'FIN_WAIT_1')}: fail(f'path {op}/{cl}: illegal {st[i-1]} -> {st[i]}')
                    if st[-1] != 'CLOSED' or 'FIN_WAIT_2' in st and 'TIME_WAIT' not in st: fail(f'path {op}/{cl}: {side} ends in {st[-1]}')
        for op in ['listenQuit', 'giveUp']:
            r = await pg.evaluate(SIM_JS, path_cfg(op, ''))
            for side in 'AB':
                st = [x['s'] for x in r['states'][side]]
                for i in range(1, len(st)): arcs.add((st[i - 1], st[i]))
        if len(arcs) != 20: fail(f'Lesson 8 paths take {len(arcs)} of the 20 arrows: {sorted(arcs)}')
        print(f'    Lesson 8 paths: all {len(arcs)} arrows of the state diagram taken; every path matches tshark')
        # 3. real kernel
        await kernel(pg)
        # 4. challenge keys
        await challenge(pg)
        # 5. RTO and header decoder
        await rto_and_header(pg)
        await br.close()
        if errs: fail('page errors: ' + str(errs))
    print('FAILS', len(fails))

def kinfo(name):
    return [norm(x[0]) + ' |' + x[1] for x in tshark_info(HERE / name)]

async def kernel(pg):
    k = kinfo('echo.pcap')
    # handshake: SYN and SYN-ACK are 74-byte frames with MSS, SACK_PERM, Timestamps, WS; data and ACKs carry 32-byte headers (66-byte frames)
    r = await pg.evaluate(SIM_JS, dict(mssA=1460, mssB=1460, ts=True, sack=True, ws=10, rbufA=64240, rbufB=65160, delay=20, rate=100000, dack=True,
        writes=[{'side': 'A', 'at': 60, 'bytes': 6}, {'side': 'B', 'onRead': 6, 'bytes': 11}], closeA={'kind': 'at', 'at': 400}, closeB={'kind': 'onFin', 'delay': 100}))
    app = [norm(('[' + f['label'] + '] ' if f['label'] else '') + f['info']) + ' |' + str(next(s['frame'] for s in r['segs'] if s['n'] == f['n'])) for f in r['cap']]
    def shape(l): return re.sub(r'\d{4,5} → \d{4,5}', 'P → P', re.sub(r'Win=\d+', 'Win=W', l))
    for want in [k[0], k[1]]:
        if shape(want) not in [shape(x) for x in app]: fail('kernel: handshake line not matched: ' + want + '\n   app has: ' + str(app[:2]))
    kc = [shape(x) for x in k if 'FIN' in x]; ac = [shape(x) for x in app if 'FIN' in x]
    if kc != ac: fail(f'kernel: four-segment close differs {kc} vs {ac}')
    print('3. kernel: handshake options and sizes, data header size, and the close match a real Linux capture')
    # closed port: RST, ACK Seq=1 Ack=1 Win=0 Len=0, 54-byte frame
    kr = kinfo('rst.pcap')[1]
    r = await pg.evaluate(SIM_JS, dict(listen=False, closeA={'kind': 'never'}, closeB={'kind': 'never'}, ts=True, ws=7, mssA=1460, mssB=1460))
    ar = norm(r['cap'][1]['info']) + ' |' + str(next(s['frame'] for s in r['segs'] if s['n'] == r['cap'][1]['n']))
    if shape(kr) != shape(ar): fail(f'kernel: closed port {kr} vs app {ar}')
    # unread close: RST, ACK
    ku = kinfo('unread.pcap')[-1]
    if '[RST, ACK]' not in ku: fail('kernel unread: ' + ku)
    # zero window: Window Full on the sender, ZeroWindow on the receiver, Keep-Alive probe at SND.UNA-1, Window Update
    kz = kinfo('zw.pcap'); labels = set(re.findall(r'\[TCP ([A-Za-z\- ]+?)\]', ' '.join(kz)))
    r = await pg.evaluate(SIM_JS, dict(mssA=100, mssB=100, rbufB=300, rbufA=400, writes=[{'side': 'A', 'at': 0, 'bytes': 900}], readB={'kind': 'pause', 'until': 3000}, closeA={'kind': 'never'}, closeB={'kind': 'never'}))
    al = ' '.join(f['label'] for f in r['cap'] if f['label'])
    for lab in ['Window Full', 'ZeroWindow', 'Keep-Alive', 'Window Update']:
        if lab not in labels: fail('kernel zw: no ' + lab)
        if 'TCP ' + lab not in al: fail('app zw: no ' + lab)
    kp = [x for x in kz if 'Keep-Alive' in x][0]; kzw = [x for x in kz if 'ZeroWindow' in x][0]
    if int(re.search(r'Seq=(\d+)', kp).group(1)) != int(re.search(r'Ack=(\d+)', kzw).group(1)) - 1: fail('kernel probe is not at SND.UNA - 1')
    ap = [f for f in r['cap'] if 'Keep-Alive' in f['label']][0]; azw = [f for f in r['cap'] if 'ZeroWindow' in f['label']][0]
    if int(re.search(r'Seq=(\d+)', ap['info']).group(1)) != int(re.search(r'Ack=(\d+)', azw['info']).group(1)) - 1: fail('app probe is not at SND.UNA - 1')
    # duplicate ACKs with SACK blocks, and the fast retransmission label
    kd = kinfo('loss3.pcap'); dup = [x for x in kd if 'Dup ACK' in x][0]
    if not re.search(r'\[TCP Dup ACK \d+#1\].*SLE=\d+ SRE=\d+', dup): fail('kernel dup ack format ' + dup)
    if not any('Fast Retransmission' in x for x in kd): fail('kernel: no fast retransmission')
    r = await pg.evaluate(SIM_JS, dict(mssA=100, mssB=100, rbufB=1000, writes=[{'side': 'A', 'at': 0, 'bytes': 800}], lose=[6], closeA={'kind': 'never'}, closeB={'kind': 'never'}))
    ad = [f['label'] + ' ' + f['info'] for f in r['cap'] if 'Dup ACK' in f['label']][0]
    if not re.search(r'TCP Dup ACK \d+#1 .*SLE=\d+ SRE=\d+', ad): fail('app dup ack format ' + ad)
    # SYN resent by timeout: [TCP Retransmission] ... [SYN], first resend 1 s later
    ks = tshark_info(HERE / 'syn.pcap')
    if '[TCP Retransmission]' not in ks[1][0] or '[SYN]' not in ks[1][0]: fail('kernel syn retx ' + ks[1][0])
    r = await pg.evaluate(SIM_JS, dict(lose=[1], closeA={'kind': 'never'}, closeB={'kind': 'never'}))
    if r['cap'][1]['label'] != 'TCP Retransmission' or abs(r['cap'][1]['t'] - 1000) > 1e-6: fail('app syn retx ' + str(r['cap'][1]))
    print('   kernel: closed-port RST, unread-data RST, zero window and Keep-Alive probe at SND.UNA − 1, duplicate ACKs with SACK, and SYN resends match')

async def challenge(pg):
    count = 0
    for lvl in 'EMH':
        for rnd in range(150):
            qs = await pg.evaluate("(l) => TCPVisualizer.makeRound(l, 10).map(q => ({ type: q.type, input: q.input, answer: q.answer, choices: q.choices || null, p: q.p, text: q.text }))", lvl)
            for q in qs:
                count += 1; p = q['p']; k = p['kind']
                ans = q['choices'][q['answer']] if q['input'] == 'choice' else q['answer']
                if q['input'] == 'choice' and len(set(q['choices'])) != len(q['choices']): fail(f'{k}: duplicate choices {q["choices"]}')
                exp = None
                if k == 'flag': exp = p['k']
                elif k == 'nextAck': exp = p['s'] + p['L'] + p['syn'] + p['fin']
                elif k == 'hdrLen': exp = 4 * p['N']
                elif k == 'hdrLenR': exp = p['B'] // 4
                elif k == 'mss': exp = p['M'] - 40
                elif k == 'mssTs': exp = p['M'] - 52
                elif k == 'state':
                    exp = {('ESTABLISHED', 'its program calls close, so it sends FIN'): 'FIN_WAIT_1', ('ESTABLISHED', 'it gets a FIN and ACKs it'): 'CLOSE_WAIT', ('LISTEN', 'it gets a SYN and answers SYN, ACK'): 'SYN_RCVD',
                           ('SYN_SENT', 'it gets SYN, ACK and answers ACK'): 'ESTABLISHED', ('FIN_WAIT_2', "it gets the other side's FIN and ACKs it"): 'TIME_WAIT', ('CLOSE_WAIT', 'its program calls close, so it sends FIN'): 'LAST_ACK',
                           ('FIN_WAIT_1', 'it gets an ACK of its FIN (and no FIN yet)'): 'FIN_WAIT_2', ('LAST_ACK', 'it gets the ACK of its FIN'): 'CLOSED', ('FIN_WAIT_1', 'it gets a FIN before its own FIN is ACKed'): 'CLOSING',
                           ('SYN_RCVD', 'it gets the ACK of its SYN'): 'ESTABLISHED'}[(p['from'], p['ev'])]
                elif k == 'spell':
                    lin = {'SYN_RCVD': 'SYN-RECV', 'ESTABLISHED': 'ESTAB', 'TIME_WAIT': 'TIME-WAIT', 'CLOSE_WAIT': 'CLOSE-WAIT', 'FIN_WAIT_2': 'FIN-WAIT-2', 'LISTEN': 'LISTEN', 'LAST_ACK': 'LAST-ACK'}
                    exp = lin[p['st']] if p['os'] == 'linux' else {'LISTEN': 'LISTENING', 'SYN_RCVD': 'SYN_RECEIVED'}.get(p['st'], p['st'])
                elif k == 'label': exp = '[' + p['l'] + ']'
                elif k == 'hs': exp = {'saAck': (p['x'] + 1) % MOD, 'ackSeq': (p['x'] + 1) % MOD, 'ackAck': (p['y'] + 1) % MOD, 'bData': (p['y'] + 1) % MOD}[p['w']]
                elif k == 'ladderSeq': exp = 1 + sum(p['lens'][:-1])
                elif k == 'ladderAck': exp = 1 + sum(p['lens'])
                elif k == 'ladderAAck': exp = 1 + p['bl']
                elif k == 'advWin': exp = p['B'] - p['U']
                elif k == 'usable': exp = p['una'] + p['w'] - p['nxt']
                elif k == 'ws': exp = p['F'] * 2 ** p['s']
                elif k == 'tw': exp = {'a': 'Only Host A', 'b': 'Only Host B', 'both': 'Both hosts', 'rst': 'Neither host'}[p['k']]
                elif k == 'refused': exp = {'refused': 'Connection refused', 'timeout': 'Connection timed out (no answer)', 'ok': 'Connected', 'reset': 'Connection reset by the other side'}[p['k']]
                elif k == 'payload': exp = p['T'] - 20 - 4 * p['N']
                elif k == 'lossAfter': exp = 1 + p['S'] * p['N']
                elif k == 'lossDup': exp = 1 + p['S'] * (p['k'] - 1); assert p['j'] > p['k']
                elif k == 'lossHow': exp = 'Fast retransmit after the third duplicate ACK' if p['N'] - p['k'] >= 3 else 'A timeout'
                elif k == 'rto':
                    R1, R2 = F(p['R1']), F(p['R2']); s1, v1 = R1, R1 / 2; v2 = F(3, 4) * v1 + F(1, 4) * abs(s1 - R2); s2 = F(7, 8) * s1 + F(1, 8) * R2; exp = s2 + 4 * v2
                    if exp.denominator != 1: fail('rto not an integer ' + str(exp))
                    exp = int(exp)
                elif k == 'synK': exp = sum(2 ** i for i in range(p['k']))
                elif k == 'synAll': exp = sum(p['r0'] * 2 ** i for i in range(p['n'] + 1))
                elif k == 'wrap': exp = (p['s'] + p['L']) % MOD
                elif k == 'thr': exp = F(p['W'] * 8, p['R'] * 1000); assert exp.denominator == 1; exp = int(exp)
                elif k == 'zero': exp = 'Nothing until a timer runs out; then a small window probe'
                elif k == 'impossible':
                    exp = 'Line ' + str(p['line'])
                    # independent: exactly that line breaks a rule
                    lines = p['shown']; badl = []
                    for i, l in enumerate(lines):
                        m = re.search(r'Seq=(\d+)(?: Ack=(\d+))?.*Len=(\d+)', l)
                        if not m: continue
                        seq, ack, ln = int(m.group(1)), m.group(2), int(m.group(3))
                        if l.startswith('B → A') and ack is not None and int(ack) > p['a'] + 2: badl.append(i)
                        if '[SYN, ACK]' in l and ack != '1': badl.append(i)
                        if l.startswith('A → B') and '[FIN' in l and seq != p['a'] + 1: badl.append(i)
                        if l.startswith('A → B') and i == len(lines) - 1 and '[ACK]' in l and ack is not None:
                            bf = [x for x in lines if x.startswith('B → A') and 'FIN' in x]
                            if bf and int(ack) != int(re.search(r'Seq=(\d+)', bf[-1]).group(1)) + 1: badl.append(i)
                    if badl != [p['line'] - 1]: fail(f'impossible: independent check found lines {badl}, key says {p["line"]} ({p["k"]})')
                else: fail('no checker for ' + k); continue
                if ans != exp: fail(f'{k}: key {ans} but expected {exp} ({p})')
    print(f'4. {count} Challenge questions re-checked')

async def rto_and_header(pg):
    rng = random.Random(3)
    for _ in range(300):
        S = [rng.choice([rng.randint(1, 3000), 8 * rng.randint(1, 300)]) for _ in range(rng.randint(1, 8))]
        skip = [rng.random() < 0.2 for _ in S]; mn = rng.choice([0, 200, 1000])
        got = await pg.evaluate("([S, k, m]) => TCPVisualizer.rtoSeries(S, k, m)", [S, skip, mn])
        srtt = var = None; rto = F(1000)
        for R, sk, g in zip(S, skip, got):
            if sk: continue
            R = F(R)
            if srtt is None: srtt, var = R, R / 2
            else: var = F(3, 4) * var + F(1, 4) * abs(srtt - R); srtt = F(7, 8) * srtt + F(1, 8) * R
            rto = max(F(mn), srtt + 4 * var)
            if abs(g['rto'] - float(rto)) > 1e-6 or abs(g['srtt'] - float(srtt)) > 1e-6: fail(f'rto {S} {skip}: {g} vs {float(srtt)} {float(rto)}')
    for _ in range(300):
        f = rng.choice(['S', 'SA', 'A', 'PA', 'FA', 'RA'])
        opts = rng.choice([[], [('MSS', 1460), ('SAckOK', b''), ('Timestamp', (rng.randrange(MOD), 0)), ('NOP', None), ('WScale', rng.randint(0, 14))], [('NOP', None), ('NOP', None), ('Timestamp', (1, 2))], [('NOP', None), ('NOP', None), ('SAck', (100, 200, 300, 400))]])
        t = TCP(sport=rng.randrange(65536), dport=rng.randrange(65536), seq=rng.randrange(MOD), ack=rng.randrange(MOD), flags=f, window=rng.randrange(65536), options=opts)
        b = list(raw(t))
        d = await pg.evaluate("(b) => TCPVisualizer.decodeHeader(b)", b)
        if d['err'] or d['sport'] != t.sport or d['dport'] != t.dport or d['seq'] != t.seq or d['ack'] != t.ack or d["hdr"] != len(raw(t))  or d['win'] != t.window or d['flagsByte'] != int(t.flags):
            fail(f'decode {bytes(b).hex()} -> {d}')
        if any(o[0] == 'MSS' for o in opts) and 'MSS = 1460' not in d['opts']: fail('decode options ' + str(d['opts']))
    print('5. RFC 6298 estimator (300 series, exact fractions) and the header decoder (300 Scapy headers) match')

asyncio.run(main())
