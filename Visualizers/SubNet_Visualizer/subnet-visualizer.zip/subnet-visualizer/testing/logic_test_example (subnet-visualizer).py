"""Logic test for Subnet Visualizer: an example to copy for new apps.

The pattern: the app exposes its math and its question generators on
window.<AppName> (Subnet Visualizer uses window.SubnetVisualizer). This script calls them in
headless Chrome and re-checks every result with an independent implementation
in Python (here, the ipaddress module). For a new app, keep the structure and
replace the checks.

  1. Calculations: compare the app with Python on many random inputs.
  2. Model: check known cases (one-way overlap, both ways, no reply).
  3. Questions: generate hundreds of rounds per level and re-check every answer
     key; choices must be unique and the answer index must be valid.
  4. Completion code: a code checks as valid, and an edited code does not.

Usage: python3 "logic_test_example (subnet-visualizer).py" path/to/subnet-visualizer.html
"""
import sys, pathlib
import asyncio, json, random, ipaddress
from playwright.async_api import async_playwright
URL=pathlib.Path(sys.argv[1]).resolve().as_uri()
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
        pg=await b.new_page(); errs=[]
        pg.on('pageerror',lambda e:errs.append(str(e))); pg.on('console',lambda m:errs.append(m.text) if m.type=='error' else None)
        await pg.goto(URL); await pg.wait_for_timeout(300)
        # 1. IP math vs Python ipaddress, all prefixes
        cases=[(random.getrandbits(32),pfx) for pfx in range(33) for _ in range(40)]
        got=await pg.evaluate('''(cs)=>cs.map(([n,p])=>{const I=SubnetVisualizer.IP;return [I.str(I.net(n,p)),I.str(I.bcast(n,p)),I.str(I.mask(p)),I.hosts(p)]})''',cases)
        bad=0
        for (n,pfx),g in zip(cases,got):
            net=ipaddress.ip_network((n,pfx),strict=False)
            hosts = 1 if pfx==32 else 2 if pfx==31 else net.num_addresses-2
            exp=[str(net.network_address),str(net.broadcast_address),str(net.netmask),hosts]
            if g!=exp: bad+=1; print('MISMATCH',n,pfx,g,exp)
        print('ip math cases',len(cases),'mismatches',bad)
        # parse
        print(await pg.evaluate('''()=>[SubnetVisualizer.IP.parse("192.168.10.130/25"),SubnetVisualizer.IP.parse("192.168.10.130 255.255.255.128"),SubnetVisualizer.IP.parse("10.0.0.1 255.0.255.0"),SubnetVisualizer.IP.parse("300.1.1.1/24")]'''))
        # 2. ping model: known cases
        r=await pg.evaluate('''()=>{const S=SubnetVisualizer,H=(a,b,a2)=>S.hostsFrom({A:[[a[0],a[1]]].concat(a2?[a2]:[]),B:[b],C:null,S:[[1,24]]});
          const o=(h,f,x)=>S.simulate(h,f,x).outcome;
          const s2=H([160,24],[130,25]),s5=H([160,24],[90,25]),la=H([160,24],[80,26],[70,26]);
          return {s2AB:o(s2,'A',130),s2BA:o(s2,'B',160),s2BS:o(s2,'B',1),s5BA:o(s5,'B',160),s5AB:o(s5,'A',90),s5free:o(s5,'B',126),s5BS:o(s5,'B',1),
            laAB:o(la,'A',80),laBS:o(la,'B',1),laAS:o(la,'A',1),pair_s2:S.pairStatus(s2,'A','B'),pair_s5:S.pairStatus(s5,'A','B'),pair_la:S.pairStatus(la,'A','B'),
            pair_none:S.pairStatus(H([10,25],[200,25]),'A','B')}}''')
        print(json.dumps(r))
        # 3. question generators: answers re-checked independently
        qs=await pg.evaluate('''()=>{const out=[];['E','M','H'].forEach(L=>{for(let i=0;i<120;i++){SubnetVisualizer.makeRound(L,10).forEach(q=>out.push({L,type:q.type,text:q.text.replace(/<[^>]+>/g,''),input:q.input,answer:q.answer,choices:q.choices||null}))}});return out}''')
        base='192.168.10.'
        import re
        probs=0; counts={}
        for q in qs:
            counts[q['type']]=counts.get(q['type'],0)+1
            t=q['text']
            if q['input']=='choice':
                if not (0<=q['answer']<len(q['choices'])): probs+=1; print('BAD idx',q); continue
                if len(set(q['choices']))!=len(q['choices']): probs+=1; print('DUP choices',q)
            if q['type']=='block':
                m=re.search(r'the (network|broadcast|first host|last host) address of 192\.168\.10\.(\d+)/(\d+)',t); kind,x,pp=m.group(1),int(m.group(2)),int(m.group(3))
                net=ipaddress.ip_network(f'{base}{x}/{pp}',strict=False); n=int(str(net.network_address).split('.')[-1]); bc=int(str(net.broadcast_address).split('.')[-1])
                exp={'network':n,'broadcast':bc,'first host':n+1,'last host':bc-1}[kind]
                if exp!=q['answer']: probs+=1; print('BLOCK',t,q['answer'],exp)
            elif q['type']=='hosts':
                pp=int(re.search(r'/(\d+)',t).group(1)); exp=2**(32-pp)-2
                if exp!=q['answer']: probs+=1; print('HOSTS',t)
            elif q['type']=='same':
                xs=[int(v) for v in re.findall(r'192\.168\.10\.(\d+)',t)]; pp=int(re.search(r'/(\d+)',t).group(1))
                same=ipaddress.ip_network(f'{base}{xs[0]}/{pp}',strict=False)==ipaddress.ip_network(f'{base}{xs[1]}/{pp}',strict=False)
                if (0 if same else 1)!=q['answer']: probs+=1; print('SAME',t)
            elif q['type']=='valid':
                m=re.search(r'join 192\.168\.10\.(\d+)/(\d+)',t); net=ipaddress.ip_network(f'{base}{m.group(1)}/{m.group(2)}')
                good=[c for c in q['choices'] if ipaddress.ip_address(c) in net and ipaddress.ip_address(c) not in (net.network_address,net.broadcast_address)]
                if len(good)!=1 or q['choices'][q['answer']]!=good[0]: probs+=1; print('VALID',t,q['choices'])
            elif q['type']=='mask':
                if q['input']=='choice':
                    pp=int(re.search(r'/(\d+)',t).group(1)); 
                    if q['choices'][q['answer']]!=str(ipaddress.ip_network(f'0.0.0.0/{pp}').netmask): probs+=1; print('MASK',t)
                else:
                    mk=re.search(r'(\d+\.\d+\.\d+\.\d+)',t).group(1)
                    if ipaddress.ip_network(f'0.0.0.0/{mk}').prefixlen!=q['answer']: probs+=1; print('MASK2',t)
            elif q['type']=='overlap':
                ns=re.findall(r'192\.168\.10\.(\d+)/(\d+)',t); a=ipaddress.ip_network(f'{base}{ns[0][0]}/{ns[0][1]}'); c=ipaddress.ip_network(f'{base}{ns[1][0]}/{ns[1][1]}')
                exp=0 if a==c else 1 if c.subnet_of(a) else 2 if a.subnet_of(c) else 3
                if exp!=q['answer']: probs+=1; print('OVL',t,q['answer'],exp)
            elif q['type']=='ping':
                ns=re.findall(r'192\.168\.10\.(\d+)/(\d+)',t); (a,pa),(bb,pb)=[(int(x),int(y)) for x,y in ns]
                A=ipaddress.ip_interface(f'{base}{a}/{pa}'); B=ipaddress.ip_interface(f'{base}{bb}/{pb}')
                if B.ip not in A.network: exp='Network is unreachable'
                elif A.ip not in B.network: exp='Destination Host Unreachable'
                else: exp='3 replies'
                if q['choices'][q['answer']]!=exp: probs+=1; print('PING',t,q['choices'][q['answer']],exp)
        print('questions',len(qs),'problems',probs,counts)
        # 4. completion code
        print(await pg.evaluate('''()=>{const c=SubnetVisualizer.code('H',96,9,10);return [c,SubnetVisualizer.checkCode(c),SubnetVisualizer.checkCode(c.replace('96','99')),SubnetVisualizer.checkCode(c.toLowerCase())]}'''))
        print('ERRORS',errs)
        await b.close()
asyncio.run(main())
