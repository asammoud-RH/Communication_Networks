import asyncio, re, sys
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(); pg = await b.new_page(viewport={'width':1280,'height':900})
        await pg.goto('file://' + sys.argv[1] + '?mode=learn&lesson=4')
        bad = 0; n = 0
        for mode, w in [('one',''), ('rtt',''), ('rtt','64')]:
            await pg.select_option('#l4mode', mode); await pg.fill('#l4w', w); await pg.dispatch_event('#l4w','input')
            mx = await pg.get_attribute('#l4scrub','max')
            for k in range(0, 1001, 7):
                await pg.fill('#l4scrub', str(k)); await pg.dispatch_event('#l4scrub','input')
                r = await pg.evaluate("""() => { const rs=[...document.querySelectorAll('#l4svg rect')];
                  const cells=rs.filter(r=>{const f=r.getAttribute('fill');return f==='#fff'||/amber|F5A623|f5a623|F2A0|E89B/.test(f)||r.getAttribute('stroke')==='#B86E00'||r.getAttribute('stroke')==='#003C5A'||true});
                  const am=rs.filter(r=>r.getAttribute('stroke')==='#B86E00').map(r=>+r.getAttribute('x'));
                  return am.length ? Math.max(...am) : null }""")
                lit = await pg.evaluate("""() => { const rs=[...document.querySelectorAll('#l4svg rect')].filter(r=>r.getAttribute('stroke')!=='#B86E00' && r.getAttribute('fill')!=='#fff' && r.getAttribute('fill')==='#00A2D7' && r.getAttribute('stroke')==='#0B3D5C' && +r.getAttribute('width')<0.5);
                  const am=[...document.querySelectorAll('#l4svg rect')].filter(r=>r.getAttribute('stroke')==='#B86E00').map(r=>+r.getAttribute('x'));
                  if(!am.length) return null; const a=Math.max(...am); return rs.filter(r=>+r.getAttribute('x')>a+0.01).length }""")
                if r is not None:
                    n += 1
                    if lit: bad += 1; print('lit ahead of amber', mode, w, k, lit)
        print('frames with amber', n, 'bad', bad); await b.close()
asyncio.run(main())
