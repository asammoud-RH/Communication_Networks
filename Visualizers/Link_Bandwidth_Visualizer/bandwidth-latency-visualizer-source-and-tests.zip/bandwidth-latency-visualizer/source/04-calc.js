
/* ===================================================== CALCULATOR: one link */
var calcState = { size: 1500, unit: 'B', bw: 100e6, dist: 1000e3, medium: 'fiber', q: 0, rtt: '' };
var C_PRESETS = {
  lan: { name: 'Local Ethernet: 1500 bytes, 1 Gbps, 100 m of copper', size: 1500, unit: 'B', bw: 1e9, dist: 100, medium: 'copper' },
  wifi: { name: 'Wi-Fi: 1500 bytes, 300 Mbps, 20 m', size: 1500, unit: 'B', bw: 300e6, dist: 20, medium: 'radio' },
  home: { name: 'Home broadband: 1 MB, 50 Mbps, 5 km of copper', size: 1, unit: 'MB', bw: 50e6, dist: 5000, medium: 'copper' },
  cross: { name: 'Across a continent: 1 MB, 100 Mbps, 4,000 km of fiber', size: 1, unit: 'MB', bw: 100e6, dist: 4000e3, medium: 'fiber' },
  ocean: { name: 'Under an ocean: 10 MB, 10 Gbps, 6,000 km of fiber', size: 10, unit: 'MB', bw: 10e9, dist: 6000e3, medium: 'fiber' },
  sat: { name: 'Satellite: 1 MB, 45 Mbps, 71,572 km up and down', size: 1, unit: 'MB', bw: 45e6, dist: 71572e3, medium: 'radio' },
  classic: { name: '1 MB over 1 Gbps with a 100 ms RTT', size: 1, unit: 'MB', bw: 1e9, dist: 10000e3, medium: 'fiber' }
};
var calcTL = null;
function bestRate(bps) { var u = bps >= 1e9 ? 'Gbps' : bps >= 1e6 ? 'Mbps' : bps >= 1e3 ? 'kbps' : 'bps'; return [bps / rateMult(u), u]; }
function setCalcInputs() {
  var s = calcState, r = bestRate(s.bw);
  $('#c_size').value = s.size; $('#c_unit').value = s.unit; $('#c_bw').value = r[0]; $('#c_bwu').value = r[1];
  if (s.dist >= 1000 || s.dist === 0) { $('#c_dist').value = s.dist / 1000; $('#c_distu').value = '1000'; } else { $('#c_dist').value = s.dist; $('#c_distu').value = '1'; }
  $('#c_med').value = s.medium; $('#c_q').value = s.q; $('#c_rtt').value = s.rtt;
}
function calcRead() {
  var size = readF('#c_size', 0, 1e15), bw = readF('#c_bw', 1e-9, 1e15), d = readF('#c_dist', 0, 1e12), q = readF('#c_q', 0, 1e9), rtt = readF('#c_rtt', 0, 1e9, true);
  if (size === null || bw === null || d === null || q === null || rtt === null) return false;
  var bps = bw * rateMult($('#c_bwu').value);
  if (size * unitBits($('#c_unit').value) <= 0) { $('#c_size').setAttribute('aria-invalid', 'true'); return false; }
  calcState.size = size; calcState.unit = $('#c_unit').value; calcState.bw = bps; calcState.dist = d * +$('#c_distu').value; calcState.medium = $('#c_med').value; calcState.q = q; calcState.rtt = rtt;
  return true;
}
function calc() {
  if (!calcRead()) { $('#c_err').textContent = 'Check the boxes marked in red: each needs a number, and the size and bandwidth must be more than 0.'; return; }
  $('#c_err').textContent = '';
  var s = calcState, bits = s.size * unitBits(s.unit), bin = /i/.test(s.unit), L = { bw: s.bw, dist: s.dist, medium: s.medium, q: s.q / 1000 };
  var h = pathTimes(bits, [L]).hops[0], P = h.P, T = h.T, Q = h.q, lat = h.end, rtt = s.rtt === '' ? 2 * P : s.rtt / 1000, x = transfer(bits, s.bw, rtt);
  var one = dxb(P, s.bw), two = dxb(rtt, s.bw);
  $('#c_key').innerHTML = stat('One-way latency', fmtT(lat), T > P ? 'transmit is the bigger part' : 'propagation is the bigger part', true) + stat('RTT × bandwidth', fmtBits(two), fmtBytes(two, bin) + ': the window that fills the pipe') +
    stat('Transfer time', fmtT(x.time), 'RTT + transmit') + stat('Effective throughput', fmtRate(x.thr), fmtN(100 * x.thr / s.bw, 3) + '% of the bandwidth', true);
  $('#c_stats').innerHTML =
    stat('Size', fmtBits(bits), fmtBytes(bits, bin)) + stat('Bit width', fmtT(bitWidth(s.bw)), 'one bit lasts this long') + stat('Bit length on the wire', fmtDist(bitLength(s.bw, s.medium)), 'in ' + MEDIUM_NAME[s.medium]) +
    stat('Queue', fmtT(Q)) + stat('Transmit', fmtT(T), 'size ÷ bandwidth') + stat('Propagation', fmtT(P), 'distance ÷ speed') + stat('One-way latency', fmtT(lat), T > P ? 'bandwidth-bound: transmit is bigger' : 'latency-bound: propagation is bigger', true) +
    stat('RTT', fmtT(rtt), s.rtt === '' ? '2 × propagation' : 'as typed') + stat('One-way delay × bandwidth', fmtBits(one), fmtBytes(one, bin) + ' on the link') + stat('RTT × bandwidth', fmtBits(two), fmtBytes(two, bin) + ': the window that fills the pipe', true) +
    stat('Transfer time', fmtT(x.time), 'RTT + transmit') + stat('Effective throughput', fmtRate(x.thr), fmtN(100 * x.thr / s.bw, 3) + '% of the bandwidth', true);
  $('#c_work').innerHTML = [
    'Size: ' + fmtN(s.size) + ' ' + s.unit + ' × ' + fmtN(unitBits(s.unit)) + ' bits = ' + fmtN(bits, 6) + ' bits.',
    'Transmit = ' + fmtN(bits, 6) + ' bits ÷ ' + fmtN(s.bw) + ' bits/s = ' + fmtT(T, 5) + '.',
    'Propagation = ' + fmtN(s.dist) + ' m ÷ ' + fmtN(SPEED[s.medium]) + ' m/s = ' + fmtT(P, 5) + '.',
    'One-way latency = ' + fmtT(Q, 4) + ' + ' + fmtT(T, 4) + ' + ' + fmtT(P, 4) + ' = ' + fmtT(lat, 5) + '.',
    'RTT × bandwidth = ' + fmtT(rtt, 4) + ' × ' + fmtRate(s.bw) + ' = ' + fmtBits(two, 5) + ' = ' + fmtBytes(two, bin, 5) + '.',
    'Transfer time = ' + fmtT(rtt, 4) + ' + ' + fmtT(T, 4) + ' = ' + fmtT(x.time, 5) + '; throughput = ' + fmtN(bits, 6) + ' bits ÷ ' + fmtT(x.time, 5) + ' = ' + fmtRate(x.thr, 5) + '.'
  ].map(function (t) { return '<li>' + t + '</li>'; }).join('');
  calcTL.set(['Host A', 'Host B'], [L], bits);
  drawBar($('#c_bar'), [{ name: 'Queue', v: Q, fill: C.amberSoft, line: C.amber }, { name: 'Transmit', v: T, fill: C.panel, line: C.brand }, { name: 'Propagation', v: P, fill: '#E7E1FF', line: '#7B61FF' }]);
  drawUsage($('#c_use'), { rtt: rtt, trans: T, bw: s.bw, thr: x.thr });
  if (P > 0) drawPipe($('#c_pipe'), { delay: P, bw: s.bw, mode: 'one', binary: bin }); else { var f = new Fig($('#c_pipe'), 0, 10, 0, 0.6, 1.5); f.text(5, 0.3, 'With no distance there is no pipe: the delay × bandwidth product is 0.', { fs: 8.4, color: C.muted }); }
  writeLink();
}

/* ===================================================== CALCULATOR: a path of links */
var pathState = { size: 1500, n: 1, links: [{ bw: 100e6, dist: 100, medium: 'copper', q: 0 }, { bw: 1e9, dist: 20000, medium: 'fiber', q: 0.5 }, { bw: 10e6, dist: 500e3, medium: 'fiber', q: 2 }] };
var PATH_NAMES = { 1: ['Host A', 'Host B'], 2: ['Host A', 'Router', 'Host B'], 3: ['Host A', 'Switch', 'Router', 'Host B'], 4: ['Host A', 'Switch', 'Router 1', 'Router 2', 'Host B'] };
var pathTL = null;
function renderPathLinks() {
  var names = PATH_NAMES[pathState.links.length];
  $('#p_links').innerHTML = pathState.links.map(function (L, i) {
    var r = bestRate(L.bw);
    return '<div class="linkbox"><b>Link ' + (i + 1) + ': ' + names[i] + ' → ' + names[i + 1] + '</b>' +
      '<label>Bandwidth ' + numIn('pb' + i, r[0], 1e-9, 1e15, 'Link ' + (i + 1) + ' bandwidth') + '<select id="pu' + i + '" aria-label="Link ' + (i + 1) + ' bandwidth unit">' + rateUnitOptions(r[1]) + '</select></label>' +
      '<label>Length ' + numIn('pd' + i, L.dist / 1000, 0, 1e9, 'Link ' + (i + 1) + ' length in kilometers') + ' km</label>' +
      '<label>Medium <select id="pm' + i + '">' + mediumOptions(L.medium) + '</select></label>' +
      '<label>Queue at ' + names[i] + ' ' + numIn('pq' + i, L.q, 0, 1e9, 'Queue at ' + names[i] + ' in milliseconds') + ' ms</label></div>';
  }).join('');
  pathState.links.forEach(function (L, i) { ['#pb', '#pd', '#pq'].forEach(function (p) { $(p + i).oninput = pathCalc; }); $('#pu' + i).onchange = pathCalc; $('#pm' + i).onchange = pathCalc; });
  $('#p_add').disabled = pathState.links.length >= 4; $('#p_del').disabled = pathState.links.length <= 1;
}
function pathCalc() {
  var size = readF('#p_size', 1, 65535), n = readF('#p_n', 1, 100000), ok = size !== null && n !== null, links = [];
  pathState.links.forEach(function (L, i) {
    var b = readF('#pb' + i, 1e-9, 1e15), d = readF('#pd' + i, 0, 1e9), q = readF('#pq' + i, 0, 1e9);
    if (b === null || d === null || q === null) { ok = false; return; }
    links.push({ bw: b * rateMult($('#pu' + i).value), dist: d * 1000, medium: $('#pm' + i).value, q: q });
  });
  if (!ok) { $('#p_err').textContent = 'Check the boxes marked in red.'; return; }
  $('#p_err').textContent = ''; pathState.size = Math.round(size); pathState.n = Math.round(n); pathState.links = links;
  var bits = pathState.size * 8, L = links.map(function (x) { return { bw: x.bw, dist: x.dist, medium: x.medium, q: x.q / 1000 }; }), r = pathTimes(bits, L), names = PATH_NAMES[links.length];
  var bi = 0; L.forEach(function (x, i) { if (x.bw < L[bi].bw) bi = i; });
  var msg = messageTime(bits, pathState.n, L);
  $('#p_key').innerHTML = stat('One packet, Host A to Host B', fmtT(r.total), 'every link transmits it again', true) + stat('Bottleneck', 'Link ' + (bi + 1) + ': ' + fmtRate(L[bi].bw), 'the most this path can carry') +
    (pathState.n > 1 ? stat('All ' + fmt(pathState.n) + ' packets', fmtT(msg), 'one every ' + fmtT(bits / L[bi].bw, 3) + ' after the first', true) : '');
  $('#p_stats').innerHTML = r.hops.map(function (h, i) { return stat('Link ' + (i + 1), fmtT(h.q + h.T + h.P, 4), (h.q ? 'queue ' + fmtT(h.q, 3) + ' + ' : '') + 'transmit ' + fmtT(h.T, 3) + ' + propagation ' + fmtT(h.P, 3)); }).join('') +
    stat('One packet, Host A to Host B', fmtT(r.total), 'every link transmits it again', true) + stat('Bottleneck', 'Link ' + (bi + 1) + ': ' + fmtRate(L[bi].bw), 'the most this path can carry') +
    (pathState.n > 1 ? stat('All ' + fmt(pathState.n) + ' packets', fmtT(msg), 'one every ' + fmtT(bits / L[bi].bw, 3) + ' after the first', true) + stat('Throughput for the message', fmtRate(bits * pathState.n / msg), 'the bottleneck limits it') : '');
  $('#p_work').innerHTML = r.hops.map(function (h, i) { return '<li>Link ' + (i + 1) + ': ' + fmtT(h.q, 4) + ' + ' + fmt(bits) + ' bits ÷ ' + fmtRate(h.bw) + ' (' + fmtT(h.T, 4) + ') + ' + fmtDist(links[i].dist) + ' ÷ ' + fmtN(SPEED[links[i].medium]) + ' m/s (' + fmtT(h.P, 4) + ') = ' + fmtT(h.q + h.T + h.P, 5) + '.</li>'; }).join('') +
    '<li>One packet: ' + fmtT(r.total, 5) + '.</li>' + (pathState.n > 1 ? '<li>' + fmt(pathState.n) + ' packets sent back to back: the last arrives (' + fmt(pathState.n) + ' − 1) × ' + fmtT(bits / L[bi].bw, 4) + ' after the first, at ' + fmtT(msg, 5) + '.</li>' : '');
  pathTL.set(names, L, bits);
}

function calcInit() {
  $('#c_unit').innerHTML = sizeUnitOptions('B'); $('#c_bwu').innerHTML = rateUnitOptions('Mbps'); $('#c_med').innerHTML = mediumOptions('fiber');
  $('#c_preset').innerHTML = '<option value="">choose…</option>' + Object.keys(C_PRESETS).map(function (k) { return '<option value="' + k + '">' + esc(C_PRESETS[k].name) + '</option>'; }).join('');
  $('#c_preset').onchange = function () {
    var P = C_PRESETS[this.value]; if (!P) return;
    calcState.size = P.size; calcState.unit = P.unit; calcState.bw = P.bw; calcState.dist = P.dist; calcState.medium = P.medium; calcState.q = 0; calcState.rtt = '';
    setCalcInputs(); calc();
  };
  ['#c_size', '#c_bw', '#c_dist', '#c_q', '#c_rtt'].forEach(function (id) { $(id).oninput = calc; });
  ['#c_unit', '#c_bwu', '#c_distu', '#c_med'].forEach(function (id) { $(id).onchange = calc; });
  $('#c_strip').innerHTML = stripHTML('c_'); $('#c_stripb').innerHTML = stripHTML('c_b');
  $('#p_strip').innerHTML = stripHTML('p_', 'Send one packet'); $('#p_stripb').innerHTML = stripHTML('p_b', 'Send one packet');
  calcTL = new Timeline({ strips: ['c_', 'c_b'], wire: $('#c_wire'), st: $('#c_st'), detail: true, alive: function () { return current === 'calc'; } });
  pathTL = new Timeline({ strips: ['p_', 'p_b'], wire: $('#p_wire'), st: $('#p_st'), detail: false, alive: function () { return current === 'calc'; } });
  function seg(path) { $('#c_one').hidden = path; $('#c_path').hidden = !path; $('#c_seg1').setAttribute('aria-pressed', String(!path)); $('#c_seg2').setAttribute('aria-pressed', String(path)); }
  $('#c_seg1').onclick = function () { seg(false); }; $('#c_seg2').onclick = function () { seg(true); };
  $('#p_size').oninput = pathCalc; $('#p_n').oninput = pathCalc;
  $('#p_add').onclick = function () { if (pathState.links.length < 4) { pathState.links.push({ bw: 1e9, dist: 10000, medium: 'fiber', q: 0 }); renderPathLinks(); pathCalc(); } };
  $('#p_del').onclick = function () { if (pathState.links.length > 1) { pathState.links.pop(); renderPathLinks(); pathCalc(); } };
  setCalcInputs(); renderPathLinks(); renderCommands($('#c_cmds'));
}
function calcShow() { setCalcInputs(); calc(); pathCalc(); }
