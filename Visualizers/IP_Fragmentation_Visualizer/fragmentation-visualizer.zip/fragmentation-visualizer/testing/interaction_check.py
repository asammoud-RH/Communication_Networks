"""Click-through check for Packet Fragmentation Demonstration: every Try it task, the animations,
the calculator presets, link parameters, and every lesson at phone width."""
import asyncio, sys, pathlib
from playwright.async_api import async_playwright
URL = pathlib.Path(sys.argv[1]).resolve().as_uri()
OUT = pathlib.Path('shots2'); OUT.mkdir(exist_ok=True)

async def main():
    errs = []
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
        pg = await b.new_page(viewport={'width': 1280, 'height': 900})
        pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: errs.append(m.text) if m.type == 'error' else None)
        async def fb(sel): return (await pg.inner_text(sel)).strip()[:160]
        # Lesson 1: pick the asked link and the right size
        await pg.goto(URL + '?mode=learn&lesson=1'); await pg.wait_for_timeout(300)
        t = await pg.inner_text('.tryit p'); name = t.split('Choose ')[1].split(' and set')[0]
        opt = await pg.evaluate('(n)=>[...document.querySelectorAll("#l1link option")].find(o=>o.textContent.startsWith(n)).value', name)
        await pg.select_option('#l1link', opt); mtu = int((await pg.evaluate('(v)=>document.querySelector(`#l1link option[value="${v}"]`).textContent', opt)).split('(')[1].rstrip(')'))
        await pg.fill('#l1n', str(mtu + 1)); await pg.dispatch_event('#l1n', 'input'); print('L1 too big:', await fb('#l1fb'))
        await pg.fill('#l1n', str(mtu)); await pg.dispatch_event('#l1n', 'input'); print('L1:', await fb('#l1fb'))
        await pg.screenshot(path=str(OUT / 'l1.png'), full_page=True)
        # Lesson 2: steps animation and the answer
        await pg.click('#lnext'); await pg.wait_for_timeout(200)
        await pg.fill('#l2m', '1000'); await pg.fill('#l2d', '1014'); await pg.dispatch_event('#l2d', 'input')
        await pg.click('#l2go'); await pg.wait_for_timeout(2400); await pg.screenshot(path=str(OUT / 'l2-steps.png'), full_page=True)
        await pg.wait_for_timeout(2500); print('L2 steps:', (await pg.inner_text('#l2steps')).replace('\n', ' | '))
        m = int((await pg.inner_text('.tryit p')).split('MTU of ')[1].split(' ')[0])
        await pg.fill('#l2a', str(m - 20)); await pg.click('#l2c'); print('L2 wrong:', await fb('#l2fb'))
        await pg.fill('#l2a', str((m - 20) // 8 * 8)); await pg.click('#l2c'); print('L2:', await fb('#l2fb'))
        # Lesson 3
        await pg.click('#lnext'); await pg.wait_for_timeout(200)
        ans = await pg.evaluate('''()=>{const t=document.querySelector('#ltext .tryit p').textContent;if(!/with ([\\d,]+) data/.test(t))return 'TEXT:'+t;const D=+t.match(/with ([\\d,]+) data/)[1].replace(/,/g,'');const M=+t.match(/MTU of (\\d+)/)[1];
          const fr=FragViz.splitFrag({off:0,len:D,mf:false},M);const k=t.match(/fragment (\\d+)\\?/);return k?fr[+k[1]-1].off/8:fr[fr.length-1].len+20}''')
        await pg.fill('#l3a', str(ans)); await pg.click('#l3c'); print('L3:', await fb('#l3fb'))
        # Lesson 4: animation, then the puzzle
        await pg.click('#lnext'); await pg.wait_for_timeout(200)
        await pg.select_option('#l4p', 'refrag'); await pg.click('#l4go'); await pg.wait_for_timeout(1500)
        await pg.screenshot(path=str(OUT / 'l4-anim.png'), full_page=True); await pg.wait_for_timeout(3500)
        print('L4 caption:', await fb('#l4cap'))
        await pg.click('#l4puz'); await pg.fill('#l4m2', '520'); await pg.dispatch_event('#l4m2', 'input'); print('L4 hint:', await fb('#l4fb'))
        await pg.fill('#l4m2', '480'); await pg.dispatch_event('#l4m2', 'input'); print('L4:', await fb('#l4fb'))
        await pg.screenshot(path=str(OUT / 'l4-done.png'), full_page=True)
        # Lesson 5: deliver with a loss, then the answer
        await pg.click('#lnext'); await pg.wait_for_timeout(200)
        await pg.select_option('#l5s', 'twice'); await pg.check('#l5lose'); await pg.click('#l5all'); await pg.wait_for_timeout(7000)
        print('L5 log end:', (await pg.inner_text('#l5log')).split('\n')[-1][:150])
        await pg.screenshot(path=str(OUT / 'l5-lost.png'), full_page=True)
        await pg.uncheck('#l5lose'); await pg.click('#l5all'); await pg.wait_for_timeout(4000); print('L5 whole:', (await pg.inner_text('#l5log')).split('\n')[-1][:100])
        ans = await pg.evaluate('''()=>{const li=[...document.querySelectorAll('.tryit li')].map(l=>l.textContent.match(/Offset (\\d+), M (\\d), Total Length (\\d+)/).slice(1).map(Number));
           const full=Math.max(...li.filter(x=>x[1]==1).map(x=>x[2]-20))/8;const offs=new Set(li.map(x=>x[0]));for(let o=0;;o+=full){if(!offs.has(o))return o}}''')
        await pg.fill('#l5a', str(ans)); await pg.click('#l5c'); print('L5:', await fb('#l5fb'))
        # Lesson 6: run pings in each mode, then the answer
        await pg.click('#lnext'); await pg.wait_for_timeout(200)
        for mode in ['want', 'do', 'winf']:
            await pg.select_option('#l6mode', mode); await pg.select_option('#l6m', '1400'); await pg.click('#l6go'); await pg.wait_for_timeout(6500)
            print('L6', mode, '|', (await pg.inner_text('#l6term')).replace('\n', ' / ')[:330])
            if mode == 'want': await pg.screenshot(path=str(OUT / 'l6-run.png'), full_page=True)
        m2 = int((await pg.inner_text('.tryit p')).split('Link 2 to ')[1].split('.')[0])
        await pg.fill('#l6a', str(m2 - 28)); await pg.click('#l6c'); print('L6:', await fb('#l6fb'))
        print('lessons done:', await pg.evaluate('JSON.parse(localStorage.getItem("fragviz.progress")).lessons'), '| points', await pg.inner_text('#xp'))
        # Calculator: presets, DF, kinds, add/remove links, errors
        await pg.goto(URL + '?mode=calc&size=1392&kind=ping&mtus=1500-532-1500&df=1'); await pg.wait_for_timeout(300)
        print('calc DF:', (await pg.inner_text('#c_df_out')).replace('\n', ' / ')[:300])
        await pg.screenshot(path=str(OUT / 'calc-df.png'), full_page=True)
        await pg.select_option('#c_preset', 'refrag'); await pg.select_option('#c_df', '0'); await pg.wait_for_timeout(200)
        print('calc stats:', (await pg.inner_text('#c_stats')).replace('\n', ' '))
        await pg.click('#c_add'); print('add disabled at 4:', await pg.is_disabled('#c_add')); await pg.click('#c_del'); await pg.click('#c_add'); print('links now:', await pg.evaluate('document.querySelectorAll("#c_links input").length'))
        await pg.select_option('#c_kind', 'udp'); await pg.fill('#c_size', '70000'); await pg.dispatch_event('#c_size', 'input'); print('calc error:', await fb('#c_err'))
        await pg.fill('#c_size', '8000'); await pg.dispatch_event('#c_size', 'input'); print('url:', pg.url.split('?')[1])
        await pg.screenshot(path=str(OUT / 'calc-4links.png'), full_page=True)
        # instructor check
        await pg.goto(URL); await pg.evaluate('document.querySelectorAll("footer details")[1].open=true')
        code = await pg.evaluate('FragViz.code("M",88,8,10)'); await pg.fill('#verifyIn', code); await pg.click('#verifyBtn'); print('verify:', await pg.inner_text('#verifyOut'))
        # phone: every lesson and the calculator
        ph = await b.new_page(viewport={'width': 390, 'height': 844}); ph.on('pageerror', lambda e: errs.append('phone ' + str(e)))
        for i in range(1, 7):
            await ph.goto(URL + f'?mode=learn&lesson={i}'); await ph.wait_for_timeout(300)
            sw = await ph.evaluate('document.documentElement.scrollWidth'); print(f'phone lesson {i}: {sw}', 'OK' if sw <= 390 else 'SCROLLS')
            if i in (4, 6): await ph.screenshot(path=str(OUT / f'phone-l{i}.png'), full_page=True)
        await ph.goto(URL + '?mode=challenge&level=H'); await ph.click('#ch-start'); await ph.wait_for_timeout(200)
        sw = await ph.evaluate('document.documentElement.scrollWidth'); print('phone question:', sw)
        # blocked storage: the app must still work
        bl = await b.new_page(); bl.on('pageerror', lambda e: errs.append('blocked ' + str(e)))
        await bl.add_init_script('Object.defineProperty(window,"localStorage",{get(){throw new Error("blocked")}})')
        await bl.goto(URL + '?mode=learn&lesson=2'); await bl.wait_for_timeout(300); print('blocked storage lesson title:', await bl.inner_text('#ltext h2'))
        await b.close()
    print('ERRORS', errs)
asyncio.run(main())
