"""Click-through test for TCP Visualizer: solves every lesson task, tries wrong answers,
runs every calculator preset, toggles losses, checks link parameters and blocked storage."""
import asyncio, sys, pathlib, json
from playwright.async_api import async_playwright
APP = pathlib.Path(sys.argv[1]).resolve(); URL = APP.as_uri(); OUT = pathlib.Path(sys.argv[2] if len(sys.argv) > 2 else 'shots2'); OUT.mkdir(exist_ok=True)
async def main():
    errs = []; fails = []
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
        pg = await b.new_page(viewport={'width': 1280, 'height': 900})
        pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: errs.append(m.text) if m.type == 'error' else None)
        for i in range(1, 9):
            await pg.goto(URL + f'?mode=learn&lesson={i}'); await pg.wait_for_timeout(300)
            check = f'#l{i}c'
            for rep in range(6):
                # wrong answer first: empty fields
                await pg.click(check); await pg.wait_for_timeout(50)
                cls = await pg.get_attribute(f'#l{i}fb', 'class')
                if 'bad' not in cls: fails.append(f'lesson {i}: empty answer not rejected')
                await pg.evaluate('TCPVisualizer.solveLesson()'); await pg.click(check); await pg.wait_for_timeout(50)
                cls = await pg.get_attribute(f'#l{i}fb', 'class')
                if 'ok' not in cls: fails.append(f'lesson {i} rep {rep}: right answer rejected: ' + await pg.inner_text(f'#l{i}fb'))
                nb = await pg.query_selector(f'button#l{i}x') or await pg.query_selector(f'button#l{i}n')
                if nb: await nb.click(); await pg.wait_for_timeout(80)
            # play the timeline a bit
            if await pg.query_selector('[data-p=first]'):
                await pg.click('[data-p=first]'); await pg.click('[data-p=next]'); await pg.click('[data-p=next]'); await pg.wait_for_timeout(50)
                await pg.screenshot(path=str(OUT / f'l{i}-step.png'), full_page=True)
                await pg.click('[data-p=last]')
            await pg.screenshot(path=str(OUT / f'l{i}.png'), full_page=True)
        # lesson case buttons
        await pg.goto(URL + '?mode=learn&lesson=2'); await pg.wait_for_timeout(200)
        for k in ['closed', 'synlost', 'salost', 'silent', 'simopen', 'normal']:
            await pg.click(f'#l2case [data-k={k}]'); await pg.wait_for_timeout(120); await pg.screenshot(path=str(OUT / f'l2-{k}.png'), full_page=True)
        await pg.goto(URL + '?mode=learn&lesson=7'); await pg.wait_for_timeout(200)
        for k in ['aFirst', 'bFirst', 'three', 'both', 'lastAck', 'reset']:
            await pg.click(f'#l7case [data-k={k}]'); await pg.wait_for_timeout(120); await pg.screenshot(path=str(OUT / f'l7-{k}.png'), full_page=True)
        await pg.goto(URL + '?mode=learn&lesson=5'); await pg.wait_for_timeout(200)
        await pg.click('#l5l [data-k="8"]'); await pg.wait_for_timeout(100); await pg.click('#l5s'); await pg.wait_for_timeout(100)
        await pg.screenshot(path=str(OUT / 'l5-two-losses-nosack.png'), full_page=True)
        await pg.click('#ldr [data-n="5"] text >> nth=1'); await pg.wait_for_timeout(100)
        # calculator presets
        await pg.goto(URL + '?mode=calc'); await pg.wait_for_timeout(300)
        for pr in await pg.evaluate('Object.keys(TCPVisualizer.PRESETS)'):
            await pg.select_option('#c_preset', pr); await pg.wait_for_timeout(150)
            st = await pg.inner_text('#c_stats'); badges = await pg.inner_text('#c_badges'); err = await pg.inner_text('#c_err')
            print('preset', pr, '|', ' '.join(st.split())[:150], '|', ' '.join(badges.split()), '|', err)
            await pg.screenshot(path=str(OUT / f'calc-{pr}.png'), full_page=True)
        await pg.fill('#c_lose', '5, 6'); await pg.dispatch_event('#c_lose', 'change'); await pg.wait_for_timeout(100)
        await pg.click('#c_ldr [data-n="4"] text >> nth=1'); await pg.wait_for_timeout(100)
        print('lose after click:', await pg.input_value('#c_lose'))
        await pg.click('#calcRoot summary:has-text("All settings")'); await pg.click('#calcRoot summary:has-text("Decode a TCP header")')
        await pg.fill('#c_fields [data-f=delay]', '-5'); await pg.dispatch_event('#c_fields [data-f=delay]', 'change'); await pg.wait_for_timeout(100)
        print('bad input message:', await pg.inner_text('#c_err'))
        await pg.fill('#q_hex', '00 50'); await pg.wait_for_timeout(50); print('short hex:', await pg.inner_text('#q_hexout'))
        # links
        await pg.goto(URL + '?mode=calc&preset=fast&lose=5-9&raw=1'); await pg.wait_for_timeout(300)
        print('link lose:', await pg.input_value('#c_lose'), 'url', pg.url.split('?')[1])
        await pg.goto(URL + '?mode=challenge&level=H&os=windows'); await pg.wait_for_timeout(200)
        print('link level:', await pg.get_attribute('[data-level=H]', 'aria-pressed'), 'os', await pg.get_attribute('.topbar [data-os=windows]', 'aria-pressed'))
        # instructor code check
        code = await pg.evaluate("TCPVisualizer.code('H', 120, 9, 10)")
        await pg.click('footer summary:has-text("instructors")'); await pg.fill('#verifyIn', code); await pg.click('#verifyBtn'); print('code', code, await pg.inner_text('#verifyOut'))
        await pg.fill('#verifyIn', code[:-1] + ('A' if code[-1] != 'A' else 'B')); await pg.click('#verifyBtn'); print('edited:', await pg.inner_text('#verifyOut'))
        # storage blocked
        ctx = await b.new_context(); pb = await ctx.new_page()
        await pb.add_init_script("Object.defineProperty(window, 'localStorage', { get() { throw new Error('blocked'); } });")
        e2 = []; pb.on('pageerror', lambda e: e2.append(str(e)))
        await pb.goto(URL + '?mode=learn&lesson=3'); await pb.wait_for_timeout(300); await pb.evaluate('TCPVisualizer.solveLesson()'); await pb.click('#l3c')
        print('blocked storage errors:', e2, await pb.inner_text('#l3fb'))
        await b.close()
    print('FAILS', fails); print('ERRORS', errs)
asyncio.run(main())
