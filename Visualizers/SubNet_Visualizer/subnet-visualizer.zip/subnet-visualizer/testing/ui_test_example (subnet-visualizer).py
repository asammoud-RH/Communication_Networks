"""Click-through test for Subnet Visualizer: an example to copy for new apps.

It does what a student does: solves every lesson's Try it task through the
page (reading the task text and computing the answer), plays the ping
animation, uses the calculator, plays a full Hard round, and opens the app at
phone width. It prints each lesson's feedback and every console error, and
saves screenshots to look at. For a new app, keep the structure and replace
the lesson-specific steps; smoke_test.py covers the parts every app shares.

Usage: python3 "ui_test_example (subnet-visualizer).py" path/to/subnet-visualizer.html
"""
import sys, pathlib
import asyncio
from playwright.async_api import async_playwright
URL=pathlib.Path(sys.argv[1]).resolve().as_uri()
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
        pg=await b.new_page(viewport={'width':1280,'height':900}); errs=[]
        pg.on('pageerror',lambda e:errs.append(str(e)+' @ '+(e.stack or '')[:300])); pg.on('console',lambda m:errs.append(m.text) if m.type=='error' else None)
        await pg.goto(URL); await pg.wait_for_timeout(300)
        await pg.screenshot(path='u_home.png',full_page=True)
        await pg.click('[data-go=learn]'); await pg.wait_for_timeout(300)
        await pg.screenshot(path='u_map.png',full_page=True)   # the lesson map comes first
        await pg.click('#lnext'); await pg.wait_for_timeout(300)
        # lesson 1: set slider to target
        tp=await pg.evaluate("(()=>{const t=document.querySelector('.tryit b.mono').textContent;return t})()")
        pfx={'255.255.255.128':25,'255.255.255.192':26,'255.255.255.224':27,'255.255.255.240':28,'255.255.255.248':29,'255.255.255.252':30,'255.255.0.0':16,'255.255.240.0':20,'255.255.252.0':22}[tp]
        await pg.evaluate(f"(()=>{{const s=document.querySelector('#l1p');s.value={pfx};s.dispatchEvent(new Event('input'))}})()")
        print('L1:',await pg.inner_text('#l1fb'))
        await pg.screenshot(path='u_l1.png',full_page=True)
        await pg.click('#lnext'); await pg.wait_for_timeout(300)
        t=await pg.evaluate("(()=>{const s=document.querySelector('.tryit p').textContent;return s})()")
        import re; m=re.search(r'the (broadcast|network) address of \S+\.(\d+)/(\d+)',t); kind,x,pp=m.group(1),int(m.group(2)),int(m.group(3))
        size=2**(32-pp); n=x//size*size; ans=n if kind=='network' else n+size-1
        await pg.fill('#l2a',str(ans)); await pg.click('#l2c'); print('L2:',await pg.inner_text('#l2fb'))
        await pg.click('#l2go'); await pg.wait_for_timeout(1400)
        await pg.screenshot(path='u_l2.png',full_page=True)
        await pg.click('#lnext'); await pg.wait_for_timeout(300)
        t=await pg.inner_text('.tryit p'); xs=[int(v) for v in re.findall(r'\.(\d+)\b',t) if v]; 
        m=re.search(r'Are \S+\.(\d+) and \S+\.(\d+) in the same /(\d+)',t); a,c,pp=int(m.group(1)),int(m.group(2)),int(m.group(3)); size=2**(32-pp)
        await pg.click('#l3yes' if a//size==c//size else '#l3no'); print('L3:',await pg.inner_text('#l3fb'))
        await pg.screenshot(path='u_l3.png',full_page=True)
        await pg.click('#lnext'); await pg.wait_for_timeout(300)
        await pg.screenshot(path='u_l4a.png',full_page=True)
        # lesson 4: Host A .40/24, Host B .200/25: move B into the lower half (.60)
        await pg.fill('input[data-k=B][data-f=x]','60'); await pg.wait_for_timeout(300)
        print('L4:',await pg.inner_text('#l4fb'))
        await pg.select_option('.p_from','A'); await pg.select_option('.p_speed','1.8'); await pg.click('.p_play'); await pg.wait_for_timeout(2300)
        el=await pg.query_selector('#topo'); await el.screenshot(path='u_topo_mid.png')
        await pg.wait_for_timeout(9000); print('LOG4:',(await pg.inner_text('.p_log'))[-160:])
        await pg.screenshot(path='u_l4b.png',full_page=True)
        await pg.click('#lnext'); await pg.wait_for_timeout(300)
        await pg.check('input[data-k=A][data-f=second]'); await pg.wait_for_timeout(200)
        # lesson 5: Host B .150/26: give Host A .140/26 as its second address
        await pg.fill('input[data-k=A][data-i="1"][data-f=x]','140'); await pg.select_option('select[data-k=A][data-i="1"]','26'); await pg.wait_for_timeout(300)
        print('L5:',await pg.inner_text('#l5fb'))
        await pg.select_option('.p_from','B'); await pg.select_option('.p_to','S:254'); 
        for i in range(4): await pg.click('.p_step'); await pg.wait_for_timeout(700)
        await pg.click('#pcard details.fold summary >> nth=0'); await pg.wait_for_timeout(200)
        await pg.screenshot(path='u_l5.png',full_page=True)
        await pg.click('#lnext'); await pg.wait_for_timeout(300)
        # lesson 6: click right choice using model
        ans=await pg.evaluate("(()=>{return null})()")
        btns=await pg.query_selector_all('#l6c .choice')
        for bt in btns:
            await bt.click(); await pg.wait_for_timeout(100)
            if 'right' in (await bt.get_attribute('class')): break
        print('L6:',await pg.inner_text('#l6fb'))
        await pg.click('[data-os=win]'); await pg.wait_for_timeout(100)
        await pg.screenshot(path='u_l6.png',full_page=True)
        print('XP:',await pg.inner_text('#xp'), 'stepper:',await pg.inner_text('#stepper'))
        # calculator
        await pg.click('.modes [data-mode=calc]'); await pg.fill('#c_ip','10.20.30.40/20'); await pg.wait_for_timeout(200)
        for sm in await pg.query_selector_all('#view-calc details.card > summary'): await sm.click()
        print('CALC:',(await pg.inner_text('#c_stats')).replace('\n',' | '))
        await pg.fill('#o_b','192.168.11.0/24'); await pg.wait_for_timeout(100); print('OVL:',await pg.inner_text('#o_res'))
        await pg.screenshot(path='u_calc.png',full_page=True)
        # challenge: hard round answered via the stored answers
        await pg.click('.modes [data-mode=challenge]'); await pg.click('[data-level=H]'); await pg.click('#ch-start'); await pg.wait_for_timeout(200)
        await pg.screenshot(path='u_q1.png',full_page=True)
        for i in range(10):
            # peek at the answer through the DOM? use hint button then pick by evaluating the generator state is private; answer by trying choice 0 / typed 0
            inp=await pg.query_selector('#q_in')
            if inp: await pg.fill('#q_in','0'); await pg.click('#q_ok')
            else: await pg.click('#q_body .choice >> nth=0')
            await pg.wait_for_timeout(100)
            if i==2: await pg.screenshot(path='u_q3.png',full_page=True)
            await pg.click('#q_next'); await pg.wait_for_timeout(100)
        await pg.screenshot(path='u_end.png',full_page=True)
        print('END:',(await pg.inner_text('#ch-end'))[:300])
        # phone
        ph=await b.new_page(viewport={'width':390,'height':844},device_scale_factor=2)
        await ph.goto(URL); await ph.wait_for_timeout(300); await ph.screenshot(path='u_phone_home.png')
        await ph.goto(URL+'?mode=learn&lesson=4'); await ph.wait_for_timeout(400); await ph.screenshot(path='u_phone_l4.png',full_page=True)
        print('ERRORS',errs)
        await b.close()
asyncio.run(main())
