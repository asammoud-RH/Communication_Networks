(function () {
'use strict';
var APP_ID = 'fragviz';

/* ===================================================== small helpers */
var $ = function (s, r) { return (r || document).querySelector(s); };
var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
function rnd(a, b) { return a + Math.floor(Math.random() * (b - a + 1)); }
function pick(a) { return a[Math.floor(Math.random() * a.length)]; }
function shuffle(a) { a = a.slice(); for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
function fmt(n) { return Number(n).toLocaleString('en-US'); }
var reduceMotion = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);

/* storage that never throws (some embeds block it) */
var store = {
  get: function (k, d) { try { var v = window.localStorage.getItem(APP_ID + '.' + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
  set: function (k, v) { try { window.localStorage.setItem(APP_ID + '.' + k, JSON.stringify(v)); } catch (e) { /* ignore */ } }
};

/* ===================================================== the fragmentation model
   A datagram or fragment: { off: first data byte (in bytes), len: data bytes, mf: More fragments flag }.
   The IP header is 20 bytes with no options. */
var HDR = 20, MIN_MTU = 68, MAX_DATA = 65515, LINUX_MIN_PMTU = 552;
function maxData(mtu) { return Math.floor((mtu - HDR) / 8) * 8; }        // data bytes in every fragment but the last
function fits(len, mtu) { return HDR + len <= mtu; }
/* One link: split one datagram or fragment, the way Linux does (checked on a real kernel):
   cut pieces of maxData bytes until the rest fits in one fragment (up to MTU - 20 bytes, any length). */
function splitFrag(f, mtu) {
  if (fits(f.len, mtu)) return [f];
  var m = maxData(mtu), room = mtu - HDR, out = [], o = 0;
  while (f.len - o > room) { out.push({ off: f.off + o, len: m, mf: true }); o += m; }
  out.push({ off: f.off + o, len: f.len - o, mf: f.mf });
  return out;
}
function countFrags(len, mtu) { return splitFrag({ off: 0, len: len, mf: false }, mtu).length; }
/* a short worked explanation of one split */
function explainSplit(len, mtu) {
  var fr = splitFrag({ off: 0, len: len, mf: false }, mtu), m = maxData(mtu), room = mtu - HDR, n = fr.length, last = fr[n - 1].len;
  if (n === 1) return '20 + ' + fmt(len) + ' = ' + fmt(len + HDR) + ' ≤ ' + fmt(mtu) + ', so it fits in one datagram.';
  return 'Every fragment but the last carries ' + fmt(m) + ' bytes (' + fmt(mtu) + ' − 20 = ' + fmt(room) + (room === m ? '' : ', rounded down to a multiple of 8') + '). ' +
    (n - 1) + ' × ' + fmt(m) + ' = ' + fmt((n - 1) * m) + ', and the last ' + fmt(last) + ' bytes fit in one fragment' + (last > m ? ' (the last one may carry up to ' + fmt(room) + ')' : '') + ': ' + n + ' fragments.';
}
/* Send `data` bytes over links with these MTUs. Link 0 starts at the source host.
   With df set, the first link whose MTU is too small drops the datagram (link 0: a local error at the source). */
function sendPath(data, mtus, df) {
  var frags = [{ off: 0, len: data, mf: false }], hops = [];
  for (var i = 0; i < mtus.length; i++) {
    var big = frags.some(function (f) { return !fits(f.len, mtus[i]); });
    if (big && df) return { hops: hops, ok: false, dropAt: i, mtu: mtus[i], frags: frags };
    var next = []; frags.forEach(function (f) { next = next.concat(splitFrag(f, mtus[i])); });
    frags = next; hops.push({ mtu: mtus[i], frags: frags, split: big });
  }
  return { hops: hops, ok: true, dropAt: -1, frags: frags };
}
function totalLen(f) { return HDR + f.len; }
function offField(f) { return f.off / 8; }
function newIdent() { return rnd(4096, 65535); }
function hex4(n) { var s = n.toString(16).toUpperCase(); while (s.length < 4) s = '0' + s; return '0x' + s; }
/* what the user typed -> IP data bytes */
var KINDS = { ping: { add: 8, name: 'ping payload' }, udp: { add: 8, name: 'UDP payload' }, data: { add: 0, name: 'IP data' } };

/* ===================================================== theme colors for figures */
var C = { brand: '#00A2D7', navy: '#0B3D5C', ink: '#1B2A35', panel: '#CFE6F0', soft: '#EAF5FA', gray: '#E4E4E4', amber: '#F5A524', ok: '#13A88A', bad: '#E5484D', oneway: '#D98A00', white: '#FFFFFF', muted: '#5B6B78' };
var CAT = [
  { line: '#00A2D7', fill: '#CFE6F0' }, { line: '#7B61FF', fill: '#E7E1FF' },
  { line: '#E08B00', fill: '#FCE9C6' }, { line: '#13A88A', fill: '#D3F1E8' }, { line: '#D6457A', fill: '#F9DCE7' }
];

/* ===================================================== figure library (inches, y up, sizes in points) */
var NS = 'http://www.w3.org/2000/svg', figN = 0;
function el(tag, at, parent) { var e = document.createElementNS(NS, tag); if (at) for (var k in at) if (at[k] !== null && at[k] !== undefined) e.setAttribute(k, at[k]); if (parent) parent.appendChild(e); return e; }
function r4(v) { return Math.round(v * 10000) / 10000; }
function Fig(svg, x0, x1, y0, y1, k) {
  while (svg.firstChild) svg.removeChild(svg.firstChild);
  svg.setAttribute('viewBox', '0 0 ' + r4(x1 - x0) + ' ' + r4(y1 - y0));
  this.svg = svg; this.x0 = x0; this.y1 = y1; this.k = k || 1.2; this.id = 'f' + (++figN);
  var defs = el('defs', null, svg);
  var m = el('marker', { id: this.id + 'a', viewBox: '0 0 10 10', refX: 10, refY: 5, markerWidth: 0.13, markerHeight: 0.13, markerUnits: 'userSpaceOnUse', orient: 'auto' }, defs);
  el('path', { d: 'M0 0L10 5L0 10z', fill: C.ink }, m);
  var m2 = el('marker', { id: this.id + 'r', viewBox: '0 0 10 10', refX: 10, refY: 5, markerWidth: 0.13, markerHeight: 0.13, markerUnits: 'userSpaceOnUse', orient: 'auto' }, defs);
  el('path', { d: 'M0 0L10 5L0 10z', fill: C.bad }, m2);
  this.root = el('g', { 'font-family': 'Segoe UI, system-ui, -apple-system, Helvetica Neue, Roboto, Arial, sans-serif' }, svg);
}
Fig.prototype.X = function (x) { return r4(x - this.x0); };
Fig.prototype.Y = function (y) { return r4(this.y1 - y); };
Fig.prototype.pt = function (v) { return r4(v / 72); };
Fig.prototype.g = function (p) { return el('g', null, p || this.root); };
Fig.prototype.rect = function (x, y, w, h, o) {
  o = o || {};
  return el('rect', { x: this.X(x), y: this.Y(y + h), width: r4(Math.max(0, w)), height: r4(h), rx: o.rx ? r4(o.rx) : null, fill: o.fill || C.white,
    stroke: o.stroke || C.brand, 'stroke-width': this.pt(o.lw || 1.1), 'stroke-dasharray': o.dash ? o.dash.map(this.pt, this).join(' ') : null }, o.parent || this.root);
};
Fig.prototype.slab = function (x, y, w, h, o) {   // slab box: thin outline, heavy top and right edges
  o = o || {};
  var g = this.g(o.parent);
  g.box = this.rect(x, y, w, h, { fill: o.fill || C.white, stroke: o.stroke || C.brand, lw: 1.1, parent: g });
  el('path', { d: 'M' + this.X(x) + ' ' + this.Y(y + h) + 'H' + this.X(x + w) + 'V' + this.Y(y), fill: 'none', stroke: o.stroke || C.brand,
    'stroke-width': this.pt(o.thick || 3.4), 'stroke-linecap': 'square' }, g);
  if (o.text) this.text(x + w / 2, y + h / 2, o.text, { fs: o.fs || 10, bold: o.bold, parent: g, color: o.color });
  return g;
};
Fig.prototype.line = function (x1, y1, x2, y2, o) {
  o = o || {};
  return el('line', { x1: this.X(x1), y1: this.Y(y1), x2: this.X(x2), y2: this.Y(y2), stroke: o.color || C.ink, 'stroke-width': this.pt(o.lw || 1.3),
    'stroke-dasharray': o.dash ? o.dash.map(this.pt, this).join(' ') : null }, o.parent || this.root);
};
Fig.prototype.poly = function (pts, o) {
  o = o || {}; var self = this;
  return el('polyline', { points: pts.map(function (p) { return self.X(p[0]) + ',' + self.Y(p[1]); }).join(' '), fill: 'none', stroke: o.color || C.ink,
    'stroke-width': this.pt(o.lw || 1.5), 'stroke-dasharray': o.dash ? o.dash.map(this.pt, this).join(' ') : null, 'stroke-linejoin': 'round' }, o.parent || this.root);
};
Fig.prototype.arrow = function (x1, y1, x2, y2, o) { o = o || {}; var l = this.line(x1, y1, x2, y2, o); l.setAttribute('marker-end', 'url(#' + this.id + (o.color === C.bad ? 'r' : 'a') + ')'); return l; };
Fig.prototype.text = function (x, y, s, o) {   // centered on y; no dominant-baseline, so every browser places it the same
  o = o || {};
  var size = (o.fs || 9.5) * this.k / 72, lh = size * 1.3, lines = String(s).split('\n'), n = lines.length;
  var t = el('text', { 'font-size': r4(size), fill: o.color || C.ink, 'fill-opacity': o.opacity, 'text-anchor': o.ha === 'left' ? 'start' : o.ha === 'right' ? 'end' : 'middle',
    'font-style': o.italic ? 'italic' : null, 'font-weight': o.bold ? 'bold' : null }, o.parent || this.root);
  var yc = this.Y(y), self = this;
  lines.forEach(function (ln, i) { var ts = el('tspan', { x: self.X(x), y: r4(yc + (i - (n - 1) / 2) * lh + size * 0.35) }, t); ts.textContent = ln; });
  return t;
};
Fig.prototype.tw = function (s, fs) { return String(s).length * (fs * this.k / 72) * 0.55; };
Fig.prototype.label = function (x, y, s, o) {   // text on a white patch, for labels that sit on lines
  o = o || {}; var w = this.tw(s, o.fs || 8.5) + 0.12, hh = (o.fs || 8.5) * this.k / 72 * 1.5;
  this.rect(x - w / 2, y - hh / 2, w, hh, { fill: o.bg || '#fff', stroke: o.bg || '#fff', lw: 0.1, rx: 0.05, parent: o.parent });
  return this.text(x, y, s, o);
};

/* ===================================================== figure: a datagram inside a frame (lesson 1) */
function drawFrame(svg, total, mtu, linkName) {
  var f = new Fig(svg, 0, 11, 0, 3.5, 2.0), L0 = 1.9, L1 = 9.9, maxB = Math.max(total, mtu) * 1.06;
  var X = function (b) { return L0 + b / maxB * (L1 - L0); };
  f.text(0.1, 3.2, linkName + ': MTU ' + fmt(mtu) + ' bytes', { fs: 9, ha: 'left', bold: true, color: C.navy });
  // the frame's payload area = the MTU
  f.rect(X(0), 1.75, X(mtu) - X(0), 0.7, { fill: C.soft, stroke: C.navy, lw: 1.2, dash: [4, 3], rx: 0.04 });
  f.text((X(0) + X(mtu)) / 2, 2.1, 'room for one IP datagram: the MTU', { fs: 7.8, color: C.muted, italic: true });
  f.rect(X(0) - 0.86, 1.75, 0.82, 0.7, { fill: C.gray, stroke: C.muted, lw: 1 }); f.text(X(0) - 0.45, 2.1, 'frame\nheader', { fs: 7 });
  f.rect(X(mtu) + 0.04, 1.75, 0.82, 0.7, { fill: C.gray, stroke: C.muted, lw: 1 }); f.text(X(mtu) + 0.45, 2.1, 'trailer', { fs: 7 });
  // the datagram
  var y = 0.7, hw = Math.max(0.08, X(HDR) - X(0)), over = total > mtu, end = X(Math.min(total, mtu));
  f.rect(X(0), y, hw, 0.55, { fill: C.navy, stroke: C.navy, lw: 1 });
  f.rect(X(0) + hw, y, Math.max(0.02, end - X(0) - hw), 0.55, { fill: C.panel, stroke: C.brand, lw: 1.2 });
  if (over) f.rect(X(mtu), y, X(total) - X(mtu), 0.55, { fill: '#FDE8E9', stroke: C.bad, lw: 1.4 });
  f.text(X(0) - 0.1, y + 0.27, 'Datagram', { fs: 8.2, ha: 'right', bold: true, color: C.navy });
  var lab = '20 + ' + fmt(total - HDR) + ' = ' + fmt(total) + ' bytes';
  if (f.tw(lab, 8) < end - X(0) - hw - 0.1) f.text((X(0) + hw + end) / 2, y + 0.27, lab, { fs: 8 });
  else f.text(X(total) + 0.1, y + 0.27, lab, { fs: 8, ha: 'left' });
  f.line(X(mtu), 0.45, X(mtu), 2.55, { color: over ? C.bad : C.ok, lw: 2 });
  f.text(Math.min(X(mtu), 8.4), 0.22, over ? '✗ ' + fmt(total - mtu) + ' bytes too big' : '✓ fits, ' + fmt(mtu - total) + ' to spare', { fs: 8.2, bold: true, color: over ? C.bad : C.ok });
  return f;
}

/* ===================================================== figure: cutting the data (lesson 2) */
function drawCut(svg, data, mtu, stage) {
  // stage: 0 nothing, 1 show MTU - 20, 2 show rounded size, 3 show cuts, 4 show fragments
  var m = maxData(mtu), frs = splitFrag({ off: 0, len: data, mf: false }, mtu), n = frs.length;
  var top = stage >= 4 ? 1.75 + Math.min(n, 12) * 0.74 : 2.7;
  var f = new Fig(svg, 0, 11, 0, top, 2.0), L0 = 1.95, L1 = 10.6, X = function (b) { return L0 + b / data * (L1 - L0); };
  var y = top - 1.0;
  f.text(L0 - 0.1, y + 0.22, 'Data', { fs: 8.5, ha: 'right', bold: true, color: C.navy });
  f.rect(X(0), y, X(data) - X(0), 0.44, { fill: C.panel, stroke: C.brand, lw: 1.2 });
  f.text(X(0), y + 0.62, '0', { fs: 7.5, color: C.muted }); f.text(X(data), y + 0.62, fmt(data), { fs: 7.5, color: C.muted, ha: 'right' });
  if (stage >= 3 && n > 1) frs.forEach(function (fr, i) {
    if (i) { f.line(X(fr.off), y - 0.1, X(fr.off), y + 0.54, { color: C.bad, lw: 2, dash: [3, 2] }); f.text(X(fr.off), y + 0.62, fmt(fr.off), { fs: 7.5, color: C.bad, bold: true }); }
    if (X(fr.off + fr.len) - X(fr.off) > 0.75) f.text((X(fr.off) + X(fr.off + fr.len)) / 2, y + 0.22, fmt(fr.len), { fs: 8, bold: true });
  });
  if (stage < 3 || n === 1) f.text((X(0) + X(data)) / 2, y + 0.22, fmt(data) + ' data bytes', { fs: 8 });
  if (stage >= 4) frs.slice(0, 12).forEach(function (fr, i) {
    var yy = y - 0.85 - i * 0.74, col = CAT[i % CAT.length];
    f.text(L0 - 0.4, yy + 0.2, i === 11 && n > 12 ? '… ' + n + ' in all' : 'Fragment ' + (i + 1), { fs: 7.8, ha: 'right', bold: true, color: C.navy });
    var hw = 0.3;
    f.rect(X(fr.off) - hw, yy, hw, 0.4, { fill: C.navy, stroke: C.navy, lw: 1 });
    f.rect(X(fr.off), yy, Math.max(0.02, X(fr.off + fr.len) - X(fr.off)), 0.4, { fill: col.fill, stroke: col.line, lw: 1.3 });
    var t = '20 + ' + fmt(fr.len) + ' = ' + fmt(totalLen(fr)) + (totalLen(fr) <= mtu ? ' ≤ ' + fmt(mtu) + ' ✓' : '');
    f.text(X(fr.off) + f.tw(t, 7.2) > 10.9 ? X(fr.off + fr.len) : X(fr.off), yy - 0.15, t, { fs: 7.2, ha: X(fr.off) + f.tw(t, 7.2) > 10.9 ? 'right' : 'left', color: C.muted });
  });
  if (stage >= 1 && stage < 4) {
    f.text(L0 - 1.8, 0.45, stage === 1 ? 'Room for data: ' + fmt(mtu) + ' − 20 = ' + fmt(mtu - HDR) + ' bytes' : 'Round down to a multiple of 8: ' + fmt(mtu - HDR) + ' → ' + fmt(m) + ' (' + (m / 8) + ' × 8)', { fs: 8.6, ha: 'left', bold: true, color: '#9A6500' });
  }
  return f;
}

/* ===================================================== figure: header fields of the original and each fragment (lesson 3) */
function drawHeaders(svg, data, mtu, ident, hiIdx) {
  var frs = splitFrag({ off: 0, len: data, mf: false }, mtu), rows = [{ off: 0, len: data, mf: false, orig: true }].concat(frs.length > 1 ? frs : []);
  var MAXR = 9; if (rows.length > MAXR + 1) rows = rows.slice(0, MAXR + 1);
  var RH = 0.7, BH = 0.48, top = 0.6 + rows.length * RH + (frs.length > 1 ? 0.5 : 0) + 0.2 + (frs.length > MAXR ? 0.4 : 0);
  var f = new Fig(svg, 0, 11, 0, top, 2.0);
  var cols = [['Ident', 0.95], ['M', 0.45], ['Offset', 0.85], ['Total Len.', 1.15]], X0 = 1.85, y = top - 0.85;
  var hdrW = cols.reduce(function (s, c) { return s + c[1]; }, 0), DX = X0 + hdrW + 0.15, DW = 10.85 - DX;
  var x = X0; cols.forEach(function (c) { f.text(x + c[1] / 2, top - 0.25, c[0], { fs: 7.6, bold: true, color: C.navy }); x += c[1]; });
  f.text(DX + DW / 2, top - 0.25, 'Bytes of the original data', { fs: 7.6, bold: true, color: C.navy });
  rows.forEach(function (r, i) {
    if (i === 1) { f.text(0.1, y + 0.24, '(b) Fragments', { fs: 7.8, ha: 'left', italic: true, color: C.muted }); y -= 0.45; }
    var hi = !r.orig && hiIdx === i - 1;
    f.text(X0 - 0.1, y + BH / 2, r.orig ? '(a) Original' : 'Fragment ' + i, { fs: 7.6, ha: 'right', bold: true, color: C.navy });
    var vals = [hex4(ident), r.mf ? '1' : '0', String(offField(r)), String(totalLen(r))], xx = X0;
    cols.forEach(function (c, j) {
      f.rect(xx, y, c[1], BH, { fill: hi ? C.amber : j === 1 && r.mf ? '#FCE9C6' : '#fff', stroke: C.navy, lw: 1 });
      f.text(xx + c[1] / 2, y + BH / 2, vals[j], { fs: 7.8, bold: j > 0 });
      xx += c[1];
    });
    var col = r.orig ? { fill: C.panel, line: C.brand } : CAT[(i - 1) % CAT.length], dx0 = DX + r.off / data * DW, dw = Math.max(0.05, r.len / data * DW);
    f.rect(DX, y, DW, BH, { fill: '#fff', stroke: '#C9DCE6', lw: 0.8, dash: [3, 2] });
    f.rect(dx0, y, dw, BH, { fill: col.fill, stroke: col.line, lw: 1.3 });
    var lab = fmt(r.off) + '–' + fmt(r.off + r.len - 1) + ' (' + fmt(r.len) + ')';
    if (f.tw(lab, 7.2) < dw - 0.08) f.text(dx0 + dw / 2, y + BH / 2, lab, { fs: 7.2 });
    else if (dx0 > DX + f.tw(lab, 7.2) + 0.1) f.text(dx0 - 0.06, y + BH / 2, lab, { fs: 7.2, ha: 'right' });
    else f.text(dx0 + dw + 0.06, y + BH / 2, lab, { fs: 7.2, ha: 'left' });
    y -= RH;
  });
  if (frs.length > MAXR) f.text(X0, y + 0.35, '… and ' + (frs.length - MAXR) + ' more fragments', { fs: 7.6, ha: 'left', italic: true, color: C.muted });
  return { f: f, frags: frs };
}

/* ===================================================== figure: the path and the fragments on each link
   res comes from sendPath. Returns a stage for the animation. */
var NODE_W = 1.15, NODE_H = 0.62;
function nodeName(i, n) { return i === 0 ? 'Host A' : i === n ? 'Host B' : 'R' + i; }
function drawPath(svg, mtus, res, opt) {
  opt = opt || {};
  var n = mtus.length, ROWS = 9, rowH = 0.6;
  var shown = res.hops.map(function (h) { return Math.min(h.frags.length, ROWS); });
  var maxRows = Math.max(1, Math.max.apply(null, shown.concat([res.ok ? 0 : 1])));
  // top to bottom: ICMP arrow, link labels, nodes, status labels, lane titles, lanes
  var icmpRow = opt.icmp && !res.ok && res.dropAt > 0 ? 0.36 : 0;   // room for the ICMP label above its arrow
  var W = 11, top = 0.85 + NODE_H + 0.55 + maxRows * rowH + 0.3 + icmpRow;
  var f = new Fig(svg, 0, W, 0, top, 2.0), yN = top - 0.92 - icmpRow - NODE_H, laneTop = yN - 0.4, xs = [];
  var span = W - 0.4 - NODE_W;
  for (var i = 0; i <= n; i++) xs.push(0.2 + (n ? i * span / n : 0));
  var cy = yN + NODE_H / 2, boxes = [], maxT = 0;
  res.hops.forEach(function (h) { h.frags.forEach(function (fr) { maxT = Math.max(maxT, totalLen(fr)); }); });
  if (!res.ok) res.frags.forEach(function (fr) { maxT = Math.max(maxT, totalLen(fr)); });
  // links and their labels
  for (i = 0; i < n; i++) {
    var xa = xs[i] + NODE_W, xb = xs[i + 1], dropped = !res.ok && res.dropAt === i;
    f.line(xa, cy, xb, cy, { lw: 2.2, color: dropped ? C.bad : C.navy });
    f.text((xa + xb) / 2, cy + 0.42, 'Link ' + (i + 1), { fs: 7.4, color: dropped ? C.bad : C.muted });
    f.text((xa + xb) / 2, cy + 0.17, 'MTU ' + mtus[i], { fs: 8, bold: true, color: dropped ? C.bad : C.navy });
  }
  for (i = 0; i <= n; i++) {
    var isHost = i === 0 || i === n, split = i < n && res.hops[i] && res.hops[i].split;
    boxes.push(f.slab(xs[i], yN, NODE_W, NODE_H, { text: nodeName(i, n), fill: isHost ? '#fff' : C.soft, fs: 8.6, bold: true }));
    if (split) f.text(xs[i] + NODE_W / 2, yN - 0.2, i === 0 ? '✂ fragments' : '✂ again', { fs: 7.4, bold: true, color: '#9A6500' });
    if (!res.ok && res.dropAt === i) f.text(xs[i] + NODE_W / 2, yN - 0.2, i === 0 ? '✗ won\'t send' : '✗ drops it', { fs: 7.4, bold: true, color: C.bad });
  }
  if (opt.icmp && !res.ok && res.dropAt > 0) {
    var yI = yN + NODE_H + 0.62;
    f.arrow(xs[res.dropAt] + NODE_W / 2, yI, xs[0] + NODE_W / 2, yI, { color: C.bad, lw: 1.4, dash: [4, 3] });
    f.line(xs[res.dropAt] + NODE_W / 2, yN + NODE_H, xs[res.dropAt] + NODE_W / 2, yI, { color: C.bad, lw: 1.4, dash: [4, 3] });
    f.text(xs[0] + NODE_W / 2, yI + 0.3, 'ICMP: fragmentation needed, MTU ' + res.mtu, { fs: 7.4, bold: true, color: C.bad, ha: 'left' });
  }
  // lanes: the fragments on each link, drawn to scale
  var lanes = [];
  for (i = 0; i < n; i++) {
    var c0 = xs[i] + NODE_W / 2 + 0.08, c1 = xs[i + 1] + NODE_W / 2 - 0.08, cw = c1 - c0;
    if (i > 0) f.line(xs[i] + NODE_W / 2, 0.1, xs[i] + NODE_W / 2, laneTop - 0.1, { color: '#D3E3EC', lw: 0.8 });
    var hop = res.hops[i];
    if (!hop) { if (!res.ok && res.dropAt === i) f.text((c0 + c1) / 2, laneTop - 0.3, i === 0 ? 'nothing is sent' : 'nothing crosses', { fs: 7.6, italic: true, color: C.bad }); lanes.push(null); continue; }
    var whole = hop.frags.length === 1 && !hop.frags[0].mf && hop.frags[0].off === 0;
    f.text((c0 + c1) / 2, laneTop - 0.08, whole ? 'whole datagram' : hop.frags.length + ' fragments', { fs: 7.8, bold: true, color: C.navy });
    var lane = [], lfs = cw < 2.4 ? 6.6 : 7.2;
    hop.frags.slice(0, ROWS).forEach(function (fr, j) {
      var y = laneTop - 0.45 - j * rowH, tw = totalLen(fr) / maxT * (cw - 0.05), hw = Math.max(0.04, HDR / maxT * (cw - 0.05));
      if (j === ROWS - 1 && hop.frags.length > ROWS) { f.text(c0, y + 0.08, '+ ' + (hop.frags.length - ROWS + 1) + ' more', { fs: 7.4, ha: 'left', italic: true, color: C.muted }); return; }
      f.rect(c0, y, hw, 0.2, { fill: C.navy, stroke: C.navy, lw: 0.6 });
      f.rect(c0 + hw, y, Math.max(0.02, tw - hw), 0.2, { fill: C.panel, stroke: C.brand, lw: 0.9 });
      f.text(c0, y - 0.15, 'Off ' + offField(fr) + ' · ' + fr.len + ' B · M ' + (fr.mf ? 1 : 0), { fs: lfs, ha: 'left', color: C.ink });
      lane.push(fr);
    });
    lanes.push(lane);
  }
  var layer = f.g();
  return { f: f, xs: xs, cy: cy, yI: yN + NODE_H + 0.62, boxes: boxes, layer: layer, n: n };
}
/* move one chip along a link */
function moveChip(stage, x0, x1, y, label, opt, tok, alive) {
  opt = opt || {};
  return new Promise(function (resolve) {
    if (!stage || !alive(tok)) { resolve(); return; }
    var f = stage.f, g = el('g', null, stage.layer), w = Math.max(0.42, label.length * 0.075 + 0.16), h = 0.26;
    el('rect', { x: r4(-w / 2), y: r4(-h / 2), width: r4(w), height: h, rx: 0.06, fill: opt.fill || '#fff', stroke: opt.stroke || C.brand, 'stroke-width': f.pt(1.6) }, g);
    var t = el('text', { 'font-size': r4(7.4 * f.k / 72), 'text-anchor': 'middle', y: r4(7.4 * f.k / 72 * 0.35), fill: C.ink, 'font-weight': 'bold' }, g); t.textContent = label;
    var X0 = f.X(x0), X1 = f.X(x1), Y = f.Y(y);
    function place(u) { g.setAttribute('transform', 'translate(' + r4(X0 + (X1 - X0) * u) + ',' + Y + ')'); }
    if (reduceMotion) { place(1); setTimeout(function () { if (g.parentNode) g.parentNode.removeChild(g); resolve(); }, 250); return; }
    var dur = (opt.dur || 900), t0 = null;
    function frame(now) {
      if (t0 === null) t0 = now;
      if (!alive(tok)) { if (g.parentNode) g.parentNode.removeChild(g); resolve(); return; }
      var u = Math.min(1, (now - t0) / dur); place(u);
      if (u < 1) requestAnimationFrame(frame); else setTimeout(function () { if (!opt.keep && g.parentNode) g.parentNode.removeChild(g); resolve(g); }, 90);
    }
    place(0); requestAnimationFrame(frame);
  });
}
function flashNode(stage, i, color) {
  if (!stage || !stage.boxes[i]) return;
  var r = stage.boxes[i].box, old = r.getAttribute('fill'); r.setAttribute('fill', color || C.amber);
  setTimeout(function () { r.setAttribute('fill', old); }, reduceMotion ? 300 : 600);
}
/* animate a whole send: link by link, each fragment as a chip */
function animatePath(stage, res, speed, tok, alive, onStep) {
  var chain = Promise.resolve(), n = stage.n;
  res.hops.forEach(function (hop, i) {
    chain = chain.then(function () {
      if (!alive(tok)) return;
      if (hop.split) flashNode(stage, i);
      if (onStep) onStep(i, hop);
      var xa = stage.xs[i] + NODE_W, xb = stage.xs[i + 1], legs = [];
      var list = hop.frags.slice(0, 8);
      list.forEach(function (fr, j) {
        legs.push(sleep(reduceMotion ? 0 : j * 260 / speed).then(function () { return moveChip(stage, xa, xb, stage.cy - 0.22 - (j % 2) * 0.0, String(fr.len), { dur: 950 / speed }, tok, alive); }));
      });
      return Promise.all(legs).then(function () { flashNode(stage, i + 1, i + 1 === n ? C.ok : C.amber); });
    });
  });
  if (!res.ok) chain = chain.then(function () {
    if (!alive(tok)) return;
    var i = res.dropAt; flashNode(stage, i, C.bad);
    if (onStep) onStep(i, null);
    if (i > 0) return moveChip(stage, stage.xs[i] + NODE_W / 2, stage.xs[0] + NODE_W / 2 + 0.3, stage.yI, 'ICMP', { fill: '#FDE8E9', stroke: C.bad, dur: 900 / speed }, tok, alive);
  });
  return chain;
}

/* ===================================================== figure: the reassembly buffer (lesson 5) */
function drawBuffer(svg, frags, got, data, knownTotal, lost) {
  var f = new Fig(svg, 0, 11, 0, 2.5, 2.0), L0 = 1.5, L1 = 10.6, X = function (b) { return L0 + b / data * (L1 - L0); }, y = 1.25;
  f.text(L0 - 0.1, y + 0.25, 'Buffer', { fs: 8.2, ha: 'right', bold: true, color: C.navy });
  f.rect(X(0), y, X(data) - X(0), 0.5, { fill: '#fff', stroke: '#9DB3C1', lw: 1, dash: [3, 2] });
  frags.forEach(function (fr, i) {
    var col = CAT[i % CAT.length], have = got.indexOf(i) >= 0, x0 = X(fr.off), w = X(fr.off + fr.len) - x0;
    if (have) f.rect(x0, y, w, 0.5, { fill: col.fill, stroke: col.line, lw: 1.4 });
    else if (lost === i) f.rect(x0, y, w, 0.5, { fill: '#FDE8E9', stroke: C.bad, lw: 1.2, dash: [3, 2] });
    var lab = have ? '#' + (i + 1) : lost === i ? 'lost' : '?';
    if (w > 0.35) f.text(x0 + w / 2, y + 0.25, lab, { fs: 8.2, bold: true, color: have ? C.ink : lost === i ? C.bad : C.muted });
    f.line(x0, y - 0.05, x0, y + 0.55, { color: '#B9CCD7', lw: 0.7 });
    f.text(x0, y - 0.17, String(offField(fr)), { fs: 7.3, color: C.muted });
  });
  f.text(L0 - 0.1, y - 0.17, 'Offset', { fs: 7.3, ha: 'right', color: C.muted, italic: true });
  f.text(0.1, 2.25, knownTotal ? 'Size known: ' + fmt(data) + ' bytes (from the fragment with M = 0)' : 'Size not known yet: it comes with the last fragment (M = 0)', { fs: 8, ha: 'left', bold: true, color: knownTotal ? C.ok : '#9A6500' });
  if (knownTotal) f.line(X(data), y - 0.1, X(data), y + 0.62, { color: C.ok, lw: 2.2 });
  var have = 0; got.forEach(function (i) { have += frags[i].len; });
  f.text(0.1, 0.3, 'Received ' + fmt(have) + ' of ' + (knownTotal ? fmt(data) : '?') + ' data bytes in ' + got.length + ' fragment' + (got.length === 1 ? '' : 's'), { fs: 8, ha: 'left', color: C.ink });
  return f;
}

/* ===================================================== ping output, as Linux iputils ping and Windows ping print it
   The path: Host A 192.168.1.10, link k is 192.168.k.0/24, router Rk answers from its address on link k, Host B is .20 on the last link. */
function routerAddr(k) { return k === 1 ? '192.168.1.1' : '192.168.' + k + '.2'; }
function destAddr(n) { return '192.168.' + n + '.20'; }
function msTime(s) { return (0.35 + ((s * 37) % 23) / 100).toFixed(3); }
/* mode: 'want' (Linux default), 'do' (-M do), 'dont' (-M dont); 'win' (Windows default), 'winf' (Windows -f) */
function pingRun(mode, payload, mtus, count, dest) {
  var n = mtus.length, total = payload + 28, data = payload + 8, lines = [], ttl = 64 - (n - 1), win = mode === 'win' || mode === 'winf';
  dest = dest || destAddr(n); count = count || 3;
  var pmtu = mtus[0], locked = false, received = 0, attempts = [];
  lines.push(win ? { t: 'Pinging ' + dest + ' with ' + payload + ' bytes of data:' } : { t: 'PING ' + dest + ' (' + dest + ') ' + payload + '(' + total + ') bytes of data.' });
  for (var s = 1; s <= count; s++) {
    var df, local = false;
    if (mode === 'do' || mode === 'winf') { df = true; if (total > pmtu) local = true; }
    else if (mode === 'want') { df = !locked && total <= pmtu; }
    else df = false;
    if (local) {
      lines.push(win ? { t: 'Packet needs to be fragmented but DF set.', c: 'e' } : { t: 'ping: local error: message too long, mtu=' + pmtu, c: 'e' });
      attempts.push({ seq: s, local: true, df: true, res: { hops: [], ok: false, dropAt: 0, mtu: pmtu, frags: [{ off: 0, len: data, mf: false }] } });
      continue;
    }
    // with DF clear the source fragments to the MTU it knows (its link, or a smaller learned path MTU); routers fragment further
    var path = [Math.min(mtus[0], pmtu)].concat(mtus.slice(1));
    var res = sendPath(data, path, df);
    attempts.push({ seq: s, df: df, res: res });
    if (res.ok) { received++; lines.push(win ? { t: 'Reply from ' + dest + ': bytes=' + payload + ' time<1ms TTL=' + ttl, c: 'g' } : { t: data + ' bytes from ' + dest + ': icmp_seq=' + s + ' ttl=' + ttl + ' time=' + msTime(s) + ' ms', c: 'g' }); }
    else {
      var r = routerAddr(res.dropAt);
      lines.push(win ? { t: 'Reply from ' + r + ': Packet needs to be fragmented but DF set.', c: 'e' } : { t: 'From ' + r + ' icmp_seq=' + s + ' Frag needed and DF set (mtu = ' + res.mtu + ')', c: 'e' });
      if (res.mtu < pmtu) { if (!win && res.mtu < LINUX_MIN_PMTU) { pmtu = LINUX_MIN_PMTU; locked = true; } else pmtu = res.mtu; }
    }
  }
  return { lines: lines, received: received, learned: pmtu, attempts: attempts };
}
function termHTML(lines) { return lines.map(function (l) { return '<span class="' + (l.c || '') + '">' + esc(l.t) + '</span>'; }).join('\n'); }

/* ===================================================== commands panel */
var cmdState = { os: 'linux', ifL: 'eth0', ifW: 'Ethernet', dest: '192.168.2.20' };
function renderCommands(box, o) {
  if (o.dest && !cmdState.destEdited) cmdState.dest = o.dest;
  var L = cmdState.ifL, W = cmdState.ifW, D = cmdState.dest, N = o.payload, M = o.mtu || 1400;
  var sets = {
    linux: [
      ['See your interface and its MTU', 'ip link show dev ' + L],
      ['Send 3 pings with a ' + N + '-byte payload (an IP datagram of ' + (N + 28) + ' bytes). If the datagram is bigger than your link, Linux fragments it at the source.', 'ping -c 3 -s ' + N + ' ' + D],
      ['Set DF and never fragment. If it is too big, ping prints the MTU that stopped it.', 'ping -c 3 -M do -s ' + N + ' ' + D],
      ['Clear DF, so routers may fragment', 'ping -c 3 -M dont -s ' + N + ' ' + D],
      ['Find the path MTU, router by router', 'tracepath -n ' + D],
      ['See the path MTU your host has learned for this destination', 'ip route get ' + D],
      ['Make your link\'s MTU smaller to test (lasts until a restart)', 'sudo ip link set dev ' + L + ' mtu ' + M],
      ['Undo: put the MTU back to 1500', 'sudo ip link set dev ' + L + ' mtu 1500'],
      ['Forget every path MTU your host has learned', 'sudo ip route flush cache']
    ],
    win: [
      ['See the MTU of every adapter', 'netsh interface ipv4 show subinterfaces'],
      ['Send 3 pings with a ' + N + '-byte payload. Windows sends them with DF clear, so routers may fragment.', 'ping -n 3 -l ' + N + ' ' + D],
      ['Set DF. If it is too big, Windows prints "Packet needs to be fragmented but DF set."', 'ping -n 3 -f -l ' + N + ' ' + D],
      ['Make the adapter\'s MTU smaller to test (Command Prompt as administrator, lasts until a restart)', 'netsh interface ipv4 set subinterface "' + W + '" mtu=' + M + ' store=active'],
      ['Undo: put the MTU back to 1500', 'netsh interface ipv4 set subinterface "' + W + '" mtu=1500 store=active']
    ],
    ws: [
      ['Show only fragments: More fragments is set, or the offset is above 0', 'ip.flags.mf == 1 || ip.frag_offset > 0'],
      ['Show packets that have DF set', 'ip.flags.df == 1'],
      ['Show the routers\' "fragmentation needed" messages (ICMP type 3, code 4)', 'icmp.type == 3 && icmp.code == 4'],
      ['Find one fragment by its Offset field. The filter counts 8-byte units: 185 means byte 1480.', 'ip.frag_offset == 185']
    ]
  };
  var notes = {
    linux: 'Linux ping sets DF by default. When a router answers "Frag needed", Linux remembers that MTU for the destination and fragments later pings itself. ip link set needs the interface name from ip link show.',
    win: 'Windows has no tracepath. To find a path MTU, lower the ping -f -l size until replies come back; the path MTU is that size plus 28. Find the adapter name with netsh interface ipv4 show subinterfaces.',
    ws: 'In the packet details, Wireshark shows "Fragment Offset" in bytes (1480), but the filter field counts 8-byte units (185). Wireshark also puts each datagram back together and lists its fragments, for example [3 IPv4 Fragments (2980 bytes)].'
  };
  var rows = sets[cmdState.os];
  box.innerHTML = '<div class="cmdtabs" role="group" aria-label="Tool"><button data-os="linux" aria-pressed="' + (cmdState.os === 'linux') + '">Linux</button><button data-os="win" aria-pressed="' + (cmdState.os === 'win') + '">Windows</button><button data-os="ws" aria-pressed="' + (cmdState.os === 'ws') + '">Wireshark filters</button></div>' +
    (cmdState.os === 'ws' ? '' : '<div class="row"><label>Interface name <input type="text" class="ifname" size="12" value="' + esc(cmdState.os === 'linux' ? L : W) + '" spellcheck="false"></label><label>Destination <input type="text" class="dest" size="15" value="' + esc(D) + '" spellcheck="false"></label></div>') +
    rows.map(function (r) { return '<p class="cmdnote" style="margin-top:8px">' + esc(r[0]) + '</p><div class="cmd"><code>' + esc(r[1]) + '</code><button type="button" data-copy="' + esc(r[1]) + '">Copy</button></div>'; }).join('') +
    '<p class="cmdnote" style="margin-top:10px">' + esc(notes[cmdState.os]) + '</p>';
  $$('[data-os]', box).forEach(function (b) { b.onclick = function () { cmdState.os = b.getAttribute('data-os'); renderCommands(box, o); }; });
  if ($('.ifname', box)) $('.ifname', box).onchange = function () { var v = this.value.trim() || (cmdState.os === 'linux' ? 'eth0' : 'Ethernet'); if (cmdState.os === 'linux') cmdState.ifL = v; else cmdState.ifW = v; renderCommands(box, o); };
  if ($('.dest', box)) $('.dest', box).onchange = function () { var v = this.value.trim(); if (/^[\w.:-]{1,60}$/.test(v)) { cmdState.dest = v; cmdState.destEdited = true; } renderCommands(box, o); };
  $$('[data-copy]', box).forEach(function (b) { b.onclick = function () { copyText(b.getAttribute('data-copy'), b); }; });
}
function copyText(t, btn) {
  function done(ok) { var o = btn.textContent; btn.textContent = ok ? 'Copied' : 'Select it'; setTimeout(function () { btn.textContent = o; }, 1200); }
  try { if (navigator.clipboard && window.isSecureContext) { navigator.clipboard.writeText(t).then(function () { done(true); }, function () { fallback(); }); return; } } catch (e) { /* fall through */ }
  fallback();
  function fallback() { var ta = document.createElement('textarea'); ta.value = t; ta.style.position = 'fixed'; ta.style.opacity = '0'; document.body.appendChild(ta); ta.select(); var ok = false; try { ok = document.execCommand('copy'); } catch (e) { ok = false; } document.body.removeChild(ta); done(ok); }
}
/* fragment cards (calculator and lessons) */
function fragCards(frags, ident) {
  return frags.map(function (fr, i) {
    var col = CAT[i % CAT.length];
    return '<div class="fcard" style="border-left-color:' + col.line + '"><b>Fragment ' + (i + 1) + '</b><div class="m">Ident ' + hex4(ident) + ' · M ' + (fr.mf ? 1 : 0) + '<br>Offset ' + offField(fr) + ' (' + fmt(fr.off) + ' bytes)<br>Total Length ' + fmt(totalLen(fr)) + '<br>data bytes ' + fmt(fr.off) + '–' + fmt(fr.off + fr.len - 1) + ' (' + fmt(fr.len) + ')</div></div>';
  }).join('');
}

/* ===================================================== points */
var progress = store.get('progress', { xp: 0, lessons: {}, badges: {}, best: {} });
function addXP(n) { progress.xp += n; store.set('progress', progress); showXP(true); }
function showXP(pop) { var e = $('#xp'); e.textContent = '★ ' + progress.xp + ' points'; if (pop && !reduceMotion) { e.classList.remove('pop'); void e.offsetWidth; e.classList.add('pop'); } }
