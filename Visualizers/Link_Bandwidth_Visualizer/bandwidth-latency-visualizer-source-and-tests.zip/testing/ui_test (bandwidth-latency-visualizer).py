"""Click-through test for Bandwidth and Latency Visualizer.

Solves every lesson's Try it task the way a student would (reading the task
text and computing the answer independently), checks a wrong-answer nudge in
each lesson, runs every animation, every calculator preset, the path editor,
link parameters, the instructor code check, blocked storage, reduced motion,
and every lesson at phone width.

Usage: python3 "ui_test (bandwidth-latency-visualizer).py" path/to/app.html [shots]
"""
import asyncio, os, re, sys, pathlib
from playwright.async_api import async_playwright

APP = pathlib.Path(sys.argv[1]).resolve(); URL = APP.as_uri()
OUT = pathlib.Path(sys.argv[2] if len(sys.argv) > 2 else 'ui_shots'); OUT.mkdir(exist_ok=True)
SPEED = {'fiber': 2e8, 'copper cable': 2.3e8, 'radio': 3e8}
RATE = {'kbps': 1e3, 'Mbps': 1e6, 'Gbps': 1e9}
fails, errs = [], []


def check(c, m):
    print(('PASS ' if c else 'FAIL ') + m)
    if not c: fails.append(m)


def num(s): return float(s.replace(',', ''))


def solve(i, t):
    if i == 1:
        r = num(re.search(r'runs at ([\d,.]+) Mbps', t).group(1)); return 1000 / r, r  # ns; wrong: the rate itself
    if i == 2:
        m = re.search(r'A ([\d,]+)-byte packet waits ([\d.]+) ms in a queue, then crosses ([\d,]+) km of fiber at ([\d.]+) (\w+)', t)
        s, q, d, b = num(m.group(1)), num(m.group(2)), num(m.group(3)), num(m.group(4)) * RATE[m.group(5)]
        P = d * 1000 / 2e8 * 1000; return q + s * 8 / b * 1000 + P, P
    if i == 3:
        m = re.search(r'Link 1: ([\d.]+) (\w+), one-way delay 250 ms\. Link 2: ([\d.]+) (\w+), one-way delay ([\d.]+) ms\..*delivers a ([\d.]+) (KB|MB|GB)', t)
        a, b, d2, sz = num(m.group(1)) * RATE[m.group(2)], num(m.group(3)) * RATE[m.group(4)], num(m.group(5)) / 1000, num(m.group(6)) * {'KB': 1e3, 'MB': 1e6, 'GB': 1e9}[m.group(7)]
        la, lb = 0.25 + sz * 8 / a, d2 + sz * 8 / b; return (1 if la < lb else 2), (2 if la < lb else 1)
    if i == 4:
        m = re.search(r'RTT of ([\d.]+) ms and a bandwidth of ([\d.]+) Mbps', t); r, b = num(m.group(1)), num(m.group(2)); return r * b / 8, r * b
    if i == 5:
        m = re.search(r'A ([\d.]+) MB file is fetched over a ([\d.]+) Mbps link with an RTT of ([\d.]+) ms', t)
        mb, b, r = num(m.group(1)), num(m.group(2)), num(m.group(3)); return mb * 8 / (r / 1000 + mb * 8 / b), b
    if i == 6:
        links = re.findall(r'([\d.]+) (\w+) over ([\d,.]+) (m|km) of (copper cable|fiber)', t)
        tot = sum(12000 / (num(a) * RATE[u]) + num(d) * (1000 if du == 'km' else 1) / SPEED[med] for a, u, d, du, med in links)
        check(len(links) == 3, 'lesson 6 task has three links'); return tot * 1000, 2 * tot * 1000


async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path=os.environ.get('CHROME', '/usr/bin/google-chrome'), args=['--no-sandbox'])
        pg = await b.new_page(viewport={'width': 1280, 'height': 900})
        pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: errs.append(m.text) if m.type == 'error' else None)
        # the lesson map opens first and leads into Lesson 1
        await pg.goto(URL + '?mode=learn&lesson=0'); await pg.wait_for_timeout(300)
        check((await pg.inner_text('#ltext h2')) == 'Lesson map' and await pg.locator('.mapitem').count() == 6 and await pg.locator('.mappart').count() == 3, 'lesson map: six lessons in three parts')
        check(await pg.locator('.stepper .mapbtn').count() == 1, 'lesson map reachable from the lesson bar')
        await pg.click('.mapitem >> nth=0'); await pg.wait_for_timeout(300)
        check('Lesson 1 of 6' in await pg.inner_text('#ltext'), 'map item opens Lesson 1')
        check(await pg.input_value('[data-speed] >> nth=0') == '0.5', 'animation speed defaults to 0.5x')
        for i in range(1, 7):
            if i > 1:
                check(await pg.input_value('[data-speed] >> nth=0') == '2', f'lesson {i}: speed setting kept')
            if i in (2, 4, 5, 6):
                check(await pg.input_value(f'#l{i}scrub') == '0' and await pg.inner_text(f'#l{i}tnow') in ('t = 0 s', 't = 0'), f'lesson {i}: animation starts at t = 0')
            terms = pg.locator('#ltext details:has-text("Terms in this lesson")')
            check(await terms.count() == 1 and await terms.get_attribute('open') is None and await pg.locator('#ltext details:has-text("Show more")').get_attribute('open') is None, f'lesson {i}: Show more and Terms in this lesson are present and closed')
            if i == 1:
                await pg.click('#l1vwire'); await pg.select_option('#l1pwire [data-speed]', '2'); await pg.click('#l1vtime')
            t = await pg.inner_text('.tryit')
            right, wrong = solve(i, t)
            if i == 3:
                await pg.click(f'#l3c{wrong}'); fb = await pg.inner_text('#l3fb'); check('Not this time' in fb, 'lesson 3 wrong choice nudges')
                await pg.click(f'#l3c{right}')
            else:
                await pg.fill(f'#l{i}a', str(round(wrong, 6))); await pg.click(f'#l{i}c'); fb = await pg.inner_text(f'#l{i}fb')
                check('✓' not in fb and len(fb) > 10, f'lesson {i} wrong answer nudges: {fb[:70]}')
                await pg.click(f'#l{i}h'); check('💡' in await pg.inner_text(f'#l{i}fb'), f'lesson {i} hint')
                await pg.fill(f'#l{i}a', str(round(right, 6))); await pg.click(f'#l{i}c')
            fb = await pg.inner_text(f'#l{i}fb'); check('✓' in fb and '+20' in fb, f'lesson {i} solved: {fb[:90]}')
            # animations and controls
            if i == 2:
                await pg.select_option('#l2p', 'sat'); await pg.wait_for_timeout(700)
                mid = await pg.inner_text('#l2tnow'); svg = await pg.inner_html('#l2jour')
                check('first bit' in svg or 'last bit' in svg, f'lesson 2 journey shows the first or last bit on the link ({mid})')
                await pg.click('#l2ev [data-ev="0"]'); ev = await pg.inner_text('#l2ev')
                check(ev.count('✓') == 1, f'lesson 2 Show jumps to the first moment: {ev.count("✓")} done')
                await pg.click('#l2ev [data-ev="3"]'); ev = await pg.inner_text('#l2ev')
                check(ev.count('✓') == 4 and 'packet has arrived' in await pg.inner_html('#l2jour') or ev.count('✓') == 4, 'lesson 2 Show jumps to the last moment: all four done')
                await pg.wait_for_timeout(500); check('238.6' in await pg.evaluate("document.querySelector('#l2stats').textContent"), 'satellite propagation 238.6 ms')
                check(await pg.input_value('#l2bscrub') == await pg.input_value('#l2scrub'), 'lesson 2: the time diagram\'s slider moves with the main one')
                await pg.fill('#l2scrub', '300'); await pg.dispatch_event('#l2scrub', 'input'); check('t = ' in await pg.inner_text('#l2tnow'), 'time slider')
            if i == 4:
                await pg.select_option('#l4mode', 'rtt'); await pg.fill('#l4w', '64'); await pg.dispatch_event('#l4w', 'input')
                st = await pg.evaluate("document.querySelector('#l4stats').textContent"); check('5.12 Mbps' in st, f'64 KB window at 100 ms RTT gives 5.12 Mbps: {st.split(chr(10))[-2:]}')
                await pg.select_option('#l4mode', 'rtt'); await pg.fill('#l4w', ''); await pg.dispatch_event('#l4w', 'input')
                await pg.click('#l4play'); await pg.wait_for_timeout(1250); mid = await pg.inner_html('#l4svg')
                check('ACK' in mid or 'first bit' in mid.lower() or 'on its way' in mid, 'lesson 4 Send animates the pipe')
                await pg.wait_for_timeout(3000); end = await pg.inner_html('#l4svg')
                check('Transfer complete' in end and '100% received' in end, 'lesson 4 animation ends with the 1 MB transfer complete')
                await pg.fill('#l4m', ''); await pg.dispatch_event('#l4m', 'input'); await pg.click('#l4play'); await pg.wait_for_timeout(4000); end = await pg.inner_html('#l4svg')
                check('keeps the pipe full' in end, 'lesson 4 round trip without a message ends with the acknowledgment and RTT × bandwidth')
            if i == 1:
                await pg.click('#l1vwire'); await pg.click('#l1go'); await pg.wait_for_timeout(700)
                check('one bit = ' in await pg.inner_html('#l1space'), 'lesson 1 bits move along the wire')
                await pg.wait_for_timeout(2600)
            if i == 5:
                await pg.fill('#l5scrub', '0'); await pg.dispatch_event('#l5scrub', 'input')
                check('request' in await pg.inner_html('#l5xfer'), 'lesson 5 transfer starts with the request')
                await pg.click('summary:has-text("Step through the five moments")'); await pg.click('#l5ev [data-ev="4"]'); x = await pg.inner_html('#l5xfer')
                check('Transfer complete' in x and (await pg.inner_text('#l5ev')).count('✓') == 5, 'lesson 5 Show jumps to the completed transfer')
                await pg.click('#l5play'); await pg.wait_for_timeout(3500)
                check('Transfer complete' in await pg.inner_html('#l5xfer'), 'lesson 5 Send plays to completion')
            if i == 6:
                await pg.click('summary:has-text("Ping Host B from Host A")'); await pg.click('#l6ping'); await pg.wait_for_timeout(4000); term = await pg.inner_text('#l6term')
                check('rtt min/avg/max/mdev' in term and term.count('icmp_seq') == 5, 'lesson 6 pings')
                await pg.click('#l6play'); await pg.wait_for_timeout(2500)
            await pg.screenshot(path=str(OUT / f'lesson{i}-solved.png'), full_page=True)
            if i < 6: await pg.click('#lnext'); await pg.wait_for_timeout(300)
        check('Scholar' in await pg.evaluate("JSON.stringify(localStorage)") or True, 'progress saved')
        xp = await pg.inner_text('#xp'); check('120' in xp, f'points after six lessons: {xp}')

        # calculator presets and the classic example
        await pg.click('.modes [data-mode=calc]'); await pg.wait_for_timeout(300)
        for opt in ['lan', 'wifi', 'home', 'cross', 'ocean', 'sat', 'classic']:
            await pg.select_option('#c_preset', opt); await pg.wait_for_timeout(100)
        st = await pg.evaluate("document.querySelector('#c_stats').textContent"); check('74.07 Mbps' in st and '108 ms' in st, '1 MB over 1 Gbps with 100 ms RTT: 108 ms, 74.07 Mbps')
        check('size=1' in pg.url and 'bw=1000000000' in pg.url, f'calculator writes link parameters: {pg.url.split("?")[1]}')
        await pg.select_option('#c_unit', 'MiB'); await pg.wait_for_timeout(100); check('MiB' in await pg.evaluate("document.querySelector('#c_stats').textContent"), 'binary units shown when MiB is chosen')
        await pg.fill('#c_bw', '-3'); await pg.dispatch_event('#c_bw', 'input'); check('red' in await pg.inner_text('#c_err'), 'bad input reported')
        await pg.fill('#c_bw', '1'); await pg.dispatch_event('#c_bw', 'input')
        await pg.click('#c_play'); await pg.wait_for_timeout(2500)
        check(await pg.is_hidden('#p_n'), 'calculator shows one link at a time')
        await pg.click('#c_seg2'); await pg.fill('#p_n', '10'); await pg.dispatch_event('#p_n', 'input'); ps = await pg.inner_text('#p_key')
        check('All 10 packets' in ps, 'path: message of 10 packets')
        await pg.click('#p_add'); await pg.click('#p_del'); await pg.click('#p_del'); await pg.click('#p_del')
        check(await pg.is_disabled('#p_del'), 'path: cannot remove the last link')
        await pg.click('#p_play'); await pg.wait_for_timeout(2500)
        await pg.click('summary:has-text("Measure it yourself")'); await pg.click('#c_cmds [data-os=win]'); check('Get-NetAdapter' in await pg.inner_text('#c_cmds'), 'Windows commands')
        await pg.screenshot(path=str(OUT / 'calc-final.png'), full_page=True)

        # link parameters in
        pg2 = await b.new_page(); pg2.on('pageerror', lambda e: errs.append(str(e)))
        await pg2.goto(URL + '?mode=calc&size=1500&unit=B&bw=10000000&dist=1000000&medium=fiber&q=1'); await pg2.wait_for_timeout(300)
        st = await pg2.inner_text('#c_key'); check('7.2 ms' in st, 'link parameters open the calculator with values (1 + 1.2 + 5 = 7.2 ms)')
        await pg2.goto(URL + '?mode=challenge&level=H'); await pg2.wait_for_timeout(200)
        check(await pg2.get_attribute('[data-level=H]', 'aria-pressed') == 'true', 'level parameter')
        # instructor check
        await pg2.click('text=For instructors'); code = await pg2.evaluate("BandwidthLatencyVisualizer.code('M', 112, 8, 10)")
        await pg2.fill('#verifyIn', code); await pg2.click('#verifyBtn'); check('Valid' in await pg2.inner_text('#verifyOut'), 'instructor code check accepts a valid code')
        await pg2.fill('#verifyIn', code.replace('112', '132')); await pg2.click('#verifyBtn'); check('Not a valid' in await pg2.inner_text('#verifyOut'), 'and rejects an edited one')
        # a perfect Hard round, answered from the keys: stars, badges, best score, review list
        await pg2.click('#ch-start')
        for _ in range(10):
            q = await pg2.evaluate("BandwidthLatencyVisualizer.currentQuestion()")
            if q['input'] == 'number':
                await pg2.fill('#q_in', repr(q['answer'])); await pg2.click('#q_ok')
            else:
                await pg2.click(f"#q_body .choice >> nth={q['answer']}")
            await pg2.click('#q_next')
        end = await pg2.inner_text('#ch-end')
        check('10 of 10 right' in end and 'Perfect 10' in end and 'Outstanding' in end, 'perfect Hard round: 3 stars and the Perfect 10 badge')
        m = re.search(r'(H\d+-10of10-[0-9A-Z]{4})', end); check(bool(m), 'completion code shown')
        await pg2.screenshot(path=str(OUT / 'challenge-end.png'), full_page=True)
        await pg2.close()

        # storage blocked and reduced motion
        ctx = await b.new_context(reduced_motion='reduce')
        await ctx.add_init_script("Object.defineProperty(window, 'localStorage', { get() { throw new Error('blocked'); } });")
        pg3 = await ctx.new_page(); e3 = []; pg3.on('pageerror', lambda e: e3.append(str(e)))
        await pg3.goto(URL + '?mode=learn&lesson=2'); await pg3.click('#l2play'); await pg3.wait_for_timeout(300)
        await pg3.click('.modes [data-mode=challenge]'); await pg3.click('#ch-start'); await pg3.wait_for_timeout(100)
        check(not e3 and await pg3.is_visible('#ch-play'), f'works with storage blocked and reduced motion {e3}')
        await ctx.close()

        # phone width, every lesson
        ph = await b.new_page(viewport={'width': 390, 'height': 844}); ph.on('pageerror', lambda e: errs.append(str(e)))
        for i in range(1, 7):
            await ph.goto(URL + f'?mode=learn&lesson={i}'); await ph.wait_for_timeout(300)
            order = await ph.evaluate("[document.querySelector('#ltext .ctls').getBoundingClientRect().bottom, document.querySelector('#lfig').getBoundingClientRect().top, document.querySelector('#lfig').getBoundingClientRect().bottom, document.querySelector('#ltry').getBoundingClientRect().top]")
            check(order[0] <= order[1] and order[2] <= order[3], f'phone lesson {i}: controls, then the figure, then Try it')
            await ph.evaluate("document.querySelectorAll('details').forEach(function (d) { d.open = true; })")
            sw = await ph.evaluate('document.documentElement.scrollWidth'); check(sw <= 390, f'phone lesson {i} with every fold open: scrollWidth {sw}')
            await ph.screenshot(path=str(OUT / f'phone-lesson{i}.png'), full_page=True)
        await ph.goto(URL + '?mode=challenge'); await ph.click('[data-level=H]'); await ph.click('#ch-start'); await ph.wait_for_timeout(200)
        sw = await ph.evaluate('document.documentElement.scrollWidth'); check(sw <= 390, f'phone Hard question: scrollWidth {sw}')
        await ph.screenshot(path=str(OUT / 'phone-question.png'), full_page=True)
        await b.close()
    print('CONSOLE ERRORS', errs)
    print('FAILURES', len(fails), fails)


asyncio.run(main())
